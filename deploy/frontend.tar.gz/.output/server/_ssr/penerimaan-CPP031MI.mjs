import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { a as useTenantStore, i as useAuthStore, o as useUserStore, r as cn } from "./authStore-CZRDvP0Z.mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-YtzMxdp3.mjs";
import { t as Input } from "./input-BBQFjwfK.mjs";
import { i as useSettingsStore } from "./settingsStore-BBOTJBY5.mjs";
import { $ as Layers, Ct as CreditCard, Dt as Clock, Gt as Boxes, M as Receipt, Mt as CircleAlert, N as Printer, O as Search, Ut as Calculator, W as MapPin, Wt as Building2, a as UserPlus, bt as Download, c as Unlink, d as TrendingUp, f as Trash2, jt as CircleCheck, lt as FolderPlus, mt as FileSpreadsheet, r as Users, vt as Eye, w as Share2, y as Sparkles, zt as Check } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-BnDjHZuV.mjs";
import { t as Badge } from "./badge-DeRhpfUp.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, o as formatRp, r as CardDescription, t as Card } from "./card-CfCIYh5x.mjs";
import { t as desaService } from "./desaService-B2uJrXze.mjs";
import { o as useDhkpStore, t as calculateFeeKolektor } from "./penerimaanStore-Dy63tgZo.mjs";
import { t as Label } from "./label-CiVZqe-N.mjs";
import { n as CheckboxIndicator, t as Checkbox$1 } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-HQswfJbV.mjs";
import { r as isDusunAllowed } from "./dusunHelper-BcA75wHe.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-B16iqma3.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-B4v5HtqW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/penerimaan-CPP031MI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ReceiptModal = ({ open, onOpenChange, activeReceiptTrxs, receiptPaperFormat, settings, onTriggerPrint }) => {
	const tenant = useTenantStore();
	if (activeReceiptTrxs.length === 0) return null;
	const firstTrx = activeReceiptTrxs[0];
	const namaDesa = tenant.nama_desa || settings.namaDesa || "DESA";
	const namaKec = tenant.nama_kecamatan || settings.kecamatan || "MALANGBONG";
	const namaKab = tenant.nama_kabupaten || settings.kabupaten || "GARUT";
	const handleShareStruk = () => {
		const totalAmount = activeReceiptTrxs.reduce((sum, t) => sum + t.totalBayar, 0);
		let text = `========================================
SIPABAR - SURAT TANDA TERIMA SETORAN (STTS)
KEC. ${namaKec.toUpperCase()} - DESA ${namaDesa.toUpperCase()}\n========================================\nJumlah NOP   : ${activeReceiptTrxs.length} SPPT\nTanggal      : ${firstTrx.tanggal}\nPetugas      : ${firstTrx.petugas}\nMetode       : ${firstTrx.metode}\n----------------------------------------\n`;
		activeReceiptTrxs.forEach((trx, idx) => {
			text += `${idx + 1}. NOP: ${trx.nop}\n   Nama: ${trx.namaSppt} (Dusun ${trx.dusun})\n   Tagihan: ${formatRp(trx.pokok + (trx.feeKolektor || 0))}\n`;
		});
		text += `----------------------------------------\nTOTAL SETORAN: ${formatRp(totalAmount)}\nSTATUS       : *** LUNAS ***\n========================================\nTerima kasih atas pembayaran PBB-P2 Anda.\nSIPABAR • Sistem Informasi Pajak Barudua`;
		if (navigator.share) navigator.share({
			title: `Bukti Pembayaran STTS PBB-P2 (${activeReceiptTrxs.length} NOP)`,
			text
		}).catch(() => {});
		else {
			navigator.clipboard.writeText(text);
			toast.success("Teks bukti setoran STTS disalin! Membuka WhatsApp...");
			window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-xl bg-slate-950 border-slate-800 text-slate-100 p-6 rounded-2xl shadow-2xl space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
					className: "border-b border-slate-800 pb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center justify-between",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
							className: "text-base font-bold text-slate-100 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5 text-emerald-400" }), " Bukti Pembayaran STTS (LUNAS)"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-xs text-slate-400",
						children: "Bukti setoran resmi PBB-P2 dengan digital Stamp LUNAS & Rincian Kolektif."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "py-4",
					children: receiptPaperFormat === "stts" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "printable-stts bg-white text-slate-950 p-5 rounded-xl border border-slate-300 shadow-md font-sans text-xs space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center border-b border-slate-400 pb-2 space-y-0.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-extrabold text-[11px] tracking-wider uppercase",
										children: ["PEMERINTAH KABUPATEN ", namaKab.toUpperCase()]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-black text-xs tracking-wider uppercase",
										children: [
											"KECAMATAN ",
											namaKec.toUpperCase(),
											" - DESA ",
											namaDesa.toUpperCase()
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-black text-sm text-indigo-950 tracking-wide uppercase mt-1",
										children: "BUKTI PEMBAYARAN PBB-P2 (KOLEKTIF)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[10px] text-slate-600 font-mono",
										children: ["Tgl: ", firstTrx.tanggal]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2 py-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-bold text-[11px] border-b border-slate-200 pb-1",
									children: [
										"RINCIAN SPPT DIBAYAR (",
										activeReceiptTrxs.length,
										" NOP):"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-1.5 max-h-[160px] overflow-y-auto pr-1",
									children: activeReceiptTrxs.map((trx, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between items-center bg-slate-50 p-1.5 rounded border border-slate-200 text-[10px]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "font-bold font-mono text-indigo-900",
											children: [
												idx + 1,
												". ",
												trx.nop
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-slate-700",
											children: [
												trx.namaSppt,
												" • Dusun ",
												trx.dusun
											]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-right",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-bold font-mono",
												children: formatRp(trx.pokok)
											}), trx.feeKolektor > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-amber-700 font-semibold text-[9px]",
												children: ["+Fee: ", formatRp(trx.feeKolektor)]
											})]
										})]
									}, trx.id))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-t border-slate-400 pt-2 flex justify-between items-end",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[10px] text-slate-600 space-y-0.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Petugas Kasir: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-slate-900",
										children: firstTrx.petugas
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Metode Bayar: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-slate-900",
										children: firstTrx.metode
									})] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-right",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] text-slate-500 font-semibold",
										children: "TOTAL SETORAN"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-base font-black font-mono text-emerald-700",
										children: formatRp(activeReceiptTrxs.reduce((sum, t) => sum + t.totalBayar, 0))
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pt-2 border-t border-slate-300 flex justify-between items-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[9px] text-slate-500 italic",
									children: "*Simpan resi ini sebagai tanda bukti setoran pajak yang sah."
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "rounded-lg border-2 border-emerald-600 px-3 py-1 text-center font-black text-emerald-600 tracking-wider text-xs rotate-[-6deg]",
									children: "LUNAS"
								})]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "printable-stts bg-white text-black p-4 rounded-md mx-auto w-[240px] font-mono text-[11px] border border-slate-300 space-y-2 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-extrabold text-xs uppercase",
								children: tenant.nama_desa?.toUpperCase() || (settings.namaDesa ? settings.namaDesa.toUpperCase().startsWith("DESA") ? settings.namaDesa.toUpperCase() : `DESA ${settings.namaDesa.toUpperCase()}` : "DESA")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[10px]",
								children: [
									"PBB-P2 KAB. ",
									settings.kabupaten?.toUpperCase() || "GARUT",
									" (KOLEKTIF)"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[9px]",
								children: "----------------------------"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-left space-y-0.5 text-[10px] uppercase",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["TGL : ", firstTrx.tanggal] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["MET : ", firstTrx.metode] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["OPR : ", firstTrx.petugas] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[9px]",
								children: "----------------------------"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-left space-y-1 text-[9px] uppercase",
								children: activeReceiptTrxs.map((trx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pb-1 border-b border-dashed border-slate-300",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-bold",
											children: trx.nop
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: trx.namaSppt }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "flex justify-between mt-0.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [trx.tahun, " (POKOK+FEE)"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatRp(trx.pokok + (trx.feeKolektor || 0)) })]
										})
									]
								}, trx.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-left space-y-0.5 text-[10px] pt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-bold flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "TOTAL SETORAN :" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatRp(activeReceiptTrxs.reduce((sum, t) => sum + (t.pokok + (t.feeKolektor || 0)), 0)) })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-bold text-[11px] flex justify-between mt-1 pt-1 border-t border-dashed",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "BAYAR :" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatRp(activeReceiptTrxs.reduce((sum, t) => sum + t.totalBayar, 0)) })]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[9px] mt-2",
								children: "----------------------------"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-black text-sm uppercase text-emerald-700",
								children: "*** LUNAS ***"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[8px] text-slate-600 mt-1",
								children: "Simpan resi ini sebagai bukti pembayaran sah PBB-P2."
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
					className: "gap-2 sm:gap-2 flex-wrap sm:flex-nowrap",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => onOpenChange(false),
							className: "border-slate-800 text-slate-300 text-xs",
							children: "Tutup"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: handleShareStruk,
							className: "border-emerald-600/50 text-emerald-400 hover:bg-emerald-950/40 text-xs gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4" }), " Bagikan Struk / WA"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: onTriggerPrint,
							className: "bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), " Cetak Bukti Setoran"]
						})
					]
				})
			]
		})
	});
};
var BatchInspectorModal = ({ open, onOpenChange, inspectBatchTrxs, onOpenReceiptModal }) => {
	if (inspectBatchTrxs.length === 0) return null;
	const firstTrx = inspectBatchTrxs[0];
	const totalPokok = inspectBatchTrxs.reduce((sum, t) => sum + t.pokok, 0);
	const totalFee = inspectBatchTrxs.reduce((sum, t) => sum + t.feeKolektor, 0);
	const totalSetoran = inspectBatchTrxs.reduce((sum, t) => sum + t.totalBayar, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-2xl bg-slate-950 border-slate-800 text-slate-100 p-6 rounded-2xl shadow-2xl space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
					className: "border-b border-slate-800 pb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center justify-between",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
							className: "text-base font-bold text-slate-100 flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "size-5 text-emerald-400" }),
								" Detail Rincian Setoran Kolektif (",
								inspectBatchTrxs.length,
								" SPPT)"
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-xs text-slate-400",
						children: "Rincian seluruh SPPT yang dibayarkan dalam satu transaksi kolektif kasir."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 sm:grid-cols-4 gap-2.5 p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-slate-400 block",
									children: "Wajib Pajak / Kolektor"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold text-slate-200",
									children: firstTrx.namaSppt
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-slate-400 block",
									children: "Tanggal Transaksi"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold text-slate-200",
									children: firstTrx.tanggal
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-slate-400 block",
									children: "Metode Pembayaran"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									className: "text-[10px] border-emerald-500/40 text-emerald-400 mt-0.5",
									children: firstTrx.metode
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-slate-400 block",
									children: "Petugas Kasir"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold text-slate-200",
									children: firstTrx.petugas
								})] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-xl border border-slate-800 overflow-hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full text-left text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "bg-slate-900 text-slate-400 font-bold border-b border-slate-800",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 text-center w-8",
											children: "#"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2",
											children: "NOP & Tahun"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2",
											children: "Lokasi & Dusun"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 text-right",
											children: "Pokok"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 text-right",
											children: "Fee Kolektor"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 text-right",
											children: "Total Setoran"
										})
									] })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
									className: "divide-y divide-slate-800/60 bg-slate-950/50",
									children: inspectBatchTrxs.map((trx, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "hover:bg-slate-900/40",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2 text-center text-slate-500 font-mono",
												children: idx + 1
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
												className: "px-3 py-2 font-mono",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "font-bold text-emerald-400",
													children: trx.nop
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-[10px] text-slate-500",
													children: ["Tahun ", trx.tahun]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
												className: "px-3 py-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "font-medium text-slate-200",
													children: ["Dusun ", trx.dusun]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[10px] text-slate-400",
													children: trx.blok
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2 text-right font-mono",
												children: formatRp(trx.pokok)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2 text-right font-mono text-amber-400",
												children: trx.feeKolektor > 0 ? formatRp(trx.feeKolektor) : "-"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2 text-right font-mono font-bold text-emerald-300",
												children: formatRp(trx.totalBayar)
											})
										]
									}, trx.id))
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between items-center p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs text-slate-300 space-y-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Total Pokok: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono font-bold text-white",
									children: formatRp(totalPokok)
								})] }), totalFee > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Total Fee Kolektor: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono font-bold text-amber-400",
									children: formatRp(totalFee)
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-slate-400 block font-semibold",
									children: "TOTAL BAYAR KOLEKTIF"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-lg font-black font-mono text-emerald-400",
									children: formatRp(totalSetoran)
								})]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
					className: "gap-2 sm:gap-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => onOpenChange(false),
						className: "border-slate-800 text-slate-300 text-xs",
						children: "Tutup"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => {
							onOpenChange(false);
							onOpenReceiptModal(inspectBatchTrxs);
						},
						className: "bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), " Cetak Resi Kolektif"]
					})]
				})
			]
		})
	});
};
var Checkbox = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox$1, {
	ref,
	className: cn("grid place-content-center peer h-4 w-4 shrink-0 rounded-sm border border-primary shadow cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckboxIndicator, {
		className: cn("grid place-content-center text-current"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" })
	})
}));
Checkbox.displayName = Checkbox$1.displayName;
var CustomGroupingModal = ({ open, onOpenChange, availableTrxs, onCreateCustomGroup }) => {
	const [groupName, setGroupName] = (0, import_react.useState)("");
	const [selectedIds, setSelectedIds] = (0, import_react.useState)([]);
	const [searchFilter, setSearchFilter] = (0, import_react.useState)("");
	const filteredTrxs = availableTrxs.filter((t) => {
		if (t.customGroupId || t.batchId) return false;
		if (!searchFilter.trim()) return true;
		const q = searchFilter.toLowerCase();
		return t.nop.toLowerCase().includes(q) || t.namaSppt.toLowerCase().includes(q) || t.dusun.toLowerCase().includes(q);
	});
	const toggleSelect = (id) => {
		setSelectedIds((prev) => prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]);
	};
	const handleCreate = () => {
		if (!groupName.trim() || selectedIds.length < 2) return;
		onCreateCustomGroup(selectedIds, groupName.trim());
		setGroupName("");
		setSelectedIds([]);
		onOpenChange(false);
	};
	const selectedTotalSum = availableTrxs.filter((t) => selectedIds.includes(t.id)).reduce((sum, t) => sum + t.totalBayar, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-xl bg-slate-950 border-slate-800 text-slate-100 p-6 rounded-2xl shadow-2xl space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
					className: "border-b border-slate-800 pb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "text-base font-bold text-slate-100 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5 text-emerald-400" }), " Tambah Pengelompokan Manual (1 KK / Custom)"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-xs text-slate-400",
						children: "Kelompokkan 2 atau lebih transaksi setoran terpisah ke dalam 1 grup keluarga/KK post-payment."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs font-semibold text-slate-300",
								children: "Nama Kelompok / Keluarga (contoh: Kel. H. ASEP MULYANA 1 KK)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: groupName,
								onChange: (e) => setGroupName(e.target.value),
								placeholder: "Masukkan nama pengelompokan...",
								className: "bg-slate-900 border-slate-800 text-xs text-slate-100 placeholder:text-slate-500 focus:border-emerald-500"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-2.5 size-4 text-slate-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: searchFilter,
								onChange: (e) => setSearchFilter(e.target.value),
								placeholder: "Cari NOP, Wajib Pajak, atau Dusun...",
								className: "pl-9 bg-slate-900 border-slate-800 text-xs text-slate-100 placeholder:text-slate-500"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between items-center text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-slate-400 font-semibold",
									children: "Pilih Transaksi Setoran:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-emerald-400 font-bold",
									children: [selectedIds.length, " Terpilih"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "max-h-[220px] overflow-y-auto space-y-1.5 pr-1 custom-scrollbar rounded-xl border border-slate-800 p-2 bg-slate-900/40",
								children: filteredTrxs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-center text-xs text-slate-500 py-6",
									children: "Tidak ada transaksi yang tersedia untuk dikelompokkan."
								}) : filteredTrxs.map((trx) => {
									const isChecked = selectedIds.includes(trx.id);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										onClick: () => toggleSelect(trx.id),
										className: `flex items-center justify-between p-2 rounded-lg border transition-all cursor-pointer ${isChecked ? "bg-emerald-950/40 border-emerald-500/50" : "bg-slate-900/70 border-slate-800 hover:border-slate-700"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
												checked: isChecked,
												onCheckedChange: () => toggleSelect(trx.id)
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-bold text-xs text-slate-200",
												children: trx.namaSppt
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[10px] text-slate-400 font-mono",
												children: [
													trx.nop,
													" • Dusun ",
													trx.dusun
												]
											})] })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-right",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-bold text-xs font-mono text-emerald-400",
												children: formatRp(trx.totalBayar)
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[9px] text-slate-500",
												children: trx.tanggal
											})]
										})]
									}, trx.id);
								})
							})]
						}),
						selectedIds.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between items-center p-2.5 rounded-lg bg-emerald-950/30 border border-emerald-500/30 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-slate-300 font-medium",
								children: "Total Akumulasi Kelompok:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold font-mono text-emerald-400 text-sm",
								children: formatRp(selectedTotalSum)
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
					className: "gap-2 sm:gap-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => onOpenChange(false),
						className: "border-slate-800 text-slate-300 text-xs",
						children: "Batal"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						disabled: !groupName.trim() || selectedIds.length < 2,
						onClick: handleCreate,
						className: "bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs gap-1.5 disabled:opacity-50",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderPlus, { className: "size-4" }), " Gabungkan Kelompok (1 KK)"]
					})]
				})
			]
		})
	});
};
var ReportExportModal = ({ open, onOpenChange, transactions, dusunRecap, stats, settings, isSuperAdmin, filterDesa = "all", selectedDesaName, selectedDesaKades, selectedDesaNipKades, onTriggerPrint, onExportExcel, onExportCSV }) => {
	const tenant = useTenantStore();
	const isKecamatanLevel = Boolean(isSuperAdmin && filterDesa === "all");
	const namaDesa = selectedDesaName || tenant.nama_desa || settings.namaDesa || "DESA";
	const namaKec = tenant.nama_kecamatan || settings.kecamatan || "MALANGBONG";
	const namaKab = tenant.nama_kabupaten || settings.kabupaten || "GARUT";
	const namaKades = isKecamatanLevel ? settings.namaKades || `Camat ${namaKec}` : selectedDesaKades || tenant.nama_kades || settings.namaKades || "____________________";
	const nipKades = isKecamatanLevel ? settings.nipKades ? `NIP. ${settings.nipKades}` : `Pemerintah Kecamatan ${namaKec}` : selectedDesaNipKades || tenant.nip_kades || settings.nipKades ? `NIP. ${selectedDesaNipKades || tenant.nip_kades || settings.nipKades}` : "-";
	const namaPetugas = isKecamatanLevel ? settings.namaPetugas || "Tim Pajak Kecamatan" : settings.namaPetugas || "____________________";
	const nipPetugas = isKecamatanLevel ? settings.nipPetugas ? `NIP/NIK. ${settings.nipPetugas}` : `Kecamatan ${namaKec}` : settings.nipPetugas ? `NIP. ${settings.nipPetugas}` : "-";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-4xl bg-slate-950 border-slate-800 text-slate-100 p-6 rounded-2xl shadow-2xl space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
					className: "border-b border-slate-800 pb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center justify-between",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
							className: "text-base font-bold text-slate-100 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-5 text-emerald-400" }), " Pratinjau & Ekspor Laporan Resmi Setoran PBB-P2"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, {
						className: "text-xs text-slate-400",
						children: [
							"Laporan formal dengan Kop Surat Resmi ",
							isKecamatanLevel ? "Kecamatan" : "Desa",
							", Rincian Per-Dusun, & Ringkasan Keuangan."
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2.5 bg-slate-900/80 p-3 rounded-xl border border-slate-800",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: onTriggerPrint,
							className: "bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs gap-1.5 shadow-md",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), " Cetak / Download PDF"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: onExportExcel,
							variant: "outline",
							className: "border-emerald-600/40 text-emerald-300 hover:bg-emerald-950/60 font-bold text-xs gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, { className: "size-4 text-emerald-400" }), " Ekspor Excel (.xlsx)"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: onExportCSV,
							variant: "outline",
							className: "border-slate-700 text-slate-300 hover:bg-slate-800 font-bold text-xs gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4 text-emerald-400" }), " Unduh CSV (.csv)"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "py-2 space-y-4 max-h-[62vh] overflow-y-auto custom-scrollbar",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						id: "printable-recap",
						className: "bg-white text-slate-950 p-8 rounded-xl border border-slate-300 font-sans text-xs space-y-5 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center border-b-4 border-double border-slate-900 pb-4 space-y-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
										className: "text-sm font-black uppercase tracking-widest text-slate-900",
										children: ["PEMERINTAH KABUPATEN ", namaKab.toUpperCase()]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-xs font-bold uppercase tracking-wider text-slate-800",
										children: isKecamatanLevel ? `KECAMATAN ${namaKec.toUpperCase()} • SELURUH WILAYAH DESA` : `KECAMATAN ${namaKec.toUpperCase()} • DESA ${namaDesa.toUpperCase()}`
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[10px] text-slate-600 italic",
										children: ["Alamat Kantor: ", settings.alamatDesa || (isKecamatanLevel ? `Kantor Kecamatan ${namaKec}` : "Kantor Kepala Desa")]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "pt-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
											className: "text-base font-black uppercase tracking-wider text-emerald-950",
											children: "LAPORAN REKAPITULASI PENERIMAAN PBB-P2"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[11px] font-semibold text-slate-600",
											children: ["Periode Laporan: ", (/* @__PURE__ */ new Date()).toLocaleDateString("id-ID", { dateStyle: "full" })]
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-4 gap-3 p-3.5 rounded-lg bg-emerald-50/60 border border-emerald-200/80 text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-semibold text-slate-600 block",
										children: "Total SPPT Terbayar"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-sm font-black font-mono text-slate-900",
										children: [stats.count, " Transaksi"]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-semibold text-slate-600 block",
										children: "Total Pokok Pajak"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-black font-mono text-slate-900",
										children: formatRp(stats.totalPokok)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-semibold text-slate-600 block",
										children: "Total Fee Kolektor"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-black font-mono text-amber-700",
										children: formatRp(stats.totalFeeKolektor)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-bold text-emerald-900 uppercase block",
										children: "Total Setoran Terkumpul"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-base font-black font-mono text-emerald-700",
										children: formatRp(stats.totalSetoran)
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-bold text-xs uppercase tracking-wider text-emerald-950 flex items-center gap-1.5",
									children: "1. RINGKASAN PENERIMAAN PER DUSUN"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full border-collapse border border-slate-400 text-left text-[11px]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "bg-emerald-700 text-white border-b border-slate-400 font-bold text-center",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "border border-slate-400 px-2 py-1.5 w-10",
												children: "No"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "border border-slate-400 px-2 py-1.5 text-left",
												children: "Nama Dusun"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "border border-slate-400 px-2 py-1.5",
												children: "Jumlah SPPT"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "border border-slate-400 px-2 py-1.5 text-right",
												children: "Total Pokok"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "border border-slate-400 px-2 py-1.5 text-right",
												children: "Total Fee Kolektor"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "border border-slate-400 px-2 py-1.5 text-right",
												children: "Total Setoran"
											})
										]
									}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [dusunRecap.map((row, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-b border-slate-300",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "border border-slate-300 px-2 py-1 text-center",
												children: idx + 1
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
												className: "border border-slate-300 px-2 py-1 font-bold",
												children: ["Dusun ", row.dusun]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "border border-slate-300 px-2 py-1 text-center font-mono",
												children: row.count
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "border border-slate-300 px-2 py-1 text-right font-mono",
												children: formatRp(row.pokok)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "border border-slate-300 px-2 py-1 text-right font-mono text-amber-800",
												children: formatRp(row.feeKolektor)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "border border-slate-300 px-2 py-1 text-right font-mono font-bold text-emerald-900",
												children: formatRp(row.total)
											})
										]
									}, row.dusun)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "bg-emerald-100 font-black border-t-2 border-slate-400",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												colSpan: 2,
												className: "border border-slate-400 px-2 py-2 text-center uppercase",
												children: "JUMLAH TOTAL REKAPITULASI"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "border border-slate-400 px-2 py-2 text-center font-mono",
												children: stats.count
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "border border-slate-400 px-2 py-2 text-right font-mono",
												children: formatRp(stats.totalPokok)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "border border-slate-400 px-2 py-2 text-right font-mono",
												children: formatRp(stats.totalFeeKolektor)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "border border-slate-400 px-2 py-2 text-right font-mono text-emerald-950 text-xs",
												children: formatRp(stats.totalSetoran)
											})
										]
									})] })]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pt-6 grid grid-cols-2 text-center text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-12",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
										"Mengetahui,",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: isKecamatanLevel ? `CAMAT ${namaKec.toUpperCase()}` : `${settings.jabatanKades || "Kepala Desa"} ${namaDesa}` })
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-bold underline",
										children: [
											namaKades,
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "no-underline text-[10px] font-normal",
												children: nipKades
											})
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-12",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
										isKecamatanLevel ? namaKec : namaDesa,
										", ",
										(/* @__PURE__ */ new Date()).toLocaleDateString("id-ID", { dateStyle: "long" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: isKecamatanLevel ? "KASI PEMERINTAHAN / TIM PBB KECAMATAN" : settings.jabatanPetugas || "Bendahara / Kolektor Pajak" })
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-bold underline",
										children: [
											namaPetugas,
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "no-underline text-[10px] font-normal",
												children: nipPetugas
											})
										]
									})]
								})]
							})
						]
					})
				})
			]
		})
	});
};
function PenerimaanPage() {
	const { user: authUser } = useAuthStore();
	const { getActiveUser } = useUserStore();
	const tenant = useTenantStore();
	const currentUser = authUser || getActiveUser();
	const currentRole = currentUser?.role || "SUPER_ADMIN";
	const isSuperAdmin = currentRole === "SUPER_ADMIN_SYSTEM" || !currentUser?.desa_id && currentRole === "SUPER_ADMIN";
	const isKades = currentRole === "KEPALA_DESA";
	const isKolektor = currentRole === "KOLEKTOR";
	const canVoid = isSuperAdmin || currentRole === "SUPER_ADMIN";
	const [filterDesa, setFilterDesa] = (0, import_react.useState)("all");
	const [desasList, setDesasList] = (0, import_react.useState)([]);
	import_react.useEffect(() => {
		if (isSuperAdmin) desaService.getAll().then((res) => {
			if (res.data) setDesasList(res.data);
		}).catch((err) => console.error("Gagal memuat list desa:", err));
	}, [isSuperAdmin]);
	const { dhkpList, transactions, addTransaction, deleteTransaction, deleteBatch, deleteGroup, createCustomGroup, dissolveCustomGroup } = useDhkpStore();
	const { settings } = useSettingsStore();
	const selectedDesaObj = (0, import_react.useMemo)(() => {
		if (filterDesa === "all") return null;
		return desasList.find((d) => String(d.id) === filterDesa) || null;
	}, [filterDesa, desasList]);
	const pageTitle = (0, import_react.useMemo)(() => {
		if (isSuperAdmin) {
			if (filterDesa === "all") return `Penerimaan PBB-P2 Kecamatan ${settings.kecamatan || "Malangbong"}`;
			return `Penerimaan PBB-P2 Desa ${selectedDesaObj?.nama_desa || "Terpilih"}`;
		}
		return `Penerimaan & SPPT Setoran Pajak ${tenant?.nama_desa || settings?.namaDesa || "Desa"}`;
	}, [
		isSuperAdmin,
		filterDesa,
		selectedDesaObj,
		tenant,
		settings
	]);
	const pageSubtitle = (0, import_react.useMemo)(() => {
		if (isSuperAdmin) {
			if (filterDesa === "all") return `Rekapitulasi penerimaan pembayaran PBB-P2 se-Kecamatan ${settings.kecamatan || "Malangbong"}, proses pembayaran, dan monitoring setoran kasir.`;
			return `Penerimaan pembayaran PBB-P2 Desa ${selectedDesaObj?.nama_desa || ""}, proses pembayaran wajib pajak, dan cetak STTS resi.`;
		}
		return "Hitung ketetapan pokok dan fee kolektor PBB-P2 warga luar desa secara presisi, proses pembayaran wajib pajak, dan cetak Surat Tanda Terima Setoran (STTS) & Laporan Rekapitulasi.";
	}, [
		isSuperAdmin,
		filterDesa,
		selectedDesaObj,
		settings
	]);
	const [activeTab, setActiveTab] = (0, import_react.useState)(isKades ? "rekap" : "input");
	const [selectedIds, setSelectedIds] = (0, import_react.useState)([]);
	const [nopSearchQuery, setNopSearchQuery] = (0, import_react.useState)("");
	const [showNopDropdown, setShowNopDropdown] = (0, import_react.useState)(false);
	const [paymentMethod, setPaymentMethod] = (0, import_react.useState)("TUNAI");
	const [collectorName, setCollectorName] = (0, import_react.useState)(settings.namaPetugas || "Kolektor Desa");
	const [cashGiven, setCashGiven] = (0, import_react.useState)("");
	const [customDiscount, setCustomDiscount] = (0, import_react.useState)("0");
	const [activeReceiptTrxs, setActiveReceiptTrxs] = (0, import_react.useState)([]);
	const [showReceiptModal, setShowReceiptModal] = (0, import_react.useState)(false);
	const [showRecapModal, setShowRecapModal] = (0, import_react.useState)(false);
	const [receiptPaperFormat, setReceiptPaperFormat] = (0, import_react.useState)("stts");
	const [voidTrx, setVoidTrx] = (0, import_react.useState)(null);
	const [voidBatchId, setVoidBatchId] = (0, import_react.useState)(null);
	const [voidGroupTrxs, setVoidGroupTrxs] = (0, import_react.useState)(null);
	const [batchDetailTrxs, setBatchDetailTrxs] = (0, import_react.useState)(null);
	const [recapViewMode, setRecapViewMode] = (0, import_react.useState)("grouped");
	const [showCreateGroupModal, setShowCreateGroupModal] = (0, import_react.useState)(false);
	const [manualGroupName, setManualGroupName] = (0, import_react.useState)("");
	const [selectedTrxIdsForGroup, setSelectedTrxIdsForGroup] = (0, import_react.useState)([]);
	const [manualGroupSearch, setManualGroupSearch] = (0, import_react.useState)("");
	const [filterDateRange, setFilterDateRange] = (0, import_react.useState)("ALL");
	const [filterDusun, setFilterDusun] = (0, import_react.useState)("ALL");
	const [filterMethod, setFilterMethod] = (0, import_react.useState)("ALL");
	const [searchRecap, setSearchRecap] = (0, import_react.useState)("");
	const selectedSppts = (0, import_react.useMemo)(() => {
		return dhkpList.filter((item) => selectedIds.includes(item.id));
	}, [dhkpList, selectedIds]);
	const userDusunAkses = currentUser?.dusun_akses || currentUser?.dusunAssigned || "ALL";
	const filteredSpptOptions = (0, import_react.useMemo)(() => {
		let available = dhkpList;
		const userDesaId = currentUser?.desa_id || tenant?.id;
		if (!isSuperAdmin && userDesaId) available = available.filter((item) => {
			const itemDesaId = item.desaId !== void 0 && item.desaId !== null ? item.desaId : item.desa_id;
			return !itemDesaId || Number(itemDesaId) === Number(userDesaId);
		});
		if (isKolektor) available = available.filter((item) => isDusunAllowed(item.dusun || item.lokasi, userDusunAkses, currentRole));
		else if (isSuperAdmin && filterDesa !== "all") available = available.filter((item) => String(item.desaId || item.desa_id) === filterDesa);
		available = available.filter((item) => item.status === "BELUM");
		if (!nopSearchQuery.trim()) return available.slice(0, 15);
		const q = nopSearchQuery.toLowerCase().trim();
		return available.filter((item) => item.nop && item.nop.toLowerCase().includes(q) || item.namaSppt && item.namaSppt.toLowerCase().includes(q) || item.namaAktual && item.namaAktual.toLowerCase().includes(q) || item.lokasi && item.lokasi.toLowerCase().includes(q) || item.dusun && item.dusun.toLowerCase().includes(q) || item.namaDesa && item.namaDesa.toLowerCase().includes(q) || item.tahun && String(item.tahun).includes(q));
	}, [
		dhkpList,
		nopSearchQuery,
		isKolektor,
		isSuperAdmin,
		filterDesa,
		currentUser,
		userDusunAkses,
		currentRole
	]);
	const availableDusunOptions = (0, import_react.useMemo)(() => {
		const userDesaId = currentUser?.desa_id || tenant?.id;
		let targetDhkp = dhkpList;
		let targetTrx = transactions;
		if (isSuperAdmin && filterDesa !== "all") {
			targetDhkp = dhkpList.filter((item) => String(item.desaId || item.desa_id) === filterDesa);
			targetTrx = transactions.filter((trx) => String(trx.desaId || trx.desa_id) === filterDesa);
		} else if (!isSuperAdmin && userDesaId) {
			targetDhkp = dhkpList.filter((item) => {
				const itemDesaId = item.desaId !== void 0 && item.desaId !== null ? item.desaId : item.desa_id;
				return !itemDesaId || Number(itemDesaId) === Number(userDesaId);
			});
			targetTrx = transactions.filter((trx) => {
				const itemDesaId = trx.desaId !== void 0 && trx.desaId !== null ? trx.desaId : trx.desa_id;
				return !itemDesaId || Number(itemDesaId) === Number(userDesaId);
			});
		}
		const dusunSet = /* @__PURE__ */ new Set();
		targetDhkp.forEach((r) => {
			const val = (r.dusun || r.lokasi || "").trim();
			if (val) dusunSet.add(val);
		});
		targetTrx.forEach((t) => {
			const val = (t.dusun || "").trim();
			if (val) dusunSet.add(val);
		});
		let list = Array.from(dusunSet).sort();
		if (isKolektor) list = list.filter((d) => isDusunAllowed(d, userDusunAkses, currentRole));
		return list;
	}, [
		dhkpList,
		transactions,
		isSuperAdmin,
		filterDesa,
		currentUser,
		tenant,
		isKolektor,
		userDusunAkses,
		currentRole
	]);
	const calculation = (0, import_react.useMemo)(() => {
		if (selectedSppts.length === 0) return {
			pokok: 0,
			feeKolektor: 0,
			diskon: 0,
			totalBayar: 0,
			items: []
		};
		let sumPokok = 0;
		let sumFeeKolektor = 0;
		const items = selectedSppts.map((sppt) => {
			const feeInfo = calculateFeeKolektor(sppt.tagihan, sppt.domisili);
			sumPokok += sppt.tagihan;
			sumFeeKolektor += feeInfo.feeKolektor;
			return {
				sppt,
				...feeInfo
			};
		});
		const diskonVal = Math.max(0, parseInt(customDiscount, 10) || 0);
		const totalBayar = Math.max(0, sumPokok + sumFeeKolektor - diskonVal);
		return {
			pokok: sumPokok,
			feeKolektor: sumFeeKolektor,
			diskon: diskonVal,
			totalBayar,
			items
		};
	}, [selectedSppts, customDiscount]);
	const cashNum = parseInt(cashGiven, 10) || 0;
	const changeAmount = paymentMethod === "TUNAI" ? Math.max(0, cashNum - calculation.totalBayar) : 0;
	const isCashInsufficient = paymentMethod === "TUNAI" && cashNum > 0 && cashNum < calculation.totalBayar;
	const handleProcessPayment = () => {
		if (selectedSppts.length === 0) {
			toast.error("Silakan pilih minimal 1 NOP / SPPT Wajib Pajak terlebih dahulu.");
			return;
		}
		if (selectedSppts.some((s) => s.status === "LUNAS")) {
			toast.error("Terdapat SPPT yang sudah berstatus LUNAS di keranjang!");
			return;
		}
		if (paymentMethod === "TUNAI" && cashNum < calculation.totalBayar) {
			toast.error("Jumlah uang yang dibayarkan kurang dari total tagihan.");
			return;
		}
		const now = /* @__PURE__ */ new Date();
		const dateFormatted = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")} ${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
		const todayStr = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}`;
		const batchIdVal = calculation.items.length > 1 ? `BATCH-${todayStr}-${String(now.getTime()).slice(-4)}` : void 0;
		const batchTotalVal = calculation.items.length > 1 ? calculation.items.length : void 0;
		const newTrxs = [];
		let seq = transactions.length + 1;
		calculation.items.forEach((item, index) => {
			const sppt = item.sppt;
			const seqStr = String(seq).padStart(3, "0");
			const isLast = index === calculation.items.length - 1;
			const itemDiskon = isLast ? calculation.diskon : 0;
			const itemTotalBayar = sppt.tagihan + item.feeKolektor - itemDiskon;
			const trxDesaId = sppt.desaId ? Number(sppt.desaId) : currentUser?.desa_id ? Number(currentUser.desa_id) : tenant?.id ? Number(tenant.id) : void 0;
			const trxNamaDesa = sppt.namaDesa || tenant?.nama_desa || settings.namaDesa;
			const trx = {
				id: `TRX-${todayStr}-${seqStr}`,
				desaId: trxDesaId,
				namaDesa: trxNamaDesa,
				noStts: `STTS-${now.getFullYear()}-${todayStr.slice(4)}-${seqStr}`,
				tanggal: dateFormatted,
				nop: sppt.nop,
				namaSppt: sppt.namaSppt,
				dusun: sppt.lokasi || sppt.dusun,
				blok: sppt.blok,
				tahun: sppt.tahun,
				pokok: sppt.tagihan,
				feeKolektor: item.feeKolektor,
				diskon: itemDiskon,
				totalBayar: Math.max(0, itemTotalBayar),
				metode: paymentMethod,
				petugas: collectorName || "Kolektor Desa",
				uangDibayar: 0,
				kembalian: 0,
				batchId: batchIdVal,
				batchTotalItems: batchTotalVal
			};
			if (isLast) {
				trx.uangDibayar = paymentMethod === "TUNAI" ? cashNum : calculation.totalBayar;
				trx.kembalian = changeAmount;
			} else trx.uangDibayar = trx.totalBayar;
			addTransaction(trx);
			newTrxs.push(trx);
			seq++;
		});
		toast.success(`${newTrxs.length} Pembayaran SPPT berhasil diproses sekaligus!`);
		setActiveReceiptTrxs(newTrxs);
		setShowReceiptModal(true);
		setSelectedIds([]);
		setNopSearchQuery("");
		setCashGiven("");
		setCustomDiscount("0");
	};
	const filteredTransactions = (0, import_react.useMemo)(() => {
		return transactions.filter((trx) => {
			if (isKolektor && !isDusunAllowed(trx.dusun, userDusunAkses, currentRole)) return false;
			const itemDesaId = trx.desaId !== void 0 && trx.desaId !== null ? trx.desaId : trx.desa_id;
			if (isSuperAdmin) {
				if (filterDesa !== "all") {
					if (itemDesaId !== void 0 && itemDesaId !== null && String(itemDesaId) !== filterDesa) return false;
				}
			} else {
				const userDesaId = currentUser?.desa_id || tenant?.id;
				if (userDesaId) {
					if (itemDesaId !== void 0 && itemDesaId !== null && Number(itemDesaId) !== Number(userDesaId)) return false;
				}
			}
			if (filterDusun !== "ALL" && (trx.dusun || "").toUpperCase() !== filterDusun.toUpperCase()) return false;
			if (filterMethod !== "ALL" && trx.metode !== filterMethod) return false;
			if (filterDateRange === "TODAY") {
				const todayStr = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
				if (!trx.tanggal.startsWith(todayStr)) return false;
			} else if (filterDateRange === "THIS_MONTH") {
				const now = /* @__PURE__ */ new Date();
				const monthStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
				if (!trx.tanggal.startsWith(monthStr)) return false;
			} else if (filterDateRange === "THIS_YEAR") {
				const yearStr = `${(/* @__PURE__ */ new Date()).getFullYear()}`;
				if (!trx.tanggal.startsWith(yearStr)) return false;
			}
			if (searchRecap.trim()) {
				const q = searchRecap.toLowerCase();
				if (!(trx.nop.toLowerCase().includes(q) || trx.namaSppt.toLowerCase().includes(q) || trx.noStts.toLowerCase().includes(q) || trx.namaDesa && trx.namaDesa.toLowerCase().includes(q) || trx.petugas.toLowerCase().includes(q))) return false;
			}
			return true;
		}).sort((a, b) => new Date(b.tanggal).getTime() - new Date(a.tanggal).getTime());
	}, [
		transactions,
		isKolektor,
		isSuperAdmin,
		filterDesa,
		currentUser,
		tenant,
		filterDusun,
		filterMethod,
		filterDateRange,
		searchRecap,
		userDusunAkses,
		currentRole
	]);
	const groupedTransactions = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		filteredTransactions.forEach((trx) => {
			const dateKey = trx.tanggal.slice(0, 10);
			const key = trx.customGroupId ? trx.customGroupId : trx.batchId ? trx.batchId : `WP_${trx.namaSppt.trim().toUpperCase()}_${dateKey}`;
			const displayName = trx.customGroupName || trx.namaSppt;
			if (!map.has(key)) map.set(key, {
				key,
				namaSppt: displayName,
				count: 1,
				nops: [trx.nop],
				dusuns: trx.dusun ? [trx.dusun] : [],
				bloks: trx.blok ? [trx.blok] : [],
				totalPokok: trx.pokok,
				totalFeeKolektor: trx.feeKolektor || 0,
				totalBayar: trx.totalBayar,
				latestTanggal: trx.tanggal,
				metode: trx.metode,
				petugas: trx.petugas,
				trxIds: [trx.id],
				items: [trx],
				batchId: trx.batchId,
				customGroupId: trx.customGroupId,
				customGroupName: trx.customGroupName
			});
			else {
				const existing = map.get(key);
				existing.count += 1;
				if (!existing.nops.includes(trx.nop)) existing.nops.push(trx.nop);
				if (trx.dusun && !existing.dusuns.includes(trx.dusun)) existing.dusuns.push(trx.dusun);
				if (trx.blok && !existing.bloks.includes(trx.blok)) existing.bloks.push(trx.blok);
				existing.totalPokok += trx.pokok;
				existing.totalFeeKolektor += trx.feeKolektor || 0;
				existing.totalBayar += trx.totalBayar;
				existing.trxIds.push(trx.id);
				existing.items.push(trx);
			}
		});
		return Array.from(map.values());
	}, [filteredTransactions]);
	const handleDissolveGroup = (customGroupId, groupName) => {
		dissolveCustomGroup(customGroupId);
		toast.info(`Pengelompokan "${groupName}" telah dilepas kembali menjadi transaksi terpisah.`);
	};
	const handleExportCSV = () => {
		if (filteredTransactions.length === 0) {
			toast.error("Tidak ada data transaksi untuk diekspor ke CSV.");
			return;
		}
		const headers = [
			"No",
			"No STTS",
			"Tanggal",
			"NOP",
			"Wajib Pajak",
			"Dusun",
			"Blok",
			"Tahun",
			"Pokok",
			"Fee Kolektor",
			"Total Setoran",
			"Metode",
			"Petugas"
		];
		const rows = filteredTransactions.map((t, idx) => [
			idx + 1,
			`"${t.noStts}"`,
			`"${t.tanggal}"`,
			`"${t.nop}"`,
			`"${t.namaSppt.replace(/"/g, "\"\"")}"`,
			`"${t.dusun}"`,
			`"${t.blok}"`,
			t.tahun,
			t.pokok,
			t.feeKolektor || 0,
			t.totalBayar,
			`"${t.metode}"`,
			`"${t.petugas.replace(/"/g, "\"\"")}"`
		]);
		const csvContent = "﻿" + [headers.join(";"), ...rows.map((r) => r.join(";"))].join("\n");
		const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.setAttribute("href", url);
		const desaName = isSuperAdmin ? selectedDesaObj?.nama_desa || (filterDesa === "all" ? `Kecamatan_${settings.kecamatan || "Malangbong"}` : "Desa") : tenant.nama_desa || settings.namaDesa || "Desa";
		link.setAttribute("download", `Rekap_Penerimaan_PBB_${desaName.replace(/\s+/g, "_")}_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.csv`);
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
		URL.revokeObjectURL(url);
		toast.success("File CSV Rekap Penerimaan berhasil diunduh.");
	};
	const handleExportExcel = () => {
		if (filteredTransactions.length === 0) {
			toast.error("Tidak ada data transaksi untuk diekspor ke Excel.");
			return;
		}
		const isKecamatanLevel = isSuperAdmin && filterDesa === "all";
		const currentDate = (/* @__PURE__ */ new Date()).toLocaleDateString("id-ID", { dateStyle: "long" });
		const desa = isSuperAdmin ? selectedDesaObj?.nama_desa || settings.namaDesa || "Desa" : tenant.nama_desa || settings.namaDesa || "Desa";
		const kades = isKecamatanLevel ? settings.namaKades || `Camat ${settings.kecamatan || "Malangbong"}` : (isSuperAdmin ? selectedDesaObj?.nama_kades || settings.namaKades : tenant.nama_kades || settings.namaKades) || "______________________";
		const nipKades = isKecamatanLevel ? settings.nipKades || "-" : (isSuperAdmin ? selectedDesaObj?.nip_kades || settings.nipKades : tenant.nip_kades || settings.nipKades) || "-";
		const petugas = isKecamatanLevel ? settings.namaPetugas || "Tim Pajak Kecamatan" : settings.namaPetugas || "Kolektor PBB";
		const nipPetugas = isKecamatanLevel ? settings.nipPetugas || "-" : settings.nipPetugas || "-";
		const kec = settings.kecamatan || "Malangbong";
		const htmlContent = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta charset="utf-8" />
        <!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>Laporan Penerimaan PBB</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->
        <style>
          body { font-family: Arial, sans-serif; font-size: 11pt; }
          .title { font-size: 14pt; font-weight: bold; text-align: center; }
          .subtitle { font-size: 12pt; font-weight: bold; text-align: center; }
          th { background-color: #059669; color: #ffffff; font-weight: bold; text-align: center; padding: 6px; border: 1px solid #047857; }
          td { padding: 5px; border: 1px solid #d1d5db; vertical-align: middle; }
          .num { text-align: right; mso-number-format:"\#\,\#\#0"; }
          .total-row td { background-color: #ecfdf5; font-weight: bold; border-top: 2px solid #059669; }
        </style>
      </head>
      <body>
        <div class="title">${(settings.kabupaten || "Garut").toUpperCase()}</div>
        <div class="subtitle">${isKecamatanLevel ? `KECAMATAN ${kec.toUpperCase()} - SELURUH WILAYAH DESA` : `KECAMATAN ${kec.toUpperCase()} - DESA ${desa.toUpperCase()}`}</div>
        <div class="title" style="margin-top: 10px; color: #047857;">LAPORAN REKAPITULASI PENERIMAAN PBB-P2</div>
        <div style="text-align: center; font-size: 10pt; color: #4b5563;">Periode Data: ${currentDate}</div>
        <br/>

        <h3 style="color: #065f46;">1. RINGKASAN PENERIMAAN PER DUSUN</h3>
        <table border="1" style="border-collapse: collapse; width: 100%;">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama Dusun</th>
              <th>Jumlah SPPT</th>
              <th>Total Pokok (Rp)</th>
              <th>Total Fee Kolektor (Rp)</th>
              <th>Total Setoran (Rp)</th>
            </tr>
          </thead>
          <tbody>
            ${dusunRecap.map((r, i) => `
              <tr>
                <td style="text-align: center;">${i + 1}</td>
                <td><b>Dusun ${r.dusun}</b></td>
                <td style="text-align: center;">${r.count}</td>
                <td class="num">${r.pokok}</td>
                <td class="num" style="color: #b45309;">${r.feeKolektor}</td>
                <td class="num" style="font-weight: bold; color: #047857;">${r.total}</td>
              </tr>
            `).join("")}
            <tr class="total-row">
              <td colspan="2" style="text-align: center;">JUMLAH TOTAL</td>
              <td style="text-align: center;">${stats.count}</td>
              <td class="num">${stats.totalPokok}</td>
              <td class="num">${stats.totalFeeKolektor}</td>
              <td class="num" style="font-size: 12pt; color: #047857;">${stats.totalSetoran}</td>
            </tr>
          </tbody>
        </table>
        <br/><br/>

        <h3 style="color: #065f46;">2. RINCIAN TRANSAKSI SETORAN (${recapViewMode === "grouped" ? "Mode Dikelompokkan Per Wajib Pajak" : "Mode Per SPPT Detail"})</h3>
        <table border="1" style="border-collapse: collapse; width: 100%;">
          <thead>
            <tr>
              <th>No</th>
              <th>Wajib Pajak</th>
              <th>NOP</th>
              <th>No STTS</th>
              <th>Dusun / Lokasi</th>
              <th>Blok</th>
              <th>Waktu Bayar</th>
              <th>Metode</th>
              <th>Pokok (Rp)</th>
              <th>Fee Kolektor (Rp)</th>
              <th>Total Setoran (Rp)</th>
            </tr>
          </thead>
          <tbody>
            ${filteredTransactions.map((t, i) => `
              <tr>
                <td style="text-align: center;">${i + 1}</td>
                <td><b>${t.namaSppt}</b></td>
                <td style="font-family: monospace;">${t.nop}</td>
                <td style="font-family: monospace;">${t.noStts}</td>
                <td>Dusun ${t.dusun}</td>
                <td>${t.blok}</td>
                <td>${t.tanggal}</td>
                <td style="text-align: center;">${t.metode}</td>
                <td class="num">${t.pokok}</td>
                <td class="num" style="color: #b45309;">${t.feeKolektor || 0}</td>
                <td class="num" style="font-weight: bold; color: #047857;">${t.totalBayar}</td>
              </tr>
            `).join("")}
          </tbody>
        </table>
        <br/><br/><br/>

        <table border="0" style="width: 100%;">
          <tr>
            <td style="text-align: center; width: 50%; border: none;">
              Mengetahui,<br/>
              <b>${isKecamatanLevel ? `CAMAT ${kec.toUpperCase()}` : `Kepala Desa ${desa}`}</b><br/><br/><br/><br/>
              <u><b>${kades}</b></u><br/>
              ${nipKades && nipKades !== "-" ? `NIP. ${nipKades}` : isKecamatanLevel ? `Pemerintah Kecamatan ${kec}` : `Kepala Desa ${desa}`}
            </td>
            <td style="text-align: center; width: 50%; border: none;">
              ${isKecamatanLevel ? kec : desa}, ${currentDate}<br/>
              <b>${isKecamatanLevel ? "KASI PEMERINTAHAN / TIM PBB KECAMATAN" : "Bendahara / Kolektor Pajak"}</b><br/><br/><br/><br/>
              <u><b>${petugas}</b></u><br/>
              ${nipPetugas && nipPetugas !== "-" ? `NIP. ${nipPetugas}` : isKecamatanLevel ? `Kecamatan ${kec}` : `Kolektor Pajak`}
            </td>
          </tr>
        </table>
      </body>
      </html>
    `;
		const blob = new Blob([htmlContent], { type: "application/vnd.ms-excel;charset=utf-8;" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = `Laporan_Penerimaan_PBB_Desa_${desa.replace(/\s+/g, "_")}_${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.xls`;
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
		URL.revokeObjectURL(url);
		toast.success("Laporan Rekap Laporan Format Excel (.xls) berhasil diunduh!");
	};
	const handleVoidTransaction = () => {
		if (!canVoid) {
			toast.error("Akses Ditolak!", { description: "Hanya Bendahara Desa dan Super Admin yang memiliki hak akses untuk membatalkan STTS." });
			setVoidTrx(null);
			return;
		}
		if (!voidTrx) return;
		deleteTransaction(voidTrx.id);
		toast.success(`Transaksi ${voidTrx.noStts} berhasil dibatalkan`, { description: `NOP ${voidTrx.nop} dikembalikan ke status BELUM LUNAS.` });
		setVoidTrx(null);
	};
	const handleVoidGroupTransaction = () => {
		if (!canVoid) {
			toast.error("Akses Ditolak!", { description: "Hanya Bendahara Desa dan Super Admin yang memiliki hak akses untuk membatalkan STTS." });
			setVoidGroupTrxs(null);
			return;
		}
		if (!voidGroupTrxs) return;
		deleteGroup(voidGroupTrxs.trxs.map((t) => t.id));
		toast.success(`${voidGroupTrxs.trxs.length} Transaksi SPPT milik ${voidGroupTrxs.name} berhasil dibatalkan`, { description: `Seluruh NOP dalam kelompok ini dikembalikan ke status BELUM LUNAS di DHKP.` });
		setVoidGroupTrxs(null);
	};
	const stats = (0, import_react.useMemo)(() => {
		const totalPokok = filteredTransactions.reduce((acc, curr) => acc + curr.pokok, 0);
		const totalFeeKolektor = filteredTransactions.reduce((acc, curr) => acc + (curr.feeKolektor || 0), 0);
		const totalSetoran = filteredTransactions.reduce((acc, curr) => acc + curr.totalBayar, 0);
		const count = filteredTransactions.length;
		const todayStr = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
		const todayTrx = filteredTransactions.filter((t) => t.tanggal.startsWith(todayStr));
		return {
			totalPokok,
			totalFeeKolektor,
			totalSetoran,
			count,
			todaySetoran: todayTrx.reduce((acc, curr) => acc + curr.totalBayar, 0),
			todayCount: todayTrx.length
		};
	}, [filteredTransactions, transactions]);
	const dusunRecap = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		filteredTransactions.forEach((t) => {
			const d = t.dusun || "LAINNYA";
			const existing = map.get(d) || {
				count: 0,
				pokok: 0,
				feeKolektor: 0,
				total: 0
			};
			map.set(d, {
				count: existing.count + 1,
				pokok: existing.pokok + t.pokok,
				feeKolektor: existing.feeKolektor + (t.feeKolektor || 0),
				total: existing.total + t.totalBayar
			});
		});
		return Array.from(map.entries()).map(([dusun, data]) => ({
			dusun,
			...data
		}));
	}, [filteredTransactions]);
	const triggerPrint = () => {
		window.print();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 pb-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-700 via-emerald-600 to-teal-700 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 p-6 text-white shadow-xl border border-emerald-500/30 dark:border-slate-800 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-10 flex flex-col justify-between gap-4 md:flex-row md:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex items-center gap-2 rounded-full bg-white/15 dark:bg-emerald-500/10 border border-white/30 dark:border-emerald-500/30 px-3 py-1 text-xs font-bold uppercase tracking-wider text-emerald-50 dark:text-emerald-400 backdrop-blur-md",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "size-3.5 text-amber-300" }), " Modul Penerimaan PBB-P2"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-2xl font-black tracking-tight md:text-3xl text-white",
								children: pageTitle
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-emerald-50 dark:text-slate-300 max-w-2xl font-medium",
								children: pageSubtitle
							})
						]
					}), isSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2.5 rounded-xl bg-white/15 dark:bg-slate-900/80 p-2.5 border border-white/20 dark:border-slate-800 backdrop-blur-md shadow-inner",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4 text-emerald-200" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-bold text-white whitespace-nowrap",
								children: "Filter Desa:"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: filterDesa,
								onValueChange: setFilterDesa,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "h-9 w-44 bg-white dark:bg-slate-950 border-emerald-300 dark:border-slate-800 text-xs font-bold text-slate-900 dark:text-slate-100 shadow-sm",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Pilih Desa" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
									className: "bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-100",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "all",
										className: "font-bold text-emerald-600 dark:text-emerald-400",
										children: "🌐 Seluruh Desa"
									}), desasList.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
										value: String(d.id),
										className: "text-xs font-medium",
										children: ["Desa ", d.nama_desa]
									}, d.id))]
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				value: activeTab,
				onValueChange: setActiveTab,
				className: "w-full space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
							className: "grid w-full sm:w-auto grid-cols-2 max-w-md bg-emerald-50 dark:bg-slate-950 p-1 border border-emerald-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 rounded-xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "input",
								className: "flex items-center gap-2 font-bold text-xs py-2 data-[state=active]:bg-emerald-600 data-[state=active]:text-white rounded-lg transition-all",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, { className: "size-4" }), " Input Penerimaan SPPT"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "rekap",
								className: "flex items-center gap-2 font-bold text-xs py-2 data-[state=active]:bg-emerald-600 data-[state=active]:text-white rounded-lg transition-all",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-4" }), " Rekapitulasi Penerimaan"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => setShowRecapModal(true),
							className: "bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 hover:from-emerald-500 hover:to-teal-400 text-white font-black text-xs h-10 px-5 gap-2 rounded-xl shadow-lg shadow-emerald-600/30 border border-emerald-400/30 transition-all hover:scale-[1.03] active:scale-[0.97]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4 text-emerald-200" }), " Cetak & Ekspor Laporan Rekap"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "input",
						className: "space-y-6 m-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-6 lg:grid-cols-12",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
								className: "lg:col-span-7 border-emerald-100/80 dark:border-slate-800/80 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md shadow-xl",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
									className: "border-b border-emerald-100/80 dark:border-slate-800/80 bg-emerald-50/60 dark:bg-slate-950/60 pb-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
										className: "flex items-center gap-2 text-base font-bold text-slate-900 dark:text-slate-100",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), " Cari & Pilih Wajib Pajak (NOP)"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, {
										className: "text-xs text-slate-600 dark:text-slate-400",
										children: "Ketik Nomor Objek Pajak (NOP) atau nama wajib pajak untuk memuat data tagihan (hanya menampilkan SPPT belum lunas)."
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
									className: "space-y-6 pt-5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative space-y-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-xs font-semibold text-slate-700 dark:text-slate-300",
													children: "Cari NOP / Nama Wajib Pajak"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "relative",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-2.5 size-4 text-slate-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														placeholder: "Contoh: 1.0001 atau IDI / IYAH...",
														value: nopSearchQuery,
														onChange: (e) => {
															setNopSearchQuery(e.target.value);
															setShowNopDropdown(true);
														},
														onFocus: () => setShowNopDropdown(true),
														className: "pl-9 bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 font-mono text-sm focus:border-emerald-500"
													})]
												}),
												showNopDropdown && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "absolute z-20 mt-1 flex flex-col max-h-80 w-full rounded-xl border border-slate-800 bg-slate-950 p-1.5 shadow-2xl backdrop-blur-md",
													children: [
														filteredSpptOptions.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center justify-between p-2 mb-1 border-b border-slate-800 bg-slate-900/80 rounded-lg",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "text-[11px] font-bold text-slate-300",
																children: [
																	"Ditemukan ",
																	filteredSpptOptions.length,
																	" NOP Belum Lunas"
																]
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																type: "button",
																size: "sm",
																variant: "ghost",
																onClick: (e) => {
																	e.stopPropagation();
																	const allFilteredIds = filteredSpptOptions.map((o) => o.id);
																	if (allFilteredIds.every((id) => selectedIds.includes(id))) setSelectedIds((prev) => prev.filter((id) => !allFilteredIds.includes(id)));
																	else setSelectedIds((prev) => Array.from(/* @__PURE__ */ new Set([...prev, ...allFilteredIds])));
																},
																className: "h-7 text-[11px] font-extrabold text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/20 px-2.5 rounded-md",
																children: filteredSpptOptions.every((o) => selectedIds.includes(o.id)) ? "Batal Pilih Semua" : "☑️ Pilih Semua NOP Ini"
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "flex-1 overflow-y-auto custom-scrollbar pr-1 space-y-1",
															children: filteredSpptOptions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																className: "p-3 text-center text-xs text-slate-500",
																children: "Data SPPT tidak ditemukan"
															}) : filteredSpptOptions.map((item) => {
																const isSelected = selectedIds.includes(item.id);
																return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																	onClick: (e) => {
																		e.stopPropagation();
																		if (isSelected) setSelectedIds((prev) => prev.filter((id) => id !== item.id));
																		else setSelectedIds((prev) => [...prev, item.id]);
																	},
																	className: `flex cursor-pointer items-center justify-between rounded-lg p-2.5 text-xs transition-colors hover:bg-slate-800/80 ${isSelected ? "bg-emerald-500/15 border border-emerald-500/40" : "border border-transparent"}`,
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																		className: "flex items-center gap-3",
																		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																			className: `flex items-center justify-center size-4 rounded ${isSelected ? "bg-emerald-500 text-white" : "border border-slate-600"}`,
																			children: isSelected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3" })
																		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																			className: "space-y-0.5",
																			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																				className: "flex items-center gap-1.5",
																				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
																					className: `font-mono font-bold ${isSelected ? "text-emerald-400" : "text-slate-100"}`,
																					children: [
																						item.nop,
																						" - ",
																						item.namaSppt
																					]
																				}), isSuperAdmin && filterDesa === "all" && item.namaDesa && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																					className: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30 text-[9px] px-1.5 py-0 font-normal",
																					children: item.namaDesa
																				})]
																			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
																				className: "text-[11px] text-slate-400",
																				children: [
																					item.lokasi,
																					" • ",
																					item.blok,
																					" • Tahun ",
																					item.tahun
																				]
																			})]
																		})]
																	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																		className: "text-right",
																		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																			className: "font-mono font-bold text-slate-200",
																			children: formatRp(item.tagihan)
																		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																			variant: "outline",
																			className: `text-[9px] px-1.5 py-0 ${item.status === "LUNAS" ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30" : "bg-rose-500/10 text-rose-400 border-rose-500/30"}`,
																			children: item.status
																		})]
																	})]
																}, item.id);
															})
														}),
														filteredSpptOptions.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "pt-2 mt-2 border-t border-slate-800 px-1 pb-1",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
																onClick: () => setShowNopDropdown(false),
																className: "w-full text-xs h-8 bg-slate-800 hover:bg-slate-700 text-white font-bold",
																children: [
																	"Selesai Memilih & Tutup (",
																	selectedIds.length,
																	" NOP Terpilih)"
																]
															})
														})
													]
												})
											]
										}),
										selectedSppts.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-xl border border-emerald-100 dark:border-slate-800 bg-emerald-50/50 dark:bg-slate-950/70 p-4 space-y-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between border-b border-emerald-200/80 dark:border-slate-800/60 pb-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[10px] uppercase font-bold tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "size-3" }), " Keranjang Pajak"]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
													className: "text-lg font-black text-slate-900 dark:text-white font-mono",
													children: [selectedSppts.length, " SPPT Terpilih"]
												})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													variant: "outline",
													size: "sm",
													onClick: () => setSelectedIds([]),
													className: "h-7 text-[10px] text-rose-600 border-rose-200 hover:bg-rose-50 dark:border-rose-900/50 dark:hover:bg-rose-900/30",
													children: "Kosongkan"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "space-y-3 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar",
												children: selectedSppts.map((sppt) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "relative rounded-lg border border-emerald-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 shadow-sm transition-all hover:border-emerald-300 dark:hover:border-slate-700",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															onClick: () => setSelectedIds((prev) => prev.filter((id) => id !== sppt.id)),
															className: "absolute top-2 right-2 text-rose-400 hover:text-rose-600 bg-rose-50 dark:bg-rose-500/10 hover:bg-rose-100 dark:hover:bg-rose-500/20 rounded-md p-1.5 transition-colors",
															title: "Hapus dari keranjang",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex justify-between items-start pr-8",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																className: "font-mono text-xs font-bold text-emerald-700 dark:text-emerald-400",
																children: sppt.nop
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																className: "font-bold text-slate-900 dark:text-slate-100 text-sm mt-0.5",
																children: sppt.namaSppt
															})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																className: `text-[9px] px-1.5 py-0 ${sppt.status === "LUNAS" ? "bg-emerald-600 text-white" : "bg-rose-600 text-white"}`,
																children: sppt.status
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "mt-2 grid grid-cols-2 gap-2 text-[10px] text-slate-600 dark:text-slate-400",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Pemilik: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "font-semibold text-slate-800 dark:text-slate-200",
																	children: sppt.namaAktual || "-"
																})] }),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Lokasi: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "font-semibold text-slate-800 dark:text-slate-200",
																	children: sppt.lokasi
																})] }),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Tahun: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "font-semibold text-slate-800 dark:text-slate-200",
																	children: sppt.tahun
																})] }),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Tagihan: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "font-mono font-bold text-slate-900 dark:text-slate-100",
																	children: formatRp(sppt.tagihan)
																})] })
															]
														})
													]
												}, sppt.id))
											})]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-xl border border-dashed border-emerald-200 dark:border-slate-800 bg-emerald-50/30 dark:bg-slate-950/40 p-8 text-center space-y-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mx-auto size-8 text-slate-400 dark:text-slate-600" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm font-semibold text-slate-600 dark:text-slate-400",
													children: "Keranjang Pajak Kosong"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-slate-500",
													children: "Cari dan pilih satu atau lebih NOP/SPPT di atas untuk memulai kalkulasi pembayaran kolektif."
												})
											]
										}),
										selectedSppts.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-3 rounded-xl bg-emerald-50/50 dark:bg-slate-950/90 border border-emerald-100 dark:border-slate-800 p-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
												className: "text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 flex items-center gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, { className: "size-3.5 text-emerald-600 dark:text-emerald-400" }), " Rincian Kalkulasi PBB-P2 & Fee Kolektor"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-2 text-xs divide-y divide-emerald-200/60 dark:divide-slate-800/60",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex justify-between pt-1 text-slate-700 dark:text-slate-300",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Pokok PBB-P2 (Kumulatif)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-mono font-semibold text-slate-900 dark:text-slate-100",
															children: formatRp(calculation.pokok)
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex justify-between pt-2 text-slate-700 dark:text-slate-300",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Fee Kolektor Pajak (Warga Luar Desa)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "font-mono font-semibold text-amber-600 dark:text-amber-400",
															children: ["+", formatRp(calculation.feeKolektor)]
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex justify-between items-center pt-2 text-slate-700 dark:text-slate-300",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-slate-600 dark:text-slate-400",
															children: "Keringanan / Diskon Fee (Rp)"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "w-32",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
																type: "number",
																value: customDiscount,
																onChange: (e) => setCustomDiscount(e.target.value),
																placeholder: "0",
																className: "h-7 text-right text-xs font-mono bg-white dark:bg-slate-900 border-emerald-200 dark:border-slate-700 text-emerald-700 dark:text-emerald-400"
															})
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex justify-between items-center pt-3 text-sm font-bold",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-slate-900 dark:text-white",
															children: "Total Harus Dibayar"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-lg font-mono font-black text-emerald-700 dark:text-amber-400",
															children: formatRp(calculation.totalBayar)
														})]
													})
												]
											})]
										})
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
								className: "lg:col-span-5 border-emerald-100/80 dark:border-slate-800/80 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md shadow-xl flex flex-col justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
									className: "border-b border-emerald-100/80 dark:border-slate-800/60 pb-4 bg-emerald-50/60 dark:bg-transparent",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
										className: "flex items-center gap-2 text-base font-bold text-slate-900 dark:text-slate-100",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "size-4 text-amber-600 dark:text-amber-400" }), " Form Eksekusi Pembayaran"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, {
										className: "text-xs text-slate-600 dark:text-slate-400",
										children: "Pilih metode bayar, isi nominal uang, dan terbitkan STTS resmi."
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
									className: "space-y-5 pt-5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												className: "text-xs font-semibold text-slate-700 dark:text-slate-300",
												children: "Metode Pembayaran"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "grid grid-cols-3 gap-2",
												children: [
													"TUNAI",
													"QRIS",
													"TRANSFER"
												].map((method) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => setPaymentMethod(method),
													className: `flex flex-col items-center justify-center rounded-xl border p-2.5 text-xs font-bold transition-all ${paymentMethod === method ? "border-emerald-500 bg-emerald-600 text-white shadow-md shadow-emerald-500/10" : "border-emerald-200 dark:border-slate-800 bg-emerald-50/40 dark:bg-slate-950/60 text-slate-700 dark:text-slate-400 hover:bg-emerald-100/60 dark:hover:bg-slate-800/50"}`,
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: method })
												}, method))
											})]
										}),
										paymentMethod === "TUNAI" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-3 rounded-xl border border-emerald-200 dark:border-slate-800 bg-emerald-50/50 dark:bg-slate-950/70 p-3.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "space-y-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
														className: "text-xs font-semibold text-slate-700 dark:text-slate-300",
														children: "Uang Diterima (Rp)"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														type: "number",
														placeholder: "Contoh: 50000",
														value: cashGiven,
														onChange: (e) => setCashGiven(e.target.value),
														className: "bg-white dark:bg-slate-900 border-emerald-200 dark:border-slate-700 font-mono text-base font-bold text-emerald-700 dark:text-emerald-400 placeholder:text-slate-400 focus:border-emerald-500"
													})]
												}),
												selectedSppts.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex flex-wrap gap-1.5 pt-1",
													children: [
														calculation.totalBayar,
														Math.ceil(calculation.totalBayar / 1e4) * 1e4,
														5e4,
														1e5
													].map((amt, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														onClick: () => setCashGiven(String(amt)),
														className: "rounded-lg bg-emerald-100/80 dark:bg-slate-800/80 px-2 py-1 text-[11px] font-mono text-emerald-900 dark:text-slate-300 hover:bg-emerald-200 dark:hover:bg-slate-700",
														children: formatRp(amt)
													}, idx))
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex justify-between items-center pt-2 text-xs border-t border-emerald-200/80 dark:border-slate-800/60",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-slate-600 dark:text-slate-400",
														children: "Kembalian:"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: `font-mono font-bold text-sm ${isCashInsufficient ? "text-rose-600 dark:text-rose-400" : "text-emerald-700 dark:text-emerald-400"}`,
														children: isCashInsufficient ? "Uang Kurang!" : formatRp(changeAmount)
													})]
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												className: "text-xs font-semibold text-slate-700 dark:text-slate-300",
												children: "Nama Petugas / Kolektor"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: collectorName,
												onChange: (e) => setCollectorName(e.target.value),
												placeholder: "Nama Petugas Penerima...",
												className: "bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-xs text-slate-900 dark:text-slate-200 focus:border-emerald-500"
											})]
										})
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "p-5 border-t border-emerald-100 dark:border-slate-800/60 bg-emerald-50/40 dark:bg-slate-950/40 rounded-b-xl",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										onClick: handleProcessPayment,
										disabled: selectedSppts.length === 0 || selectedSppts.some((s) => s.status === "LUNAS") || isCashInsufficient,
										className: "w-full bg-emerald-600 hover:bg-emerald-500 text-white font-black tracking-wide py-6 text-sm shadow-lg shadow-emerald-600/20 transition-all rounded-xl gap-2 disabled:opacity-50",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5" }), " Proses Pembayaran & Cetak STTS"]
									})
								})]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "rekap",
						className: "space-y-6 m-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
									className: "border-emerald-100 dark:border-slate-800 bg-white dark:bg-slate-900/60 backdrop-blur-md shadow-md",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
										className: "p-4 flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] font-semibold text-slate-500 dark:text-slate-400",
												children: "Total Setoran Terkumpul"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-xl font-black font-mono text-emerald-700 dark:text-emerald-400 mt-1",
												children: formatRp(stats.totalSetoran)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[10px] text-slate-500 mt-0.5",
												children: [stats.count, " Transaksi Masuk"]
											})
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 grid place-items-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-5" })
										})]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
									className: "border-emerald-100 dark:border-slate-800 bg-white dark:bg-slate-900/60 backdrop-blur-md shadow-md",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
										className: "p-4 flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] font-semibold text-slate-500 dark:text-slate-400",
												children: "Total Pokok Pajak"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-xl font-black font-mono text-slate-900 dark:text-white mt-1",
												children: formatRp(stats.totalPokok)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-slate-500 mt-0.5",
												children: "Ketetapan Murni"
											})
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-10 rounded-xl bg-sky-500/10 border border-sky-500/20 text-sky-600 dark:text-sky-400 grid place-items-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5" })
										})]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
									className: "border-emerald-100 dark:border-slate-800 bg-white dark:bg-slate-900/60 backdrop-blur-md shadow-md",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
										className: "p-4 flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] font-semibold text-slate-500 dark:text-slate-400",
												children: "Total Fee Kolektor"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-xl font-black font-mono text-amber-600 dark:text-amber-400 mt-1",
												children: formatRp(stats.totalFeeKolektor)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-slate-500 mt-0.5",
												children: "Warga Luar Desa"
											})
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-600 dark:text-amber-400 grid place-items-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-5" })
										})]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
									className: "border-emerald-100 dark:border-slate-800 bg-white dark:bg-slate-900/60 backdrop-blur-md shadow-md",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
										className: "p-4 flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] font-semibold text-slate-500 dark:text-slate-400",
												children: "Penerimaan Hari Ini"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-xl font-black font-mono text-emerald-600 dark:text-emerald-400 mt-1",
												children: formatRp(stats.todaySetoran)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[10px] text-slate-500 mt-0.5",
												children: [stats.todayCount, " Transaksi Hari Ini"]
											})
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 grid place-items-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-5" })
										})]
									})
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "border-emerald-100/80 dark:border-slate-800 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md shadow-xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
								className: "border-b border-emerald-100/80 dark:border-slate-800/60 pb-4 bg-emerald-50/40 dark:bg-transparent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
											className: "text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), " Rekapitulasi Riwayat Penerimaan PBB-P2"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, {
											className: "text-xs text-slate-600 dark:text-slate-400",
											children: "Daftar transaksi setoran PBB-P2 terstruktur dengan ringkasan finansial dan bukti setoran."
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "inline-flex items-center gap-1 rounded-xl bg-emerald-100/70 dark:bg-slate-950 p-1 border border-emerald-200/80 dark:border-slate-800 shadow-inner",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setRecapViewMode("grouped"),
												className: `flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${recapViewMode === "grouped" ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/20" : "text-slate-700 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"}`,
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "size-3.5" }),
													" Kelompokkan (",
													groupedTransactions.length,
													")"
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => setRecapViewMode("itemized"),
												className: `flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${recapViewMode === "itemized" ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/20" : "text-slate-700 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"}`,
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, { className: "size-3.5" }),
													" Per SPPT (",
													filteredTransactions.length,
													")"
												]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											onClick: () => setShowCreateGroupModal(true),
											variant: "outline",
											className: "border-emerald-300 dark:border-emerald-800 bg-emerald-50/80 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 font-bold text-xs h-9 gap-1.5 rounded-xl shadow-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), " Kelompokkan Manual (1 KK)"]
										})]
									})]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
								className: "space-y-4 pt-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-3 sm:grid-cols-2 md:grid-cols-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-2.5 size-3.5 text-slate-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												placeholder: "Cari NOP / Wajib Pajak / STTS...",
												value: searchRecap,
												onChange: (e) => setSearchRecap(e.target.value),
												className: "pl-8 bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-xs text-slate-900 dark:text-slate-200 h-9 focus:border-emerald-500"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											value: filterDusun,
											onValueChange: setFilterDusun,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
												className: "bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-xs text-slate-900 dark:text-slate-200 h-9",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Pilih Dusun" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
												className: "bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-200",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
													value: "ALL",
													children: "Semua Dusun"
												}), availableDusunOptions.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
													value: d,
													children: ["Dusun ", d]
												}, d))]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											value: filterMethod,
											onValueChange: setFilterMethod,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
												className: "bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-xs text-slate-900 dark:text-slate-200 h-9",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Metode Bayar" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
												className: "bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-200",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "ALL",
														children: "Semua Metode"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "TUNAI",
														children: "TUNAI"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "QRIS",
														children: "QRIS"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "TRANSFER",
														children: "TRANSFER"
													})
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											value: filterDateRange,
											onValueChange: setFilterDateRange,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
												className: "bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-xs text-slate-900 dark:text-slate-200 h-9",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Rentang Waktu" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
												className: "bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-200",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "ALL",
														children: "Semua Waktu"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "TODAY",
														children: "Hari Ini"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "THIS_MONTH",
														children: "Bulan Ini"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
														value: "THIS_YEAR",
														children: "Tahun Ini"
													})
												]
											})]
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "overflow-x-auto rounded-xl border border-emerald-100 dark:border-slate-800 bg-white dark:bg-slate-950/60 shadow-sm",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
										className: "w-full text-left text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
											className: "bg-emerald-50/80 dark:bg-slate-900/90 text-emerald-950 dark:text-slate-400 uppercase tracking-wider font-extrabold border-b border-emerald-100 dark:border-slate-800",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-4 py-3.5",
													children: "Wajib Pajak & Setoran"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-4 py-3.5",
													children: "Lokasi"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-4 py-3.5",
													children: "Waktu & Metode"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-4 py-3.5",
													children: "Rincian Pokok & Fee"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-4 py-3.5 text-right",
													children: "Total Setoran"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-4 py-3.5 text-center",
													children: "Aksi"
												})
											] })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
											className: "divide-y divide-emerald-100/60 dark:divide-slate-800/60 text-slate-800 dark:text-slate-300",
											children: recapViewMode === "grouped" ? groupedTransactions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												colSpan: 6,
												className: "py-12 text-center text-slate-500",
												children: "Tidak ada data transaksi penerimaan yang sesuai."
											}) }) : groupedTransactions.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
												className: "hover:bg-emerald-50/50 dark:hover:bg-slate-800/40 transition-colors",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "px-4 py-3.5",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "space-y-1",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "flex items-center gap-2",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "font-extrabold text-slate-900 dark:text-slate-100 text-sm",
																	children: group.namaSppt
																}), group.count > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
																	className: "bg-emerald-600 text-white font-extrabold text-[10px] px-2 py-0.5 rounded-md shadow-sm border-none",
																	children: [
																		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Boxes, { className: "size-3 mr-1 inline" }),
																		" KOLEKTIF (",
																		group.count,
																		" SPPT)"
																	]
																}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																	variant: "outline",
																	className: "text-[10px] font-mono text-emerald-700 dark:text-emerald-400 border-emerald-500/30 bg-emerald-50/50 dark:bg-emerald-500/10",
																	children: group.nops[0]
																})]
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																className: "text-[11px] font-mono text-slate-500 dark:text-slate-400 flex items-center gap-2",
																children: group.count > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
																	"NOP Terdaftar: ",
																	group.nops.slice(0, 3).join(", "),
																	group.nops.length > 3 ? ` +${group.nops.length - 3} lagi` : ""
																] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["No STTS: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
																	className: "text-slate-700 dark:text-slate-300",
																	children: group.items[0].noStts
																})] })
															})]
														})
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
														className: "px-4 py-3.5",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																className: "text-xs font-bold text-slate-800 dark:text-slate-200",
																children: group.dusuns.join(", ") || "-"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																className: "text-[11px] text-slate-500 dark:text-slate-400",
																children: group.bloks.join(", ") || "-"
															}),
															isSuperAdmin && filterDesa === "all" && group.items[0]?.namaDesa && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
																variant: "outline",
																className: "mt-1 text-[9px] font-semibold bg-emerald-50/50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/30",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3 mr-0.5 inline" }), group.items[0].namaDesa]
															})
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
														className: "px-4 py-3.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "font-mono text-xs font-semibold text-slate-700 dark:text-slate-300",
															children: group.latestTanggal
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
															variant: "outline",
															className: `text-[9px] font-bold mt-0.5 ${group.metode === "TUNAI" ? "bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/30" : group.metode === "QRIS" ? "bg-purple-500/10 text-purple-700 dark:text-purple-400 border-purple-500/30" : "bg-sky-500/10 text-sky-700 dark:text-sky-400 border-sky-500/30"}`,
															children: group.metode
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
														className: "px-4 py-3.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "font-mono text-xs font-semibold text-slate-800 dark:text-slate-200",
															children: formatRp(group.totalPokok)
														}), group.totalFeeKolektor > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
															className: "font-mono text-[10px] font-bold text-amber-600 dark:text-amber-400",
															children: ["+Fee ", formatRp(group.totalFeeKolektor)]
														}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-[10px] text-slate-400",
															children: "Fee Rp 0"
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "px-4 py-3.5 text-right font-mono font-black text-emerald-700 dark:text-emerald-400 text-sm",
														children: formatRp(group.totalBayar)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "px-4 py-3.5 text-center",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center justify-center gap-1",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
																	size: "sm",
																	variant: "ghost",
																	onClick: () => setBatchDetailTrxs(group.items),
																	className: "h-8 px-2 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-50 dark:hover:bg-slate-800 font-semibold text-xs gap-1",
																	title: "Lihat Detail Rincian SPPT",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), " Detail"]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
																	size: "sm",
																	variant: "ghost",
																	onClick: () => {
																		setActiveReceiptTrxs(group.items);
																		setShowReceiptModal(true);
																	},
																	className: "h-8 px-2 text-slate-700 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-slate-800 font-semibold text-xs gap-1",
																	title: "Cetak Resi Pembayaran",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), " Resi"]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																	size: "sm",
																	variant: "ghost",
																	onClick: () => {
																		if (group.count > 1) setVoidGroupTrxs({
																			name: group.namaSppt,
																			trxs: group.items
																		});
																		else setVoidTrx(group.items[0]);
																	},
																	title: "Batalkan Transaksi Ini",
																	className: "h-8 px-2 text-rose-500 hover:bg-rose-500/10 hover:text-rose-600",
																	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-rose-500" })
																})
															]
														})
													})
												]
											}, group.key)) : filteredTransactions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												colSpan: 6,
												className: "py-12 text-center text-slate-500",
												children: "Tidak ada data transaksi penerimaan yang sesuai."
											}) }) : filteredTransactions.map((trx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
												className: "hover:bg-emerald-50/50 dark:hover:bg-slate-800/40 transition-colors",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "px-4 py-3.5",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "space-y-0.5",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																className: "font-extrabold text-slate-900 dark:text-slate-100 text-sm",
																children: trx.namaSppt
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
																className: "font-mono text-[11px] text-slate-500 flex items-center gap-2",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["NOP: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
																		className: "text-emerald-700 dark:text-emerald-400",
																		children: trx.nop
																	})] }),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
																	/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["STTS: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: trx.noStts })] })
																]
															})]
														})
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
														className: "px-4 py-3.5",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																className: "text-xs font-bold text-slate-800 dark:text-slate-200",
																children: trx.dusun
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																className: "text-[11px] text-slate-500 dark:text-slate-400",
																children: trx.blok
															}),
															isSuperAdmin && filterDesa === "all" && trx.namaDesa && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
																variant: "outline",
																className: "mt-1 text-[9px] font-semibold bg-emerald-50/50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/30",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3 mr-0.5 inline" }), trx.namaDesa]
															})
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
														className: "px-4 py-3.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "font-mono text-xs font-semibold text-slate-700 dark:text-slate-300",
															children: trx.tanggal
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
															variant: "outline",
															className: `text-[9px] font-bold mt-0.5 ${trx.metode === "TUNAI" ? "bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/30" : trx.metode === "QRIS" ? "bg-purple-500/10 text-purple-700 dark:text-purple-400 border-purple-500/30" : "bg-sky-500/10 text-sky-700 dark:text-sky-400 border-sky-500/30"}`,
															children: trx.metode
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
														className: "px-4 py-3.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "font-mono text-xs font-semibold text-slate-800 dark:text-slate-200",
															children: formatRp(trx.pokok)
														}), trx.feeKolektor > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
															className: "font-mono text-[10px] font-bold text-amber-600 dark:text-amber-400",
															children: ["+Fee ", formatRp(trx.feeKolektor)]
														}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-[10px] text-slate-400",
															children: "Fee Rp 0"
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "px-4 py-3.5 text-right font-mono font-black text-emerald-700 dark:text-emerald-400 text-sm",
														children: formatRp(trx.totalBayar)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "px-4 py-3.5 text-center",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center justify-center gap-1",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
																size: "sm",
																variant: "ghost",
																onClick: () => {
																	setActiveReceiptTrxs([trx]);
																	setShowReceiptModal(true);
																},
																className: "h-8 px-2 text-slate-700 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-slate-800 font-semibold text-xs gap-1",
																title: "Cetak Resi Pembayaran",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), " Resi"]
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																size: "sm",
																variant: "ghost",
																onClick: () => setVoidTrx(trx),
																title: "Batalkan Transaksi Ini",
																className: "h-8 px-2 text-rose-500 hover:bg-rose-500/10 hover:text-rose-600",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-rose-500" })
															})]
														})
													})
												]
											}, trx.id))
										})]
									})
								})]
							})]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReceiptModal, {
				open: showReceiptModal,
				onOpenChange: setShowReceiptModal,
				activeReceiptTrxs,
				receiptPaperFormat,
				settings,
				onTriggerPrint: triggerPrint
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BatchInspectorModal, {
				open: !!batchDetailTrxs,
				onOpenChange: (open) => !open && setBatchDetailTrxs(null),
				inspectBatchTrxs: batchDetailTrxs || [],
				onOpenReceiptModal: (trxs) => {
					setActiveReceiptTrxs(trxs);
					setShowReceiptModal(true);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CustomGroupingModal, {
				open: showCreateGroupModal,
				onOpenChange: setShowCreateGroupModal,
				availableTrxs: transactions,
				onCreateCustomGroup: (selectedIds, groupName) => {
					createCustomGroup(selectedIds, groupName);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportExportModal, {
				open: showRecapModal,
				onOpenChange: setShowRecapModal,
				transactions: filteredTransactions,
				dusunRecap,
				stats,
				settings,
				isSuperAdmin,
				filterDesa,
				selectedDesaName: selectedDesaObj?.nama_desa,
				selectedDesaKades: selectedDesaObj?.nama_kades,
				selectedDesaNipKades: selectedDesaObj?.nip_kades,
				onTriggerPrint: triggerPrint,
				onExportExcel: handleExportExcel,
				onExportCSV: handleExportCSV
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: !!voidTrx,
				onOpenChange: (open) => !open && setVoidTrx(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, {
					className: "bg-slate-950 border-slate-800 text-slate-100 max-w-md rounded-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogTitle, {
						className: "text-base font-bold text-rose-400 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-5" }), " Batalkan / Void Transaksi Ini?"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogDescription, {
						className: "text-slate-400 text-xs space-y-2 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"Transaksi dengan No STTS ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-slate-200 font-mono",
								children: voidTrx?.noStts
							}),
							" milik Wajib Pajak",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-slate-200",
								children: voidTrx?.namaSppt
							}),
							" (NOP: ",
							voidTrx?.nop,
							") senilai",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-emerald-400 font-mono",
								children: voidTrx ? formatRp(voidTrx.totalBayar) : ""
							}),
							" akan dibatalkan."
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-amber-400 text-[11px] bg-amber-500/10 border border-amber-500/20 p-2 rounded-lg",
							children: [
								"⚠️ Status SPPT di database DHKP akan secara otomatis dikembalikan ke ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "BELUM LUNAS" }),
								"."
							]
						})]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
						className: "border-slate-800 bg-slate-900 text-slate-300 hover:bg-slate-800 text-xs",
						children: "Batal"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
						onClick: handleVoidTransaction,
						className: "bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs",
						children: "Ya, Batalkan Transaksi"
					})] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: !!voidGroupTrxs,
				onOpenChange: (open) => !open && setVoidGroupTrxs(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, {
					className: "bg-slate-950 border-slate-800 text-slate-100 max-w-md rounded-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogTitle, {
						className: "text-base font-bold text-rose-400 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-5" }), " Batalkan Kelompok Setoran Ini?"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogDescription, {
						className: "text-slate-400 text-xs space-y-2 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"Kelompok pembayaran milik Wajib Pajak ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-slate-200",
								children: voidGroupTrxs?.name
							}),
							" sebanyak",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
								className: "text-amber-400 font-bold",
								children: [voidGroupTrxs?.trxs.length, " SPPT"]
							}),
							" dengan total setoran",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-emerald-400 font-mono",
								children: voidGroupTrxs ? formatRp(voidGroupTrxs.trxs.reduce((sum, t) => sum + t.totalBayar, 0)) : ""
							}),
							" ",
							"akan dibatalkan sekaligus."
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-amber-400 text-[11px] bg-amber-500/10 border border-amber-500/20 p-2 rounded-lg",
							children: [
								"⚠️ Seluruh SPPT dalam kelompok ini akan secara otomatis dikembalikan ke status ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "BELUM LUNAS" }),
								" di DHKP."
							]
						})]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
						className: "border-slate-800 bg-slate-900 text-slate-300 hover:bg-slate-800 text-xs",
						children: "Batal"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
						onClick: handleVoidGroupTransaction,
						className: "bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs",
						children: "Ya, Batalkan Kelompok Transaksi"
					})] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!batchDetailTrxs,
				onOpenChange: (open) => !open && setBatchDetailTrxs(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-2xl bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 p-6 rounded-2xl shadow-2xl space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
							className: "border-b border-emerald-100 dark:border-slate-800 pb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
									className: "text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "size-4 text-emerald-600 dark:text-emerald-400" }),
										" Rincian Setoran Kolektif (",
										batchDetailTrxs?.length || 0,
										" NOP)"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									className: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/30 font-bold px-3 py-1 text-xs",
									children: batchDetailTrxs?.[0]?.metode || "TUNAI"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
								className: "text-xs text-slate-500 dark:text-slate-400",
								children: "Pengelompokan transaksi setoran kasir untuk beberapa NOP SPPT sekaligus."
							})]
						}),
						batchDetailTrxs && batchDetailTrxs.length > 0 && (() => {
							const first = batchDetailTrxs[0];
							const totalSetoran = batchDetailTrxs.reduce((sum, t) => sum + t.totalBayar, 0);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-4 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 sm:grid-cols-3 gap-3 p-3.5 rounded-xl border border-emerald-100 dark:border-slate-800 bg-emerald-50/50 dark:bg-slate-900/60",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] text-slate-500 dark:text-slate-400 font-semibold block",
												children: "Wajib Pajak / Pengumpul"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-bold text-slate-900 dark:text-slate-100 text-sm",
												children: first.namaSppt
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] text-slate-500 dark:text-slate-400 font-semibold block",
												children: "Waktu Transaksi"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono text-slate-700 dark:text-slate-300",
												children: first.tanggal
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] text-slate-500 dark:text-slate-400 font-semibold block",
												children: "Petugas Penerima"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold text-slate-800 dark:text-slate-200",
												children: first.petugas
											})] })
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "rounded-xl border border-emerald-100 dark:border-slate-800 overflow-hidden",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
											className: "w-full text-left text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
												className: "bg-emerald-50/80 dark:bg-slate-900/90 text-emerald-950 dark:text-slate-400 uppercase font-bold text-[10px] border-b border-emerald-100 dark:border-slate-800",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-2.5",
														children: "No STTS"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-2.5",
														children: "NOP / Lokasi"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-2.5 text-right",
														children: "Pokok"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-2.5 text-right",
														children: "Fee Kolektor"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
														className: "p-2.5 text-right",
														children: "Total"
													})
												] })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
												className: "divide-y divide-emerald-100/60 dark:divide-slate-800/60 text-slate-800 dark:text-slate-300",
												children: batchDetailTrxs.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
													className: "hover:bg-emerald-50/40 dark:hover:bg-slate-900/40",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "p-2.5 font-mono font-bold text-emerald-700 dark:text-emerald-400",
															children: t.noStts
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
															className: "p-2.5",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "font-mono font-bold block",
																children: t.nop
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: "text-[10px] text-slate-500",
																children: [
																	t.dusun,
																	" (",
																	t.blok,
																	") • Thn ",
																	t.tahun
																]
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "p-2.5 text-right font-mono",
															children: formatRp(t.pokok)
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "p-2.5 text-right font-mono text-amber-600 dark:text-amber-400",
															children: t.feeKolektor > 0 ? `+${formatRp(t.feeKolektor)}` : "-"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
															className: "p-2.5 text-right font-mono font-bold text-emerald-700 dark:text-emerald-400",
															children: formatRp(t.totalBayar)
														})
													]
												}, t.id))
											})]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between p-4 rounded-xl border border-emerald-500/30 bg-emerald-500/10",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] uppercase font-bold text-emerald-800 dark:text-emerald-300",
											children: "Total Setoran Kolektif"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-slate-500",
											children: [batchDetailTrxs.length, " SPPT Terbayar Sekaligus"]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-right",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xl font-black font-mono text-emerald-700 dark:text-emerald-400",
												children: formatRp(totalSetoran)
											})
										})]
									})
								]
							});
						})(),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
							className: "pt-3 border-t border-emerald-100 dark:border-slate-800 flex justify-between items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setBatchDetailTrxs(null),
								className: "border-emerald-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 text-xs",
								children: "Tutup"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [batchDetailTrxs && batchDetailTrxs[0]?.customGroupId && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: () => {
										const cid = batchDetailTrxs[0].customGroupId;
										const cname = batchDetailTrxs[0].customGroupName || batchDetailTrxs[0].namaSppt;
										setBatchDetailTrxs(null);
										handleDissolveGroup(cid, cname);
									},
									className: "border-amber-300 dark:border-amber-900/60 text-amber-700 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40 text-xs gap-1 font-bold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Unlink, { className: "size-3.5 text-amber-600 dark:text-amber-400" }), " Lepas Pengelompokan Ini"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: () => {
										if (batchDetailTrxs) {
											setActiveReceiptTrxs(batchDetailTrxs);
											setShowReceiptModal(true);
										}
									},
									className: "bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs gap-1.5 shadow-md",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-3.5" }), " Cetak Resi Kolektif 1-Lembar"]
								})]
							})]
						})
					]
				})
			})
		]
	});
}
//#endregion
export { PenerimaanPage as component };
