import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as apiClient } from "./authStore-CZRDvP0Z.mjs";
import { n as getGlobalSettings } from "./settingsStore-BBOTJBY5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/penerimaanStore-Dy63tgZo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/**
* Dhkp API Service Layer
* Interfaces frontend with backend DHKP Objek Pajak endpoints.
*/
function mapBackendToDhkpRow(raw) {
	const status = raw.status_bayar === "LUNAS" || raw.status === "LUNAS" ? "LUNAS" : "BELUM";
	return {
		id: Number(raw.id),
		desaId: raw.desa_id ? Number(raw.desa_id) : raw.desa?.id ? Number(raw.desa.id) : void 0,
		namaDesa: raw.desa?.nama_desa || raw.nama_desa || void 0,
		jumlahSppt: Number(raw.jumlahSppt || raw.jumlah_sppt || 1),
		nop: String(raw.nop || ""),
		namaSppt: String(raw.nama_wp || raw.namaSppt || ""),
		namaAktual: String(raw.nama_aktual || raw.nama_wp || raw.namaSppt || raw.namaAktual || "-"),
		alamatPemilik: String(raw.alamat_wp || raw.alamatPemilik || raw.dusun || ""),
		lokasi: String(raw.alamat_op || raw.lokasi || raw.dusun || ""),
		dusun: String(raw.dusun || "BALOK"),
		blok: String(raw.blok || "Blok 01"),
		tahun: Number(raw.tahun) || 2026,
		tagihan: Number(raw.ketetapan_pbb ?? raw.tagihan ?? 0),
		dibulatkan: Number(raw.dibulatkan ?? raw.ketetapan_pbb ?? raw.tagihan ?? 0),
		round: Number(raw.round ?? 0),
		feeKolektor: Number(raw.fee_kolektor ?? 0),
		denda: Number(raw.denda ?? 0),
		totalBayar: Number(raw.total_bayar ?? Number(raw.ketetapan_pbb ?? raw.tagihan ?? 0) + Number(raw.fee_kolektor ?? 0) + Number(raw.denda ?? 0)),
		status,
		domisili: raw.domisili === "LUAR_DESA" ? "LUAR_DESA" : "DALAM_DESA",
		riwayatBayar: raw.transaksi ? [{
			id: String(raw.transaksi.id),
			tanggal: raw.transaksi.tanggal_transaksi || raw.tanggal_bayar || "",
			jumlah: Number(raw.transaksi.total_bayar || raw.total_bayar || 0),
			metode: raw.transaksi.metode_pembayaran || "TUNAI",
			petugas: "Kolektor Desa",
			noResi: raw.transaksi.nomor_stts || ""
		}] : raw.riwayatBayar || []
	};
}
function mapDhkpRowToBackend(row) {
	const payload = {};
	if (row.nop !== void 0) payload.nop = row.nop;
	if (row.desaId !== void 0) payload.desa_id = row.desaId;
	if (row.namaSppt !== void 0) payload.nama_wp = row.namaSppt;
	if (row.namaAktual !== void 0) payload.nama_aktual = row.namaAktual;
	if (row.alamatPemilik !== void 0) payload.alamat_wp = row.alamatPemilik;
	if (row.lokasi !== void 0) payload.alamat_op = row.lokasi;
	if (row.dusun !== void 0) payload.dusun = row.dusun;
	if (row.blok !== void 0) payload.blok = row.blok;
	if (row.tahun !== void 0) payload.tahun = row.tahun;
	if (row.tagihan !== void 0) payload.ketetapan_pbb = row.tagihan;
	if (row.domisili !== void 0) payload.domisili = row.domisili;
	if (row.status !== void 0) payload.status_bayar = row.status === "LUNAS" ? "LUNAS" : "BELUM_BAYAR";
	if (row.nop) {
		payload.luas_bumi = 100;
		payload.luas_bangunan = 50;
		payload.njop_bumi = 1e5;
		payload.njop_bangunan = 2e5;
		payload.denda = row.denda ?? 0;
		if (row.feeKolektor !== void 0) payload.fee_kolektor = row.feeKolektor;
	}
	return payload;
}
var dhkpService = {
	async getDhkpList(params) {
		const res = await apiClient.get("/dhkp", params);
		const mappedData = Array.isArray(res.data) ? res.data.map(mapBackendToDhkpRow) : [];
		return {
			...res,
			data: mappedData
		};
	},
	async getDhkpById(id) {
		const res = await apiClient.get(`/dhkp/${id}`);
		return {
			...res,
			data: mapBackendToDhkpRow(res.data)
		};
	},
	async createDhkp(data) {
		const payload = mapDhkpRowToBackend(data);
		const res = await apiClient.post("/dhkp", payload);
		return {
			...res,
			data: mapBackendToDhkpRow(res.data)
		};
	},
	async updateDhkp(id, data) {
		const payload = mapDhkpRowToBackend(data);
		const res = await apiClient.put(`/dhkp/${id}`, payload);
		return {
			...res,
			data: mapBackendToDhkpRow(res.data)
		};
	},
	async deleteDhkp(id) {
		return apiClient.delete(`/dhkp/${id}`);
	},
	async getKpiSummary(tahun = 2026, dusun, desaId) {
		return apiClient.get("/dhkp/summary", {
			tahun,
			dusun,
			desa_id: desaId
		});
	},
	async importDhkp(rows) {
		const backendRows = rows.map(mapDhkpRowToBackend);
		return apiClient.post("/dhkp/import", { rows: backendRows });
	},
	async previewReset(tahun, desaId) {
		return apiClient.get("/dhkp/reset-preview", {
			tahun,
			desa_id: desaId
		});
	},
	async resetDhkp(params) {
		return apiClient.post("/dhkp/reset", params);
	}
};
/**
* Penerimaan & Transaction API Service Layer
* Interfaces frontend with backend Cashier, STTS, Void, and Grouping endpoints.
*/
function mapBackendToTransactions(rawInput) {
	const rawArray = Array.isArray(rawInput) ? rawInput : rawInput && typeof rawInput === "object" && Array.isArray(rawInput.data) ? rawInput.data : [];
	if (!Array.isArray(rawArray) || rawArray.length === 0) return [];
	const result = [];
	rawArray.forEach((raw) => {
		if (!raw || typeof raw !== "object") return;
		const dhkpRows = raw.dhkp_rows || raw.dhkpRows || [];
		const operatorName = raw.operator?.name || raw.petugas || "Kolektor Desa";
		const desaIdVal = raw.desa_id ? Number(raw.desa_id) : raw.desa?.id ? Number(raw.desa.id) : dhkpRows[0]?.desa_id ? Number(dhkpRows[0].desa_id) : dhkpRows[0]?.desa?.id ? Number(dhkpRows[0].desa.id) : void 0;
		const namaDesaVal = raw.desa?.nama_desa || raw.namaDesa || dhkpRows[0]?.desa?.nama_desa || void 0;
		if (dhkpRows.length === 0) result.push({
			id: String(raw.id || raw.noStts),
			desaId: desaIdVal,
			namaDesa: namaDesaVal,
			noStts: raw.nomor_stts || raw.noStts || `STTS-${raw.id}`,
			tanggal: raw.tanggal_transaksi || raw.tanggal || (/* @__PURE__ */ new Date()).toISOString(),
			nop: raw.nop || "1.0001",
			namaSppt: raw.nama_wp || raw.namaSppt || "Wajib Pajak",
			dusun: raw.dusun || "BALOK",
			blok: raw.blok || "Blok 01",
			tahun: Number(raw.tahun || 2026),
			pokok: Number(raw.total_pokok || raw.pokok || 0),
			feeKolektor: Number(raw.total_fee || raw.feeKolektor || 0),
			diskon: 0,
			totalBayar: Number(raw.total_bayar || raw.totalBayar || 0),
			metode: raw.metode_pembayaran || raw.metode || "TUNAI",
			petugas: operatorName,
			batchId: raw.metadata_kk?.batchId || raw.batchId,
			batchTotalItems: raw.metadata_kk?.batchTotalItems || raw.batchTotalItems,
			customGroupId: raw.metadata_kk?.customGroupId || raw.customGroupId,
			customGroupName: raw.metadata_kk?.customGroupName || raw.customGroupName
		});
		else dhkpRows.forEach((item) => {
			const itemDesaId = item.desa_id ? Number(item.desa_id) : item.desa?.id ? Number(item.desa.id) : desaIdVal;
			const itemNamaDesa = item.desa?.nama_desa || item.namaDesa || namaDesaVal;
			result.push({
				id: `TRX-${raw.id}-${item.id}`,
				desaId: itemDesaId,
				namaDesa: itemNamaDesa,
				noStts: raw.nomor_stts || raw.noStts || `STTS-${raw.id}`,
				tanggal: raw.tanggal_transaksi || raw.tanggal || (/* @__PURE__ */ new Date()).toISOString(),
				nop: item.nop || raw.nop,
				namaSppt: item.nama_wp || item.namaSppt || raw.namaSppt,
				dusun: item.dusun || raw.dusun,
				blok: item.blok || raw.blok,
				tahun: Number(item.tahun || raw.tahun || 2026),
				pokok: Number(item.ketetapan_pbb || item.pokok || 0),
				feeKolektor: Number(item.fee_kolektor || item.feeKolektor || 0),
				diskon: 0,
				totalBayar: Number((item.ketetapan_pbb || 0) + (item.fee_kolektor || 0)),
				metode: raw.metode_pembayaran || raw.metode || "TUNAI",
				petugas: operatorName,
				batchId: dhkpRows.length > 1 ? `BATCH-${raw.id}` : void 0,
				batchTotalItems: dhkpRows.length > 1 ? dhkpRows.length : void 0,
				customGroupId: raw.metadata_kk?.customGroupId || raw.customGroupId,
				customGroupName: raw.metadata_kk?.customGroupName || raw.customGroupName
			});
		});
	});
	return result;
}
var penerimaanService = {
	async getTransactions(params) {
		const res = await apiClient.get("/transactions", params);
		const data = mapBackendToTransactions(res.data);
		return {
			...res,
			data
		};
	},
	async processPayment(payload) {
		const res = await apiClient.post("/transactions", payload);
		const data = mapBackendToTransactions(Array.isArray(res.data) ? res.data : [res.data]);
		return {
			...res,
			data
		};
	},
	async voidTransaction(trxId) {
		const numericId = trxId.replace(/\D/g, "") || trxId;
		return apiClient.delete(`/transactions/${numericId}`);
	},
	async createCustomGroup(trxIds, groupName) {
		return apiClient.post("/transactions/group", {
			trxIds,
			groupName
		});
	},
	async dissolveCustomGroup(customGroupId) {
		return apiClient.post("/transactions/ungroup", { customGroupId });
	}
};
function calculateFeeKolektor(pokok, domisili) {
	const settings = getGlobalSettings();
	if (domisili === "LUAR_DESA" && settings.enableFeeKolektorLuarDesa) {
		const feeKolektor = settings.feeKolektorLuarDesa || 5e3;
		return {
			feeKolektor,
			totalBayar: pokok + feeKolektor
		};
	}
	return {
		feeKolektor: 0,
		totalBayar: pokok
	};
}
var defaultLaporanRows = [
	{
		dusun: "Rumah Pasir",
		ketetapanRp: 154e5,
		jumlahSppt: 420,
		pokokMingguLaluStts: 185,
		pokokMingguLaluRp: 65e5,
		pokokMingguIniStts: 45,
		pokokMingguIniRp: 18e5,
		tunggakanMingguLaluStts: 12,
		tunggakanMingguLaluRp: 45e4,
		tunggakanMingguIniStts: 5,
		tunggakanMingguIniRp: 22e4
	},
	{
		dusun: "Rumah Seng",
		ketetapanRp: 128e5,
		jumlahSppt: 380,
		pokokMingguLaluStts: 140,
		pokokMingguLaluRp: 48e5,
		pokokMingguIniStts: 30,
		pokokMingguIniRp: 12e5,
		tunggakanMingguLaluStts: 8,
		tunggakanMingguLaluRp: 32e4,
		tunggakanMingguIniStts: 3,
		tunggakanMingguIniRp: 15e4
	},
	{
		dusun: "Sampan Jambu",
		ketetapanRp: 182e5,
		jumlahSppt: 510,
		pokokMingguLaluStts: 210,
		pokokMingguLaluRp: 75e5,
		pokokMingguIniStts: 60,
		pokokMingguIniRp: 24e5,
		tunggakanMingguLaluStts: 15,
		tunggakanMingguLaluRp: 6e5,
		tunggakanMingguIniStts: 8,
		tunggakanMingguIniRp: 35e4
	},
	{
		dusun: "Balok",
		ketetapanRp: 285e5,
		jumlahSppt: 812,
		pokokMingguLaluStts: 310,
		pokokMingguLaluRp: 112e5,
		pokokMingguIniStts: 75,
		pokokMingguIniRp: 29e5,
		tunggakanMingguLaluStts: 24,
		tunggakanMingguLaluRp: 98e4,
		tunggakanMingguIniStts: 10,
		tunggakanMingguIniRp: 48e4
	},
	{
		dusun: "Cideres",
		ketetapanRp: 24e6,
		jumlahSppt: 704,
		pokokMingguLaluStts: 260,
		pokokMingguLaluRp: 91e5,
		pokokMingguIniStts: 55,
		pokokMingguIniRp: 21e5,
		tunggakanMingguLaluStts: 18,
		tunggakanMingguLaluRp: 72e4,
		tunggakanMingguIniStts: 6,
		tunggakanMingguIniRp: 29e4
	},
	{
		dusun: "Puncak Sari",
		ketetapanRp: 195e5,
		jumlahSppt: 641,
		pokokMingguLaluStts: 190,
		pokokMingguLaluRp: 62e5,
		pokokMingguIniStts: 40,
		pokokMingguIniRp: 15e5,
		tunggakanMingguLaluStts: 14,
		tunggakanMingguLaluRp: 51e4,
		tunggakanMingguIniStts: 4,
		tunggakanMingguIniRp: 18e4
	},
	{
		dusun: "Cipedes",
		ketetapanRp: 135e5,
		jumlahSppt: 518,
		pokokMingguLaluStts: 115,
		pokokMingguLaluRp: 34e5,
		pokokMingguIniStts: 25,
		pokokMingguIniRp: 85e4,
		tunggakanMingguLaluStts: 9,
		tunggakanMingguLaluRp: 34e4,
		tunggakanMingguIniStts: 2,
		tunggakanMingguIniRp: 9e4
	}
];
function computeLaporanRow(raw, index) {
	const pokokSdMingguIniStts = raw.pokokMingguLaluStts + raw.pokokMingguIniStts;
	const pokokSdMingguIniRp = raw.pokokMingguLaluRp + raw.pokokMingguIniRp;
	const tunggakanSdMingguIniStts = raw.tunggakanMingguLaluStts + raw.tunggakanMingguIniStts;
	const tunggakanSdMingguIniRp = raw.tunggakanMingguLaluRp + raw.tunggakanMingguIniRp;
	const jumlahStts = pokokSdMingguIniStts + tunggakanSdMingguIniStts;
	const jumlahRp = pokokSdMingguIniRp + tunggakanSdMingguIniRp;
	const sisaStts = raw.jumlahSppt - jumlahStts;
	const sisaPokokRp = raw.ketetapanRp - jumlahRp;
	const persentase = raw.ketetapanRp > 0 ? jumlahRp / raw.ketetapanRp * 100 : 0;
	return {
		no: index + 1,
		...raw,
		pokokSdMingguIniStts,
		pokokSdMingguIniRp,
		tunggakanSdMingguIniStts,
		tunggakanSdMingguIniRp,
		jumlahStts,
		jumlahRp,
		sisaStts,
		sisaPokokRp,
		persentase: Math.round(persentase * 100) / 100
	};
}
var globalDhkpList = [];
var globalTransactions = [];
var listeners = /* @__PURE__ */ new Set();
function notifyListeners() {
	listeners.forEach((fn) => fn());
}
async function refreshStoreFromApi() {
	try {
		const [dhkpRes, trxRes] = await Promise.allSettled([dhkpService.getDhkpList({ limit: 1e4 }), penerimaanService.getTransactions({ limit: 1e4 })]);
		if (dhkpRes.status === "fulfilled" && Array.isArray(dhkpRes.value.data)) globalDhkpList = dhkpRes.value.data;
		if (trxRes.status === "fulfilled" && Array.isArray(trxRes.value.data)) globalTransactions = trxRes.value.data;
		notifyListeners();
	} catch (err) {
		console.warn("[penerimaanStore] API sync fallback to local memory state:", err);
	}
}
function addGlobalDhkp(row) {
	globalDhkpList = [row, ...globalDhkpList];
	notifyListeners();
	dhkpService.createDhkp(row).then((res) => {
		if (res.data) {
			globalDhkpList = globalDhkpList.map((r) => r.nop === row.nop ? res.data : r);
			notifyListeners();
		}
	}).catch((err) => {
		console.warn("Failed to create DHKP on backend API:", err);
	});
}
function updateGlobalDhkp(id, updated) {
	globalDhkpList = globalDhkpList.map((r) => r.id === id ? {
		...r,
		...updated
	} : r);
	notifyListeners();
	dhkpService.updateDhkp(id, updated).catch((err) => {
		console.warn(`Failed to update DHKP #${id} on backend API:`, err);
	});
}
function deleteGlobalDhkp(id) {
	globalDhkpList = globalDhkpList.filter((r) => r.id !== id);
	notifyListeners();
	dhkpService.deleteDhkp(id).catch((err) => {
		console.warn(`Failed to delete DHKP #${id} on backend API:`, err);
	});
}
function addGlobalTransaction(trx) {
	globalTransactions = [trx, ...globalTransactions];
	globalDhkpList = globalDhkpList.map((r) => r.nop === trx.nop ? {
		...r,
		status: "LUNAS",
		riwayatBayar: [...r.riwayatBayar || [], {
			id: trx.id,
			tanggal: trx.tanggal,
			jumlah: trx.totalBayar,
			metode: trx.metode,
			petugas: trx.petugas,
			noResi: trx.noStts
		}]
	} : r);
	notifyListeners();
	const dhkpTarget = globalDhkpList.find((r) => r.nop === trx.nop);
	if (dhkpTarget) penerimaanService.processPayment({
		nops: [dhkpTarget.nop],
		dhkp_ids: [dhkpTarget.id],
		tahun: dhkpTarget.tahun,
		items: [{
			dhkpId: dhkpTarget.id,
			nop: dhkpTarget.nop,
			namaSppt: dhkpTarget.namaSppt,
			dusun: dhkpTarget.dusun,
			blok: dhkpTarget.blok,
			tahun: dhkpTarget.tahun,
			pokok: dhkpTarget.tagihan,
			domisili: dhkpTarget.domisili
		}],
		metode: trx.metode,
		petugas: trx.petugas,
		uangDibayar: trx.uangDibayar,
		kembalian: trx.kembalian
	}).catch((err) => console.warn("Failed to push transaction to backend API:", err));
}
function deleteGlobalTransaction(trxId) {
	const targetTrx = globalTransactions.find((t) => t.id === trxId);
	if (!targetTrx) return;
	globalTransactions = globalTransactions.filter((t) => t.id !== trxId);
	globalDhkpList = globalDhkpList.map((r) => {
		if (r.nop === targetTrx.nop) {
			const remainingHistory = (r.riwayatBayar || []).filter((h) => h.id !== trxId);
			const isStillPaid = remainingHistory.length > 0;
			return {
				...r,
				status: isStillPaid ? "LUNAS" : "BELUM",
				riwayatBayar: remainingHistory
			};
		}
		return r;
	});
	notifyListeners();
	penerimaanService.voidTransaction(trxId).catch((err) => console.warn("Failed to void transaction on API:", err));
}
function deleteGlobalBatch(batchId) {
	const batchTrxs = globalTransactions.filter((t) => t.batchId === batchId);
	if (batchTrxs.length === 0) return;
	const targetNops = new Set(batchTrxs.map((t) => t.nop));
	const targetTrxIds = new Set(batchTrxs.map((t) => t.id));
	globalTransactions = globalTransactions.filter((t) => t.batchId !== batchId);
	globalDhkpList = globalDhkpList.map((r) => {
		if (targetNops.has(r.nop)) {
			const remainingHistory = (r.riwayatBayar || []).filter((h) => !targetTrxIds.has(h.id));
			return {
				...r,
				status: remainingHistory.length > 0 ? "LUNAS" : "BELUM",
				riwayatBayar: remainingHistory
			};
		}
		return r;
	});
	notifyListeners();
	batchTrxs.forEach((t) => {
		penerimaanService.voidTransaction(t.id).catch((err) => console.warn("Failed to void batch item on API:", err));
	});
}
function deleteGlobalGroup(trxIds) {
	const targetTrxs = globalTransactions.filter((t) => trxIds.includes(t.id));
	if (targetTrxs.length === 0) return;
	const targetNops = new Set(targetTrxs.map((t) => t.nop));
	const targetTrxIdSet = new Set(trxIds);
	globalTransactions = globalTransactions.filter((t) => !targetTrxIdSet.has(t.id));
	globalDhkpList = globalDhkpList.map((r) => {
		if (targetNops.has(r.nop)) {
			const remainingHistory = (r.riwayatBayar || []).filter((h) => !targetTrxIdSet.has(h.id));
			return {
				...r,
				status: remainingHistory.length > 0 ? "LUNAS" : "BELUM",
				riwayatBayar: remainingHistory
			};
		}
		return r;
	});
	notifyListeners();
	trxIds.forEach((id) => {
		penerimaanService.voidTransaction(id).catch((err) => console.warn("Failed to void group item on API:", err));
	});
}
function createCustomGroup(trxIds, groupName) {
	if (trxIds.length === 0) return;
	const groupId = `GRP-${Date.now()}`;
	globalTransactions = globalTransactions.map((t) => trxIds.includes(t.id) ? {
		...t,
		customGroupId: groupId,
		customGroupName: groupName
	} : t);
	notifyListeners();
	penerimaanService.createCustomGroup(trxIds, groupName).catch((err) => console.warn("Failed to save custom group to API:", err));
}
function dissolveCustomGroup(customGroupId) {
	globalTransactions = globalTransactions.map((t) => t.customGroupId === customGroupId ? {
		...t,
		customGroupId: void 0,
		customGroupName: void 0
	} : t);
	notifyListeners();
	penerimaanService.dissolveCustomGroup(customGroupId).catch((err) => console.warn("Failed to dissolve group on API:", err));
}
var apiFetchedOnce = false;
function useDhkpStore() {
	const [dhkpList, setDhkpList] = (0, import_react.useState)(globalDhkpList);
	const [transactions, setTransactions] = (0, import_react.useState)(globalTransactions);
	(0, import_react.useEffect)(() => {
		if (!apiFetchedOnce) {
			apiFetchedOnce = true;
			refreshStoreFromApi();
		}
		const handleUpdate = () => {
			setDhkpList([...globalDhkpList]);
			setTransactions([...globalTransactions]);
		};
		listeners.add(handleUpdate);
		return () => {
			listeners.delete(handleUpdate);
		};
	}, []);
	return {
		dhkpList,
		transactions,
		refreshFromApi: refreshStoreFromApi,
		addDhkp: addGlobalDhkp,
		updateDhkp: updateGlobalDhkp,
		deleteDhkp: deleteGlobalDhkp,
		addTransaction: addGlobalTransaction,
		deleteTransaction: deleteGlobalTransaction,
		deleteBatch: deleteGlobalBatch,
		deleteGroup: deleteGlobalGroup,
		createCustomGroup,
		dissolveCustomGroup
	};
}
//#endregion
export { refreshStoreFromApi as a, dhkpService as i, computeLaporanRow as n, useDhkpStore as o, defaultLaporanRows as r, calculateFeeKolektor as t };
