import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { a as useTenantStore, i as useAuthStore, o as useUserStore, t as ROLE_LABELS } from "./authStore-CZRDvP0Z.mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-YtzMxdp3.mjs";
import { t as Input } from "./input-BBQFjwfK.mjs";
import { i as useSettingsStore } from "./settingsStore-BBOTJBY5.mjs";
import { A as RotateCcw, At as CircleX, C as ShieldAlert, Ct as CreditCard, Et as CloudUpload, Ht as Calendar, L as Pencil, M as Receipt, Mt as CircleAlert, N as Printer, O as Search, P as Plus, St as Database, Wt as Building2, Xt as ArrowLeft, Y as LoaderCircle, Yt as ArrowRight, Z as LayoutGrid, bt as Download, ct as Funnel, d as TrendingUp, f as Trash2, ft as FileText, gt as FileCheck, h as TableProperties, it as History, j as RefreshCw, jt as CircleCheck, mt as FileSpreadsheet, n as Wallet, nt as KeyRound, rt as Info, s as Upload, t as X, u as TriangleAlert, vt as Eye, w as Share2, yt as EyeOff, z as PenLine } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-BnDjHZuV.mjs";
import { t as Badge } from "./badge-DeRhpfUp.mjs";
import { i as CardHeader, n as CardContent, o as formatRp, t as Card } from "./card-CfCIYh5x.mjs";
import { t as desaService } from "./desaService-B2uJrXze.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-C2Ya5HzI.mjs";
import { a as refreshStoreFromApi, i as dhkpService, o as useDhkpStore, t as calculateFeeKolektor } from "./penerimaanStore-Dy63tgZo.mjs";
import { t as Label } from "./label-CiVZqe-N.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-HQswfJbV.mjs";
import { t as Switch } from "./switch-CXK2mflC.mjs";
import { n as getAllowedDusunOptions, r as isDusunAllowed } from "./dusunHelper-BcA75wHe.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-B16iqma3.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as utils, r as writeFileSync, t as readSync } from "../_libs/xlsx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dhkp-Dp5GyNSX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SpptDetailModal = ({ detailRow, onClose, settings, onPaySppt, onViewHistory, onEditSppt }) => {
	if (!detailRow) return null;
	const isPaid = detailRow.status === "LUNAS";
	const feeKolektor = detailRow.domisili === "LUAR_DESA" && settings.enableFeeKolektorLuarDesa ? settings.feeKolektorLuarDesa || 5e3 : 0;
	const pokokKetetapan = detailRow.tagihan ?? detailRow.dibulatkan ?? 0;
	const totalTagihan = pokokKetetapan + feeKolektor;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: !!detailRow,
		onOpenChange: (open) => !open && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-xl bg-slate-950 border-slate-800 text-slate-100 p-6 rounded-2xl shadow-2xl space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
					className: "border-b border-slate-800 pb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
							className: "text-base font-bold text-slate-100 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-5 text-amber-400" }), " Detail Rincian Objek Pajak (SPPT)"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								className: isPaid ? "border-emerald-500/50 bg-emerald-500/10 text-emerald-400 font-bold" : "border-rose-500/50 bg-rose-500/10 text-rose-400 font-bold",
								children: isPaid ? "✓ LUNAS" : "⏳ BELUM LUNAS"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								className: detailRow.domisili === "LUAR_DESA" ? "border-amber-500/50 bg-amber-500/10 text-amber-400 font-bold" : "border-emerald-500/50 bg-emerald-500/10 text-emerald-400 font-bold",
								children: detailRow.domisili === "LUAR_DESA" ? "Warga Luar Desa" : "Warga Dalam Desa"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, {
						className: "text-xs text-slate-400",
						children: ["Nomor Objek Pajak (NOP): ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "font-mono text-emerald-400",
							children: detailRow.nop
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 py-2 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "font-bold text-slate-300 uppercase tracking-wider text-[10px] text-amber-400",
								children: "DATA KEPEMILIKAN & WAJIB PAJAK"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-slate-400 block",
										children: "Nama di SPPT (Terdaftar)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-slate-100 text-sm",
										children: detailRow.namaSppt
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-slate-400 block",
										children: "Nama Pemilik Sekarang"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-slate-100 text-sm",
										children: detailRow.namaAktual || detailRow.namaSppt
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "col-span-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-slate-400 block",
											children: "Alamat Pemilik"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-slate-300 font-medium",
											children: detailRow.alamatPemilik || "Alamat pemilik belum dicatat"
										})]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-bold text-slate-300 uppercase tracking-wider text-[10px] text-emerald-400",
									children: "LOKASI & LETAK OBJEK PAJAK"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-3 gap-2 text-center",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-2 rounded-lg bg-slate-950/60 border border-slate-800",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[9px] text-slate-400 block",
												children: "Dusun / Wilayah"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-bold text-slate-200",
												children: (() => {
													const d = (detailRow.dusun || "").toUpperCase();
													if (d.includes("BALOK") || d.includes("DUSUN 1")) return "Dusun 1";
													if (d.includes("CIDERES") || d.includes("DUSUN 2")) return "Dusun 2";
													if (d.includes("PUNCAK") || d.includes("DUSUN 3") || d.includes("CIPEDES")) return "Dusun 3";
													if (d.includes("LUAR")) return "Luar Desa";
													return detailRow.dusun || "-";
												})()
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-2 rounded-lg bg-slate-950/60 border border-slate-800",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[9px] text-slate-400 block",
												children: "Blok / Wilayah"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-bold text-slate-200",
												children: detailRow.blok
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-2 rounded-lg bg-slate-950/60 border border-slate-800",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[9px] text-slate-400 block",
												children: "Jumlah SPPT"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-bold text-slate-200",
												children: [detailRow.jumlahSppt || 1, " Lembar"]
											})]
										})
									]
								}),
								detailRow.lokasi && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-slate-400 block",
										children: "Alamat / Lokasi Objek Pajak"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-slate-300 font-medium",
										children: detailRow.lokasi
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3.5 rounded-xl bg-emerald-950/20 border border-emerald-500/30 space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "font-bold text-slate-300 uppercase tracking-wider text-[10px] text-emerald-400",
								children: "RINCIAN TAGIHAN & KETETAPAN PAJAK"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5 pt-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between items-center text-slate-300",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
											"Pokok Ketetapan PBB (",
											detailRow.tahun,
											"):"
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono font-bold text-slate-100",
											children: formatRp(pokokKetetapan)
										})]
									}),
									feeKolektor > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between items-center text-amber-400",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Fee Kolektor (Warga Luar Desa):" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono font-bold",
											children: ["+", formatRp(feeKolektor)]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between items-center text-sm font-black pt-2 border-t border-slate-800 text-emerald-400",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "TOTAL TAGIHAN:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-base",
											children: formatRp(totalTagihan)
										})]
									})
								]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
					className: "gap-2 sm:gap-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: onClose,
							className: "border-slate-800 text-slate-300 text-xs",
							children: "Tutup"
						}),
						!isPaid && onPaySppt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => {
								onClose();
								onPaySppt(detailRow);
							},
							className: "bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "size-4" }), " Bayar SPPT Ini"]
						}),
						isPaid && onViewHistory && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => {
								onClose();
								onViewHistory(detailRow);
							},
							className: "bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-4" }), " Lihat Riwayat Setoran"]
						}),
						onEditSppt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: () => {
								onClose();
								onEditSppt(detailRow);
							},
							className: "border-slate-700 bg-slate-900 text-slate-200 hover:bg-slate-800 text-xs gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "size-4" }), " Edit Data"]
						})
					]
				})
			]
		})
	});
};
var ImportDhkpModal = ({ open, onClose, onSuccess, desasList = [], initialDesaId = "1", isSuperAdmin = false }) => {
	const tenant = useTenantStore();
	const [targetDesaId, setTargetDesaId] = (0, import_react.useState)(initialDesaId);
	const [file, setFile] = (0, import_react.useState)(null);
	const [parsedRows, setParsedRows] = (0, import_react.useState)([]);
	const [isDragOver, setIsDragOver] = (0, import_react.useState)(false);
	const [isProcessing, setIsProcessing] = (0, import_react.useState)(false);
	const [isUploading, setIsUploading] = (0, import_react.useState)(false);
	const [uploadProgress, setUploadProgress] = (0, import_react.useState)(null);
	const fileInputRef = (0, import_react.useRef)(null);
	import_react.useEffect(() => {
		if (initialDesaId) setTargetDesaId(initialDesaId);
	}, [initialDesaId]);
	const resetState = () => {
		setFile(null);
		setParsedRows([]);
		setIsProcessing(false);
		setIsUploading(false);
		setUploadProgress(null);
	};
	const handleClose = () => {
		resetState();
		onClose();
	};
	const downloadExcelTemplate = () => {
		try {
			const ws = utils.aoa_to_sheet([
				[
					"NOP",
					"Nama Wajib Pajak (SPPT)",
					"Nama Pemilik Sekarang (Aktual)",
					"Alamat Pemilik Sekarang",
					"Alamat Objek Pajak / Lokasi",
					"Dusun",
					"Blok",
					"Tahun",
					"Tagihan PBB (Rp)",
					"Domisili (DALAM_DESA / LUAR_DESA)",
					"Status Bayar (BELUM / LUNAS)"
				],
				[
					"32.05.010.001.001-0101.0",
					"H. ASEP MULYANA",
					"H. ASEP MULYANA",
					"KP. BALOK RT 01 RW 02",
					"KP. BALOK",
					"Balok",
					"Blok 01",
					2026,
					45e3,
					"DALAM_DESA",
					"BELUM"
				],
				[
					"32.05.010.001.001-0102.0",
					"DRS. BAMBANG SUTRISNO",
					"DRS. BAMBANG SUTRISNO",
					"JL. SOEKARNO HATTA NO 120 BANDUNG",
					"KP. BALOK (KEBUN)",
					"Luar Desa",
					"Blok 01",
					2026,
					435e3,
					"LUAR_DESA",
					"BELUM"
				],
				[
					"32.05.010.002.002-0103.0",
					"HJ. EULIS KOMALASARI",
					"HJ. EULIS KOMALASARI",
					"KP. CIDERES RT 02 RW 01",
					"KP. CIDERES",
					"Cideres",
					"Blok 02",
					2026,
					125e3,
					"DALAM_DESA",
					"LUNAS"
				]
			]);
			ws["!cols"] = [
				{ wch: 26 },
				{ wch: 25 },
				{ wch: 26 },
				{ wch: 35 },
				{ wch: 30 },
				{ wch: 20 },
				{ wch: 14 },
				{ wch: 10 },
				{ wch: 18 },
				{ wch: 28 },
				{ wch: 24 }
			];
			const wb = utils.book_new();
			utils.book_append_sheet(wb, ws, "Template DHKP PBB-P2");
			writeFileSync(wb, "Template_Import_DHKP.xlsx");
			toast.success("Template Excel berhasil diunduh!", { description: "Silakan isi data SPPT sesuai format kolom template." });
		} catch (err) {
			console.error("Download template failed:", err);
			toast.error("Gagal mengunduh template Excel.");
		}
	};
	const downloadCsvTemplate = () => {
		try {
			const blob = new Blob(["NOP,Nama Wajib Pajak,Nama Pemilik Sekarang,Alamat Pemilik Sekarang,Alamat Objek Pajak,Dusun,Blok,Tahun,Tagihan PBB (Rp),Domisili,Status Bayar\n32.05.010.001.001-0101.0,H. ASEP MULYANA,H. ASEP MULYANA,KP. BALOK RT 01 RW 02,KP. BALOK,Balok,Blok 01,2026,45000,DALAM_DESA,BELUM\n32.05.010.001.001-0102.0,DRS. BAMBANG SUTRISNO,DRS. BAMBANG SUTRISNO,JL. SOEKARNO HATTA BANDUNG,KP. BALOK,Luar Desa,Blok 01,2026,435000,LUAR_DESA,BELUM\n32.05.010.002.002-0103.0,HJ. EULIS KOMALASARI,HJ. EULIS KOMALASARI,KP. CIDERES RT 02 RW 01,KP. CIDERES,Cideres,Blok 02,2026,125000,DALAM_DESA,LUNAS\n"], { type: "text/csv;charset=utf-8;" });
			const url = URL.createObjectURL(blob);
			const link = document.createElement("a");
			link.setAttribute("href", url);
			link.setAttribute("download", "Template_Import_DHKP.csv");
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
			toast.success("Template CSV berhasil diunduh!");
		} catch (err) {
			toast.error("Gagal mengunduh template CSV.");
		}
	};
	const processFile = (selectedFile) => {
		setFile(selectedFile);
		setIsProcessing(true);
		const reader = new FileReader();
		reader.onload = (e) => {
			try {
				const workbook = readSync(new Uint8Array(e.target?.result), { type: "array" });
				const firstSheetName = workbook.SheetNames[0];
				const worksheet = workbook.Sheets[firstSheetName];
				const json = utils.sheet_to_json(worksheet, { defval: "" });
				if (json.length === 0) {
					toast.error("File Excel/CSV kosong atau format tidak sesuai.");
					setIsProcessing(false);
					return;
				}
				const parsed = json.map((row, idx) => {
					const keys = Object.keys(row);
					const getVal = (possibleKeys) => {
						const foundKey = keys.find((k) => possibleKeys.some((pk) => k.toLowerCase().trim().includes(pk.toLowerCase())));
						return foundKey ? row[foundKey] : "";
					};
					const rawNop = String(getVal([
						"nop",
						"nomor objek",
						"no_sppt"
					]) || "").trim();
					const rawNamaSppt = String(getVal([
						"nama wajib",
						"nama_wp",
						"nama sppt",
						"nama"
					]) || "").trim();
					const rawNamaAktual = String(getVal([
						"nama pemilik sekarang",
						"pemilik sekarang",
						"nama pemilik",
						"nama_aktual",
						"aktual"
					]) || rawNamaSppt).trim();
					const rawAlamatPemilik = String(getVal([
						"alamat pemilik sekarang",
						"alamat pemilik",
						"alamat_wp",
						"alamat"
					]) || "").trim();
					const rawLokasi = String(getVal([
						"alamat objek",
						"alamat op",
						"lokasi tanah",
						"lokasi",
						"alamat_op"
					]) || "").trim();
					const rawDusun = String(getVal(["dusun", "wilayah"]) || "Balok").trim();
					const rawBlok = String(getVal(["blok"]) || "Blok 01").trim();
					const rawTahun = parseInt(String(getVal(["tahun", "thn"]) || "2026"), 10) || 2026;
					const rawTagihan = parseFloat(String(getVal([
						"tagihan",
						"ketetapan",
						"pbb",
						"jumlah"
					]) || "0").replace(/[^0-9.]/g, "")) || 0;
					const domisili = String(getVal(["domisili", "luar desa"]) || "DALAM_DESA").toUpperCase().includes("LUAR") ? "LUAR_DESA" : "DALAM_DESA";
					const status = String(getVal(["status"]) || "BELUM").toUpperCase().includes("LUNAS") ? "LUNAS" : "BELUM";
					let isValid = true;
					let errorReason = "";
					if (!rawNop) {
						isValid = false;
						errorReason = "NOP wajib diisi";
					} else if (!rawNamaSppt) {
						isValid = false;
						errorReason = "Nama Wajib Pajak wajib diisi";
					} else if (rawTagihan <= 0) {
						isValid = false;
						errorReason = "Tagihan PBB harus lebih besar dari Rp 0";
					}
					return {
						nop: rawNop || `NOP-INVALID-${idx + 1}`,
						namaSppt: rawNamaSppt || "Tanpa Nama",
						namaAktual: rawNamaAktual || rawNamaSppt || "-",
						alamatPemilik: rawAlamatPemilik || rawDusun,
						lokasi: rawLokasi || rawDusun,
						dusun: rawDusun,
						blok: rawBlok,
						tahun: rawTahun,
						tagihan: rawTagihan,
						domisili,
						status,
						isValid,
						errorReason
					};
				});
				setParsedRows(parsed);
				toast.success(`Berhasil membaca ${parsed.length} baris data dari file.`);
			} catch (err) {
				console.error("Failed to parse file:", err);
				toast.error("Format file tidak valid atau rusak. Pastikan file berupa .xlsx atau .csv");
			} finally {
				setIsProcessing(false);
			}
		};
		reader.readAsArrayBuffer(selectedFile);
	};
	const handleFileChange = (e) => {
		if (e.target.files && e.target.files[0]) processFile(e.target.files[0]);
	};
	const handleDrop = (e) => {
		e.preventDefault();
		setIsDragOver(false);
		if (e.dataTransfer.files && e.dataTransfer.files[0]) processFile(e.dataTransfer.files[0]);
	};
	const validRows = parsedRows.filter((r) => r.isValid);
	const invalidRows = parsedRows.filter((r) => !r.isValid);
	const handleConfirmImport = async () => {
		if (validRows.length === 0) {
			toast.error("Tidak ada data valid yang bisa diimport.");
			return;
		}
		setIsUploading(true);
		const selectedDesa = desasList?.find((d) => String(d.id) === targetDesaId);
		const desaIdNum = Number(targetDesaId) || 1;
		const namaDesaStr = selectedDesa?.nama_desa;
		const newDhkpItems = validRows.map((r, idx) => ({
			id: Date.now() + idx,
			desaId: desaIdNum,
			namaDesa: namaDesaStr,
			jumlahSppt: 1,
			nop: r.nop,
			namaSppt: r.namaSppt,
			namaAktual: r.namaAktual,
			alamatPemilik: r.alamatPemilik,
			lokasi: r.lokasi,
			dusun: r.dusun,
			blok: r.blok || "Blok 01",
			tahun: r.tahun,
			tagihan: r.tagihan,
			dibulatkan: r.tagihan,
			round: 0,
			status: r.status,
			domisili: r.domisili,
			riwayatBayar: []
		}));
		const BATCH_SIZE = 500;
		const totalBatches = Math.ceil(newDhkpItems.length / BATCH_SIZE);
		let totalCreated = 0;
		let totalUpdated = 0;
		setUploadProgress({
			currentBatch: 0,
			totalBatches,
			processedCount: 0,
			totalCount: newDhkpItems.length,
			percentage: 0,
			created: 0,
			updated: 0
		});
		try {
			for (let i = 0; i < totalBatches; i++) {
				const batch = newDhkpItems.slice(i * BATCH_SIZE, (i + 1) * BATCH_SIZE);
				const res = await dhkpService.importDhkp(batch);
				if (!res || !res.success) throw new Error(res?.message || `Gagal mengimpor batch data ke-${i + 1}`);
				totalCreated += res.data?.created || 0;
				totalUpdated += res.data?.updated || 0;
				const currentProcessed = Math.min((i + 1) * BATCH_SIZE, newDhkpItems.length);
				const currentPercentage = Math.round(currentProcessed / newDhkpItems.length * 100);
				setUploadProgress({
					currentBatch: i + 1,
					totalBatches,
					processedCount: currentProcessed,
					totalCount: newDhkpItems.length,
					percentage: currentPercentage,
					created: totalCreated,
					updated: totalUpdated
				});
			}
			await refreshStoreFromApi();
			onSuccess(newDhkpItems);
			toast.success(`Berhasil mengimpor ${newDhkpItems.length} data SPPT DHKP!`, { description: `${totalCreated} data baru ditambahkan, ${totalUpdated} data diperbarui untuk ${namaDesaStr ? `Desa ${namaDesaStr}` : "wilayah target"}.` });
			handleClose();
		} catch (err) {
			console.error("Failed to import DHKP rows:", err);
			toast.error(err?.message || "Gagal melakukan pengimporan data ke backend.");
		} finally {
			setIsUploading(false);
			setUploadProgress(null);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (v) => !v && !isUploading && handleClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-3xl max-h-[90vh] w-[95vw] sm:w-full flex flex-col p-0 bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 rounded-2xl shadow-2xl overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
					className: "p-5 pb-3 border-b border-emerald-100 dark:border-slate-800 shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
							className: "text-base font-black text-slate-900 dark:text-slate-100 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, { className: "size-5 text-emerald-600 dark:text-emerald-400" }), "Import Data DHKP PBB-P2 (Excel / CSV)"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "outline",
							className: "border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 font-mono text-[10px]",
							children: "Multi-Tenant Target"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-xs text-slate-500 dark:text-slate-400",
						children: "Unggah file spreadsheet `.xlsx` atau `.csv` untuk memperbarui/menambah ketetapan DHKP Desa secara masal (Mendukung 3.000+ baris data tanpa limit)."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 overflow-y-auto p-5 space-y-4 min-h-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3.5 rounded-xl border border-emerald-100 dark:border-slate-800 bg-emerald-50/40 dark:bg-slate-900/60 space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
								className: "text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), " Desa Ketetapan (Wilayah Target Import)"]
							}), isSuperAdmin && desasList && desasList.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: targetDesaId,
								onValueChange: setTargetDesaId,
								disabled: isUploading,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "bg-white dark:bg-slate-900 border-emerald-200 dark:border-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 h-9 focus:border-emerald-500",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Pilih Desa Tujuan..." })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
									className: "bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-xs",
									children: desasList.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
										value: String(d.id),
										children: [
											d.nama_desa,
											" (",
											d.kode_desa || `ID: ${d.id}`,
											")"
										]
									}, d.id))
								})]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between bg-white dark:bg-slate-900 border border-emerald-200 dark:border-slate-800 p-2.5 rounded-xl text-xs shadow-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
										variant: "outline",
										className: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/30 font-bold px-2 py-0.5 text-[10px]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3 mr-1 text-emerald-600 dark:text-emerald-400" }), " Terkunci Otomatis"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-slate-900 dark:text-slate-100",
										children: desasList?.find((d) => String(d.id) === targetDesaId)?.nama_desa || tenant?.nama_desa || "Desa"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-slate-500 dark:text-slate-400 italic",
									children: "Sesuai Wilayah Kerja Akun Login Anda"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-2.5 p-3 rounded-xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200/60 dark:border-blue-900/40 text-[11px] text-blue-900 dark:text-blue-300 leading-relaxed",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-4 shrink-0 text-blue-600 dark:text-blue-400 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold",
									children: "Otomatis Menimpa Data Lama (Upsert): "
								}),
								"Jika NOP & Tahun Pajak dari file Excel sudah ada di sistem, data lama akan ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold underline",
									children: "langsung ditimpa/diperbarui"
								}),
								" dengan data terbaru dari Excel (tidak terjadi data ganda). Data yang belum pernah ada akan ditambahkan sebagai data baru."
							] })]
						}),
						!file ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-4 rounded-xl bg-emerald-50/40 dark:bg-slate-900/40 border border-emerald-100 dark:border-slate-800 space-y-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-0.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "text-xs font-bold text-slate-900 dark:text-slate-200 flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "size-4 text-amber-500 dark:text-amber-400" }), " Unduh Template Format Import"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] text-slate-600 dark:text-slate-400",
										children: "Gunakan template standar dengan susunan kolom NOP, Nama WP, Dusun / Lokasi Tanah, Tagihan, & Domisili."
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "button",
										onClick: downloadExcelTemplate,
										size: "sm",
										disabled: isUploading,
										className: "bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs h-8 gap-1.5 rounded-lg shadow-sm shadow-emerald-500/10",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" }), " Template Excel (.xlsx)"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "button",
										onClick: downloadCsvTemplate,
										size: "sm",
										variant: "outline",
										disabled: isUploading,
										className: "border-emerald-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-slate-800 text-xs h-8 gap-1.5 rounded-lg",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-3.5 text-amber-500 dark:text-amber-400" }), " CSV (.csv)"]
									})]
								})]
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5 font-medium text-[11px]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "size-3.5 text-emerald-600 dark:text-emerald-400" }), " Template:"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: downloadExcelTemplate,
										className: "text-[11px] font-bold text-emerald-600 dark:text-emerald-400 hover:underline inline-flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3" }), " Unduh .xlsx"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-slate-300 dark:text-slate-700",
										children: "|"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: downloadCsvTemplate,
										className: "text-[11px] font-bold text-slate-600 dark:text-slate-400 hover:underline inline-flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-3 text-amber-500" }), " Unduh .csv"]
									})
								]
							})]
						}),
						!file && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							onDragOver: (e) => {
								e.preventDefault();
								setIsDragOver(true);
							},
							onDragLeave: () => setIsDragOver(false),
							onDrop: handleDrop,
							onClick: () => fileInputRef.current?.click(),
							className: `border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${isDragOver ? "border-emerald-500 bg-emerald-500/10 dark:bg-emerald-500/20" : "border-emerald-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 hover:border-emerald-500/60 hover:bg-emerald-50/40 dark:hover:bg-slate-900"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									ref: fileInputRef,
									onChange: handleFileChange,
									accept: ".xlsx, .xls, .csv",
									className: "hidden"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mx-auto size-12 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 grid place-items-center mb-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, { className: "size-6" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-bold text-slate-800 dark:text-slate-200",
									children: ["Tarik & Lepaskan File Excel/CSV di sini, atau ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-emerald-600 dark:text-emerald-400 underline font-extrabold",
										children: "Klik untuk Pilih File"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-slate-500 dark:text-slate-400 mt-1",
									children: "Mendukung format `.xlsx`, `.xls`, dan `.csv` (Mendukung hingga ribuan data tanpa error)"
								})
							]
						}),
						file && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between p-3 rounded-xl bg-white dark:bg-slate-900 border border-emerald-100 dark:border-slate-800 shadow-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "size-9 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 grid place-items-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, { className: "size-5" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-bold text-slate-900 dark:text-slate-100",
											children: file.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[10px] text-slate-500 dark:text-slate-400 font-mono",
											children: [
												(file.size / 1024).toFixed(1),
												" KB · Total ",
												parsedRows.length.toLocaleString(),
												" Baris Ditemukan"
											]
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex items-center gap-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											size: "sm",
											variant: "ghost",
											onClick: resetState,
											disabled: isUploading,
											className: "h-8 text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-500/10 gap-1 rounded-lg font-bold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" }), " Ganti File"]
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-xs pt-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
											variant: "outline",
											className: "border-emerald-500/40 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 font-bold px-2.5 py-0.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3 mr-1 text-emerald-600 dark:text-emerald-400" }),
												" ",
												validRows.length.toLocaleString(),
												" Valid Siap Import"
											]
										}), invalidRows.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
											variant: "outline",
											className: "border-rose-500/40 bg-rose-500/10 text-rose-700 dark:text-rose-400 font-bold px-2.5 py-0.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-3 mr-1 text-rose-600 dark:text-rose-400" }),
												" ",
												invalidRows.length,
												" Data Tidak Valid (Dilewati)"
											]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[11px] text-slate-500 dark:text-slate-400",
										children: [
											"Pratinjau ",
											Math.min(parsedRows.length, 5),
											" dari ",
											parsedRows.length.toLocaleString(),
											" Baris Data"
										]
									})]
								}),
								isUploading && uploadProgress && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 rounded-xl border border-emerald-300 dark:border-emerald-800/60 bg-emerald-50/80 dark:bg-emerald-950/40 shadow-inner space-y-2 animate-in fade-in duration-200",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-xs font-bold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-2 text-emerald-800 dark:text-emerald-200",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3.5 animate-spin text-emerald-600 dark:text-emerald-400" }),
													"Sedang Mengimpor: Batch ",
													uploadProgress.currentBatch,
													" dari ",
													uploadProgress.totalBatches
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-mono text-emerald-700 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-900/60 px-2 py-0.5 rounded-md text-[11px]",
												children: [uploadProgress.percentage, "%"]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-full bg-slate-200 dark:bg-slate-800 rounded-full h-2.5 overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-300 ease-out",
												style: { width: `${uploadProgress.percentage}%` }
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-[11px] text-slate-600 dark:text-slate-400 pt-0.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
												"Terproses ",
												uploadProgress.processedCount.toLocaleString(),
												" dari ",
												uploadProgress.totalCount.toLocaleString(),
												" baris"
											] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-medium text-emerald-700 dark:text-emerald-400",
												children: [
													uploadProgress.created,
													" baru · ",
													uploadProgress.updated,
													" diperbarui"
												]
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "max-h-52 overflow-y-auto rounded-xl border border-emerald-100 dark:border-slate-800 bg-white dark:bg-slate-950 shadow-sm",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
										className: "w-full text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
											className: "bg-slate-50 dark:bg-slate-900 text-slate-600 dark:text-slate-400 uppercase tracking-wider text-[10px] border-b border-emerald-100 dark:border-slate-800 font-bold sticky top-0 z-10",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
													className: "px-3 py-2",
													children: "NOP"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
													className: "px-3 py-2",
													children: "WAJIB PAJAK"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
													className: "px-3 py-2",
													children: "PEMILIK SEKARANG"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
													className: "px-3 py-2",
													children: "DUSUN / BLOK"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
													className: "px-3 py-2 text-right",
													children: "TAGIHAN (RP)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
													className: "px-3 py-2 text-center",
													children: "DOMISILI"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
													className: "px-3 py-2 text-center",
													children: "STATUS"
												})
											]
										}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, {
											className: "divide-y divide-emerald-100/60 dark:divide-slate-800 text-slate-800 dark:text-slate-200",
											children: parsedRows.slice(0, 8).map((r, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
												className: !r.isValid ? "bg-rose-50 dark:bg-rose-950/20 text-rose-700 dark:text-rose-300" : "hover:bg-emerald-50/30 dark:hover:bg-slate-900/50",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
														className: "px-3 py-2 font-mono text-[11px] font-bold text-emerald-700 dark:text-emerald-400",
														children: r.nop
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
														className: "px-3 py-2 font-semibold text-slate-900 dark:text-slate-100",
														children: r.namaSppt
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
														className: "px-3 py-2 text-slate-700 dark:text-slate-300 font-medium",
														children: r.namaAktual
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
														className: "px-3 py-2 text-slate-600 dark:text-slate-400",
														children: [
															r.dusun,
															" (",
															r.blok,
															")"
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
														className: "px-3 py-2 text-right font-mono font-bold text-slate-900 dark:text-slate-100",
														children: ["Rp ", r.tagihan.toLocaleString("id-ID")]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
														className: "px-3 py-2 text-center",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
															variant: "outline",
															className: r.domisili === "LUAR_DESA" ? "border-amber-500/40 text-amber-700 dark:text-amber-400 bg-amber-500/10 text-[9px]" : "border-emerald-500/40 text-emerald-700 dark:text-emerald-400 bg-emerald-500/10 text-[9px]",
															children: r.domisili === "LUAR_DESA" ? "Luar Desa" : "Dalam Desa"
														})
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
														className: "px-3 py-2 text-center",
														children: r.isValid ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
															variant: "outline",
															className: "border-emerald-500/30 text-emerald-700 dark:text-emerald-400 text-[9px] font-bold",
															children: r.status
														}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
															variant: "outline",
															className: "border-rose-500/30 text-rose-700 dark:text-rose-400 text-[9px] font-bold",
															title: r.errorReason,
															children: ["Error: ", r.errorReason]
														})
													})
												]
											}, idx))
										})]
									})
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
					className: "p-4 border-t border-emerald-100 dark:border-slate-800 bg-slate-50/90 dark:bg-slate-900/90 backdrop-blur-sm shrink-0 flex items-center justify-between sm:justify-between w-full",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: handleClose,
						disabled: isUploading,
						className: "border-emerald-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 text-xs hover:bg-slate-100 dark:hover:bg-slate-800 h-9 px-4",
						children: "Batal"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: handleConfirmImport,
						disabled: !file || validRows.length === 0 || isProcessing || isUploading,
						className: "bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs gap-1.5 shadow-md shadow-emerald-500/20 h-9 px-5",
						children: isUploading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4 animate-spin" }), " Mengimpor Ke Database..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudUpload, { className: "size-4" }),
							" Proses Import (",
							validRows.length.toLocaleString(),
							" Baris Valid)"
						] })
					})]
				})
			]
		})
	});
};
function ResetDhkpModal({ open, onClose, desasList, initialDesaId, isSuperAdmin, onSuccess }) {
	const currentYear = (/* @__PURE__ */ new Date()).getFullYear();
	const availableYears = (0, import_react.useMemo)(() => {
		return Array.from({ length: 6 }, (_, i) => currentYear - 2 + i);
	}, [currentYear]);
	const [step, setStep] = (0, import_react.useState)(1);
	const [selectedTahun, setSelectedTahun] = (0, import_react.useState)("2026");
	const [selectedDesaId, setSelectedDesaId] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [showPassword, setShowPassword] = (0, import_react.useState)(false);
	const [errorMessage, setErrorMessage] = (0, import_react.useState)(null);
	const [preview, setPreview] = (0, import_react.useState)(null);
	const [isLoadingPreview, setIsLoadingPreview] = (0, import_react.useState)(false);
	const [isSubmitting, setIsSubmitting] = (0, import_react.useState)(false);
	const [deletedResult, setDeletedResult] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (open) {
			setStep(1);
			setPassword("");
			setShowPassword(false);
			setErrorMessage(null);
			setDeletedResult(null);
			if (initialDesaId && initialDesaId !== "all") setSelectedDesaId(initialDesaId);
			else if (desasList.length > 0) setSelectedDesaId(String(desasList[0].id));
		}
	}, [
		open,
		initialDesaId,
		desasList
	]);
	const selectedDesaObj = (0, import_react.useMemo)(() => {
		return desasList.find((d) => String(d.id) === selectedDesaId) || null;
	}, [desasList, selectedDesaId]);
	(0, import_react.useEffect)(() => {
		if (!open || !selectedDesaId || !isSuperAdmin) {
			setPreview(null);
			return;
		}
		let isMounted = true;
		setIsLoadingPreview(true);
		dhkpService.previewReset(Number(selectedTahun), Number(selectedDesaId)).then((res) => {
			if (isMounted) setPreview(res.data || null);
		}).catch((err) => {
			if (isMounted) {
				console.warn("[ResetDhkpModal] Preview error:", err);
				setPreview(null);
			}
		}).finally(() => {
			if (isMounted) setIsLoadingPreview(false);
		});
		return () => {
			isMounted = false;
		};
	}, [
		open,
		selectedTahun,
		selectedDesaId,
		isSuperAdmin
	]);
	const namaDesa = selectedDesaObj?.nama_desa || `Desa #${selectedDesaId}`;
	const totalDhkp = preview?.total_dhkp ?? 0;
	const totalKet = preview?.total_ketetapan ?? 0;
	const handleGoToStep2 = () => {
		if (!selectedDesaId) {
			toast.error("Silakan pilih Desa terlebih dahulu!");
			return;
		}
		setErrorMessage(null);
		setStep(2);
	};
	const handleExecuteReset = async (e) => {
		e.preventDefault();
		if (!password.trim()) {
			setErrorMessage("Masukkan Password Super Admin untuk mengonfirmasi!");
			return;
		}
		try {
			setIsSubmitting(true);
			setErrorMessage(null);
			const res = await dhkpService.resetDhkp({
				tahun: Number(selectedTahun),
				desa_id: Number(selectedDesaId),
				password: password.trim()
			});
			if (res.success) {
				setDeletedResult({
					dhkp: res.data?.deleted_dhkp ?? totalDhkp,
					transactions: res.data?.deleted_transactions ?? preview?.total_transaksi ?? 0
				});
				setStep(3);
				toast.success(`Data DHKP Desa ${namaDesa} Tahun ${selectedTahun} berhasil direset.`);
				await onSuccess();
			} else throw new Error(res.message || "Gagal melakukan reset data.");
		} catch (err) {
			console.error("[ResetDhkpModal] Reset failed:", err);
			const msg = err?.message || err?.data?.message || "Password salah atau terjadi kesalahan pada server.";
			setErrorMessage(msg);
		} finally {
			setIsSubmitting(false);
		}
	};
	const handleClose = () => {
		if (!isSubmitting) onClose();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (val) => !val && handleClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-xl rounded-2xl p-0 overflow-hidden border-rose-500/20 shadow-2xl dark:bg-slate-900",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 p-6 text-white relative",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-11 rounded-xl bg-white/15 backdrop-blur-md border border-white/30 flex items-center justify-center shadow-inner",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-6 text-rose-100" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
							className: "text-xl font-black tracking-tight text-white flex items-center gap-2",
							children: ["Reset / Hapus Data DHKP", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								className: "bg-white/20 text-white text-[10px] font-bold border-white/30",
								children: "Super Admin"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, {
							className: "text-rose-100 text-xs mt-0.5 font-medium",
							children: [
								step === 1 && "Langkah 1/2: Pilih Tahun Pajak & Nama Desa untuk ditinjau.",
								step === 2 && "Langkah 2/2: Konfirmasi Pemusnahan Data & Masukkan Password.",
								step === 3 && "Pembersihan Data Selesai."
							]
						})] })]
					})
				}),
				step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-6 space-y-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-5 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs text-rose-900 dark:text-rose-200 leading-relaxed",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold",
									children: "Perhatian:"
								}), " Fitur ini digunakan untuk mengosongkan seluruh data SPPT DHKP dan riwayat pembayaran pada desa dan tahun pajak terpilih."]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
									className: "text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3.5 text-rose-500" }), " Tahun Pajak"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: selectedTahun,
									onValueChange: setSelectedTahun,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "h-10 rounded-xl border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold text-xs cursor-pointer",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Pilih Tahun" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: availableYears.map((yr) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
										value: String(yr),
										className: "font-medium text-xs",
										children: ["Tahun Pajak ", yr]
									}, yr)) })]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
									className: "text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5 text-rose-500" }), " Nama Desa"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: selectedDesaId,
									onValueChange: setSelectedDesaId,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "h-10 rounded-xl border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold text-xs cursor-pointer",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Pilih Desa" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: desasList.map((desa) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
										value: String(desa.id),
										className: "font-medium text-xs",
										children: ["Desa ", desa.nama_desa]
									}, desa.id)) })]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/50 p-4 space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "size-4 text-slate-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold text-slate-800 dark:text-slate-200",
										children: "Kalkulasi Data yang Terdeteksi:"
									})]
								}), isLoadingPreview && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1 text-[11px] text-slate-500 font-medium",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3 animate-spin text-rose-500" }), " Memeriksa..."]
								})]
							}), preview ? preview.total_dhkp > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 sm:grid-cols-4 gap-2 text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-white dark:bg-slate-800 p-2.5 rounded-lg border border-slate-200/80 dark:border-slate-700/60 shadow-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-slate-500 block font-medium",
											children: "Total SPPT"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-base font-black text-rose-600 dark:text-rose-400",
											children: preview.total_dhkp.toLocaleString("id-ID")
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-white dark:bg-slate-800 p-2.5 rounded-lg border border-slate-200/80 dark:border-slate-700/60 shadow-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-slate-500 block font-medium",
											children: "Total Pokok"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-black text-slate-800 dark:text-slate-200 truncate block mt-0.5",
											children: formatRp(preview.total_ketetapan)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-white dark:bg-slate-800 p-2.5 rounded-lg border border-slate-200/80 dark:border-slate-700/60 shadow-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-slate-500 block font-medium",
											children: "SPPT Lunas"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm font-bold text-emerald-600 dark:text-emerald-400",
											children: preview.sppt_lunas.toLocaleString("id-ID")
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-white dark:bg-slate-800 p-2.5 rounded-lg border border-slate-200/80 dark:border-slate-700/60 shadow-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-slate-500 block font-medium",
											children: "Transaksi"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm font-bold text-amber-600 dark:text-amber-400",
											children: preview.total_transaksi.toLocaleString("id-ID")
										})]
									})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center py-3 text-xs font-medium text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/30 rounded-lg border border-amber-200 dark:border-amber-800/40",
								children: [
									"ℹ️ Tidak ditemukan data DHKP untuk Desa ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: namaDesa }),
									" pada Tahun Pajak ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: selectedTahun }),
									" (Sudah Kosong)."
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-center py-3 text-xs text-slate-500",
								children: isLoadingPreview ? "Memuat kalkulasi data..." : "Pilih desa dan tahun untuk melihat data."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
							className: "pt-2 flex flex-col-reverse sm:flex-row gap-2 sm:justify-end",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								onClick: handleClose,
								className: "rounded-xl h-10 text-xs font-semibold cursor-pointer",
								children: "Batal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								onClick: handleGoToStep2,
								disabled: isLoadingPreview || !selectedDesaId || preview !== null && preview.total_dhkp === 0,
								className: "bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs h-10 gap-1.5 rounded-xl shadow-lg shadow-rose-500/20 cursor-pointer",
								children: ["Lanjut ke Konfirmasi ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
							})]
						})
					]
				}),
				step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleExecuteReset,
					className: "p-6 space-y-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border-2 border-rose-500/40 bg-rose-50/70 dark:bg-rose-950/50 p-4 space-y-2.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-rose-700 dark:text-rose-300 font-extrabold text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4.5 text-rose-600 dark:text-rose-400 shrink-0" }), "Konfirmasi Pemusnahan Data DHKP"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs space-y-1.5 text-slate-700 dark:text-slate-300 pl-6 border-l-2 border-rose-300 dark:border-rose-800",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["• Desa Target: ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
											className: "text-slate-900 dark:text-white",
											children: ["Desa ", namaDesa]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["• Tahun Pajak: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "text-slate-900 dark:text-white",
											children: selectedTahun
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
											"• Volume SPPT: ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
												className: "text-rose-600 dark:text-rose-400",
												children: [totalDhkp.toLocaleString("id-ID"), " Data SPPT"]
											}),
											" (",
											formatRp(totalKet),
											")"
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["• Transaksi Terkait: ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [preview?.total_transaksi ?? 0, " Transaksi Pembayaran"] })] })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-rose-700 dark:text-rose-400 italic pt-1",
									children: "⚠️ Data yang dihapus tidak dapat dipulihkan kembali."
								})
							]
						}),
						errorMessage && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3 rounded-xl bg-red-100 dark:bg-red-950/80 border border-red-300 dark:border-red-800 text-red-700 dark:text-red-300 text-xs font-semibold flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-4 shrink-0 text-red-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: errorMessage })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
									className: "text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-3.5 text-rose-500" }), " Masukkan Password Super Admin"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-rose-500 font-semibold",
										children: "*Wajib"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: showPassword ? "text" : "password",
										value: password,
										onChange: (e) => {
											setPassword(e.target.value);
											if (errorMessage) setErrorMessage(null);
										},
										placeholder: "Ketik password login Super Admin aktif Anda...",
										disabled: isSubmitting,
										autoFocus: true,
										className: "h-10 pr-10 rounded-xl border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-mono",
										required: true
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setShowPassword(!showPassword),
										className: "absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 cursor-pointer",
										children: showPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-slate-500 dark:text-slate-400",
									children: "Verifikasi keamanan untuk memastikan hanya Super Admin berwenang yang dapat mengeksekusi penghapusan."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
							className: "pt-2 flex flex-col-reverse sm:flex-row gap-2 sm:justify-end",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "outline",
								onClick: () => setStep(1),
								disabled: isSubmitting,
								className: "rounded-xl h-10 text-xs font-semibold gap-1.5 cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), " Kembali"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: isSubmitting || !password.trim(),
								className: "bg-rose-600 hover:bg-rose-700 text-white font-black text-xs h-10 gap-2 rounded-xl shadow-lg shadow-rose-500/20 cursor-pointer",
								children: isSubmitting ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), " Menghapus Data..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), " Ya, Hapus Permanen Sekarang!"] })
							})]
						})
					]
				}),
				step === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-8 text-center space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-16 rounded-full bg-emerald-100 dark:bg-emerald-950/60 border-2 border-emerald-500 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-9" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-black text-slate-900 dark:text-white",
								children: "Data DHKP Berhasil Dikosongkan!"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-slate-600 dark:text-slate-400",
								children: [
									"Seluruh data DHKP ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: ["Desa ", namaDesa] }),
									" Tahun Pajak ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: selectedTahun }),
									" telah dihapus dari sistem."
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/40 rounded-xl p-3.5 text-xs text-emerald-800 dark:text-emerald-300 max-w-sm mx-auto text-left space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-bold",
									children: "📊 Rincian Penghapusan:"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									"• Data DHKP Dihapus: ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: deletedResult?.dhkp ?? 0 }),
									" baris"
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									"• Transaksi Dibersihkan: ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: deletedResult?.transactions ?? 0 }),
									" transaksi"
								] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "pt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								onClick: handleClose,
								className: "bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs h-10 px-8 rounded-xl cursor-pointer",
								children: "Tutup & Selesai"
							})
						})
					]
				})
			]
		})
	});
}
function ReceiptDialog({ row, amount, open, onOpenChange }) {
	const { settings } = useSettingsStore();
	const tenant = useTenantStore();
	if (!row) return null;
	const now = /* @__PURE__ */ new Date();
	const line = settings.printerFormat === "thermal80" ? "----------------------------------------" : "----------------------------";
	const namaDesa = tenant.nama_desa || settings.namaDesa || "Desa";
	const namaKec = tenant.nama_kecamatan || settings.kecamatan || "Malangbong";
	const namaKab = tenant.nama_kabupaten || settings.kabupaten || "Garut";
	const kodeDesa = tenant.kode_desa || settings.kodeDesa || "3205120004";
	const handleShareStruk = () => {
		const text = `========================================
SIPABAR - BUKTI SETORAN STTS PBB-P2
DESA ${namaDesa.toUpperCase()} - KEC. ${namaKec.toUpperCase()}\n========================================\nNo. Resi     : RSI-${String(row.id).padStart(5, "0")}\nNOP PBB-P2   : ${row.nop}\nNama WP      : ${row.namaSppt}\nLokasi/Dusun : ${row.lokasi}\nTahun Pajak  : ${settings.tahunAktif}\nWaktu Bayar  : ${now.toLocaleString("id-ID")}\nPetugas      : ${settings.namaPetugas}\n----------------------------------------\nTOTAL SETORAN: ${formatRp(amount)}\nSTATUS       : *** LUNAS ***\n========================================\n${settings.footerStruk}\nSIPABAR PBB-P2 • ${kodeDesa}`;
		if (navigator.share) navigator.share({
			title: `Bukti Setoran STTS PBB-P2 ${row.nop}`,
			text
		}).catch(() => {});
		else {
			navigator.clipboard.writeText(text);
			toast.success("Teks resi STTS disalin! Membuka WhatsApp...");
			window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-[360px] bg-slate-900 border-slate-800 text-slate-100",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "text-center text-base text-slate-100 font-extrabold",
					children: "Pratinjau Resi STTS Thermal"
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "receipt mx-auto w-[250px] rounded border border-slate-700 bg-white p-3 text-center uppercase text-slate-950 font-mono text-[11px] leading-tight shadow-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-extrabold text-[12px]",
							children: namaDesa.toUpperCase()
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-bold",
							children: [
								"KEC. ",
								namaKec.toUpperCase(),
								" - ",
								namaKab.toUpperCase()
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px]",
							children: "Tanda Terima Setoran PBB-P2"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-bold",
							children: ["Tahun Pajak ", settings.tahunAktif]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] text-slate-400",
							children: line
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-0.5 text-left normal-case",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["NOP : ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold",
									children: row.nop
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Nama : ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold",
									children: row.namaSppt
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Dusun/Lokasi : ", row.lokasi] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Tanggal : ", now.toLocaleString("id-ID")] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									settings.jabatanPetugas || "Petugas",
									" : ",
									settings.namaPetugas
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["No. Resi : RSI-", String(row.id).padStart(5, "0")] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] text-slate-400",
							children: line
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold tracking-wider",
							children: "TOTAL SETORAN"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[14px] font-black",
							children: formatRp(amount)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] text-slate-400",
							children: line
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-black text-emerald-700 tracking-widest text-[13px] border border-emerald-600 rounded py-0.5 my-1 bg-emerald-50",
							children: "*** LUNAS ***"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "normal-case text-[10px] leading-tight mt-1 text-slate-700",
							children: settings.footerStruk
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-[9px] text-slate-500",
							children: ["SIPABAR PBB-P2 • ", kodeDesa]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
					className: "flex flex-col sm:flex-row gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: handleShareStruk,
						className: "w-full border-emerald-600/50 text-emerald-400 hover:bg-emerald-950/40 font-bold text-xs gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4" }), " Bagikan Struk / WA"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs gap-1.5",
						onClick: () => onOpenChange(false),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), " Cetak Resi Thermal"]
					})]
				})
			]
		})
	});
}
function normalizeDusun(dusun) {
	if (!dusun) return "Dusun 1";
	const d = dusun.trim();
	const upper = d.toUpperCase();
	if (upper === "BALOK" || upper === "DUSUN 1" || upper.includes("DUSUN 1") || upper.includes("BALOK")) return "Dusun 1";
	if (upper === "CIDERES" || upper === "DUSUN 2" || upper.includes("DUSUN 2") || upper.includes("CIDERES")) return "Dusun 2";
	if (upper === "PUNCAK SARI" || upper === "CIPEDES" || upper === "DUSUN 3" || upper.includes("DUSUN 3") || upper.includes("PUNCAK") || upper.includes("CIPEDES")) return "Dusun 3";
	if (upper === "LUAR_DESA" || upper === "LUAR DESA" || upper.includes("LUAR")) return "Luar Desa";
	return d;
}
function formatDusunLabel(dusun) {
	if (!dusun) return "-";
	return normalizeDusun(dusun);
}
var PAGE_SIZE = 8;
function DhkpPage() {
	const { settings } = useSettingsStore();
	const tenant = useTenantStore();
	const { dhkpList: rows, addDhkp, updateDhkp, deleteDhkp, addTransaction, refreshFromApi } = useDhkpStore();
	const { user: authUser } = useAuthStore();
	const { getActiveUser } = useUserStore();
	const currentUser = authUser || getActiveUser();
	const currentRole = currentUser?.role || "SUPER_ADMIN";
	const isSuperAdminSystem = currentRole === "SUPER_ADMIN_SYSTEM" || !currentUser?.desa_id && currentRole === "SUPER_ADMIN";
	const isSuperAdmin = isSuperAdminSystem;
	const canManageDhkp = isSuperAdmin || currentRole === "SUPER_ADMIN" || currentRole === "BENDAHARA";
	const isKolektor = currentRole === "KOLEKTOR";
	const userDusunAkses = currentUser?.dusun_akses || currentUser?.dusunAssigned || "ALL";
	const userDesaId = currentUser?.desa_id ? String(currentUser.desa_id) : tenant?.id ? String(tenant.id) : null;
	const [query, setQuery] = (0, import_react.useState)("");
	const [filterDesa, setFilterDesa] = (0, import_react.useState)("all");
	const [filterTahun, setFilterTahun] = (0, import_react.useState)("all");
	const [filterDusun, setFilterDusun] = (0, import_react.useState)("all");
	const [filterBlok, setFilterBlok] = (0, import_react.useState)("all");
	const [filterStatus, setFilterStatus] = (0, import_react.useState)("all");
	const [filterDomisili, setFilterDomisili] = (0, import_react.useState)("all");
	const [desasList, setDesasList] = (0, import_react.useState)([]);
	const [page, setPage] = (0, import_react.useState)(1);
	const [viewMode, setViewMode] = (0, import_react.useState)("table");
	const [mobileFilterOpen, setMobileFilterOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (isSuperAdmin) desaService.getAll().then((res) => {
			if (res.data) setDesasList(res.data);
		}).catch((err) => console.error("Gagal memuat list desa:", err));
	}, [isSuperAdmin]);
	const availableDusunOptions = (0, import_react.useMemo)(() => {
		let targetRows = rows;
		if (isSuperAdmin && filterDesa !== "all") targetRows = rows.filter((r) => String(r.desaId || r.desa_id) === filterDesa);
		else if (!isSuperAdmin && userDesaId) targetRows = rows.filter((r) => {
			const itemDesaId = r.desaId !== void 0 && r.desaId !== null ? r.desaId : r.desa_id;
			return !itemDesaId || Number(itemDesaId) === Number(userDesaId);
		});
		const dusunSet = /* @__PURE__ */ new Set([
			"Dusun 1",
			"Dusun 2",
			"Dusun 3",
			"Luar Desa"
		]);
		targetRows.forEach((r) => {
			const val = normalizeDusun(r.dusun);
			if (val && !val.toUpperCase().startsWith("KP.") && !val.toUpperCase().startsWith("RT") && !val.toUpperCase().startsWith("RW")) dusunSet.add(val);
		});
		const list = Array.from(dusunSet);
		if (isKolektor) return getAllowedDusunOptions(userDusunAkses, currentRole, list);
		return list;
	}, [
		isSuperAdmin,
		filterDesa,
		userDesaId,
		rows,
		isKolektor,
		userDusunAkses,
		currentRole
	]);
	(0, import_react.useEffect)(() => {
		if (filterDusun !== "all" && filterDusun !== "Luar Desa" && !availableDusunOptions.some((d) => d.toUpperCase() === filterDusun.toUpperCase())) setFilterDusun("all");
	}, [
		filterDesa,
		availableDusunOptions,
		filterDusun
	]);
	const selectedDesaObj = (0, import_react.useMemo)(() => {
		if (filterDesa === "all") return null;
		return desasList.find((d) => String(d.id) === filterDesa) || null;
	}, [filterDesa, desasList]);
	const pageTitle = (0, import_react.useMemo)(() => {
		if (isSuperAdmin) {
			if (filterDesa === "all") return `Data DHKP Se-Kecamatan ${settings.kecamatan || "Malangbong"}`;
			return `Data DHKP Desa ${selectedDesaObj?.nama_desa || "Terpilih"}`;
		}
		return `Data DHKP ${tenant?.nama_desa || settings.namaDesa || "Desa"}`;
	}, [
		isSuperAdmin,
		filterDesa,
		selectedDesaObj,
		tenant,
		settings
	]);
	const pageSubtitle = (0, import_react.useMemo)(() => {
		if (isSuperAdmin) {
			if (filterDesa === "all") return `Rekapitulasi Himpunan Ketetapan Pajak PBB-P2 terpadu seluruh desa di Kecamatan ${settings.kecamatan || "Malangbong"}.`;
			return `Daftar Himpunan Ketetapan Pajak dan status pembayaran PBB-P2 Desa ${selectedDesaObj?.nama_desa || ""}.`;
		}
		return "Daftar Himpunan Ketetapan Pajak, pencarian NOP, dan pengelolaan status pembayaran.";
	}, [
		isSuperAdmin,
		filterDesa,
		selectedDesaObj,
		settings
	]);
	const targetStatusRows = (0, import_react.useMemo)(() => {
		let list = rows;
		if (!isSuperAdmin && userDesaId) list = list.filter((r) => {
			const rowDesaId = r.desaId ? String(r.desaId) : r.desa_id ? String(r.desa_id) : null;
			return !rowDesaId || rowDesaId === userDesaId;
		});
		if (isKolektor) return list.filter((r) => isDusunAllowed(r.dusun || r.lokasi, userDusunAkses, currentRole));
		if (isSuperAdmin && filterDesa !== "all") return list.filter((r) => String(r.desaId || r.desa_id) === filterDesa);
		return list;
	}, [
		rows,
		isKolektor,
		isSuperAdmin,
		filterDesa,
		userDusunAkses,
		currentRole,
		userDesaId
	]);
	const summaryMetrics = (0, import_react.useMemo)(() => {
		const targetRows = targetStatusRows;
		const totalCount = targetRows.length;
		const totalTagihan = targetRows.reduce((sum, r) => sum + (r.tagihan ?? r.dibulatkan ?? 0), 0);
		const lunasRows = targetRows.filter((r) => r.status === "LUNAS");
		const lunasCount = lunasRows.length;
		const lunasAmount = lunasRows.reduce((sum, r) => sum + (r.tagihan ?? r.dibulatkan ?? 0), 0);
		const belumRows = targetRows.filter((r) => r.status === "BELUM");
		return {
			totalCount,
			totalTagihan,
			lunasCount,
			lunasAmount,
			belumCount: belumRows.length,
			belumAmount: belumRows.reduce((sum, r) => sum + (r.tagihan ?? r.dibulatkan ?? 0), 0),
			percent: totalCount > 0 ? Math.round(lunasCount / totalCount * 100) : 0
		};
	}, [targetStatusRows]);
	const [importOpen, setImportOpen] = (0, import_react.useState)(false);
	const [resetOpen, setResetOpen] = (0, import_react.useState)(false);
	const [payRow, setPayRow] = (0, import_react.useState)(null);
	const [rounded, setRounded] = (0, import_react.useState)(true);
	const [receiptRow, setReceiptRow] = (0, import_react.useState)(null);
	const [receiptAmount, setReceiptAmount] = (0, import_react.useState)(0);
	const [detailRow, setDetailRow] = (0, import_react.useState)(null);
	const [historyRow, setHistoryRow] = (0, import_react.useState)(null);
	const [editRow, setEditRow] = (0, import_react.useState)(null);
	const [deleteRow, setDeleteRow] = (0, import_react.useState)(null);
	const [addOpen, setAddOpen] = (0, import_react.useState)(false);
	const [formDesaId, setFormDesaId] = (0, import_react.useState)("");
	const [formNop, setFormNop] = (0, import_react.useState)("");
	const [formJumlahSppt, setFormJumlahSppt] = (0, import_react.useState)("1");
	const [formNamaSppt, setFormNamaSppt] = (0, import_react.useState)("");
	const [formNamaAktual, setFormNamaAktual] = (0, import_react.useState)("");
	const [formAlamatPemilik, setFormAlamatPemilik] = (0, import_react.useState)("");
	const [formDomisili, setFormDomisili] = (0, import_react.useState)("DALAM_DESA");
	const [formDusun, setFormDusun] = (0, import_react.useState)("Dusun 1");
	const [formLokasi, setFormLokasi] = (0, import_react.useState)("");
	const [formBlok, setFormBlok] = (0, import_react.useState)("Blok 01");
	const [formTahun, setFormTahun] = (0, import_react.useState)("2026");
	const [formTagihan, setFormTagihan] = (0, import_react.useState)("");
	const [formDibulatkan, setFormDibulatkan] = (0, import_react.useState)("");
	const [formRound, setFormRound] = (0, import_react.useState)("0");
	const [formStatus, setFormStatus] = (0, import_react.useState)("BELUM");
	const filtered = (0, import_react.useMemo)(() => {
		return rows.filter((r) => {
			const rowDesaId = r.desaId ? String(r.desaId) : r.desa_id ? String(r.desa_id) : null;
			if (!isSuperAdmin && userDesaId && rowDesaId && rowDesaId !== userDesaId) return false;
			if (isKolektor && !isDusunAllowed(r.dusun || r.lokasi, userDusunAkses, currentRole)) return false;
			const q = query.trim().toLowerCase();
			const matchesQuery = !q || [
				r.nop,
				r.namaSppt,
				r.namaAktual,
				r.lokasi,
				r.dusun,
				r.blok,
				r.namaDesa || ""
			].join(" ").toLowerCase().includes(q);
			const matchesDesa = isSuperAdmin ? filterDesa === "all" || rowDesaId === filterDesa : !userDesaId || !rowDesaId || rowDesaId === userDesaId;
			const matchesTahun = filterTahun === "all" || String(r.tahun) === filterTahun;
			const matchesDusun = filterDusun === "all" || (() => {
				const rowDusunNorm = normalizeDusun(r.dusun);
				const fDusunNorm = normalizeDusun(filterDusun);
				if (fDusunNorm === "Luar Desa") return r.domisili === "LUAR_DESA" || rowDusunNorm === "Luar Desa";
				return rowDusunNorm === fDusunNorm;
			})();
			const matchesBlok = isSuperAdmin || filterBlok === "all" || r.blok === filterBlok;
			const matchesStatus = filterStatus === "all" || r.status === filterStatus;
			const matchesDomisili = filterDomisili === "all" || r.domisili === filterDomisili;
			return matchesQuery && matchesDesa && matchesTahun && matchesDusun && matchesBlok && matchesStatus && matchesDomisili;
		});
	}, [
		rows,
		query,
		filterDesa,
		filterTahun,
		filterDusun,
		filterBlok,
		filterStatus,
		filterDomisili,
		isKolektor,
		userDusunAkses,
		currentRole,
		isSuperAdmin,
		userDesaId
	]);
	const hasActiveFilters = query !== "" || filterDesa !== "all" || filterTahun !== "all" || filterDusun !== "all" || filterBlok !== "all" || filterStatus !== "all" || filterDomisili !== "all";
	const resetFilters = () => {
		setQuery("");
		setFilterDesa("all");
		setFilterTahun("all");
		setFilterDusun("all");
		setFilterBlok("all");
		setFilterStatus("all");
		setFilterDomisili("all");
		setPage(1);
	};
	const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
	const currentPage = Math.min(page, totalPages);
	const pageRows = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
	const payAmount = payRow ? rounded ? Math.round(payRow.tagihan / 1e3) * 1e3 : payRow.tagihan : 0;
	const confirmPayment = () => {
		if (!payRow) return;
		const now = /* @__PURE__ */ new Date();
		const dateFormatted = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")} ${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
		const sttsNo = `STTS-${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}-${String(payRow.id).padStart(4, "0")}`;
		const feeInfo = calculateFeeKolektor(payAmount, payRow.domisili);
		const newTrx = {
			id: `TRX-${Date.now()}`,
			noStts: sttsNo,
			tanggal: dateFormatted,
			nop: payRow.nop,
			namaSppt: payRow.namaSppt,
			dusun: payRow.dusun || payRow.lokasi,
			blok: payRow.blok,
			tahun: payRow.tahun,
			pokok: payAmount,
			feeKolektor: feeInfo.feeKolektor,
			diskon: 0,
			totalBayar: feeInfo.totalBayar,
			metode: "TUNAI",
			petugas: "Kolektor Desa",
			uangDibayar: feeInfo.totalBayar,
			kembalian: 0
		};
		addTransaction(newTrx);
		const targetRow = payRow;
		const amt = payAmount;
		setPayRow(null);
		toast.success(`Pembayaran NOP ${targetRow.nop} berhasil diproses`, { description: `Wajib Pajak: ${targetRow.namaSppt} · Resi diterbitkan` });
		setReceiptRow(targetRow);
		setReceiptAmount(amt);
	};
	const openEditModal = (r) => {
		setEditRow(r);
		const userDesaId = currentUser?.desa_id ? String(currentUser.desa_id) : String(tenant?.id || 1);
		setFormDesaId(r.desaId ? String(r.desaId) : r.desa_id ? String(r.desa_id) : userDesaId);
		setFormNop(r.nop);
		setFormJumlahSppt(String(r.jumlahSppt || 1));
		setFormNamaSppt(r.namaSppt);
		setFormNamaAktual(r.namaAktual && r.namaAktual !== "-" ? r.namaAktual : r.namaSppt);
		setFormAlamatPemilik(r.alamatPemilik || "");
		setFormDomisili(r.domisili || "DALAM_DESA");
		setFormDusun(normalizeDusun(r.dusun));
		setFormLokasi(r.lokasi && normalizeDusun(r.lokasi) !== normalizeDusun(r.dusun) ? r.lokasi : "");
		setFormBlok(r.blok || "Blok 01");
		setFormTahun(String(r.tahun));
		setFormTagihan(String(r.tagihan));
		setFormDibulatkan(String(r.dibulatkan || r.tagihan));
		setFormRound(String(r.round || 0));
		setFormStatus(r.status);
	};
	const handleSaveEdit = () => {
		if (!editRow) return;
		const targetDesaId = Number(formDesaId) || editRow.desaId || (currentUser?.desa_id ? Number(currentUser.desa_id) : tenant?.id || 1);
		const targetNamaDesa = desasList.find((d) => Number(d.id) === targetDesaId)?.nama_desa || editRow.namaDesa || tenant?.nama_desa || "Desa";
		updateDhkp(editRow.id, {
			desaId: targetDesaId,
			namaDesa: targetNamaDesa,
			nop: formNop,
			jumlahSppt: parseInt(formJumlahSppt, 10) || 1,
			namaSppt: formNamaSppt,
			namaAktual: formNamaAktual || formNamaSppt,
			alamatPemilik: formAlamatPemilik,
			lokasi: formLokasi || formDusun,
			dusun: formDusun,
			blok: formBlok,
			tahun: parseInt(formTahun, 10) || editRow.tahun,
			tagihan: parseFloat(formTagihan) || editRow.tagihan,
			dibulatkan: parseFloat(formDibulatkan) || parseFloat(formTagihan),
			round: parseFloat(formRound) || 0,
			status: formStatus,
			domisili: formDomisili
		});
		setEditRow(null);
		toast.success("Data SPPT berhasil diperbarui", { description: `NOP ${formNop} · ${formNamaSppt}` });
	};
	const handleConfirmDelete = () => {
		if (!deleteRow) return;
		deleteDhkp(deleteRow.id);
		toast.success("Data SPPT telah dihapus", { description: `NOP ${deleteRow.nop} · ${deleteRow.namaSppt}` });
		setDeleteRow(null);
	};
	const openAddModal = () => {
		const nextId = rows.length > 0 ? Math.max(...rows.map((r) => r.id)) + 1 : 1;
		const userDesaId = currentUser?.desa_id ? String(currentUser.desa_id) : String(tenant?.id || 1);
		const initialDesaId = isSuperAdmin ? filterDesa !== "all" ? filterDesa : desasList[0]?.id ? String(desasList[0].id) : userDesaId : userDesaId;
		setFormDesaId(initialDesaId);
		setFormNop(`1.${String(nextId).padStart(4, "0")}`);
		setFormJumlahSppt("1");
		setFormNamaSppt("");
		setFormNamaAktual("");
		setFormAlamatPemilik("");
		setFormDomisili("DALAM_DESA");
		setFormDusun("Dusun 1");
		setFormLokasi("");
		setFormBlok("Blok 01");
		setFormTahun("2026");
		setFormTagihan("25000");
		setFormDibulatkan("25000");
		setFormRound("0");
		setFormStatus("BELUM");
		setAddOpen(true);
	};
	const handleSaveAdd = () => {
		if (!formNop || !formNamaSppt) {
			toast.error("NOP dan Nama SPPT wajib diisi.");
			return;
		}
		const nextId = rows.length > 0 ? Math.max(...rows.map((r) => r.id)) + 1 : 1;
		const targetDesaId = Number(formDesaId) || (currentUser?.desa_id ? Number(currentUser.desa_id) : tenant?.id || 1);
		const newRow = {
			id: nextId,
			desaId: targetDesaId,
			namaDesa: desasList.find((d) => Number(d.id) === targetDesaId)?.nama_desa || tenant?.nama_desa || "Desa",
			jumlahSppt: parseInt(formJumlahSppt, 10) || 1,
			nop: formNop,
			namaSppt: formNamaSppt,
			namaAktual: formNamaAktual || formNamaSppt,
			alamatPemilik: formAlamatPemilik || formDusun,
			lokasi: formLokasi || formDusun,
			dusun: formDusun,
			blok: formBlok,
			tahun: parseInt(formTahun, 10) || 2026,
			tagihan: parseFloat(formTagihan) || 0,
			dibulatkan: parseFloat(formDibulatkan) || parseFloat(formTagihan) || 0,
			round: parseFloat(formRound) || 0,
			status: formStatus,
			domisili: formDomisili,
			riwayatBayar: []
		};
		addDhkp(newRow);
		setAddOpen(false);
		toast.success("Data SPPT baru berhasil ditambahkan", { description: `NOP ${newRow.nop} · ${newRow.namaSppt}` });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-7xl space-y-6 pb-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-700 via-emerald-600 to-teal-700 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 p-6 text-white shadow-xl border border-emerald-500/30 dark:border-slate-800 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-10 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex items-center gap-2 rounded-full bg-white/15 dark:bg-emerald-500/10 border border-white/30 dark:border-emerald-500/30 px-3 py-1 text-xs font-bold uppercase tracking-wider text-emerald-50 dark:text-emerald-400 backdrop-blur-md",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "size-3.5 text-amber-300" }), " Modul Ketetapan DHKP"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-2xl font-black tracking-tight text-white sm:text-3xl",
								children: pageTitle
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-emerald-50 dark:text-slate-300 font-medium",
								children: pageSubtitle
							})
						]
					}), canManageDhkp && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2.5 shrink-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: openAddModal,
								className: "bg-white hover:bg-emerald-50 text-emerald-950 font-black text-xs h-10 gap-1.5 rounded-xl shadow-lg cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 text-emerald-700" }), " Tambah SPPT Baru"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => setImportOpen(true),
								variant: "outline",
								className: "border-white/40 bg-emerald-800/40 text-white hover:bg-emerald-800/60 font-bold text-xs h-10 gap-1.5 rounded-xl shadow-sm cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4 text-amber-300" }), " Import Excel"]
							}),
							isSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => setResetOpen(true),
								variant: "outline",
								className: "border-rose-300/40 bg-rose-950/40 text-rose-100 hover:bg-rose-900/60 hover:text-white font-bold text-xs h-10 gap-1.5 rounded-xl shadow-sm cursor-pointer transition-all",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-rose-300" }), " Reset Data DHKP"]
							})
						]
					})]
				})
			}),
			!canManageDhkp && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-300 text-xs font-medium flex items-center gap-3 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-5 shrink-0 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-bold",
					children: [
						"Mode Terbatas (Akses Peran: ",
						ROLE_LABELS[currentRole]?.label || currentRole,
						")"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] opacity-90",
					children: isKolektor ? `Tampilan otomatis terfilter untuk Dusun ${userDusunAkses !== "ALL" ? userDusunAkses : "Anda"}. Fitur penambahan SPPT baru dan Impor DHKP khusus untuk Super Admin / Bendahara.` : "Anda sedang dalam mode monitoring eksekutif (Read-Only). Perubahan data DHKP dikelola oleh Super Admin & Bendahara Desa."
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "border-emerald-100 dark:border-slate-800 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md shadow-md",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
							className: "p-4 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-semibold text-slate-500 dark:text-slate-400",
									children: "Total Ketetapan SPPT"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-xl font-black font-mono text-slate-900 dark:text-white mt-1",
									children: [summaryMetrics.totalCount, " SPPT"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-slate-500 mt-0.5",
									children: formatRp(summaryMetrics.totalTagihan)
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "size-5" })
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "border-emerald-100 dark:border-slate-800 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md shadow-md",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
							className: "p-4 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-semibold text-slate-500 dark:text-slate-400",
									children: "Sudah Terbayar (LUNAS)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-xl font-black font-mono text-emerald-600 dark:text-emerald-400 mt-1",
									children: [summaryMetrics.lunasCount, " SPPT"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-emerald-600/80 font-mono mt-0.5",
									children: formatRp(summaryMetrics.lunasAmount)
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5" })
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "border-emerald-100 dark:border-slate-800 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md shadow-md",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
							className: "p-4 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-semibold text-slate-500 dark:text-slate-400",
									children: "Belum Terbayar (Piutang)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-xl font-black font-mono text-rose-600 dark:text-rose-400 mt-1",
									children: [summaryMetrics.belumCount, " SPPT"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-rose-600/80 font-mono mt-0.5",
									children: formatRp(summaryMetrics.belumAmount)
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-10 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-600 dark:text-rose-400 grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-5" })
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "border-emerald-100 dark:border-slate-800 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md shadow-md",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
							className: "p-4 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] font-semibold text-slate-500 dark:text-slate-400",
									children: "Capaian Realisasi"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-xl font-black font-mono text-amber-600 dark:text-amber-400 mt-1",
									children: [summaryMetrics.percent, "%"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[10px] text-slate-500 mt-0.5",
									children: [
										summaryMetrics.lunasCount,
										" dari ",
										summaryMetrics.totalCount,
										" Wajib Pajak"
									]
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-600 dark:text-amber-400 grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-5" })
							})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "overflow-hidden border-emerald-100/80 dark:border-slate-800/80 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md shadow-xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
					className: "space-y-4 border-b border-emerald-100/80 dark:border-slate-800/80 bg-emerald-50/60 dark:bg-slate-950/60 p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-slate-600 dark:text-slate-400",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { className: "size-3.5 text-emerald-600 dark:text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Filter & Pencarian Data DHKP" })]
								}),
								hasActiveFilters && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: resetFilters,
									className: "inline-flex items-center gap-1 text-xs font-bold text-rose-600 dark:text-rose-400 hover:underline cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3" }), "Reset Semua Filter"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setMobileFilterOpen(!mobileFilterOpen),
									className: "sm:hidden inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold shadow-sm cursor-pointer",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { className: "size-3.5" }),
										mobileFilterOpen ? "Tutup" : "Filter",
										hasActiveFilters && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "size-5 rounded-full bg-white text-emerald-700 text-[10px] font-black grid place-items-center",
											children: [
												filterDesa !== "all",
												filterDusun !== "all",
												filterBlok !== "all",
												filterTahun !== "all",
												filterDomisili !== "all"
											].filter(Boolean).length
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: query,
								onChange: (e) => {
									setQuery(e.target.value);
									setPage(1);
								},
								placeholder: "Cari NOP, Nama SPPT, Pemilik, Alamat...",
								className: "h-9 pl-9 border-emerald-200 dark:border-slate-800 bg-white dark:bg-slate-950/80 text-xs text-slate-900 dark:text-slate-200 shadow-sm focus:border-emerald-500"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `grid gap-3 sm:grid-cols-2 lg:grid-cols-5 mobile-filter-panel sm:!max-h-none sm:!opacity-100 ${mobileFilterOpen ? "open" : ""}`,
							children: [
								isSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: filterDesa,
									onValueChange: (v) => {
										setFilterDesa(v);
										setPage(1);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "h-9 text-xs bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-200 font-semibold",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Pilih Desa" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
										className: "bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-200",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "all",
											children: "Semua Desa"
										}), desasList.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
											value: String(d.id),
											children: [
												"Desa ",
												d.nama_desa,
												" (",
												d.kode_desa,
												")"
											]
										}, d.id))]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: filterDusun,
									onValueChange: (v) => {
										setFilterDusun(v);
										setPage(1);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "h-9 text-xs bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-200 font-semibold",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Lokasi Tanah / Dusun" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
										className: "bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-200",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "all",
												children: isKolektor && userDusunAkses !== "ALL" ? "Semua Lokasi Saya" : "Semua Lokasi / Dusun"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Dusun 1",
												children: "Dusun 1"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Dusun 2",
												children: "Dusun 2"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Dusun 3",
												children: "Dusun 3"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Luar Desa",
												children: "Luar Desa"
											}),
											availableDusunOptions.filter((d) => ![
												"Dusun 1",
												"Dusun 2",
												"Dusun 3",
												"Luar Desa"
											].includes(d)).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: d,
												children: d
											}, d))
										]
									})]
								}),
								!isSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: filterBlok,
									onValueChange: (v) => {
										setFilterBlok(v);
										setPage(1);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "h-9 text-xs bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-200",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Pilih Blok" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
										className: "bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-200",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "all",
												children: "Semua Blok"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Blok 01",
												children: "Blok 01"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Blok 02",
												children: "Blok 02"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Blok 03",
												children: "Blok 03"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "Blok 04",
												children: "Blok 04"
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: filterTahun,
									onValueChange: (v) => {
										setFilterTahun(v);
										setPage(1);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "h-9 text-xs bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-200",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Tahun Pajak" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
										className: "bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-200",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "all",
												children: "Semua Tahun"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "2026",
												children: "Tahun 2026"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "2025",
												children: "Tahun 2025"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "2024",
												children: "Tahun 2024"
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: filterDomisili,
									onValueChange: (v) => {
										setFilterDomisili(v);
										setPage(1);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "h-9 text-xs bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-200",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Domisili WP" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
										className: "bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-200",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "all",
												children: "Semua Domisili"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "DALAM_DESA",
												children: "Dalam Desa"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "LUAR_DESA",
												children: "Luar Desa"
											})
										]
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-3 pt-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5 text-xs font-semibold",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-slate-500 dark:text-slate-400 text-[11px] mr-1",
										children: "Status:"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => {
											setFilterStatus("all");
											setPage(1);
										},
										className: `px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${filterStatus === "all" ? "bg-emerald-600 text-white font-black shadow-sm" : "bg-emerald-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-400 hover:bg-emerald-100 dark:hover:bg-slate-700"}`,
										children: [
											"Semua (",
											targetStatusRows.length,
											")"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => {
											setFilterStatus("LUNAS");
											setPage(1);
										},
										className: `px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${filterStatus === "LUNAS" ? "bg-emerald-600 text-white font-black shadow-sm" : "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/20"}`,
										children: [
											"Lunas (",
											targetStatusRows.filter((r) => r.status === "LUNAS").length,
											")"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => {
											setFilterStatus("BELUM");
											setPage(1);
										},
										className: `px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${filterStatus === "BELUM" ? "bg-rose-600 text-white font-black shadow-sm" : "bg-rose-500/10 text-rose-700 dark:text-rose-400 border border-rose-500/30 hover:bg-rose-500/20"}`,
										children: [
											"Belum Lunas (",
											targetStatusRows.filter((r) => r.status === "BELUM").length,
											")"
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1 bg-white dark:bg-slate-950 p-1 rounded-lg border border-emerald-200 dark:border-slate-800",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setViewMode("table"),
										className: `flex items-center gap-1 px-2.5 py-1 text-xs font-bold rounded-md transition-all ${viewMode === "table" ? "bg-emerald-600 text-white shadow-sm" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
										title: "Tampilan Tabel Sleek",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableProperties, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "hidden sm:inline",
											children: "Tabel"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setViewMode("card"),
										className: `flex items-center gap-1 px-2.5 py-1 text-xs font-bold rounded-md transition-all ${viewMode === "card" ? "bg-emerald-600 text-white shadow-sm" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
										title: "Tampilan Kartu Grid Responsive",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "hidden sm:inline",
											children: "Kartu"
										})]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-medium text-slate-600 dark:text-slate-400",
									children: [
										"Ditemukan ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-bold text-slate-900 dark:text-white font-mono",
											children: filtered.length
										}),
										" SPPT"
									]
								})]
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "space-y-4 pt-4",
					children: [viewMode === "table" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto rounded-xl border border-emerald-100 dark:border-slate-800 bg-white dark:bg-slate-950/40",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
							className: "w-full text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
								className: "bg-emerald-50/80 dark:bg-slate-900/90 text-emerald-950 dark:text-slate-400 uppercase tracking-wider font-extrabold border-b border-emerald-100 dark:border-slate-800 text-[10px]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										className: "px-3.5 py-3",
										children: "NOP & TAHUN"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										className: "px-3.5 py-3",
										children: "WAJIB PAJAK / PEMILIK"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										className: "px-3.5 py-3",
										children: "LOKASI & BLOK"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										className: "px-3.5 py-3 text-right",
										children: "TAGIHAN PAJAK"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										className: "px-3.5 py-3 text-center",
										children: "STATUS"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										className: "px-3.5 py-3 text-center",
										children: "PEMBAYARAN"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										className: "px-3.5 py-3 text-center",
										children: "KELOLA"
									})
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, {
								className: "divide-y divide-emerald-100/60 dark:divide-slate-800/60 text-slate-800 dark:text-slate-300",
								children: pageRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									colSpan: 7,
									className: "py-8 text-center text-slate-500",
									children: "Tidak ada data DHKP SPPT yang sesuai dengan filter."
								}) }) : pageRows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
									className: "hover:bg-emerald-50/60 dark:hover:bg-slate-800/40 transition-colors",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
											className: "px-3.5 py-3 font-mono",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-bold text-emerald-700 dark:text-emerald-400 text-xs block",
												children: r.nop
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[10px] text-slate-500 dark:text-slate-400",
												children: [
													"Thn ",
													r.tahun,
													" • ",
													r.jumlahSppt || 1,
													" SPPT"
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
											className: "px-3.5 py-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-bold text-slate-900 dark:text-slate-100 text-xs",
												children: r.namaSppt
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1.5 mt-0.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[11px] text-slate-600 dark:text-slate-400",
													children: ["Pemilik: ", r.namaAktual || "-"]
												}), r.domisili === "LUAR_DESA" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
													variant: "outline",
													className: "bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/30 text-[9px] px-1.5 py-0",
													children: "Luar Desa"
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
													variant: "outline",
													className: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/30 text-[9px] px-1.5 py-0",
													children: "Dalam Desa"
												})]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
											className: "px-3.5 py-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
													variant: "outline",
													className: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/30 text-[10px] px-1.5 py-0 font-bold",
													children: normalizeDusun(r.dusun)
												}), r.lokasi && normalizeDusun(r.lokasi) !== normalizeDusun(r.dusun) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-semibold text-slate-900 dark:text-slate-200 text-xs",
													children: r.lokasi
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-wrap items-center gap-1.5 mt-0.5",
												children: [isSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
													variant: "outline",
													className: "bg-sky-500/10 text-sky-700 dark:text-sky-400 border-sky-500/30 text-[9px] px-1.5 py-0 font-bold",
													children: r.namaDesa ? `Desa ${r.namaDesa}` : "Desa"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[11px] text-slate-500 dark:text-slate-400",
													children: [
														r.blok,
														" • ",
														r.alamatPemilik
													]
												})]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
											className: "px-3.5 py-3 text-right font-mono",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-black text-emerald-700 dark:text-emerald-400 text-xs",
												children: formatRp(r.tagihan ?? r.dibulatkan)
											}), r.feeKolektor && r.feeKolektor > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[9px] text-amber-600 dark:text-amber-400 font-medium",
												children: ["+ Jasa ", formatRp(r.feeKolektor)]
											}) : r.dibulatkan && r.dibulatkan !== r.tagihan ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[9px] text-slate-500",
												children: ["Pokok: ", formatRp(r.tagihan)]
											}) : null]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
											className: "px-3.5 py-3 text-center",
											children: r.status === "LUNAS" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												variant: "outline",
												className: "border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 font-bold px-2.5 py-0.5 rounded-full",
												children: "LUNAS"
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												variant: "outline",
												className: "border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-400 font-bold px-2.5 py-0.5 rounded-full",
												children: "BELUM"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
											className: "px-3.5 py-3 text-center",
											children: r.status === "BELUM" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												size: "sm",
												className: "h-8 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-[11px] px-3 shadow-md shadow-amber-500/10 rounded-lg gap-1.5",
												onClick: () => {
													setRounded(true);
													setPayRow(r);
												},
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-3.5 shrink-0" }), " Bayar SPPT"]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												size: "sm",
												variant: "outline",
												className: "h-8 border-emerald-500/40 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/10 font-bold text-[11px] px-3 rounded-lg gap-1.5",
												onClick: () => setHistoryRow(r),
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-3.5 shrink-0" }), " Riwayat"]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
											className: "px-3.5 py-3 text-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-center gap-1 bg-slate-50 dark:bg-slate-900 border border-emerald-100 dark:border-slate-800 p-1 rounded-xl w-fit mx-auto",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														size: "sm",
														variant: "ghost",
														className: "h-7 size-7 p-0 text-sky-600 dark:text-sky-400 hover:text-sky-700 dark:hover:text-sky-300 hover:bg-sky-500/10 rounded-lg",
														onClick: () => setDetailRow(r),
														title: "Lihat Detail SPPT (Mata)",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5" })
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														size: "sm",
														variant: "ghost",
														className: "h-7 size-7 p-0 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg",
														onClick: () => openEditModal(r),
														title: "Edit Data SPPT",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3.5" })
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														size: "sm",
														variant: "ghost",
														className: "h-7 size-7 p-0 text-rose-600 dark:text-rose-400 hover:text-rose-700 dark:hover:text-rose-300 hover:bg-rose-500/10 rounded-lg",
														onClick: () => setDeleteRow(r),
														title: "Hapus SPPT",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
													})
												]
											})
										})
									]
								}, r.id))
							})]
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
						children: pageRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "col-span-full py-12 text-center text-slate-500",
							children: "Tidak ada data DHKP SPPT yang sesuai dengan filter."
						}) : pageRows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "border-emerald-100 dark:border-slate-800 bg-white dark:bg-slate-950/60 shadow-md hover:shadow-lg transition-all flex flex-col justify-between",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
									className: "p-4 border-b border-emerald-100/60 dark:border-slate-800/60 pb-3 space-y-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono font-black text-emerald-700 dark:text-emerald-400 text-xs",
											children: r.nop
										}), r.status === "LUNAS" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "outline",
											className: "border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 font-bold text-[10px] px-2 py-0.5",
											children: "LUNAS"
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "outline",
											className: "border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-400 font-bold text-[10px] px-2 py-0.5",
											children: "BELUM"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "font-bold text-slate-900 dark:text-slate-100 text-sm",
											children: r.namaSppt
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5",
											children: ["Pemilik: ", r.namaAktual || "-"]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-0.5 bg-slate-50 dark:bg-slate-900 border border-emerald-100 dark:border-slate-800 p-1 rounded-lg shrink-0",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => setDetailRow(r),
													className: "p-1 text-sky-600 dark:text-sky-400 hover:bg-sky-500/10 rounded transition-all",
													title: "Detail SPPT (Mata)",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => openEditModal(r),
													className: "p-1 text-slate-500 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-200 dark:hover:bg-slate-800 rounded transition-all",
													title: "Edit SPPT",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3.5" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => setDeleteRow(r),
													className: "p-1 text-rose-600 hover:bg-rose-500/10 rounded transition-all",
													title: "Hapus SPPT",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
												})
											]
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
									className: "p-4 text-xs space-y-2.5 flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between items-center text-slate-600 dark:text-slate-400",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Lokasi / Dusun:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-semibold text-slate-900 dark:text-slate-200",
												children: [normalizeDusun(r.dusun), r.lokasi && normalizeDusun(r.lokasi) !== normalizeDusun(r.dusun) ? ` • ${r.lokasi}` : ""]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between items-center text-slate-600 dark:text-slate-400",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isSuperAdmin ? "Wilayah Desa:" : "Blok Objek:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold text-slate-900 dark:text-slate-200",
												children: isSuperAdmin ? r.namaDesa ? `Desa ${r.namaDesa}` : "-" : r.blok
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between items-center text-slate-600 dark:text-slate-400",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Tahun / Domisili:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-bold",
													children: r.tahun
												}), r.domisili === "LUAR_DESA" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
													variant: "outline",
													className: "bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/30 text-[9px] px-1 py-0",
													children: "Luar"
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
													variant: "outline",
													className: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/30 text-[9px] px-1 py-0",
													children: "Dalam"
												})]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "pt-2 border-t border-emerald-100/60 dark:border-slate-800/60 flex justify-between items-center",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] text-slate-500 font-medium",
												children: "Tagihan Pajak:"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-right",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-mono font-black text-emerald-700 dark:text-emerald-400 text-sm",
													children: formatRp(r.tagihan ?? r.dibulatkan)
												}), r.feeKolektor && r.feeKolektor > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "block text-[10px] text-amber-600 dark:text-amber-400 font-medium",
													children: ["+ Jasa ", formatRp(r.feeKolektor)]
												}) : null]
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "p-3 bg-emerald-50/40 dark:bg-slate-900/60 border-t border-emerald-100/60 dark:border-slate-800/60 rounded-b-xl",
									children: r.status === "BELUM" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										onClick: () => {
											setRounded(true);
											setPayRow(r);
										},
										className: "w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs gap-1.5 shadow-md shadow-amber-500/10 rounded-lg h-9",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-4" }), " Bayar SPPT Ini"]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => setHistoryRow(r),
										className: "w-full border-emerald-500/40 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/10 font-bold text-xs gap-1.5 rounded-lg h-9",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-4" }), " Lihat Riwayat Setoran"]
									})
								})
							]
						}, r.id))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between pt-2 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-slate-600 dark:text-slate-400",
							children: [
								"Halaman ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold text-slate-900 dark:text-slate-200",
									children: currentPage
								}),
								" dari ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold text-slate-900 dark:text-slate-200",
									children: totalPages
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								disabled: currentPage === 1,
								onClick: () => setPage((p) => p - 1),
								className: "border-emerald-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-slate-800 h-8",
								children: "Sebelumnya"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								disabled: currentPage === totalPages,
								onClick: () => setPage((p) => p + 1),
								className: "border-emerald-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-slate-800 h-8",
								children: "Berikutnya"
							})]
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!payRow,
				onOpenChange: (open) => !open && setPayRow(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-md bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 p-6 rounded-2xl shadow-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
							className: "border-b border-emerald-100 dark:border-slate-800 pb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
								className: "text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), " Konfirmasi Pembayaran Pajak"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
								className: "text-xs text-slate-500 dark:text-slate-400",
								children: "Periksa rincian ketetapan dan konfirmasi pembayaran tunai."
							})]
						}),
						payRow && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4 py-2 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-emerald-100 dark:border-slate-800 bg-emerald-50/50 dark:bg-slate-900/80 p-4 space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-slate-500 dark:text-slate-400",
												children: "NOP:"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono font-bold text-emerald-700 dark:text-emerald-400",
												children: payRow.nop
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-slate-500 dark:text-slate-400",
												children: "Nama SPPT:"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-bold text-slate-900 dark:text-slate-100",
												children: payRow.namaSppt
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-slate-500 dark:text-slate-400",
												children: "Lokasi:"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-slate-800 dark:text-slate-200",
												children: [
													payRow.lokasi,
													" (",
													payRow.blok,
													")"
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-slate-500 dark:text-slate-400",
												children: "Tahun Pajak:"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-bold text-slate-800 dark:text-slate-200",
												children: payRow.tahun
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between border-t border-emerald-200/80 dark:border-slate-800 pt-2 font-bold text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-slate-900 dark:text-white",
												children: "Tagihan Pokok:"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono text-amber-600 dark:text-amber-400",
												children: formatRp(payRow.tagihan)
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between rounded-xl bg-white dark:bg-slate-900 border border-emerald-200 dark:border-slate-800 p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "rounding",
										className: "text-xs text-slate-700 dark:text-slate-300 font-semibold cursor-pointer",
										children: "Pembulatan Otomatis (Ribuan)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
										id: "rounding",
										checked: rounded,
										onCheckedChange: setRounded
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between items-center text-sm font-extrabold bg-emerald-500/10 border border-emerald-500/30 p-3 rounded-xl",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-emerald-700 dark:text-emerald-400",
										children: "Total Dibayar:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-lg font-mono font-black text-emerald-700 dark:text-emerald-400",
										children: formatRp(payAmount)
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
							className: "gap-2 sm:gap-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setPayRow(null),
								className: "border-emerald-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 text-xs",
								children: "Batal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: confirmPayment,
								className: "bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs gap-1.5 shadow-md",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4" }), " Konfirmasi Bayar & Cetak Resi"]
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: addOpen || !!editRow,
				onOpenChange: (open) => {
					if (!open) {
						setAddOpen(false);
						setEditRow(null);
					}
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-2xl bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 p-6 rounded-2xl shadow-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, {
							className: "border-b border-emerald-100 dark:border-slate-800 pb-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
								className: "text-lg font-black text-slate-900 dark:text-slate-100 flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-5 text-emerald-600 dark:text-emerald-400" }),
									" ",
									editRow ? "Edit Data SPPT" : "Tambah SPPT Baru"
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-6 py-4 text-xs h-[65vh] overflow-y-auto pr-2 custom-scrollbar",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-4 rounded-xl border border-emerald-100 dark:border-slate-800 bg-emerald-50/30 dark:bg-slate-900/30 p-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
										className: "flex items-center gap-2 font-bold text-emerald-800 dark:text-emerald-400 text-sm border-b border-emerald-100 dark:border-slate-800 pb-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "size-4" }), " Informasi Utama SPPT"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5 sm:col-span-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
													className: "text-slate-700 dark:text-slate-300 font-semibold flex items-center gap-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5 text-emerald-600 dark:text-emerald-400" }), " Desa Ketetapan (Wilayah Legal SPPT)"]
												}), isSuperAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
													value: formDesaId,
													onValueChange: setFormDesaId,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
														className: "bg-white dark:bg-slate-900 border-emerald-200 dark:border-slate-800 text-sm shadow-sm transition-all focus:border-emerald-500 font-medium",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Pilih Desa..." })
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
														className: "bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-sm",
														children: desasList.length > 0 ? desasList.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
															value: String(d.id),
															children: [
																d.nama_desa,
																" (",
																d.kode_desa || `ID: ${d.id}`,
																")"
															]
														}, d.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
															value: String(tenant?.id || 1),
															children: tenant?.nama_desa || "Desa"
														})
													})]
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between bg-white dark:bg-slate-900 border border-emerald-200 dark:border-slate-800 p-2.5 rounded-xl shadow-sm",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
															variant: "outline",
															className: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/30 text-xs font-bold px-2.5 py-1",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5 mr-1 text-emerald-600 dark:text-emerald-400" }), " Otomatis Terpilih"]
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-bold text-slate-800 dark:text-slate-100 text-xs",
															children: tenant?.nama_desa || "Desa"
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] text-slate-500 dark:text-slate-400 italic",
														children: "Terhubung ke Wilayah Kerja Akun Anda"
													})]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-slate-700 dark:text-slate-300 font-semibold",
													children: "Nomor Objek Pajak (NOP)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: formNop,
													onChange: (e) => setFormNop(e.target.value),
													className: "bg-white dark:bg-slate-900 border-emerald-200 dark:border-slate-800 font-mono text-sm shadow-sm transition-all focus:border-emerald-500",
													placeholder: "Contoh: 1.0001"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-slate-700 dark:text-slate-300 font-semibold",
													children: "Tahun Pajak"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: formTahun,
													onChange: (e) => setFormTahun(e.target.value),
													className: "bg-white dark:bg-slate-900 border-emerald-200 dark:border-slate-800 font-mono text-sm shadow-sm transition-all focus:border-emerald-500"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5 sm:col-span-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-slate-700 dark:text-slate-300 font-semibold",
													children: "Nama Sesuai SPPT"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: formNamaSppt,
													onChange: (e) => setFormNamaSppt(e.target.value),
													className: "bg-white dark:bg-slate-900 border-emerald-200 dark:border-slate-800 font-medium text-sm shadow-sm transition-all focus:border-emerald-500",
													placeholder: "Nama Wajib Pajak sesuai dokumen"
												})]
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-4 rounded-xl border border-emerald-100 dark:border-slate-800 bg-emerald-50/30 dark:bg-slate-900/30 p-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
										className: "flex items-center gap-2 font-bold text-emerald-800 dark:text-emerald-400 text-sm border-b border-emerald-100 dark:border-slate-800 pb-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4" }), " Data Kepemilikan & Lokasi Tanah"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-slate-700 dark:text-slate-300 font-semibold",
													children: "Nama Pemilik Tanah Sekarang"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: formNamaAktual,
													onChange: (e) => setFormNamaAktual(e.target.value),
													className: "bg-white dark:bg-slate-900 border-emerald-200 dark:border-slate-800 text-sm shadow-sm transition-all focus:border-emerald-500",
													placeholder: "Nama pemilik aktual / penggarap"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-slate-700 dark:text-slate-300 font-semibold",
													children: "Domisili Wajib Pajak"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
													value: formDomisili,
													onValueChange: (v) => setFormDomisili(v),
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
														className: "bg-white dark:bg-slate-900 border-emerald-200 dark:border-slate-800 text-sm shadow-sm transition-all focus:border-emerald-500",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
														className: "bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-sm",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
															value: "DALAM_DESA",
															children: "Dalam Desa"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
															value: "LUAR_DESA",
															children: "Luar Desa"
														})]
													})]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5 sm:col-span-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-slate-700 dark:text-slate-300 font-semibold",
													children: "Alamat Pemilik (Jalan/RT/RW)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: formAlamatPemilik,
													onChange: (e) => setFormAlamatPemilik(e.target.value),
													className: "bg-white dark:bg-slate-900 border-emerald-200 dark:border-slate-800 text-sm shadow-sm transition-all focus:border-emerald-500",
													placeholder: "Alamat lengkap pemilik saat ini"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-slate-700 dark:text-slate-300 font-semibold",
													children: "Wilayah Dusun"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
													value: formDusun,
													onValueChange: setFormDusun,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
														className: "bg-white dark:bg-slate-900 border-emerald-200 dark:border-slate-800 text-sm shadow-sm transition-all focus:border-emerald-500",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Pilih Dusun" })
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
														className: "bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-sm",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "Dusun 1",
																children: "Dusun 1"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "Dusun 2",
																children: "Dusun 2"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "Dusun 3",
																children: "Dusun 3"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "Luar Desa",
																children: "Luar Desa"
															}),
															availableDusunOptions.filter((d) => ![
																"Dusun 1",
																"Dusun 2",
																"Dusun 3",
																"Luar Desa"
															].includes(d)).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: d,
																children: d
															}, d))
														]
													})]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-slate-700 dark:text-slate-300 font-semibold",
													children: "Blok Objek Pajak"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
													value: formBlok,
													onValueChange: setFormBlok,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
														className: "bg-white dark:bg-slate-900 border-emerald-200 dark:border-slate-800 text-sm shadow-sm transition-all focus:border-emerald-500",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Pilih Blok" })
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
														className: "bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-sm",
														children: [
															"Blok 01",
															"Blok 02",
															"Blok 03",
															"Blok 04",
															"Blok 05",
															"Blok 06",
															"Blok 07",
															"Blok 08"
														].map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
															value: b,
															children: b
														}, b))
													})]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5 sm:col-span-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-slate-700 dark:text-slate-300 font-semibold",
													children: "Lokasi Tanah / Alamat OP (Objek Pajak)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: formLokasi,
													onChange: (e) => setFormLokasi(e.target.value),
													className: "bg-white dark:bg-slate-900 border-emerald-200 dark:border-slate-800 text-sm shadow-sm transition-all focus:border-emerald-500",
													placeholder: "Contoh: Kp. Balok RT 01 / Blok Cigadung"
												})]
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-4 rounded-xl border border-emerald-100 dark:border-slate-800 bg-emerald-50/30 dark:bg-slate-900/30 p-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
										className: "flex items-center gap-2 font-bold text-emerald-800 dark:text-emerald-400 text-sm border-b border-emerald-100 dark:border-slate-800 pb-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-4" }), " Rincian Tagihan & Ketetapan"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-slate-700 dark:text-slate-300 font-semibold",
													children: "Tagihan Pokok (Rp)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: formTagihan,
													onChange: (e) => setFormTagihan(e.target.value),
													className: "bg-white dark:bg-slate-900 border-emerald-200 dark:border-slate-800 font-mono font-bold text-emerald-700 dark:text-emerald-400 text-sm shadow-sm transition-all focus:border-emerald-500",
													placeholder: "0"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-slate-700 dark:text-slate-300 font-semibold",
													children: "Jumlah SPPT"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: formJumlahSppt,
													onChange: (e) => setFormJumlahSppt(e.target.value),
													className: "bg-white dark:bg-slate-900 border-emerald-200 dark:border-slate-800 font-mono text-sm shadow-sm transition-all focus:border-emerald-500"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-slate-700 dark:text-slate-300 font-semibold",
													children: "Dibulatkan (Rp)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: formDibulatkan,
													onChange: (e) => setFormDibulatkan(e.target.value),
													className: "bg-white dark:bg-slate-900 border-emerald-200 dark:border-slate-800 font-mono font-bold text-emerald-700 dark:text-emerald-400 text-sm shadow-sm transition-all focus:border-emerald-500",
													placeholder: "0"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-slate-700 dark:text-slate-300 font-semibold",
													children: "Round (Rp)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: formRound,
													onChange: (e) => setFormRound(e.target.value),
													className: "bg-white dark:bg-slate-900 border-emerald-200 dark:border-slate-800 font-mono font-bold text-amber-600 dark:text-amber-500 text-sm shadow-sm transition-all focus:border-emerald-500",
													placeholder: "0"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5 sm:col-span-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-slate-700 dark:text-slate-300 font-semibold",
													children: "Status Pembayaran"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
													value: formStatus,
													onValueChange: (v) => setFormStatus(v),
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
														className: "bg-white dark:bg-slate-900 border-emerald-200 dark:border-slate-800 text-sm shadow-sm transition-all focus:border-emerald-500",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
														className: "bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-sm",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
															value: "BELUM",
															children: "Belum Lunas"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
															value: "LUNAS",
															children: "Sudah Lunas"
														})]
													})]
												})]
											})
										]
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
							className: "pt-4 border-t border-emerald-100 dark:border-slate-800",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => {
									setAddOpen(false);
									setEditRow(null);
								},
								className: "border-emerald-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800",
								children: "Batal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: editRow ? handleSaveEdit : handleSaveAdd,
								className: "bg-emerald-600 hover:bg-emerald-500 text-white font-bold shadow-md shadow-emerald-500/20 px-6 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4" }), " Simpan Data"]
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: !!deleteRow,
				onOpenChange: (open) => !open && setDeleteRow(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, {
					className: "bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-100",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogTitle, {
						className: "text-rose-600 dark:text-rose-400 flex items-center gap-2 text-base",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-5" }), " Hapus Data SPPT"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogDescription, {
						className: "text-slate-600 dark:text-slate-400 text-xs",
						children: [
							"Apakah Anda yakin ingin menghapus SPPT dengan NOP ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-slate-900 dark:text-white font-mono",
								children: deleteRow?.nop
							}),
							" atas nama ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-slate-900 dark:text-white",
								children: deleteRow?.namaSppt
							}),
							"? Tindakan ini tidak dapat dibatalkan."
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
						className: "bg-emerald-50 dark:bg-slate-900 border-emerald-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 text-xs hover:bg-emerald-100 dark:hover:bg-slate-800",
						children: "Batal"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
						onClick: handleConfirmDelete,
						className: "bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md",
						children: "Hapus Permanen"
					})] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!historyRow,
				onOpenChange: (open) => !open && setHistoryRow(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-xl bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 p-6 rounded-2xl shadow-2xl space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
							className: "border-b border-emerald-100 dark:border-slate-800 pb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
								className: "text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), " Riwayat Pembayaran Pajak PBB-P2"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
								className: "text-xs text-slate-500 dark:text-slate-400",
								children: "Rincian jejak setoran dan bukti penerimaan untuk Wajib Pajak terpilih."
							})]
						}),
						historyRow && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl border border-emerald-100 dark:border-slate-800 bg-emerald-50/50 dark:bg-slate-900/80 p-4 space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between items-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono font-bold text-emerald-700 dark:text-emerald-400 text-sm",
										children: historyRow.nop
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										className: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/30 font-bold px-2.5 py-0.5",
										children: "LUNAS"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2 text-slate-700 dark:text-slate-300 pt-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-slate-500 dark:text-slate-400 text-[10px]",
											children: "Wajib Pajak (SPPT):"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-bold text-slate-900 dark:text-slate-100",
											children: historyRow.namaSppt
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-slate-500 dark:text-slate-400 text-[10px]",
											children: "Nama Pemilik Sekarang / Penggarap:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-semibold text-slate-800 dark:text-slate-200",
											children: historyRow.namaAktual || "-"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-slate-500 dark:text-slate-400 text-[10px]",
											children: "Lokasi & Blok:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "font-semibold",
											children: [
												historyRow.lokasi,
												" (",
												historyRow.blok,
												")"
											]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-slate-500 dark:text-slate-400 text-[10px]",
											children: "Tahun & Tagihan:"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "font-mono font-bold text-amber-600 dark:text-amber-400",
											children: [
												historyRow.tahun,
												" · ",
												formatRp(historyRow.tagihan)
											]
										})] })
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
									className: "font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider text-[11px] flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "size-3.5 text-amber-600 dark:text-amber-400" }), " Catatan Transaksi Setoran"]
								}), !historyRow.riwayatBayar || historyRow.riwayatBayar.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-emerald-100 dark:border-slate-800 bg-emerald-50/40 dark:bg-slate-900/50 p-4 space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono font-bold text-emerald-700 dark:text-emerald-400",
												children: "LNT-2026-0612-0002"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												variant: "outline",
												className: "bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/30 text-[10px]",
												children: "TUNAI"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between text-slate-500 dark:text-slate-400 text-[11px] pt-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Waktu: 2026-06-12 09:15 WIB" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Petugas: Kolektor Desa" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between items-center border-t border-emerald-100 dark:border-slate-800/80 pt-2 mt-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-bold text-slate-800 dark:text-slate-200",
												children: "Jumlah Dibayar:"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono font-black text-emerald-700 dark:text-emerald-400 text-sm",
												children: formatRp(historyRow.tagihan)
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex gap-2 pt-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												size: "sm",
												className: "w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs gap-1.5 rounded-lg shadow-md",
												onClick: () => {
													setReceiptRow(historyRow);
													setReceiptAmount(historyRow.tagihan);
												},
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-3.5" }), " Cetak Resi Struk Thermal"]
											})
										})
									]
								}) : historyRow.riwayatBayar.map((pay, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-emerald-100 dark:border-slate-800 bg-emerald-50/40 dark:bg-slate-900/50 p-4 space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono font-bold text-emerald-700 dark:text-emerald-400",
												children: pay.noResi
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												variant: "outline",
												className: "bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/30 text-[10px]",
												children: pay.metode
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between text-slate-500 dark:text-slate-400 text-[11px] pt-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Waktu: ", pay.tanggal] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Petugas: ", pay.petugas] })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between items-center border-t border-emerald-100 dark:border-slate-800/80 pt-2 mt-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-bold text-slate-800 dark:text-slate-200",
												children: "Jumlah Dibayar:"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono font-black text-emerald-700 dark:text-emerald-400 text-sm",
												children: formatRp(pay.jumlah)
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex gap-2 pt-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												size: "sm",
												className: "w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs gap-1.5 rounded-lg shadow-md",
												onClick: () => {
													setReceiptRow(historyRow);
													setReceiptAmount(pay.jumlah);
												},
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-3.5" }), " Cetak Resi Struk Thermal"]
											})
										})
									]
								}, pay.id || idx))]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogFooter, {
							className: "pt-2 border-t border-emerald-100 dark:border-slate-800",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setHistoryRow(null),
								className: "border-emerald-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 text-xs rounded-xl",
								children: "Tutup"
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpptDetailModal, {
				detailRow,
				onClose: () => setDetailRow(null),
				settings,
				onPaySppt: (row) => {
					setRounded(true);
					setPayRow(row);
				},
				onViewHistory: (row) => setHistoryRow(row),
				onEditSppt: (row) => openEditModal(row)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReceiptDialog, {
				row: receiptRow,
				amount: receiptAmount,
				open: !!receiptRow,
				onOpenChange: (v) => !v && setReceiptRow(null)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImportDhkpModal, {
				open: importOpen,
				onClose: () => setImportOpen(false),
				desasList,
				initialDesaId: isSuperAdmin ? filterDesa !== "all" ? filterDesa : String(desasList[0]?.id || 1) : String(currentUser?.desa_id || tenant?.id || 1),
				isSuperAdmin,
				onSuccess: async () => {
					await refreshFromApi();
				}
			}),
			isSuperAdminSystem && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResetDhkpModal, {
				open: resetOpen,
				onClose: () => setResetOpen(false),
				desasList,
				initialDesaId: filterDesa !== "all" ? filterDesa : String(desasList[0]?.id || 1),
				isSuperAdmin: isSuperAdminSystem,
				onSuccess: async () => {
					await refreshFromApi();
				}
			})
		]
	});
}
//#endregion
export { DhkpPage as component, formatDusunLabel, normalizeDusun };
