import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/themeStore-CN2DoDyW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var THEME_STORAGE_KEY = "lentera_theme_mode_v1";
function getStoredTheme() {
	if (typeof window === "undefined") return "light";
	try {
		const saved = localStorage.getItem(THEME_STORAGE_KEY);
		if (saved && [
			"light",
			"dark",
			"system"
		].includes(saved)) return saved;
	} catch (err) {
		console.error("Gagal membaca tema dari localStorage:", err);
	}
	return "light";
}
function resolveIsDark(mode) {
	if (typeof window === "undefined") return false;
	if (mode === "system") return window.matchMedia("(prefers-color-scheme: dark)").matches;
	return mode === "dark";
}
var globalTheme = getStoredTheme();
var themeListeners = /* @__PURE__ */ new Set();
function applyThemeToDocument(mode = globalTheme) {
	if (typeof window === "undefined") return;
	const isDark = resolveIsDark(mode);
	const root = document.documentElement;
	if (isDark) root.classList.add("dark");
	else root.classList.remove("dark");
}
function notifyThemeListeners() {
	if (typeof window !== "undefined") try {
		localStorage.setItem(THEME_STORAGE_KEY, globalTheme);
	} catch (err) {
		console.error("Gagal menyimpan tema ke localStorage:", err);
	}
	applyThemeToDocument(globalTheme);
	themeListeners.forEach((fn) => fn());
}
function setGlobalTheme(mode) {
	globalTheme = mode;
	notifyThemeListeners();
}
function useThemeStore() {
	const [theme, setThemeState] = (0, import_react.useState)(globalTheme);
	(0, import_react.useEffect)(() => {
		applyThemeToDocument(globalTheme);
		const handleChange = () => {
			setThemeState(globalTheme);
		};
		themeListeners.add(handleChange);
		const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
		const handleSystemChange = () => {
			if (globalTheme === "system") {
				applyThemeToDocument("system");
				setThemeState("system");
			}
		};
		mediaQuery.addEventListener("change", handleSystemChange);
		return () => {
			themeListeners.delete(handleChange);
			mediaQuery.removeEventListener("change", handleSystemChange);
		};
	}, []);
	const setTheme = (newTheme) => {
		setGlobalTheme(newTheme);
	};
	return {
		theme,
		setTheme,
		isDarkResolved: resolveIsDark(theme)
	};
}
//#endregion
export { useThemeStore as t };
