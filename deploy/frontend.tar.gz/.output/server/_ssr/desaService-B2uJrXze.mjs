import { n as apiClient } from "./authStore-CZRDvP0Z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/desaService-B2uJrXze.js
var desaService = {
	async getAll(search) {
		return apiClient.get("desas", search ? { search } : void 0);
	},
	async getById(id) {
		return apiClient.get(`desas/${id}`);
	},
	async create(payload) {
		return apiClient.post("desas", payload);
	},
	async update(id, payload) {
		return apiClient.put(`desas/${id}`, payload);
	},
	async toggleStatus(id) {
		return apiClient.post(`desas/${id}/toggle-status`, {});
	},
	async delete(id) {
		return apiClient.delete(`desas/${id}`);
	}
};
//#endregion
export { desaService as t };
