import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { a as useTenantStore, i as useAuthStore } from "./authStore-CZRDvP0Z.mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useSettingsStore } from "./settingsStore-BBOTJBY5.mjs";
import { At as CircleX, D as Send, Dt as Clock, W as MapPin, Wt as Building2, Y as LoaderCircle, Yt as ArrowRight, j as RefreshCw, jt as CircleCheck, n as Wallet, p as Target, pt as FileStack, r as Users, rt as Info, tt as Landmark, u as TriangleAlert, y as Sparkles } from "../_libs/lucide-react.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, o as formatRp, t as Card } from "./card-CfCIYh5x.mjs";
import { t as desaService } from "./desaService-B2uJrXze.mjs";
import { i as dhkpService, o as useDhkpStore } from "./penerimaanStore-Dy63tgZo.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-HQswfJbV.mjs";
import { r as isDusunAllowed } from "./dusunHelper-BcA75wHe.mjs";
import { t as Progress } from "./progress-D8ag4YZx.mjs";
import { c as Cell, d as Legend, i as XAxis, l as ResponsiveContainer, o as CartesianGrid, r as YAxis, s as Bar, t as BarChart, u as Tooltip } from "../_libs/recharts+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as useSetoranKecamatanStore } from "./setoranKecamatanStore-9CbL7icp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CKYD18YG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Dashboard() {
	const { user: authUser } = useAuthStore();
	const { settings } = useSettingsStore();
	const namaDesaAktif = useTenantStore()?.nama_desa || authUser?.desa?.nama_desa || settings.namaDesa || "Desa";
	const currentRole = authUser?.role;
	const userDesaId = authUser?.desa_id;
	const isSuperAdmin = currentRole === "SUPER_ADMIN_SYSTEM" || !userDesaId && currentRole === "SUPER_ADMIN";
	const isKolektor = currentRole === "KOLEKTOR";
	const userDusunAkses = authUser?.dusun_akses || authUser?.dusunAssigned || "ALL";
	const { dhkpList } = useDhkpStore();
	const [filterDesa, setFilterDesa] = (0, import_react.useState)("all");
	const [desasList, setDesasList] = (0, import_react.useState)([]);
	const [summaryData, setSummaryData] = (0, import_react.useState)(null);
	const [isLoading, setIsLoading] = (0, import_react.useState)(true);
	const [isRefreshing, setIsRefreshing] = (0, import_react.useState)(false);
	const [selectedLokasi, setSelectedLokasi] = (0, import_react.useState)(null);
	const [viewModeDusun, setViewModeDusun] = (0, import_react.useState)("grid");
	const [hoveredBlock, setHoveredBlock] = (0, import_react.useState)(null);
	const { items: setoranItems, summary: setoranSummary, fetchItems: fetchSetoranItems, fetchSummary: fetchSetoranSummary } = useSetoranKecamatanStore();
	(0, import_react.useEffect)(() => {
		if (isSuperAdmin) desaService.getAll().then((res) => {
			if (res.data) setDesasList(res.data);
		}).catch((err) => console.error("Gagal memuat list desa:", err));
	}, [isSuperAdmin]);
	const selectedDesaObj = (0, import_react.useMemo)(() => {
		if (filterDesa === "all") return null;
		return desasList.find((d) => String(d.id) === filterDesa) || null;
	}, [filterDesa, desasList]);
	const fetchSummary = (0, import_react.useCallback)(async (showRefreshing = false) => {
		try {
			if (showRefreshing) setIsRefreshing(true);
			else setIsLoading(true);
			const dusunParam = isKolektor && userDusunAkses !== "ALL" ? userDusunAkses : void 0;
			const desaIdParam = isSuperAdmin ? filterDesa !== "all" ? filterDesa : void 0 : userDesaId ? userDesaId : void 0;
			await Promise.all([
				dhkpService.getKpiSummary(2026, dusunParam, desaIdParam).then((res) => {
					if (res.success && res.data) setSummaryData(res.data);
				}),
				fetchSetoranSummary({
					desa_id: desaIdParam,
					tahun: 2026
				}),
				fetchSetoranItems({
					desa_id: desaIdParam,
					limit: 5
				})
			]);
		} catch (err) {
			console.warn("[Dashboard] Failed to fetch KPI summary from API:", err);
		} finally {
			setIsLoading(false);
			setIsRefreshing(false);
		}
	}, [
		isKolektor,
		userDusunAkses,
		isSuperAdmin,
		filterDesa,
		fetchSetoranSummary,
		fetchSetoranItems
	]);
	(0, import_react.useEffect)(() => {
		fetchSummary();
	}, [
		fetchSummary,
		dhkpList,
		filterDesa
	]);
	const chartData = (0, import_react.useMemo)(() => {
		let items = [];
		if (isSuperAdmin && summaryData?.by_desa && summaryData.by_desa.length > 0) items = summaryData.by_desa.map((item) => ({
			lokasi: item.nama_desa,
			Target: item.target,
			Realisasi: item.realisasi,
			sisaPiutang: item.sisa_piutang,
			totalSppt: item.total_sppt,
			spptLunas: item.sppt_lunas,
			spptBelum: item.sppt_belum,
			persentase: item.persentase,
			kodeDesa: item.kode_desa,
			desaId: item.desa_id
		}));
		else if (summaryData?.by_dusun && summaryData.by_dusun.length > 0) items = summaryData.by_dusun.map((item) => ({
			lokasi: item.dusun,
			Target: item.target,
			Realisasi: item.realisasi,
			sisaPiutang: item.sisa_piutang,
			totalSppt: item.total_sppt,
			spptLunas: item.sppt_lunas,
			spptBelum: item.sppt_belum,
			persentase: item.persentase
		}));
		else {
			const dusunMap = {};
			dhkpList.forEach((row) => {
				const dName = row.dusun || row.lokasi || "Balok";
				if (!dusunMap[dName]) dusunMap[dName] = {
					target: 0,
					realisasi: 0,
					totalSppt: 0,
					spptLunas: 0
				};
				dusunMap[dName].target += row.tagihan;
				dusunMap[dName].totalSppt += 1;
				if (row.status === "LUNAS") {
					dusunMap[dName].realisasi += row.tagihan;
					dusunMap[dName].spptLunas += 1;
				}
			});
			const keys = Object.keys(dusunMap);
			if (keys.length > 0) items = keys.map((dName) => {
				const data = dusunMap[dName];
				const target = data.target;
				const realisasi = data.realisasi;
				const persentase = target > 0 ? Math.round(realisasi / target * 100) : 0;
				return {
					lokasi: dName,
					Target: target,
					Realisasi: realisasi,
					sisaPiutang: target - realisasi,
					totalSppt: data.totalSppt,
					spptLunas: data.spptLunas,
					spptBelum: data.totalSppt - data.spptLunas,
					persentase
				};
			});
		}
		if (isKolektor) return items.filter((it) => isDusunAllowed(it.lokasi, userDusunAkses, currentRole));
		return items;
	}, [
		summaryData,
		dhkpList,
		isKolektor,
		userDusunAkses,
		currentRole,
		isSuperAdmin
	]);
	const blockStats = (0, import_react.useMemo)(() => {
		return chartData.map((d) => {
			const norm = d.lokasi.toUpperCase();
			const persen = d.Target > 0 ? d.Realisasi / d.Target * 100 : 0;
			let colorClass = "";
			let strokeClass = "";
			let badgeColor = "";
			if (persen < 30) {
				colorClass = "fill-rose-500/20 hover:fill-rose-500/35";
				strokeClass = "stroke-rose-500";
				badgeColor = "bg-rose-50 text-rose-800 dark:bg-rose-500/15 dark:text-rose-400 border-rose-200 dark:border-rose-500/30";
			} else if (persen < 45) {
				colorClass = "fill-amber-500/20 hover:fill-amber-500/35";
				strokeClass = "stroke-amber-500";
				badgeColor = "bg-amber-50 text-amber-800 dark:bg-amber-500/15 dark:text-amber-400 border-amber-200 dark:border-amber-500/30";
			} else {
				colorClass = "fill-emerald-500/20 hover:fill-emerald-500/35";
				strokeClass = "stroke-emerald-600";
				badgeColor = "bg-emerald-50 text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-400 border-emerald-200 dark:border-emerald-500/30";
			}
			return {
				key: norm,
				name: d.lokasi,
				target: d.Target,
				realisasi: d.Realisasi,
				piutang: d.Target - d.Realisasi,
				spptCount: d.totalSppt,
				persen,
				colorClass,
				strokeClass,
				badgeColor,
				kodeDesa: d.kodeDesa,
				desaId: d.desaId
			};
		});
	}, [chartData]);
	const activeStats = selectedLokasi ? blockStats.find((s) => s.name.toUpperCase() === selectedLokasi.toUpperCase()) : null;
	const totalTarget = activeStats ? activeStats.target : summaryData?.total_ketetapan ?? chartData.reduce((a, c) => a + c.Target, 0);
	const totalRealisasi = activeStats ? activeStats.realisasi : summaryData?.terbayar ?? chartData.reduce((a, c) => a + c.Realisasi, 0);
	const totalPiutang = activeStats ? activeStats.piutang : summaryData?.sisa_piutang ?? totalTarget - totalRealisasi;
	const totalSPPTVal = `${activeStats ? activeStats.spptCount : summaryData?.total_sppt ?? dhkpList.length} lembar`;
	const progressPercent = totalTarget > 0 ? Math.round(totalRealisasi / totalTarget * 100) : 0;
	const totalDisetorKecamatan = setoranSummary?.totalDiterima ?? 0;
	setoranSummary?.sisaKasDesa;
	setoranSummary?.totalPending;
	const metrics = [
		{
			label: activeStats ? `Target ${selectedLokasi}` : isSuperAdmin ? "Total Target Ketetapan (Semua Desa)" : "Total Target Ketetapan",
			value: formatRp(totalTarget),
			sub: activeStats ? isSuperAdmin ? "Ketetapan desa terpilih" : "Ketetapan wilayah terpilih" : "Tahun Pajak 2026",
			icon: Target,
			tone: "gold"
		},
		{
			label: activeStats ? `SPPT ${selectedLokasi}` : isSuperAdmin ? "Total SPPT Terdistribusi (Semua Desa)" : "Total SPPT Terdistribusi",
			value: totalSPPTVal,
			sub: activeStats ? `Terdistribusi di ${selectedLokasi}` : isSuperAdmin ? `Tersebar di ${chartData.length} desa terdaftar` : `Tersebar di ${chartData.length} dusun`,
			icon: FileStack,
			tone: "sky"
		},
		{
			label: activeStats ? `Sudah Terbayar ${selectedLokasi}` : "Sudah Terbayar (Realisasi DHKP)",
			value: formatRp(totalRealisasi),
			sub: `${progressPercent}% dari target ketetapan`,
			icon: Wallet,
			tone: "emerald",
			progress: progressPercent
		},
		{
			label: isSuperAdmin ? "Disetorkan ke Kecamatan (Diterima)" : "Disetorkan ke Kecamatan",
			value: formatRp(totalDisetorKecamatan),
			sub: isSuperAdmin ? `${setoranSummary?.counts?.diterima || 0} setoran terverifikasi` : `Verified oleh Kecamatan`,
			icon: Landmark,
			tone: "teal"
		},
		{
			label: activeStats ? `Belum Terbayar ${selectedLokasi}` : isSuperAdmin ? "Belum Terbayar (Piutang Lintas Desa)" : "Belum Terbayar",
			value: formatRp(totalPiutang),
			sub: "Perlu penagihan intensif",
			icon: TriangleAlert,
			tone: "rose"
		}
	];
	const topUnpaidTaxpayers = (0, import_react.useMemo)(() => {
		if (summaryData?.top_unpaid && summaryData.top_unpaid.length > 0) {
			if (!selectedLokasi) return summaryData.top_unpaid.slice(0, 10).map((r) => ({
				id: r.id,
				namaSppt: r.nama_wp,
				nop: r.nop,
				lokasi: r.nama_desa ? `${r.nama_desa} - ${r.dusun}` : r.dusun,
				tagihan: r.ketetapan_pbb
			}));
			const filtered = summaryData.top_unpaid.filter((r) => {
				return (r.nama_desa || r.dusun || "").toUpperCase() === selectedLokasi.toUpperCase() || r.dusun.toUpperCase() === selectedLokasi.toUpperCase();
			});
			if (filtered.length > 0) return filtered.slice(0, 10).map((r) => ({
				id: r.id,
				namaSppt: r.nama_wp,
				nop: r.nop,
				lokasi: r.nama_desa ? `${r.nama_desa} - ${r.dusun}` : r.dusun,
				tagihan: r.ketetapan_pbb
			}));
		}
		if (!selectedLokasi) return dhkpList.filter((r) => r.status === "BELUM").slice(0, 10).map((r) => ({
			id: r.id,
			namaSppt: r.namaSppt,
			nop: r.nop,
			lokasi: r.dusun || r.lokasi,
			tagihan: r.tagihan
		}));
		return dhkpList.filter((r) => (r.dusun || r.lokasi).toUpperCase() === selectedLokasi.toUpperCase() && r.status === "BELUM").slice(0, 10).map((r) => ({
			id: r.id,
			namaSppt: r.namaSppt,
			nop: r.nop,
			lokasi: r.dusun || r.lokasi,
			tagihan: r.tagihan
		}));
	}, [
		summaryData,
		selectedLokasi,
		dhkpList
	]);
	const activeChartData = chartData.map((d) => ({
		...d,
		opacity: selectedLokasi === null || d.lokasi.toUpperCase() === selectedLokasi.toUpperCase() ? 1 : .3
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-7xl space-y-6 pb-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative overflow-hidden rounded-2xl border border-emerald-500/30 dark:border-slate-800 bg-gradient-to-r from-emerald-700 via-emerald-600 to-teal-700 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 p-6 text-white shadow-xl sm:p-8 backdrop-blur-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute right-0 top-0 -mr-16 -mt-16 size-72 rounded-full bg-white/10 blur-3xl" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-1/3 bottom-0 -mb-20 size-80 rounded-full bg-amber-300/20 blur-3xl" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-3xl space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex items-center gap-2 rounded-full bg-white/15 dark:bg-emerald-500/10 border border-white/30 dark:border-emerald-500/30 px-3 py-1 text-xs font-extrabold uppercase tracking-widest text-emerald-50 dark:text-emerald-400 backdrop-blur-md",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5 text-amber-300" }), " Portal SIPABAR (Sistem Informasi Pajak Barudua)"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-2xl font-black tracking-tight sm:text-4xl text-white",
								children: isSuperAdmin ? filterDesa === "all" ? `Dashboard Kecamatan ${settings.kecamatan || "Malangbong"} - Rekapitulasi PBB-P2 Se-Kecamatan` : `Dashboard Kecamatan ${settings.kecamatan || "Malangbong"} - Realisasi Desa ${selectedDesaObj?.nama_desa || "Terpilih"}` : `Dashboard Pengawasan & Realisasi PBB-P2 ${namaDesaAktif}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-emerald-50 dark:text-slate-300 sm:text-base leading-relaxed font-medium",
								children: isSuperAdmin ? filterDesa === "all" ? `Pengawasan & Evaluasi Penerimaan PBB-P2 Se-Kecamatan ${settings.kecamatan || "Malangbong"}: Pantau realisasi penerimaan seluruh desa, kepatuhan setoran ke kecamatan, dan mitigasi piutang terutang.` : `Evaluasi Realisasi Pajak Daerah Desa ${selectedDesaObj?.nama_desa || ""}: Pantau target ketetapan, realisasi setoran STTS, dan rincian piutang per dusun.` : `Evaluasi Manajemen Risiko Pajak ${namaDesaAktif}: Pantau realisasi penerimaan, peta persebaran per blok, dan mitigasi piutang terutang secara langsung dari backend database.`
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-3 self-start sm:self-center shrink-0",
						children: [isSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: filterDesa,
							onValueChange: (val) => setFilterDesa(val),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectTrigger, {
								className: "w-[190px] sm:w-[220px] bg-white/20 hover:bg-white/30 text-white border-white/40 text-xs font-extrabold shadow-lg backdrop-blur-md rounded-xl cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4 text-amber-300 shrink-0 mr-1" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Filter Target Desa" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
								className: "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 font-medium",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "all",
									className: "font-extrabold text-xs",
									children: "🏘️ Seluruh Desa"
								}), desasList.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: String(d.id),
									className: "text-xs font-bold",
									children: d.nama_desa
								}, d.id))]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => fetchSummary(true),
							disabled: isRefreshing || isLoading,
							className: "inline-flex items-center gap-2 rounded-xl bg-white text-emerald-900 hover:bg-emerald-50 border border-white/50 px-4 py-2.5 text-xs font-extrabold shadow-lg backdrop-blur-md transition-all active:scale-95 disabled:opacity-50 cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `size-4 text-emerald-700 ${isRefreshing ? "animate-spin" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isRefreshing ? "Memuat Data..." : "Refresh Database" })]
						})]
					})]
				})
			]
		}), isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center justify-center p-12 space-y-4 border border-dashed border-emerald-200 dark:border-slate-800 rounded-2xl bg-white/50 dark:bg-slate-900/50",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-8 animate-spin text-emerald-600 dark:text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-bold text-slate-600 dark:text-slate-400",
				children: "Mengambil data realisasi real-time dari backend REST API..."
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5",
				children: metrics.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "group relative overflow-hidden border-emerald-100/80 dark:border-slate-800/80 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md transition-all duration-300 hover:-translate-y-1 hover:border-emerald-300 dark:hover:border-slate-700 shadow-md shadow-emerald-950/5 dark:shadow-xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
						className: "grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3 pb-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
							className: "min-w-0 truncate text-[11px] font-bold tracking-wider uppercase text-slate-500 dark:text-slate-400",
							children: m.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-10 shrink-0 place-items-center rounded-xl transition-colors duration-300 " + (m.tone === "emerald" ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30 group-hover:bg-emerald-600 group-hover:text-white" : m.tone === "teal" ? "bg-teal-500/15 text-teal-700 dark:text-teal-400 border border-teal-500/30 group-hover:bg-teal-600 group-hover:text-white" : m.tone === "rose" ? "bg-rose-500/15 text-rose-700 dark:text-rose-400 border border-rose-500/30 group-hover:bg-rose-600 group-hover:text-white" : m.tone === "gold" ? "bg-amber-500/15 text-amber-700 dark:text-amber-400 border border-amber-500/30 group-hover:bg-amber-500 group-hover:text-slate-950" : "bg-sky-500/15 text-sky-700 dark:text-sky-400 border border-sky-500/30 group-hover:bg-sky-600 group-hover:text-white"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(m.icon, { className: "size-5" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xl font-black tracking-tight text-slate-900 dark:text-white font-mono",
								children: m.value
							}),
							m.progress !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
								value: m.progress,
								className: "h-2 bg-emerald-100 dark:bg-slate-950 border border-emerald-200 dark:border-slate-800 [&>*]:bg-gradient-to-r [&>*]:from-emerald-600 [&>*]:to-amber-500",
								"aria-label": "Progres realisasi"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium text-slate-500 dark:text-slate-400",
								children: m.sub
							})
						]
					})]
				}, m.label))
			}),
			isSuperAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "lg:col-span-3 overflow-hidden border-emerald-100/80 dark:border-slate-800/80 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md shadow-xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
						className: "border-b border-emerald-100/80 dark:border-slate-800/80 bg-emerald-50/60 dark:bg-slate-950/60 px-6 py-4 flex flex-row items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
							className: "text-base font-extrabold tracking-tight text-slate-900 dark:text-slate-100 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), " Ringkasan & Status Realisasi Per Desa"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-600 dark:text-slate-400",
							children: "Klik salah satu kartu desa untuk memfilter rincian realisasi penerimaan pajak."
						})] }), selectedLokasi && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setSelectedLokasi(null),
							className: "inline-flex items-center gap-1.5 rounded-lg border border-emerald-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-2.5 py-1.5 text-xs font-bold text-slate-800 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-slate-700 transition-all cursor-pointer shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3.5 text-amber-600 dark:text-amber-400" }), "Reset Filter"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
						className: "p-6 bg-emerald-50/30 dark:bg-slate-950/40",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: blockStats.map((stat) => {
								const isSelected = selectedLokasi?.toUpperCase() === stat.name.toUpperCase();
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									onClick: () => setSelectedLokasi(isSelected ? null : stat.name),
									className: `relative cursor-pointer overflow-hidden rounded-2xl border p-4 transition-all duration-300 ${isSelected ? "border-emerald-500 bg-emerald-50/90 dark:bg-emerald-950/40 shadow-lg ring-2 ring-emerald-500/40" : "border-emerald-100/90 dark:border-slate-800 bg-white/90 dark:bg-slate-900/80 hover:-translate-y-1 hover:border-emerald-300 hover:shadow-md"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: "text-sm font-black text-slate-900 dark:text-white",
												children: stat.name
											})]
										}), stat.kodeDesa && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-0.5 text-[10px] font-mono text-slate-500 dark:text-slate-400",
											children: ["Kode: ", stat.kodeDesa]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: `rounded-full border px-2.5 py-0.5 text-[10px] font-extrabold ${stat.badgeColor}`,
											children: [Math.round(stat.persen), "%"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-3 space-y-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between text-xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-slate-500 dark:text-slate-400 font-medium",
													children: "Target:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-mono font-bold text-slate-800 dark:text-slate-200",
													children: formatRp(stat.target)
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between text-xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-slate-500 dark:text-slate-400 font-medium",
													children: "Realisasi:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-mono font-bold text-emerald-700 dark:text-emerald-400",
													children: formatRp(stat.realisasi)
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between text-xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-slate-500 dark:text-slate-400 font-medium",
													children: "Piutang:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-mono font-bold text-rose-600 dark:text-rose-400",
													children: formatRp(stat.piutang)
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
												value: stat.persen,
												className: "mt-2 h-1.5 bg-slate-200 dark:bg-slate-800 [&>*]:bg-emerald-600"
											})
										]
									})]
								}, stat.name);
							})
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "lg:col-span-2 overflow-hidden flex flex-col justify-between border-emerald-100/80 dark:border-slate-800/80 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md shadow-xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
						className: "border-b border-emerald-100/80 dark:border-slate-800/80 bg-emerald-50/60 dark:bg-slate-950/60 px-6 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
							className: "text-base font-extrabold tracking-tight text-slate-900 dark:text-slate-100 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4 text-amber-600 dark:text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Detail Desa: ", selectedLokasi || "Seluruh Desa"] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-600 dark:text-slate-400",
							children: selectedLokasi ? `Statistik khusus dan penagihan prioritas di ${selectedLokasi}` : "Rincian kumulatif seluruh desa terdaftar"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-6 flex-1 space-y-6",
						children: [
							activeStats && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `rounded-xl border p-3.5 flex items-center justify-between shadow-inner ${activeStats.badgeColor}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-0.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-bold uppercase tracking-wider opacity-85",
										children: "Kategori Realisasi Desa"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-black",
										children: activeStats.persen < 30 ? "PENERIMAAN KRITIS" : activeStats.persen < 45 ? "PENERIMAAN MODERAT" : "PENERIMAAN OPTIMAL"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xl font-black font-mono",
									children: [Math.round(activeStats.persen), "%"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-xs font-bold tracking-wider uppercase text-slate-500 dark:text-slate-400",
									children: "Indikator Realisasi Desa"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between text-xs font-bold mb-1.5 text-slate-700 dark:text-slate-300",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Rasio Realisasi Terhadap Target" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono text-emerald-700 dark:text-emerald-400",
											children: [progressPercent, "%"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
										value: progressPercent,
										className: "h-2 bg-emerald-100 dark:bg-slate-950 border border-emerald-200 dark:border-slate-800 [&>*]:bg-emerald-600"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-3 pt-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-emerald-50/50 dark:bg-slate-950/80 border border-emerald-100 dark:border-slate-800 rounded-xl p-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase",
												children: "Total SPPT"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-black text-slate-900 dark:text-slate-100 font-mono mt-0.5",
												children: totalSPPTVal
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-emerald-50/50 dark:bg-slate-950/80 border border-emerald-100 dark:border-slate-800 rounded-xl p-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase",
												children: "Sisa Piutang"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-black text-rose-600 dark:text-rose-400 font-mono mt-0.5",
												children: formatRp(totalPiutang)
											})]
										})]
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3 pt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
										className: "text-xs font-bold tracking-wider uppercase text-slate-500 dark:text-slate-400 flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4 text-amber-600 dark:text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Prioritas Penagihan (Top 10 Lintas Desa)" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-bold rounded-full bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/30 px-2.5 py-0.5",
										children: "Belum Lunas"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-2 max-h-[440px] overflow-y-auto pr-1 custom-scrollbar",
									children: topUnpaidTaxpayers.length > 0 ? topUnpaidTaxpayers.map((taxpayer, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between border border-emerald-100 dark:border-slate-800 rounded-xl p-3 bg-emerald-50/40 dark:bg-slate-950/60 hover:bg-emerald-100/50 dark:hover:bg-slate-800/40 transition-colors",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2.5 min-w-0 pr-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: `size-6 shrink-0 rounded-lg flex items-center justify-center text-[11px] font-black font-mono shadow-xs ${idx === 0 ? "bg-amber-400 text-slate-950" : idx === 1 ? "bg-slate-300 text-slate-950" : idx === 2 ? "bg-amber-700/80 text-white" : "bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300"}`,
												children: ["#", idx + 1]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-w-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-bold text-slate-900 dark:text-slate-100 truncate",
													children: taxpayer.namaSppt
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-[10px] text-slate-500 dark:text-slate-400 font-mono flex items-center gap-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["NOP: ", taxpayer.nop] }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1 rounded-full bg-slate-300 dark:bg-slate-700" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "font-bold text-emerald-700 dark:text-emerald-400",
															children: taxpayer.lokasi
														})
													]
												})]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold text-rose-600 dark:text-rose-400 font-mono shrink-0",
											children: formatRp(taxpayer.tagihan)
										})]
									}, taxpayer.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "border border-dashed border-emerald-200 dark:border-slate-800 rounded-xl p-5 text-center text-xs text-slate-500",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-4 mx-auto mb-1 text-slate-400 dark:text-slate-600" }), "Tidak ada tunggakan aktif di wilayah ini."]
									})
								})]
							})
						]
					})]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "lg:col-span-3 overflow-hidden border-emerald-100/80 dark:border-slate-800/80 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md shadow-xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
						className: "border-b border-emerald-100/80 dark:border-slate-800/80 bg-emerald-50/60 dark:bg-slate-950/60 px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
							className: "text-base font-extrabold tracking-tight text-slate-900 dark:text-slate-100 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), " Ringkasan & Status Realisasi Per Dusun"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-600 dark:text-slate-400",
							children: "Klik salah satu kartu dusun untuk memfilter rincian realisasi penerimaan pajak."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 self-end sm:self-center shrink-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex rounded-xl border border-emerald-200 dark:border-slate-800 bg-white dark:bg-slate-950 p-1 shadow-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setViewModeDusun("grid"),
									className: `rounded-lg px-2.5 py-1 text-xs font-extrabold transition-all cursor-pointer ${viewModeDusun === "grid" ? "bg-emerald-600 text-white shadow-sm" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
									children: "Kartu Dusun"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setViewModeDusun("map"),
									className: `rounded-lg px-2.5 py-1 text-xs font-extrabold transition-all cursor-pointer ${viewModeDusun === "map" ? "bg-emerald-600 text-white shadow-sm" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
									children: "Peta Choropleth"
								})]
							}), selectedLokasi && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setSelectedLokasi(null),
								className: "inline-flex items-center gap-1.5 rounded-lg border border-emerald-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-2.5 py-1.5 text-xs font-bold text-slate-800 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-slate-700 transition-all cursor-pointer shadow-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3.5 text-amber-600 dark:text-amber-400" }), "Reset"]
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
						className: "p-6 bg-emerald-50/30 dark:bg-slate-950/40",
						children: viewModeDusun === "grid" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: blockStats.map((stat) => {
								const isSelected = selectedLokasi?.toUpperCase() === stat.name.toUpperCase();
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									onClick: () => setSelectedLokasi(isSelected ? null : stat.name),
									className: `relative cursor-pointer overflow-hidden rounded-2xl border p-4 transition-all duration-300 ${isSelected ? "border-emerald-500 bg-emerald-50/90 dark:bg-emerald-950/40 shadow-lg ring-2 ring-emerald-500/40" : "border-emerald-100/90 dark:border-slate-800 bg-white/90 dark:bg-slate-900/80 hover:-translate-y-1 hover:border-emerald-300 hover:shadow-md"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: "text-sm font-black text-slate-900 dark:text-white",
												children: stat.name
											})]
										}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: `rounded-full border px-2.5 py-0.5 text-[10px] font-extrabold ${stat.badgeColor}`,
											children: [Math.round(stat.persen), "%"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-3 space-y-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between text-xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-slate-500 dark:text-slate-400 font-medium",
													children: "Target:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-mono font-bold text-slate-800 dark:text-slate-200",
													children: formatRp(stat.target)
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between text-xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-slate-500 dark:text-slate-400 font-medium",
													children: "Realisasi:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-mono font-bold text-emerald-700 dark:text-emerald-400",
													children: formatRp(stat.realisasi)
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between text-xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-slate-500 dark:text-slate-400 font-medium",
													children: "Piutang:"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-mono font-bold text-rose-600 dark:text-rose-400",
													children: formatRp(stat.piutang)
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
												value: stat.persen,
												className: "mt-2 h-1.5 bg-slate-200 dark:bg-slate-800 [&>*]:bg-emerald-600"
											})
										]
									})]
								}, stat.name);
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative p-2 flex flex-col items-center justify-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative w-full max-w-lg aspect-[500/350]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
									viewBox: "0 0 500 350",
									className: "w-full h-full select-none",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
											d: "M 20,150 Q 250,170 480,160",
											fill: "none",
											stroke: "currentColor",
											strokeWidth: "4",
											strokeDasharray: "8,6",
											className: "opacity-40 text-emerald-400 dark:text-slate-700"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
											x: "30",
											y: "142",
											className: "fill-slate-500 dark:fill-slate-400 text-[9px] font-mono font-bold tracking-widest",
											children: "JL. UTAMA DESA"
										}),
										blockStats.map((stat) => {
											const isSelected = selectedLokasi?.toUpperCase() === stat.name.toUpperCase();
											let dPath = "";
											let textCoords = {
												x: 0,
												y: 0
											};
											const sName = stat.name.toUpperCase();
											if (sName === "BALOK" || sName === "DUSUN BALOK") {
												dPath = "M 50,50 L 240,50 L 220,170 L 60,150 Z";
												textCoords = {
													x: 140,
													y: 100
												};
											} else if (sName === "CIDERES" || sName === "DUSUN CIDERES") {
												dPath = "M 240,50 L 450,50 L 430,170 L 220,170 Z";
												textCoords = {
													x: 330,
													y: 105
												};
											} else if (sName.includes("PUNCAK")) {
												dPath = "M 60,150 L 220,170 L 200,290 L 80,270 Z";
												textCoords = {
													x: 140,
													y: 220
												};
											} else if (sName === "CIPEDES" || sName === "DUSUN CIPEDES") {
												dPath = "M 220,170 L 430,170 L 400,290 L 200,290 Z";
												textCoords = {
													x: 310,
													y: 230
												};
											} else {
												dPath = "M 80,270 L 200,290 L 180,340 L 60,320 Z";
												textCoords = {
													x: 130,
													y: 310
												};
											}
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
												className: "cursor-pointer",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
														d: dPath,
														className: `${stat.colorClass} ${stat.strokeClass} transition-all duration-300`,
														strokeWidth: isSelected ? "3" : "1.5",
														style: {
															filter: isSelected ? "drop-shadow(0 0 12px rgba(16, 185, 129, 0.4))" : "none",
															opacity: selectedLokasi === null || isSelected ? 1 : .35
														},
														onClick: () => setSelectedLokasi(isSelected ? null : stat.name),
														onMouseMove: (e) => {
															const parentRect = e.currentTarget.parentElement?.parentElement?.getBoundingClientRect();
															if (parentRect) setHoveredBlock({
																name: stat.name,
																target: stat.target,
																realisasi: stat.realisasi,
																persen: Math.round(stat.persen),
																x: e.clientX - parentRect.left + 15,
																y: e.clientY - parentRect.top - 15
															});
														},
														onMouseLeave: () => setHoveredBlock(null)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
														x: textCoords.x,
														y: textCoords.y,
														textAnchor: "middle",
														className: `text-xs font-bold pointer-events-none transition-colors duration-300 ${isSelected ? "fill-slate-900 dark:fill-white font-black" : "fill-slate-700 dark:fill-slate-300"}`,
														children: stat.name
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("text", {
														x: textCoords.x,
														y: textCoords.y + 16,
														textAnchor: "middle",
														className: `text-[10px] font-mono font-bold pointer-events-none transition-colors duration-300 ${isSelected ? "fill-emerald-700 dark:fill-emerald-400" : "fill-slate-600 dark:fill-slate-400"}`,
														children: [Math.round(stat.persen), "%"]
													})
												]
											}, stat.name);
										})
									]
								}), hoveredBlock && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "absolute pointer-events-none rounded-xl border border-emerald-200 dark:border-slate-700 bg-white/95 dark:bg-slate-950/95 p-3.5 shadow-2xl backdrop-blur-md text-xs space-y-1.5 transition-all duration-100 z-50 min-w-44 text-slate-900 dark:text-slate-100",
									style: {
										left: hoveredBlock.x,
										top: hoveredBlock.y
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-extrabold text-amber-600 dark:text-amber-400 font-mono text-sm",
										children: hoveredBlock.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1 text-slate-700 dark:text-slate-300 font-medium",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between gap-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Target:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-mono font-bold text-slate-900 dark:text-white",
													children: formatRp(hoveredBlock.target)
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between gap-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Realisasi:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-mono font-bold text-emerald-700 dark:text-emerald-400",
													children: formatRp(hoveredBlock.realisasi)
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-between gap-4 border-t border-emerald-100 dark:border-slate-800 pt-1 mt-1 font-bold",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Capaian:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "font-mono text-amber-600 dark:text-amber-400",
													children: [hoveredBlock.persen, "%"]
												})]
											})
										]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-wrap gap-5 justify-center border-t border-emerald-100/80 dark:border-slate-800/60 pt-4 w-full text-xs font-semibold text-slate-600 dark:text-slate-400",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3 rounded-md bg-rose-500/20 border border-rose-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Kritis (< 30%)" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3 rounded-md bg-amber-500/20 border border-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Moderat (30% - 45%)" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3 rounded-md bg-emerald-500/20 border border-emerald-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Optimal (> 45%)" })]
									})
								]
							})]
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "lg:col-span-2 overflow-hidden flex flex-col justify-between border-emerald-100/80 dark:border-slate-800/80 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md shadow-xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
						className: "border-b border-emerald-100/80 dark:border-slate-800/80 bg-emerald-50/60 dark:bg-slate-950/60 px-6 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
							className: "text-base font-extrabold tracking-tight text-slate-900 dark:text-slate-100 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4 text-amber-600 dark:text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Detail Dusun: ", selectedLokasi || "Seluruh Dusun"] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-600 dark:text-slate-400",
							children: selectedLokasi ? `Statistik khusus dan penagihan prioritas di ${selectedLokasi}` : `Rincian kumulatif seluruh dusun di ${namaDesaAktif}`
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-6 flex-1 space-y-6",
						children: [
							activeStats && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `rounded-xl border p-3.5 flex items-center justify-between shadow-inner ${activeStats.badgeColor}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-0.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-bold uppercase tracking-wider opacity-85",
										children: "Kategori Realisasi"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-black",
										children: activeStats.persen < 30 ? "PENERIMAAN KRITIS" : activeStats.persen < 45 ? "PENERIMAAN MODERAT" : "PENERIMAAN OPTIMAL"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xl font-black font-mono",
									children: [Math.round(activeStats.persen), "%"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-xs font-bold tracking-wider uppercase text-slate-500 dark:text-slate-400",
									children: "Indikator Realisasi"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between text-xs font-bold mb-1.5 text-slate-700 dark:text-slate-300",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Rasio Realisasi Terhadap Target" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono text-emerald-700 dark:text-emerald-400",
											children: [progressPercent, "%"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
										value: progressPercent,
										className: "h-2 bg-emerald-100 dark:bg-slate-950 border border-emerald-200 dark:border-slate-800 [&>*]:bg-emerald-600"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-3 pt-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-emerald-50/50 dark:bg-slate-950/80 border border-emerald-100 dark:border-slate-800 rounded-xl p-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase",
												children: "Total SPPT"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-black text-slate-900 dark:text-slate-100 font-mono mt-0.5",
												children: totalSPPTVal
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-emerald-50/50 dark:bg-slate-950/80 border border-emerald-100 dark:border-slate-800 rounded-xl p-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase",
												children: "Sisa Piutang"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-black text-rose-600 dark:text-rose-400 font-mono mt-0.5",
												children: formatRp(totalPiutang)
											})]
										})]
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3 pt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
										className: "text-xs font-bold tracking-wider uppercase text-slate-500 dark:text-slate-400 flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4 text-amber-600 dark:text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Prioritas Penagihan (Top 10)" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] font-bold rounded-full bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/30 px-2.5 py-0.5",
										children: "Belum Lunas"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-2 max-h-[440px] overflow-y-auto pr-1 custom-scrollbar",
									children: topUnpaidTaxpayers.length > 0 ? topUnpaidTaxpayers.map((taxpayer, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between border border-emerald-100 dark:border-slate-800 rounded-xl p-3 bg-emerald-50/40 dark:bg-slate-950/60 hover:bg-emerald-100/50 dark:hover:bg-slate-800/40 transition-colors",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2.5 min-w-0 pr-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: `size-6 shrink-0 rounded-lg flex items-center justify-center text-[11px] font-black font-mono shadow-xs ${idx === 0 ? "bg-amber-400 text-slate-950" : idx === 1 ? "bg-slate-300 text-slate-950" : idx === 2 ? "bg-amber-700/80 text-white" : "bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300"}`,
												children: ["#", idx + 1]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-w-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-bold text-slate-900 dark:text-slate-100 truncate",
													children: taxpayer.namaSppt
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-[10px] text-slate-500 dark:text-slate-400 font-mono flex items-center gap-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["NOP: ", taxpayer.nop] }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1 rounded-full bg-slate-300 dark:bg-slate-700" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: taxpayer.lokasi })
													]
												})]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold text-rose-600 dark:text-rose-400 font-mono shrink-0",
											children: formatRp(taxpayer.tagihan)
										})]
									}, taxpayer.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "border border-dashed border-emerald-200 dark:border-slate-800 rounded-xl p-5 text-center text-xs text-slate-500",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-4 mx-auto mb-1 text-slate-400 dark:text-slate-600" }), "Tidak ada tunggakan aktif di wilayah ini."]
									})
								})]
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "overflow-hidden border-emerald-100/80 dark:border-slate-800/80 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md shadow-xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
					className: "border-b border-emerald-100/80 dark:border-slate-800/80 bg-emerald-50/60 dark:bg-slate-950/60 px-6 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "text-base font-extrabold tracking-tight text-slate-900 dark:text-slate-100",
						children: isSuperAdmin ? "Grafik Perbandingan Target vs Realisasi Per Desa" : "Grafik Perbandingan Target vs Realisasi Per Dusun"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-slate-600 dark:text-slate-400",
						children: isSuperAdmin ? "Grafik perbandingan ketetapan target PBB-P2 terhadap capaian penerimaan untuk seluruh desa terdaftar." : `Grafik perbandingan ketetapan target PBB-P2 terhadap capaian penerimaan per dusun di ${namaDesaAktif}.`
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
					className: "h-[340px] pl-2 pt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: activeChartData,
							margin: {
								top: 8,
								right: 16,
								left: 8,
								bottom: 0
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
									strokeDasharray: "3 3",
									vertical: false,
									stroke: "var(--border)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "lokasi",
									tickLine: false,
									axisLine: false,
									fontSize: 12,
									fontWeight: 600,
									stroke: "var(--muted-foreground)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									tickFormatter: (v) => `${v / 1e6}jt`,
									tickLine: false,
									axisLine: false,
									fontSize: 12,
									fontWeight: 600,
									stroke: "var(--muted-foreground)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									cursor: {
										fill: "var(--accent)",
										opacity: .4
									},
									formatter: (v) => formatRp(v),
									contentStyle: {
										borderRadius: 12,
										border: "1px solid var(--border)",
										background: "var(--card)",
										boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)",
										fontSize: 12,
										fontWeight: 600,
										color: "var(--foreground)"
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, { wrapperStyle: {
									fontSize: 12,
									fontWeight: 600,
									paddingTop: 10,
									color: "var(--muted-foreground)"
								} }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "Target",
									radius: [
										6,
										6,
										0,
										0
									],
									maxBarSize: 38,
									children: activeChartData.map((entry, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
										fill: "#f59e0b",
										fillOpacity: entry.opacity
									}, `cell-target-${index}`))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "Realisasi",
									radius: [
										6,
										6,
										0,
										0
									],
									maxBarSize: 38,
									children: activeChartData.map((entry, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
										fill: "#059669",
										fillOpacity: entry.opacity
									}, `cell-realisasi-${index}`))
								})
							]
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "overflow-hidden border-emerald-100/80 dark:border-slate-800/80 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md shadow-xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
					className: "border-b border-emerald-100/80 dark:border-slate-800/80 bg-gradient-to-r from-emerald-900/10 via-teal-900/5 to-slate-900/10 dark:from-emerald-950/40 dark:via-slate-950 dark:to-slate-900 px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid size-8 place-items-center rounded-lg bg-emerald-600 text-white shadow-md",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
							className: "text-base font-black tracking-tight text-slate-900 dark:text-slate-100",
							children: isSuperAdmin ? "Realisasi & Pengawasan Setoran Desa ke Kecamatan" : `Status Setoran PBB-P2 ${namaDesaAktif} ke Kecamatan`
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs font-medium text-slate-600 dark:text-slate-400",
						children: isSuperAdmin ? "Pantau status penerimaan berkas setoran, verifikasi dana dari seluruh desa, dan akumulasi sisa kas desa." : `Rekap setoran resmi yang telah dikirim ke pihak Kecamatan dan status verifikasi penerimaan.`
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/setoran-kecamatan",
						className: "inline-flex items-center gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 text-xs font-black shadow-md transition-all active:scale-95 shrink-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-3.5" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isSuperAdmin ? "Kelola & Verifikasi Setoran" : "Modul Pengeluaran PBB-P2" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5" })
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "p-6 space-y-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-emerald-200 dark:border-emerald-900/40 bg-emerald-50/60 dark:bg-emerald-950/20 p-4 transition-all hover:shadow-md",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-extrabold uppercase tracking-wider text-emerald-800 dark:text-emerald-400",
											children: "Setoran Diterima (Verified)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid size-7 place-items-center rounded-full bg-emerald-500/20 text-emerald-700 dark:text-emerald-400",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4" })
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-2xl font-black font-mono text-emerald-900 dark:text-emerald-300",
										children: formatRp(setoranSummary?.totalDiterima || 0)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-[11px] font-semibold text-emerald-700 dark:text-emerald-400",
										children: [setoranSummary?.counts?.diterima || 0, " transaksi disetujui Kecamatan"]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-amber-200 dark:border-amber-900/40 bg-amber-50/60 dark:bg-amber-950/20 p-4 transition-all hover:shadow-md",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-extrabold uppercase tracking-wider text-amber-800 dark:text-amber-400",
											children: "Pending Verifikasi"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid size-7 place-items-center rounded-full bg-amber-500/20 text-amber-700 dark:text-amber-400",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4" })
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-2xl font-black font-mono text-amber-900 dark:text-amber-300",
										children: formatRp(setoranSummary?.totalPending || 0)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-[11px] font-semibold text-amber-700 dark:text-amber-400",
										children: [setoranSummary?.counts?.pending || 0, " berkas menunggu persetujuan"]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-teal-200 dark:border-teal-900/40 bg-teal-50/60 dark:bg-teal-950/20 p-4 transition-all hover:shadow-md",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-extrabold uppercase tracking-wider text-teal-800 dark:text-teal-400",
											children: "Sisa Kas Desa (Belum Disetor)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid size-7 place-items-center rounded-full bg-teal-500/20 text-teal-700 dark:text-teal-400",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4" })
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-2xl font-black font-mono text-teal-900 dark:text-teal-300",
										children: formatRp(setoranSummary?.sisaKasDesa || 0)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-[11px] font-semibold text-teal-700 dark:text-teal-400",
										children: "Realisasi PBB tersimpan di Kas Desa"
									})
								]
							})
						]
					}), isSuperAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
								className: "text-xs font-extrabold tracking-wider uppercase text-slate-700 dark:text-slate-300 flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Rekapitulasi Capaian Setoran Per Desa ke Kecamatan" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-800",
								children: [setoranSummary?.rekapPerDesa?.length || 0, " Desa Terdaftar"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full text-left text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-300 font-extrabold uppercase text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3",
											children: "Desa"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 text-right",
											children: "Target PBB"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 text-right",
											children: "Realisasi PBB"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 text-right",
											children: "Disetor (Diterima)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 text-center",
											children: "% Capaian"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 text-right",
											children: "Sisa Kas Desa"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 text-center",
											children: "Status Terakhir"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 text-center",
											children: "Aksi"
										})
									] })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
									className: "divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-slate-900/80 font-medium",
									children: setoranSummary?.rekapPerDesa && setoranSummary.rekapPerDesa.length > 0 ? setoranSummary.rekapPerDesa.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
												className: "px-4 py-3 font-bold text-slate-900 dark:text-white",
												children: [row.namaDesa, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "block text-[10px] font-mono font-normal text-slate-500 dark:text-slate-400",
													children: ["Kode: ", row.kodeDesa]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3 text-right font-mono font-semibold",
												children: formatRp(row.targetPbb)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3 text-right font-mono font-semibold text-emerald-700 dark:text-emerald-400",
												children: formatRp(row.realisasiPbb)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3 text-right font-mono font-bold text-teal-700 dark:text-teal-400",
												children: formatRp(row.totalDisetorDiterima)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3 text-center",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-col items-center gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "font-mono font-black text-amber-600 dark:text-amber-400",
														children: [row.persentaseDisetor, "%"]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
														value: Math.min(100, row.persentaseDisetor),
														className: "h-1.5 w-16 bg-slate-200 dark:bg-slate-800 [&>*]:bg-emerald-600"
													})]
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3 text-right font-mono font-bold text-amber-600 dark:text-amber-400",
												children: formatRp(row.sisaKasDesa)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3 text-center",
												children: row.statusTerakhir === "DITERIMA" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-800",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3" }), " DITERIMA"]
												}) : row.statusTerakhir === "PENDING" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-400 border border-amber-300 dark:border-amber-800",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3" }), " PENDING"]
												}) : row.statusTerakhir === "DITOLAK" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-400 border border-rose-300 dark:border-rose-800",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-3" }), " DITOLAK"]
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] text-slate-400 font-mono",
													children: "Belum Ada"
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3 text-center",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
													to: "/setoran-kecamatan",
													className: "inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 hover:underline",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Verifikasi" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3" })]
												})
											})
										]
									}, row.desaId)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										colSpan: 8,
										className: "px-4 py-6 text-center text-slate-500 text-xs",
										children: "Tidak ada data rekapitulasi desa."
									}) })
								})]
							})
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
								className: "text-xs font-extrabold tracking-wider uppercase text-slate-700 dark:text-slate-300 flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4 text-teal-600 dark:text-teal-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Riwayat Setoran Desa ke Kecamatan Terakhir" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/setoran-kecamatan",
								className: "text-[11px] font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Lihat Semua Setoran" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3" })]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full text-left text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-300 font-extrabold uppercase text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3",
											children: "No. Bukti"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3",
											children: "Tanggal Setor"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 text-right",
											children: "Nominal Setoran"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3",
											children: "Metode & Bank"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3",
											children: "Penyetor"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3 text-center",
											children: "Status"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-3",
											children: "Keterangan Verifikasi"
										})
									] })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
									className: "divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-slate-900/80 font-medium",
									children: setoranItems && setoranItems.length > 0 ? setoranItems.slice(0, 5).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3 font-mono font-bold text-slate-900 dark:text-white",
												children: item.nomorBukti
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3 text-slate-700 dark:text-slate-300 font-mono",
												children: item.tanggalSetor
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3 text-right font-mono font-extrabold text-emerald-700 dark:text-emerald-400",
												children: formatRp(item.nominal)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
												className: "px-4 py-3 text-slate-700 dark:text-slate-300",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-bold",
													children: item.metodeSetoran
												}), item.bankTujuan && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block text-[10px] text-slate-500 font-mono",
													children: item.bankTujuan
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
												className: "px-4 py-3 text-slate-700 dark:text-slate-300",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-bold",
													children: item.penyetorNama
												}), item.penyetorJabatan && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block text-[10px] text-slate-500",
													children: item.penyetorJabatan
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-3 text-center",
												children: item.status === "DITERIMA" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-800",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3" }), " DITERIMA"]
												}) : item.status === "PENDING" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-400 border border-amber-300 dark:border-amber-800",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3" }), " PENDING"]
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-400 border border-rose-300 dark:border-rose-800",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-3" }), " DITOLAK"]
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
												className: "px-4 py-3 text-slate-600 dark:text-slate-400 text-[11px]",
												children: [item.tanggalDiterima && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "block text-[10px] font-mono text-emerald-700 dark:text-emerald-400 font-bold",
													children: ["Diverifikasi: ", item.tanggalDiterima]
												}), item.catatanKecamatan || item.catatanDesa || "-"]
											})
										]
									}, item.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										colSpan: 7,
										className: "px-4 py-8 text-center text-slate-500",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-col items-center justify-center space-y-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-8 text-slate-400 dark:text-slate-600" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-bold text-slate-700 dark:text-slate-300",
													children: "Belum ada riwayat setoran PBB-P2 ke kecamatan."
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
													to: "/setoran-kecamatan",
													className: "inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-1.5 text-xs font-extrabold shadow-sm transition-all",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Buat Setoran Baru ke Kecamatan" })]
												})
											]
										})
									}) })
								})]
							})
						})]
					})]
				})]
			})
		] })]
	});
}
//#endregion
export { Dashboard as component };
