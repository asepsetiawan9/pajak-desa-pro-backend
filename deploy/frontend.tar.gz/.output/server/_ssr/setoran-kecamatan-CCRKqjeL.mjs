import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { a as useTenantStore, i as useAuthStore, o as useUserStore, r as cn, t as ROLE_LABELS } from "./authStore-CZRDvP0Z.mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-YtzMxdp3.mjs";
import { t as Input } from "./input-BBQFjwfK.mjs";
import { i as useSettingsStore } from "./settingsStore-BBOTJBY5.mjs";
import { At as CircleX, D as Send, Dt as Clock, Jt as Award, Mt as CircleAlert, N as Printer, O as Search, S as ShieldCheck, Wt as Building2, d as TrendingUp, f as Trash2, ft as FileText, jt as CircleCheck, kt as Circle, m as Tag, n as Wallet, rt as Info, s as Upload, tt as Landmark, u as TriangleAlert, v as SquarePen, vt as Eye } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-BnDjHZuV.mjs";
import { t as Badge } from "./badge-DeRhpfUp.mjs";
import { t as desaService } from "./desaService-B2uJrXze.mjs";
import { t as Label } from "./label-CiVZqe-N.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-HQswfJbV.mjs";
import { t as require_jspdf_node_min } from "../_libs/jspdf.mjs";
import { t as autoTable } from "../_libs/jspdf-autotable.mjs";
import { t as Swal } from "../_libs/sweetalert2.mjs";
import { t as Textarea } from "./textarea-DnDCSoN1.mjs";
import { t as triggerGlobalNotifRefresh } from "./pengeluaranNotifStore-B2Fwq7FT.mjs";
import { t as useSetoranKecamatanStore } from "./setoranKecamatanStore-9CbL7icp.mjs";
import { n as RadioGroupIndicator, r as RadioGroupItem$1, t as RadioGroup$1 } from "../_libs/radix-ui__react-radio-group.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/setoran-kecamatan-CCRKqjeL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_jspdf_node_min = /* @__PURE__ */ __toESM(require_jspdf_node_min());
var formatRp = (val) => {
	return new Intl.NumberFormat("id-ID", {
		style: "currency",
		currency: "IDR",
		maximumFractionDigits: 0
	}).format(val);
};
var generateBuktiSetorPdf = (item, settings) => {
	const doc = new import_jspdf_node_min.default({
		orientation: "portrait",
		unit: "pt",
		format: "a4"
	});
	const pageWidth = doc.internal.pageSize.getWidth();
	doc.setFillColor(5, 150, 105);
	doc.rect(0, 0, pageWidth, 8, "F");
	doc.setFont("helvetica", "bold");
	doc.setFontSize(12);
	doc.setTextColor(15, 23, 42);
	doc.text(`PEMERINTAH KABUPATEN ${settings.kabupaten.toUpperCase()}`, pageWidth / 2, 32, { align: "center" });
	doc.setFontSize(11);
	doc.setTextColor(5, 150, 105);
	doc.text(`KECAMATAN ${(item.namaKecamatan || settings.kecamatan).toUpperCase()}`, pageWidth / 2, 46, { align: "center" });
	doc.setFontSize(10);
	doc.setTextColor(30, 41, 59);
	doc.text(`DESA ${(item.namaDesa || settings.namaDesa).toUpperCase()}`, pageWidth / 2, 58, { align: "center" });
	doc.setFont("helvetica", "normal");
	doc.setFontSize(8);
	doc.setTextColor(100, 116, 139);
	doc.text(settings.alamatDesa || "Kantor Sekretariat Pelayanan Pajak Daerah & PBB-P2", pageWidth / 2, 70, { align: "center" });
	doc.setDrawColor(5, 150, 105);
	doc.setLineWidth(1.5);
	doc.line(36, 78, pageWidth - 36, 78);
	doc.setDrawColor(245, 158, 11);
	doc.setLineWidth(.5);
	doc.line(36, 81, pageWidth - 36, 81);
	let startY = 100;
	doc.setFont("helvetica", "bold");
	doc.setFontSize(13);
	doc.setTextColor(15, 23, 42);
	doc.text("SURAT TANDA TERIMA SETORAN PBB-P2 KE KECAMATAN", pageWidth / 2, startY, { align: "center" });
	doc.setFontSize(9);
	doc.setFont("helvetica", "normal");
	doc.setTextColor(71, 85, 105);
	doc.text(`Nomor Bukti: ${item.nomorBukti}`, pageWidth / 2, startY + 14, { align: "center" });
	startY += 34;
	const statusColor = item.status === "DITERIMA" ? [
		5,
		150,
		105
	] : item.status === "DITOLAK" ? [
		225,
		29,
		72
	] : [
		217,
		119,
		6
	];
	doc.setFillColor(item.status === "DITERIMA" ? 240 : item.status === "DITOLAK" ? 254 : 254, item.status === "DITERIMA" ? 253 : item.status === "DITOLAK" ? 242 : 243, item.status === "DITERIMA" ? 244 : item.status === "DITOLAK" ? 242 : 199);
	doc.setDrawColor(statusColor[0], statusColor[1], statusColor[2]);
	doc.roundedRect(36, startY, pageWidth - 72, 32, 6, 6, "FD");
	const isInternal = item.kategori !== "SETOR_KECAMATAN";
	const statusTitle = isInternal ? `STATUS PERSETUJUAN KEPALA DESA: ${item.status === "DITERIMA" ? "DISETUJUI" : item.status}` : `STATUS VERIFIKASI KECAMATAN: ${item.status}`;
	doc.setFont("helvetica", "bold");
	doc.setFontSize(9);
	doc.setTextColor(statusColor[0], statusColor[1], statusColor[2]);
	doc.text(statusTitle, 48, startY + 20);
	if (item.tanggalDiterima) {
		doc.setFont("helvetica", "normal");
		doc.setFontSize(8);
		doc.setTextColor(71, 85, 105);
		doc.text(`Dikonfirmasi Tanggal: ${item.tanggalDiterima}`, pageWidth - 200, startY + 20);
	}
	startY += 48;
	autoTable(doc, {
		startY,
		head: [["PARAMETER INFORMASI", "RINCIAN DATA PENGELUARAN PBB-P2"]],
		body: [
			["Desa", `${item.namaDesa || settings.namaDesa} (Kode: ${item.kodeDesa || settings.kodeDesa})`],
			["Kategori Pengeluaran", item.kategori === "SETOR_KECAMATAN" ? "Setor PBB ke Kecamatan" : item.kategori === "KEGIATAN_DESA" ? "Kegiatan Desa / PHBN" : item.kategori === "OPERASIONAL_DESA" ? "Operasional Petugas" : item.kategori === "ADMINISTRASI" ? "Administrasi & ATK" : "Pengeluaran Lainnya"],
			["Tahun Pajak Ketetapan", `Tahun ${item.tahun}`],
			["Tanggal Setor / Pengeluaran", item.tanggalSetor],
			["Jumlah Nominal Pengeluaran", formatRp(item.nominal)],
			["Metode Pembayaran", item.metodeSetoran === "TRANSFER" ? `Transfer Bank (${item.bankTujuan || "BJB"})` : item.metodeSetoran],
			["Nomor Referensi Transfer", item.nomorReferensi || "-"],
			["Penanggung Jawab", `${item.penyetorNama} (${item.penyetorJabatan || "Petugas Desa"})`],
			["Tujuan / Penerima", item.penerimaKecamatan || (item.kategori === "SETOR_KECAMATAN" ? "Pemerintah Kecamatan" : "Internal Desa")],
			["Catatan Pengirim", item.catatanDesa || "-"],
			[isInternal ? "Catatan Persetujuan Kades" : "Catatan Verifikasi Kecamatan", item.catatanKecamatan || "-"]
		],
		theme: "plain",
		styles: {
			fontSize: 8.5,
			cellPadding: 6,
			font: "helvetica"
		},
		headStyles: {
			fillColor: [
				5,
				150,
				105
			],
			textColor: 255,
			fontStyle: "bold"
		},
		columnStyles: {
			0: {
				cellWidth: 160,
				fontStyle: "bold",
				textColor: [
					30,
					41,
					59
				]
			},
			1: { textColor: [
				15,
				23,
				42
			] }
		},
		didParseCell: (data) => {
			if (data.row.index === 4) {
				data.cell.styles.fontStyle = "bold";
				data.cell.styles.fontSize = 10;
				data.cell.styles.textColor = [
					5,
					150,
					105
				];
			}
		},
		margin: {
			left: 36,
			right: 36
		}
	});
	const finalY = doc.lastAutoTable.finalY + 40;
	const leftColX = pageWidth * .25;
	const rightColX = pageWidth * .75;
	doc.setFont("helvetica", "normal");
	doc.setFontSize(8.5);
	doc.setTextColor(30, 41, 59);
	doc.text("Penyetor (Desa),", leftColX, finalY, { align: "center" });
	doc.setFont("helvetica", "bold");
	doc.text(item.penyetorNama, leftColX, finalY + 45, { align: "center" });
	doc.setFont("helvetica", "normal");
	doc.setFontSize(8);
	doc.text(item.penyetorJabatan || "Bendahara Desa", leftColX, finalY + 56, { align: "center" });
	doc.text("Diterima Oleh (Kecamatan),", rightColX, finalY, { align: "center" });
	doc.setFont("helvetica", "bold");
	doc.text(item.penerimaNama || item.penerimaKecamatan || "Petugas Kecamatan", rightColX, finalY + 45, { align: "center" });
	doc.setFont("helvetica", "normal");
	doc.setFontSize(8);
	doc.text("Tim Penerima PBB Kecamatan", rightColX, finalY + 56, { align: "center" });
	doc.setFont("helvetica", "normal");
	doc.setFontSize(7.5);
	doc.setTextColor(148, 163, 184);
	doc.text(`Bukti Setor Resmi SIPABAR (Sistem Informasi Pajak Barudua) • Dicetak pada: ${(/* @__PURE__ */ new Date()).toLocaleString("id-ID")}`, pageWidth / 2, doc.internal.pageSize.getHeight() - 14, { align: "center" });
	const filename = `Bukti_Setor_Kecamatan_${item.nomorBukti.replace(/[\/\s]+/g, "_")}.pdf`;
	doc.save(filename);
	return filename;
};
var generateRekapSetoranKecamatanPdf = (rekapList, tahun, settings) => {
	const doc = new import_jspdf_node_min.default({
		orientation: "landscape",
		unit: "pt",
		format: "a4"
	});
	const pageWidth = doc.internal.pageSize.getWidth();
	doc.setFillColor(5, 150, 105);
	doc.rect(0, 0, pageWidth, 8, "F");
	doc.setFont("helvetica", "bold");
	doc.setFontSize(13);
	doc.setTextColor(15, 23, 42);
	doc.text(`PEMERINTAH KABUPATEN ${settings.kabupaten.toUpperCase()}`, pageWidth / 2, 32, { align: "center" });
	doc.setFontSize(11);
	doc.setTextColor(5, 150, 105);
	doc.text(`KECAMATAN ${settings.kecamatan.toUpperCase()}`, pageWidth / 2, 48, { align: "center" });
	doc.setFont("helvetica", "normal");
	doc.setFontSize(8.5);
	doc.setTextColor(100, 116, 139);
	doc.text("Laporan Rekapitulasi Catatan Penerimaan Setoran PBB-P2 dari Seluruh Desa", pageWidth / 2, 60, { align: "center" });
	doc.setDrawColor(5, 150, 105);
	doc.setLineWidth(1.5);
	doc.line(36, 68, pageWidth - 36, 68);
	doc.setDrawColor(245, 158, 11);
	doc.setLineWidth(.5);
	doc.line(36, 71, pageWidth - 36, 71);
	let startY = 88;
	doc.setFont("helvetica", "bold");
	doc.setFontSize(12);
	doc.setTextColor(15, 23, 42);
	doc.text(`REKAPITULASI PENERIMAAN SETORAN PBB-P2 DESA SE-KECAMATAN TAHUN ${tahun}`, pageWidth / 2, startY, { align: "center" });
	startY += 18;
	const totalTarget = rekapList.reduce((acc, curr) => acc + curr.targetPbb, 0);
	const totalRealisasi = rekapList.reduce((acc, curr) => acc + curr.realisasiPbb, 0);
	const totalDisetor = rekapList.reduce((acc, curr) => acc + curr.totalDisetorDiterima, 0);
	const totalSisa = rekapList.reduce((acc, curr) => acc + curr.sisaKasDesa, 0);
	const overallPct = totalTarget > 0 ? totalDisetor / totalTarget * 100 : 0;
	const tableHeaders = [[
		"NO",
		"KODE DESA",
		"NAMA DESA",
		"TARGET PBB (Rp)",
		"REALISASI DESA (Rp)",
		"DISITOR KE KECAMATAN (Rp)",
		"SISA KAS DESA (Rp)",
		"% CAPAIAN",
		"TGL SETOR TERAKHIR"
	]];
	const bodyRows = rekapList.map((r, idx) => [
		idx + 1,
		r.kodeDesa,
		r.namaDesa,
		formatRp(r.targetPbb),
		formatRp(r.realisasiPbb),
		formatRp(r.totalDisetorDiterima),
		formatRp(r.sisaKasDesa),
		`${r.persentaseDisetor.toFixed(2)}%`,
		r.tanggalSetorTerakhir || "-"
	]);
	const grandTotalRow = [
		"JUMLAH TOTAL",
		"",
		"KECAMATAN",
		formatRp(totalTarget),
		formatRp(totalRealisasi),
		formatRp(totalDisetor),
		formatRp(totalSisa),
		`${overallPct.toFixed(2)}%`,
		""
	];
	autoTable(doc, {
		startY,
		head: tableHeaders,
		body: [...bodyRows, grandTotalRow],
		theme: "grid",
		styles: {
			fontSize: 8,
			cellPadding: 5,
			halign: "center",
			font: "helvetica"
		},
		headStyles: {
			fillColor: [
				5,
				150,
				105
			],
			textColor: 255,
			fontStyle: "bold"
		},
		alternateRowStyles: { fillColor: [
			248,
			250,
			252
		] },
		columnStyles: {
			0: { cellWidth: 25 },
			2: {
				halign: "left",
				fontStyle: "bold"
			},
			3: { halign: "right" },
			4: { halign: "right" },
			5: {
				halign: "right",
				fontStyle: "bold",
				textColor: [
					4,
					120,
					87
				]
			},
			6: {
				halign: "right",
				fontStyle: "bold",
				textColor: [
					217,
					119,
					6
				]
			},
			7: {
				fontStyle: "bold",
				textColor: [
					4,
					120,
					87
				]
			}
		},
		didParseCell: (data) => {
			if (data.row.index === bodyRows.length) {
				data.cell.styles.fillColor = [
					209,
					250,
					229
				];
				data.cell.styles.fontStyle = "bold";
				data.cell.styles.textColor = [
					6,
					78,
					59
				];
			}
		},
		margin: {
			left: 36,
			right: 36
		}
	});
	const finalY = doc.lastAutoTable.finalY + 30;
	const leftColX = pageWidth * .25;
	const rightColX = pageWidth * .75;
	doc.setFont("helvetica", "normal");
	doc.setFontSize(8.5);
	doc.setTextColor(30, 41, 59);
	doc.text("Mengetahui,", leftColX, finalY, { align: "center" });
	doc.setFont("helvetica", "bold");
	doc.text(`CAMAT ${settings.kecamatan.toUpperCase()}`, leftColX, finalY + 12, { align: "center" });
	doc.text("________________________", leftColX, finalY + 55, { align: "center" });
	doc.setFont("helvetica", "normal");
	doc.text(`${settings.kecamatan}, ${(/* @__PURE__ */ new Date()).toLocaleDateString("id-ID", {
		day: "numeric",
		month: "long",
		year: "numeric"
	})}`, rightColX, finalY, { align: "center" });
	doc.setFont("helvetica", "bold");
	doc.text("KASI PEMERINTAHAN / TIM PBB KECAMATAN", rightColX, finalY + 12, { align: "center" });
	doc.text("________________________", rightColX, finalY + 55, { align: "center" });
	const totalPages = doc.internal.getNumberOfPages();
	for (let i = 1; i <= totalPages; i++) {
		doc.setPage(i);
		doc.setFont("helvetica", "normal");
		doc.setFontSize(7.5);
		doc.setTextColor(148, 163, 184);
		doc.text(`SIPABAR (Sistem Informasi Pajak Barudua) • Halaman ${i} dari ${totalPages}`, pageWidth / 2, doc.internal.pageSize.getHeight() - 14, { align: "center" });
	}
	const filename = `Rekap_Setoran_Kecamatan_${settings.kecamatan}_${tahun}.pdf`;
	doc.save(filename);
	return filename;
};
function SetorDesaTab({ items, summary, isLoading, onOpenCreate, onOpenEdit, onOpenDetail, onOpenVerify, onDelete, desasList = [], filterDesa = "all", onFilterDesaChange, isSuperAdmin = false, isKepalaDesa = false }) {
	const { settings } = useSettingsStore();
	const [search, setSearch] = (0, import_react.useState)("");
	const [filterStatus, setFilterStatus] = (0, import_react.useState)("ALL");
	const [filterKategori, setFilterKategori] = (0, import_react.useState)("ALL");
	const formatRp = (val) => {
		return new Intl.NumberFormat("id-ID", {
			style: "currency",
			currency: "IDR",
			maximumFractionDigits: 0
		}).format(val);
	};
	const filteredItems = items.filter((item) => {
		const matchDesa = !isSuperAdmin || filterDesa === "all" || String(item.desaId) === filterDesa;
		const matchStatus = filterStatus === "ALL" ? true : filterStatus === "PENDING_ALL" ? item.status === "PENDING" || item.status === "PENDING_HAPUS" : item.status === filterStatus;
		const matchKategori = filterKategori === "ALL" ? true : filterKategori === "SETOR_KECAMATAN" ? item.kategori === "SETOR_KECAMATAN" : item.kategori !== "SETOR_KECAMATAN";
		const q = search.toLowerCase().trim();
		const matchSearch = !q || item.nomorBukti.toLowerCase().includes(q) || item.penyetorNama.toLowerCase().includes(q) || (item.namaDesa || "").toLowerCase().includes(q) || (item.bankTujuan || "").toLowerCase().includes(q) || (item.nomorReferensi || "").toLowerCase().includes(q);
		return matchDesa && matchStatus && matchKategori && matchSearch;
	});
	const pendingKadesCount = items.filter((i) => i.kategori !== "SETOR_KECAMATAN" && (i.status === "PENDING" || i.status === "PENDING_HAPUS")).length;
	const pendingKecamatanCount = items.filter((i) => i.kategori === "SETOR_KECAMATAN" && (i.status === "PENDING" || i.status === "PENDING_HAPUS")).length;
	const handlePrintPdf = (item) => {
		generateBuktiSetorPdf(item, settings);
	};
	const handleCreateClick = (defaultKategori) => {
		if ((summary?.sisaKasDesa ?? 0) <= 0) {
			Swal.fire({
				title: "Saldo Kas Desa Rp 0",
				html: `
          <div style="text-align: left; font-size: 13px; line-height: 1.6;">
            <p style="color: #475569; margin-bottom: 10px;">
              Saat ini sisa saldo kas penerimaan PBB-P2 desa bernilai <strong>Rp 0</strong>.
            </p>
            <div style="background: #fff1f2; border: 1px solid #fecdd3; border-radius: 12px; padding: 12px; color: #9f1239;">
              ⚠️ <strong>Pengeluaran Tidak Dapat Dibuat</strong><br/>
              Pengeluaran baru (Setoran Kecamatan atau Kegiatan Internal) hanya dapat dicatat setelah ada penerimaan pembayaran PBB-P2 yang masuk ke kas desa.
            </div>
          </div>
        `,
				icon: "warning",
				confirmButtonColor: "#059669",
				confirmButtonText: "Mengerti",
				customClass: {
					popup: "rounded-2xl shadow-2xl",
					confirmButton: "rounded-xl font-bold px-5 py-2.5 text-xs"
				}
			});
			return;
		}
		onOpenCreate(defaultKategori || (filterKategori === "INTERNAL" ? "OPERASIONAL_DESA" : "SETOR_KECAMATAN"));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			isKepalaDesa && pendingKadesCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-4 rounded-2xl bg-gradient-to-r from-amber-500/20 via-rose-500/15 to-amber-500/20 border border-amber-500/40 text-amber-950 dark:text-amber-200 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-pulse",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-11 rounded-xl bg-amber-500 text-white grid place-items-center shrink-0 shadow-md",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-black",
						children: "Pemberitahuan Persetujuan Kepala Desa"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-slate-700 dark:text-slate-300 font-medium",
						children: [
							"Terdapat ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: pendingKadesCount }),
							" permohonan pengeluaran internal / permohonan hapus dari Admin Desa yang menunggu eksekusi Anda."
						]
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => {
						setFilterKategori("INTERNAL");
						setFilterStatus("PENDING_ALL");
					},
					className: "px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-extrabold text-xs shadow-md shrink-0 transition flex items-center gap-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4" }),
						" Eksekusi Sekarang (",
						pendingKadesCount,
						")"
					]
				})]
			}),
			isSuperAdmin && pendingKecamatanCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-4 rounded-2xl bg-gradient-to-r from-indigo-500/20 via-purple-500/15 to-indigo-500/20 border border-indigo-500/40 text-indigo-950 dark:text-indigo-200 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-pulse",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-11 rounded-xl bg-indigo-600 text-white grid place-items-center shrink-0 shadow-md",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-black",
						children: "Pemberitahuan Verifikasi Setoran Kecamatan"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-slate-700 dark:text-slate-300 font-medium",
						children: [
							"Terdapat ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: pendingKecamatanCount }),
							" setoran / permohonan hapus dari desa yang menunggu verifikasi Kecamatan."
						]
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => {
						setFilterKategori("SETOR_KECAMATAN");
						setFilterStatus("PENDING_ALL");
					},
					className: "px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs shadow-md shrink-0 transition flex items-center gap-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4" }),
						" Verifikasi Sekarang (",
						pendingKecamatanCount,
						")"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-emerald-200 dark:border-slate-800 bg-gradient-to-br from-emerald-50 to-teal-50/40 dark:from-slate-900 dark:to-slate-900/60 p-4 shadow-sm relative overflow-hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-extrabold uppercase tracking-wider text-slate-500 dark:text-slate-400",
									children: "Total Realisasi PBB Desa"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-8 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 grid place-items-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-black text-slate-900 dark:text-white mt-2",
								children: formatRp(summary?.totalRealisasiDesa || 0)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-slate-500 dark:text-slate-400 mt-1 font-semibold",
								children: "Penerimaan kas PBB-P2 masuk"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-indigo-200 dark:border-slate-800 bg-gradient-to-br from-indigo-50 to-indigo-100/40 dark:from-slate-900 dark:to-slate-900/60 p-4 shadow-sm relative overflow-hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-extrabold uppercase tracking-wider text-indigo-700 dark:text-indigo-400",
									children: "Setoran ke Kecamatan"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-8 rounded-xl bg-indigo-500 text-white grid place-items-center shadow-md",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-black text-indigo-700 dark:text-indigo-400 mt-2",
								children: formatRp(summary?.totalDisetorkan || 0)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-indigo-800 dark:text-indigo-400 mt-1 font-medium",
								children: "Disetor ke Kas Kecamatan"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-amber-200 dark:border-slate-800 bg-gradient-to-br from-amber-50 to-amber-100/40 dark:from-slate-900 dark:to-slate-900/60 p-4 shadow-sm relative overflow-hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-extrabold uppercase tracking-wider text-amber-700 dark:text-amber-400",
									children: "Pengeluaran Internal"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-8 rounded-xl bg-amber-500 text-white grid place-items-center shadow-md",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-black text-amber-700 dark:text-amber-400 mt-2",
								children: formatRp(summary?.totalPengeluaranInternal || 0)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-amber-800 dark:text-amber-400 mt-1 font-medium",
								children: "Operasional, Kegiatan & ATK"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-emerald-200 dark:border-slate-800 bg-gradient-to-br from-emerald-600 via-teal-600 to-emerald-700 p-4 text-white shadow-md relative overflow-hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-extrabold uppercase tracking-wider text-emerald-100",
									children: "Sisa Saldo Kas Desa"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-8 rounded-xl bg-white/20 text-white grid place-items-center backdrop-blur-md",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-black text-white mt-2",
								children: formatRp(summary?.sisaKasDesa || 0)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-emerald-100 mt-1 font-semibold",
								children: "Saldo kas desa yang tersisa"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-2xl bg-white dark:bg-slate-950 border border-emerald-100 dark:border-slate-800 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative w-full sm:w-64",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "text",
								placeholder: "Cari bukti, nama penyetor, ref...",
								value: search,
								onChange: (e) => setSearch(e.target.value),
								className: "pl-8 h-10 text-xs rounded-xl border-slate-200 dark:border-slate-800"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center bg-slate-100 dark:bg-slate-900 p-1 rounded-xl gap-1 overflow-x-auto",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => {
										setFilterStatus("ALL");
										setFilterKategori("ALL");
									},
									className: `px-3 py-1.5 rounded-lg text-xs font-bold transition ${filterStatus === "ALL" && filterKategori === "ALL" ? "bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm" : "text-slate-500"}`,
									children: [
										"Semua (",
										items.length,
										")"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => {
										setFilterStatus("ALL");
										setFilterKategori("SETOR_KECAMATAN");
									},
									className: `px-3 py-1.5 rounded-lg text-xs font-bold transition ${filterKategori === "SETOR_KECAMATAN" && filterStatus === "ALL" ? "bg-indigo-600 text-white shadow-sm" : "text-slate-500"}`,
									children: "🏛️ Setor Kecamatan"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => {
										setFilterStatus("ALL");
										setFilterKategori("INTERNAL");
									},
									className: `px-3 py-1.5 rounded-lg text-xs font-bold transition ${filterKategori === "INTERNAL" && filterStatus === "ALL" ? "bg-amber-600 text-white shadow-sm" : "text-slate-500"}`,
									children: "💼 Internal Desa"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => {
										setFilterKategori("ALL");
										setFilterStatus("PENDING_ALL");
									},
									className: `px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 ${filterStatus === "PENDING_ALL" ? "bg-rose-500 text-white shadow-sm" : "text-slate-500"}`,
									children: ["⏳ Menunggu Eksekusi", (pendingKadesCount > 0 || pendingKecamatanCount > 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "px-1.5 py-0.2 rounded-full bg-white/30 text-[10px]",
										children: isKepalaDesa ? pendingKadesCount : pendingKecamatanCount
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => {
										setFilterKategori("ALL");
										setFilterStatus("PENDING_HAPUS");
									},
									className: `px-3 py-1.5 rounded-lg text-xs font-bold transition ${filterStatus === "PENDING_HAPUS" ? "bg-rose-700 text-white shadow-sm" : "text-slate-500"}`,
									children: "🗑️ Permohonan Hapus"
								})
							]
						}),
						isSuperAdmin && desasList.length > 0 && onFilterDesaChange && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: filterDesa,
							onValueChange: onFilterDesaChange,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectTrigger, {
								className: "w-[180px] h-10 text-xs font-bold rounded-xl border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5 mr-1 text-emerald-600 dark:text-emerald-400 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Filter Desa" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "all",
								children: "🏘️ Seluruh Desa"
							}), desasList.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: String(d.id),
								children: d.nama_desa
							}, d.id))] })]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => handleCreateClick("SETOR_KECAMATAN"),
						className: "rounded-xl h-10 text-xs font-black bg-gradient-to-r from-indigo-600 to-blue-600 text-white shadow-md hover:from-indigo-700 hover:to-blue-700 flex items-center gap-1.5 ring-2 ring-indigo-500/20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-4" }), " 🏛️ Setor ke Kecamatan"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => handleCreateClick("OPERASIONAL_DESA"),
						className: "rounded-xl h-10 text-xs font-black bg-gradient-to-r from-amber-600 to-orange-600 text-white shadow-md hover:from-amber-700 hover:to-orange-700 flex items-center gap-1.5 ring-2 ring-amber-500/20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-4" }), " 💼 Pengeluaran Internal Desa"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 shadow-sm overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-xs text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-slate-50 dark:bg-slate-900/80 border-b border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-extrabold uppercase tracking-wider text-[10px]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5 text-center w-12",
									children: "NO"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5",
									children: "KATEGORI & NO BUKTI"
								}),
								isSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5",
									children: "DESA"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5 text-right",
									children: "NOMINAL PENGELUARAN (RP)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5",
									children: "METODE & RESI"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5",
									children: "PENANGGUNG JAWAB"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5 text-center",
									children: "STATUS"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5 text-center w-36",
									children: "AKSI"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-slate-100 dark:divide-slate-800/80",
							children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: isSuperAdmin ? 8 : 7,
								className: "px-4 py-8 text-center text-slate-400 font-medium",
								children: "Memuat data setoran..."
							}) }) : filteredItems.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								colSpan: isSuperAdmin ? 8 : 7,
								className: "px-4 py-12 text-center text-slate-400 font-medium",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" }), "Belum ada catatan data pengeluaran / setoran PBB-P2."]
							}) }) : filteredItems.map((item, idx) => {
								const isInternal = item.kategori !== "SETOR_KECAMATAN";
								const canAcc = (item.status === "PENDING" || item.status === "PENDING_HAPUS") && (!isInternal && isSuperAdmin || isInternal && isKepalaDesa);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "hover:bg-slate-50/80 dark:hover:bg-slate-900/50 transition",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3.5 text-center font-bold text-slate-400",
											children: idx + 1
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-4 py-3.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "mb-1",
													children: item.kategori === "SETOR_KECAMATAN" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
														className: "bg-indigo-500/15 text-indigo-700 dark:text-indigo-400 border-indigo-500/30 text-[9px] font-extrabold px-1.5 py-0.5",
														children: "🏛️ Setor Kecamatan"
													}) : item.kategori === "KEGIATAN_DESA" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
														className: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30 text-[9px] font-extrabold px-1.5 py-0.5",
														children: "🎉 Kegiatan Desa"
													}) : item.kategori === "OPERASIONAL_DESA" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
														className: "bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-500/30 text-[9px] font-extrabold px-1.5 py-0.5",
														children: "⚡ Operasional"
													}) : item.kategori === "ADMINISTRASI" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
														className: "bg-cyan-500/15 text-cyan-700 dark:text-cyan-400 border-cyan-500/30 text-[9px] font-extrabold px-1.5 py-0.5",
														children: "📄 Administrasi/ATK"
													}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
														className: "bg-purple-500/15 text-purple-700 dark:text-purple-400 border-purple-500/30 text-[9px] font-extrabold px-1.5 py-0.5",
														children: "🛠️ Pengeluaran Lain"
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "font-extrabold text-slate-900 dark:text-white font-mono",
													children: item.nomorBukti
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-[10px] text-slate-500 dark:text-slate-400 font-medium",
													children: ["Tgl: ", item.tanggalSetor]
												})
											]
										}),
										isSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3.5 font-bold text-slate-800 dark:text-slate-200",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5" }),
													" ",
													item.namaDesa || "Desa"
												]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3.5 text-right font-black text-emerald-700 dark:text-emerald-400 text-sm",
											children: formatRp(item.nominal)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-4 py-3.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-semibold text-slate-800 dark:text-slate-200",
												children: item.metodeSetoran === "TRANSFER" ? `Transfer (${item.bankTujuan || "BJB"})` : item.metodeSetoran
											}), item.nomorReferensi && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[10px] text-slate-400 font-mono",
												children: ["Ref: ", item.nomorReferensi]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-4 py-3.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-bold text-slate-900 dark:text-white",
												children: item.penyetorNama
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-slate-500 dark:text-slate-400",
												children: item.penyetorJabatan || "Bendahara Desa"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3.5 text-center",
											children: item.status === "DITERIMA" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
												className: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30 font-bold text-[10px]",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3 mr-1" }),
													" ",
													isInternal ? "Disetujui Kades" : "Diterima Kecamatan"
												]
											}) : item.status === "DITOLAK" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
												className: "bg-rose-500/15 text-rose-700 dark:text-rose-400 border-rose-500/30 font-bold text-[10px]",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-3 mr-1" }),
													" ",
													isInternal ? "Ditolak Kades" : "Ditolak Kecamatan"
												]
											}) : item.status === "PENDING_HAPUS" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
												className: "bg-rose-500/20 text-rose-700 dark:text-rose-400 border-rose-500/40 font-black text-[10px] animate-pulse",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-3 mr-1" }),
													" ",
													isInternal ? "Menunggu Verif Hapus Kades" : "Menunggu Verif Hapus Kecamatan"
												]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
												className: "bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-500/30 font-bold text-[10px] animate-pulse",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3 mr-1" }),
													" ",
													isInternal ? "Menunggu Persetujuan Kades" : "Menunggu Kecamatan"
												]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3.5 text-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-center gap-1",
												children: [
													canAcc && onOpenVerify && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														size: "sm",
														title: item.status === "PENDING_HAPUS" ? "Verifikasi Permohonan Hapus" : !isInternal ? "Verifikasi Penerimaan Setoran Kecamatan" : "Persetujuan Kepala Desa",
														onClick: () => onOpenVerify(item),
														className: `h-7 px-2 rounded-lg ${item.status === "PENDING_HAPUS" ? "bg-rose-600 hover:bg-rose-700" : "bg-emerald-600 hover:bg-emerald-700"} text-white font-extrabold text-[10px] gap-1 shadow-xs`,
														children: item.status === "PENDING_HAPUS" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-3" }), " Verif Hapus"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3" }),
															" ",
															!isInternal ? "Verifikasi" : "Setujui"
														] })
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														size: "icon",
														variant: "ghost",
														title: "Pratinjau Detail",
														onClick: () => onOpenDetail(item),
														className: "size-8 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4 text-emerald-600 dark:text-emerald-400" })
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														size: "icon",
														variant: "ghost",
														title: "Cetak Bukti PDF",
														onClick: () => handlePrintPdf(item),
														className: "size-8 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4 text-amber-600 dark:text-amber-400" })
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														size: "icon",
														variant: "ghost",
														title: "Edit Data Pengeluaran",
														onClick: () => onOpenEdit(item),
														className: "size-8 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquarePen, { className: "size-4 text-indigo-600 dark:text-indigo-400" })
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														size: "icon",
														variant: "ghost",
														title: "Hapus Data Pengeluaran",
														onClick: () => onDelete(item),
														className: "size-8 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-rose-100 dark:hover:bg-rose-900/50",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-rose-600 dark:text-rose-400" })
													})
												]
											})
										})
									]
								}, item.id);
							})
						})]
					})
				})
			})
		]
	});
}
function SetoranKecamatanTab({ items, summary, isLoading, onOpenVerify, onOpenDetail, desasList, filterDesa, onFilterDesaChange, isSuperAdmin = false, isKepalaDesa = false }) {
	const { settings } = useSettingsStore();
	const [search, setSearch] = (0, import_react.useState)("");
	const [filterStatus, setFilterStatus] = (0, import_react.useState)("ALL");
	const formatRp = (val) => {
		return new Intl.NumberFormat("id-ID", {
			style: "currency",
			currency: "IDR",
			maximumFractionDigits: 0
		}).format(val);
	};
	const filteredItems = items.filter((item) => {
		const matchKategori = isKepalaDesa ? item.kategori !== "SETOR_KECAMATAN" : item.kategori === "SETOR_KECAMATAN";
		const matchDesa = !isSuperAdmin || filterDesa === "all" || String(item.desaId) === filterDesa;
		const matchStatus = filterStatus === "ALL" ? true : filterStatus === "PENDING_ALL" ? item.status === "PENDING" || item.status === "PENDING_HAPUS" : item.status === filterStatus;
		const q = search.toLowerCase().trim();
		const matchSearch = !q || item.nomorBukti.toLowerCase().includes(q) || item.penyetorNama.toLowerCase().includes(q) || (item.namaDesa || "").toLowerCase().includes(q) || (item.catatanDesa || "").toLowerCase().includes(q);
		return matchKategori && matchDesa && matchStatus && matchSearch;
	});
	const pendingItemsCount = items.filter((i) => {
		return (isKepalaDesa ? i.kategori !== "SETOR_KECAMATAN" : i.kategori === "SETOR_KECAMATAN") && (i.status === "PENDING" || i.status === "PENDING_HAPUS");
	}).length;
	const handlePrintPdf = (item) => {
		generateBuktiSetorPdf(item, settings);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			pendingItemsCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-4 rounded-2xl bg-gradient-to-r from-amber-500/15 via-rose-500/10 to-amber-500/15 border border-amber-500/30 text-amber-900 dark:text-amber-300 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-pulse",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-10 rounded-xl bg-amber-500 text-white grid place-items-center shrink-0 shadow-md",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-black",
						children: isKepalaDesa ? "Antrean Persetujuan Kepala Desa" : "Antrean Verifikasi Penerimaan Kecamatan"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[11px] text-slate-600 dark:text-slate-400 font-medium",
						children: [
							"Terdapat ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: pendingItemsCount }),
							" permohonan (",
							isKepalaDesa ? "Pengeluaran Internal / Hapus" : "Setor Kecamatan / Hapus",
							") yang siap Anda eksekusi."
						]
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setFilterStatus("PENDING_ALL"),
					className: "px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-extrabold text-xs shadow-md shrink-0",
					children: [
						"Tampilkan Antrean (",
						pendingItemsCount,
						")"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-emerald-200 dark:border-slate-800 bg-gradient-to-br from-emerald-600 via-teal-600 to-emerald-700 p-4 text-white shadow-md relative overflow-hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-extrabold uppercase tracking-wider text-emerald-100",
									children: isKepalaDesa ? "Total Internal Disetujui" : "Total Diterima Kecamatan"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-8 rounded-xl bg-white/20 text-white grid place-items-center backdrop-blur-md",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-black text-white mt-2",
								children: formatRp(isKepalaDesa ? summary?.totalPengeluaranInternal || 0 : summary?.totalDiterima || 0)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[10px] text-emerald-100 mt-1 font-semibold",
								children: [summary?.counts.diterima || 0, " Pengeluaran sah disetujui"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-amber-200 dark:border-slate-800 bg-gradient-to-br from-amber-500 to-amber-600 p-4 text-white shadow-md relative overflow-hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-extrabold uppercase tracking-wider text-amber-100",
									children: isKepalaDesa ? "Menunggu Persetujuan Kades" : "Menunggu Verifikasi Kecamatan"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-8 rounded-xl bg-white/20 text-white grid place-items-center backdrop-blur-md",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-black text-white mt-2",
								children: formatRp(summary?.totalPending || 0)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[10px] text-amber-100 mt-1 font-semibold",
								children: [pendingItemsCount, " Data menunggu eksekusi Anda"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-rose-200 dark:border-slate-800 bg-gradient-to-br from-rose-50 to-rose-100/40 dark:from-slate-900 dark:to-slate-900/60 p-4 shadow-sm relative overflow-hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-extrabold uppercase tracking-wider text-rose-700 dark:text-rose-400",
									children: "Pengeluaran Ditolak"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-8 rounded-xl bg-rose-500 text-white grid place-items-center shadow-md",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-black text-rose-700 dark:text-rose-400 mt-2",
								children: formatRp(summary?.totalDitolak || 0)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[10px] text-rose-800 dark:text-rose-400 mt-1 font-medium",
								children: [summary?.counts.ditolak || 0, " Pengeluaran ditolak"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-slate-200 dark:border-slate-800 bg-gradient-to-br from-slate-50 to-slate-100/50 dark:from-slate-900 dark:to-slate-900/60 p-4 shadow-sm relative overflow-hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-extrabold uppercase tracking-wider text-slate-600 dark:text-slate-400",
									children: isKepalaDesa ? "Sisa Saldo Kas Desa" : "Target & Realisasi"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-8 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 grid place-items-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-black text-slate-900 dark:text-white mt-2",
								children: formatRp(isKepalaDesa ? summary?.sisaKasDesa || 0 : summary?.totalRealisasiDesa || 0)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-slate-500 dark:text-slate-400 mt-1 font-semibold",
								children: isKepalaDesa ? "Kas PBB-P2 siap digunakan" : "Total realisasi penerimaan PBB"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-2xl bg-white dark:bg-slate-950 border border-emerald-100 dark:border-slate-800 shadow-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						isSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: filterDesa,
							onValueChange: onFilterDesaChange,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectTrigger, {
								className: "w-[200px] h-10 text-xs rounded-xl border-slate-200 dark:border-slate-800",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5 mr-2 text-emerald-600 dark:text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Filter Desa" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "all",
								children: "🏘️ Seluruh Desa"
							}), desasList.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: String(d.id),
								children: d.nama_desa
							}, d.id))] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative min-w-[200px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 absolute left-3 top-3 text-slate-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "text",
								value: search,
								onChange: (e) => setSearch(e.target.value),
								placeholder: "Cari no bukti, desa, penyetor...",
								className: "pl-9 h-10 text-xs rounded-xl border-slate-200 dark:border-slate-800"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1 bg-slate-100 dark:bg-slate-900 p-1 rounded-xl border border-slate-200 dark:border-slate-800",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setFilterStatus("ALL"),
									className: `px-3 py-1.5 rounded-lg text-xs font-bold transition ${filterStatus === "ALL" ? "bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm" : "text-slate-500"}`,
									children: "Semua"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setFilterStatus("PENDING"),
									className: `px-3 py-1.5 rounded-lg text-xs font-bold transition ${filterStatus === "PENDING" ? "bg-amber-500 text-white shadow-sm" : "text-slate-500"}`,
									children: [
										"Pending (",
										summary?.counts.pending || 0,
										")"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setFilterStatus("DITERIMA"),
									className: `px-3 py-1.5 rounded-lg text-xs font-bold transition ${filterStatus === "DITERIMA" ? "bg-emerald-500 text-white shadow-sm" : "text-slate-500"}`,
									children: "Diterima"
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 shadow-sm overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-xs text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-slate-50 dark:bg-slate-900/80 border-b border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-extrabold uppercase tracking-wider text-[10px]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5 text-center w-12",
									children: "NO"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5",
									children: "DESA PENGIRIM"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5",
									children: "NO BUKTI & TGL SETOR"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5 text-right",
									children: "NOMINAL SETORAN (RP)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5",
									children: "METODE & RESI"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5",
									children: "PENYETOR (DESA)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5 text-center",
									children: "STATUS VERIFIKASI"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5 text-center w-36",
									children: "VERIFIKASI & AKSI"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-slate-100 dark:divide-slate-800/80",
							children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 8,
								className: "px-4 py-8 text-center text-slate-400 font-medium",
								children: "Memuat catatan penerimaan kecamatan..."
							}) }) : filteredItems.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								colSpan: 8,
								className: "px-4 py-12 text-center text-slate-400 font-medium",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" }), "Belum ada data setoran yang masuk dari desa."]
							}) }) : filteredItems.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "hover:bg-slate-50/80 dark:hover:bg-slate-900/50 transition",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3.5 text-center font-bold text-slate-400",
										children: idx + 1
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "font-black text-slate-900 dark:text-white flex items-center gap-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5 text-emerald-600 dark:text-emerald-400" }),
												" ",
												item.namaDesa || "Desa"
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[10px] text-slate-400 font-mono",
											children: ["Kode: ", item.kodeDesa || "-"]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-extrabold text-slate-900 dark:text-white font-mono",
											children: item.nomorBukti
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[10px] text-slate-500 dark:text-slate-400 font-medium",
											children: ["Tgl: ", item.tanggalSetor]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3.5 text-right font-black text-emerald-700 dark:text-emerald-400 text-sm",
										children: formatRp(item.nominal)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-semibold text-slate-800 dark:text-slate-200",
											children: item.metodeSetoran === "TRANSFER" ? `Transfer (${item.bankTujuan || "BJB"})` : item.metodeSetoran
										}), item.nomorReferensi && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[10px] text-slate-400 font-mono",
											children: ["Ref: ", item.nomorReferensi]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-bold text-slate-900 dark:text-white",
											children: item.penyetorNama
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] text-slate-500 dark:text-slate-400",
											children: item.penyetorJabatan || "Bendahara Desa"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3.5 text-center",
										children: item.status === "DITERIMA" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
											className: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30 font-bold text-[10px]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3 mr-1" }),
												" ",
												isKepalaDesa ? "DISETUJUI KADES" : "DITERIMA KECAMATAN"
											]
										}) : item.status === "DITOLAK" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
											className: "bg-rose-500/15 text-rose-700 dark:text-rose-400 border-rose-500/30 font-bold text-[10px]",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-3 mr-1" }),
												" ",
												isKepalaDesa ? "DITOLAK KADES" : "DITOLAK"
											]
										}) : item.status === "PENDING_HAPUS" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
											className: "bg-rose-500/20 text-rose-700 dark:text-rose-400 border-rose-500/40 font-black text-[10px] animate-pulse",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-3 mr-1" }), " PERMOHONAN HAPUS"]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
											className: "bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-500/30 font-bold text-[10px] animate-pulse",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3 mr-1" }),
												" ",
												isKepalaDesa ? "MENUNGGU PERSETUJUAN" : "PENDING VERIFIKASI"
											]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3.5 text-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-center gap-1.5",
											children: [
												(item.status === "PENDING" || item.status === "PENDING_HAPUS") && (isSuperAdmin && item.kategori === "SETOR_KECAMATAN" || isKepalaDesa && item.kategori !== "SETOR_KECAMATAN") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
													size: "sm",
													variant: "outline",
													onClick: () => onOpenVerify(item),
													className: `h-8 px-2.5 rounded-lg text-xs font-extrabold ${item.status === "PENDING_HAPUS" ? "border-rose-500/40 text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950" : "border-emerald-500/40 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950"} flex items-center gap-1`,
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5" }),
														" ",
														item.status === "PENDING_HAPUS" ? "Verif Hapus" : isKepalaDesa ? "Setujui" : "Verifikasi"
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													size: "icon",
													variant: "ghost",
													title: "Detail",
													onClick: () => onOpenDetail(item),
													className: "size-8 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4 text-emerald-600 dark:text-emerald-400" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													size: "icon",
													variant: "ghost",
													title: "Cetak PDF",
													onClick: () => handlePrintPdf(item),
													className: "size-8 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4 text-amber-600 dark:text-amber-400" })
												})
											]
										})
									})
								]
							}, item.id))
						})]
					})
				})
			})
		]
	});
}
function RekapDesaSetoranTab({ rekapList, tahun, isLoading }) {
	const { settings } = useSettingsStore();
	const formatRp = (val) => {
		return new Intl.NumberFormat("id-ID", {
			style: "currency",
			currency: "IDR",
			maximumFractionDigits: 0
		}).format(val);
	};
	const totalTarget = rekapList.reduce((acc, curr) => acc + curr.targetPbb, 0);
	const totalRealisasi = rekapList.reduce((acc, curr) => acc + curr.realisasiPbb, 0);
	const totalDisetor = rekapList.reduce((acc, curr) => acc + curr.totalDisetorDiterima, 0);
	const totalSisa = rekapList.reduce((acc, curr) => acc + curr.sisaKasDesa, 0);
	const overallPct = totalTarget > 0 ? totalDisetor / totalTarget * 100 : 0;
	const handlePrintRekapPdf = () => {
		generateRekapSetoranKecamatanPdf(rekapList, tahun, settings);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-emerald-800 via-teal-700 to-emerald-900 text-white shadow-lg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 text-emerald-100 text-xs font-bold mb-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "size-3.5 text-amber-300" }), " Executive Dashboard Kecamatan"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-black text-white",
						children: "Rekapitulasi Perbandingan Setoran Per Desa"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-emerald-100 mt-1 max-w-xl font-medium",
						children: [
							"Perbandingan total realisasi PBB desa dengan jumlah nominal setoran yang sudah disetujui & diterima oleh Kecamatan Tahun ",
							tahun,
							"."
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: handlePrintRekapPdf,
					className: "rounded-xl h-11 px-4 text-xs font-extrabold bg-white text-emerald-900 shadow-md hover:bg-emerald-50 flex items-center gap-2 shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4 text-emerald-700" }), " Cetak Rekap Kecamatan (PDF)"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 p-4 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wider",
								children: "Total Target PBB Kecamatan"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-black text-slate-900 dark:text-white mt-1",
								children: formatRp(totalTarget)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-slate-500 mt-1 font-medium",
								children: "Ketetapan DHKP Seluruh Desa"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 p-4 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] font-bold text-slate-500 uppercase tracking-wider",
								children: "Total Realisasi Desa (Lunas)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-black text-slate-900 dark:text-white mt-1",
								children: formatRp(totalRealisasi)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-slate-500 mt-1 font-medium",
								children: "Uang terkumpul di tingkat desa"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-emerald-200 dark:border-slate-800 bg-emerald-50/50 dark:bg-slate-900 p-4 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] font-extrabold text-emerald-800 dark:text-emerald-400 uppercase tracking-wider",
								children: "Total Disetor ke Kecamatan"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-black text-emerald-700 dark:text-emerald-400 mt-1",
								children: formatRp(totalDisetor)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[10px] text-emerald-800 dark:text-emerald-400 mt-1 font-bold",
								children: [
									"Capaian Setoran: ",
									overallPct.toFixed(2),
									"%"
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-indigo-200 dark:border-slate-800 bg-indigo-50/50 dark:bg-slate-900 p-4 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] font-extrabold text-indigo-800 dark:text-indigo-400 uppercase tracking-wider",
								children: "Sisa Belum Disetor ke Kec"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-black text-indigo-700 dark:text-indigo-400 mt-1",
								children: formatRp(totalSisa)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-indigo-800 dark:text-indigo-400 mt-1 font-medium",
								children: "Masih di kas desa"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 shadow-sm overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-xs text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-slate-50 dark:bg-slate-900/80 border-b border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 font-extrabold uppercase tracking-wider text-[10px]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5 text-center w-12",
									children: "NO"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5",
									children: "KODE & NAMA DESA"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5 text-right",
									children: "TARGET PBB (RP)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5 text-right",
									children: "REALISASI DESA (RP)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5 text-right",
									children: "DISITOR KE KECAMATAN (RP)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5 text-right",
									children: "SISA KAS DESA (RP)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5 text-center",
									children: "% CAPAIAN"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3.5 text-center",
									children: "TGL SETOR TERAKHIR"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
							className: "divide-y divide-slate-100 dark:divide-slate-800/80",
							children: [isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 8,
								className: "px-4 py-8 text-center text-slate-400 font-medium",
								children: "Memuat rekapitulasi per desa..."
							}) }) : rekapList.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 8,
								className: "px-4 py-12 text-center text-slate-400 font-medium",
								children: "Belum ada data desa terdaftar."
							}) }) : rekapList.map((row, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "hover:bg-slate-50/80 dark:hover:bg-slate-900/50 transition",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3.5 text-center font-bold text-slate-400",
										children: idx + 1
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4 text-emerald-600 dark:text-emerald-400" }),
												" ",
												row.namaDesa
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[10px] text-slate-400 font-mono",
											children: ["Kode: ", row.kodeDesa]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3.5 text-right font-semibold text-slate-700 dark:text-slate-300",
										children: formatRp(row.targetPbb)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3.5 text-right font-bold text-slate-900 dark:text-white",
										children: formatRp(row.realisasiPbb)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3.5 text-right font-black text-emerald-700 dark:text-emerald-400 text-sm",
										children: formatRp(row.totalDisetorDiterima)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3.5 text-right font-extrabold text-indigo-700 dark:text-indigo-400",
										children: formatRp(row.sisaKasDesa)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3.5 text-center font-black",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: `inline-block px-2.5 py-1 rounded-lg text-xs ${row.persentaseDisetor >= 100 ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30" : row.persentaseDisetor >= 50 ? "bg-amber-500/15 text-amber-700 dark:text-amber-400 border border-amber-500/30" : "bg-rose-500/15 text-rose-700 dark:text-rose-400 border border-rose-500/30"}`,
											children: [row.persentaseDisetor.toFixed(2), "%"]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3.5 text-center text-slate-500 dark:text-slate-400 font-medium",
										children: row.tanggalSetorTerakhir || "-"
									})
								]
							}, row.desaId)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "bg-emerald-50/80 dark:bg-slate-900 font-extrabold border-t-2 border-emerald-500/30",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										colSpan: 2,
										className: "px-4 py-4 text-slate-900 dark:text-white",
										children: "JUMLAH TOTAL KECAMATAN"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-4 text-right text-slate-800 dark:text-slate-200",
										children: formatRp(totalTarget)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-4 text-right text-slate-900 dark:text-white",
										children: formatRp(totalRealisasi)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-4 text-right text-emerald-700 dark:text-emerald-400 text-sm",
										children: formatRp(totalDisetor)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-4 text-right text-indigo-700 dark:text-indigo-400",
										children: formatRp(totalSisa)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-4 text-center text-emerald-700 dark:text-emerald-400",
										children: [overallPct.toFixed(2), "%"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { className: "px-4 py-4" })
								]
							})]
						})]
					})
				})
			})
		]
	});
}
function BuatSetoranModal({ isOpen, onClose, onSave, editData, desasList = [], isSuperAdmin = false, sisaKasDesa = 0, initialKategori }) {
	const { user } = useAuthStore();
	const tenant = useTenantStore();
	const { settings } = useSettingsStore();
	const [tipePengeluaran, setTipePengeluaran] = (0, import_react.useState)("KECAMATAN");
	const [kategoriInternal, setKategoriInternal] = (0, import_react.useState)("OPERASIONAL_DESA");
	const [desaId, setDesaId] = (0, import_react.useState)("");
	const [tanggalSetor, setTanggalSetor] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
	const [tahun, setTahun] = (0, import_react.useState)(2026);
	const [nominal, setNominal] = (0, import_react.useState)("");
	const [metodeSetoran, setMetodeSetoran] = (0, import_react.useState)("TRANSFER");
	const [bankTujuan, setBankTujuan] = (0, import_react.useState)("Bank Jabar Banten (BJB)");
	const [nomorReferensi, setNomorReferensi] = (0, import_react.useState)("");
	const [penyetorNama, setPenyetorNama] = (0, import_react.useState)("");
	const [penyetorJabatan, setPenyetorJabatan] = (0, import_react.useState)("Bendahara Desa");
	const [penerimaKecamatan, setPenerimaKecamatan] = (0, import_react.useState)("Kasi Pemerintahan Kecamatan");
	const [penerimaInternal, setPenerimaInternal] = (0, import_react.useState)("");
	const [catatanDesa, setCatatanDesa] = (0, import_react.useState)("");
	const [buktiFile, setBuktiFile] = (0, import_react.useState)("");
	const [isSubmitting, setIsSubmitting] = (0, import_react.useState)(false);
	const [errorMsg, setErrorMsg] = (0, import_react.useState)(null);
	const formatRp = (val) => {
		return new Intl.NumberFormat("id-ID", {
			style: "currency",
			currency: "IDR",
			maximumFractionDigits: 0
		}).format(val);
	};
	const availableKas = editData ? sisaKasDesa + (editData.status === "DITERIMA" ? editData.nominal : 0) : sisaKasDesa;
	const isKasZero = !editData && sisaKasDesa <= 0;
	(0, import_react.useEffect)(() => {
		if (editData) {
			setDesaId(String(editData.desaId || ""));
			const isKatInternal = editData.kategori !== "SETOR_KECAMATAN";
			setTipePengeluaran(isKatInternal ? "INTERNAL" : "KECAMATAN");
			if (isKatInternal) {
				setKategoriInternal(editData.kategori || "OPERASIONAL_DESA");
				setPenerimaInternal(editData.penerimaKecamatan || "");
			} else setPenerimaKecamatan(editData.penerimaKecamatan || "Kasi Pemerintahan / Tim PBB Kecamatan");
			setTanggalSetor(editData.tanggalSetor || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
			setTahun(editData.tahun || 2026);
			setNominal(String(editData.nominal || ""));
			setMetodeSetoran(editData.metodeSetoran || "TRANSFER");
			setBankTujuan(editData.bankTujuan || "");
			setNomorReferensi(editData.nomorReferensi || "");
			setPenyetorNama(editData.penyetorNama || "");
			setPenyetorJabatan(editData.penyetorJabatan || "Bendahara Desa");
			setCatatanDesa(editData.catatanDesa || "");
			setBuktiFile(editData.buktiFile || "");
		} else {
			const activeDesaId = user?.desa_id || user?.desa?.id || tenant?.id;
			setDesaId(activeDesaId ? String(activeDesaId) : isSuperAdmin && desasList.length > 0 ? String(desasList[0].id) : "");
			if (initialKategori && initialKategori !== "SETOR_KECAMATAN") {
				setTipePengeluaran("INTERNAL");
				setKategoriInternal(initialKategori);
				setMetodeSetoran("TUNAI");
			} else {
				setTipePengeluaran("KECAMATAN");
				setKategoriInternal("OPERASIONAL_DESA");
				setMetodeSetoran("TRANSFER");
			}
			setTanggalSetor((/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
			setTahun(2026);
			setNominal("");
			setBankTujuan("Bank Jabar Banten (BJB)");
			setNomorReferensi("");
			setPenyetorNama(user?.name || settings.namaPetugas || "Bendahara Desa");
			setPenyetorJabatan(settings.jabatanPetugas || "Bendahara Desa");
			setPenerimaKecamatan("Kasi Pemerintahan / Tim PBB Kecamatan");
			setPenerimaInternal("");
			setCatatanDesa("");
			setBuktiFile("");
		}
		setErrorMsg(null);
	}, [
		editData,
		isOpen,
		initialKategori
	]);
	const handleFileUpload = (e) => {
		const file = e.target.files?.[0];
		if (file) {
			if (file.size > 5 * 1024 * 1024) {
				setErrorMsg("Ukuran file bukti lampiran maksimal 5 MB.");
				return;
			}
			const reader = new FileReader();
			reader.onloadend = () => {
				setBuktiFile(reader.result);
				setErrorMsg(null);
			};
			reader.readAsDataURL(file);
		}
	};
	const handleSubmit = async (e) => {
		e.preventDefault();
		setErrorMsg(null);
		if (isKasZero) {
			setErrorMsg("Saldo kas PBB-P2 desa bernilai Rp 0. Pengeluaran baru tidak dapat dibuat.");
			return;
		}
		const cleanNominalStr = String(nominal).replace(/\./g, "").replace(/,/g, ".");
		const parsedNominal = parseFloat(cleanNominalStr);
		if (isNaN(parsedNominal) || parsedNominal <= 0) {
			setErrorMsg("Nominal pengeluaran harus berupa angka bernilai lebih dari 0.");
			return;
		}
		if (parsedNominal > availableKas) {
			setErrorMsg(`Nominal pengeluaran (${formatRp(parsedNominal)}) melebihi sisa saldo kas yang tersedia (${formatRp(availableKas)}).`);
			return;
		}
		if (!penyetorNama.trim()) {
			setErrorMsg("Nama penanggung jawab / pemohon pengeluaran wajib diisi.");
			return;
		}
		const finalKategori = tipePengeluaran === "KECAMATAN" ? "SETOR_KECAMATAN" : kategoriInternal;
		setIsSubmitting(true);
		try {
			const activeDesaId = desaId || user?.desa_id || user?.desa?.id || tenant?.id;
			await onSave({
				desaId: activeDesaId ? Number(activeDesaId) : void 0,
				kategori: finalKategori,
				tanggalSetor,
				tahun: Number(tahun),
				nominal: parsedNominal,
				metodeSetoran,
				bankTujuan: metodeSetoran === "TRANSFER" ? bankTujuan : void 0,
				nomorReferensi: metodeSetoran === "TRANSFER" ? nomorReferensi : void 0,
				penyetorNama,
				penyetorJabatan,
				penerimaKecamatan: tipePengeluaran === "KECAMATAN" ? penerimaKecamatan : penerimaInternal || void 0,
				catatanDesa,
				buktiFile
			});
			onClose();
		} catch (err) {
			setErrorMsg(err.message || "Gagal menyimpan data pengeluaran.");
		} finally {
			setIsSubmitting(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: isOpen,
		onOpenChange: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-2xl max-h-[92vh] overflow-y-auto bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 rounded-2xl p-6 shadow-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `size-11 rounded-2xl grid place-items-center shadow-md shrink-0 text-white transition-colors duration-300 ${tipePengeluaran === "KECAMATAN" ? "bg-gradient-to-tr from-indigo-600 to-blue-500" : "bg-gradient-to-tr from-amber-600 to-orange-500"}`,
						children: tipePengeluaran === "KECAMATAN" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "text-lg font-black text-slate-900 dark:text-white",
						children: editData ? tipePengeluaran === "KECAMATAN" ? "Edit Setoran Kas ke Kecamatan" : "Edit Pengeluaran Internal Desa" : tipePengeluaran === "KECAMATAN" ? "Form Setoran PBB-P2 ke Kecamatan" : "Form Pengeluaran Kas Internal Desa"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-xs text-slate-500 dark:text-slate-400",
						children: editData ? "Ubah data pengeluaran/setoran. Perubahan akan dikirimkan ulang untuk proses verifikasi." : "Pilih alur tujuan pengeluaran kas PBB-P2: Setor ke Kecamatan atau Pengeluaran Internal Desa."
					})] })]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-1.5 bg-slate-100 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 grid grid-cols-2 gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setTipePengeluaran("KECAMATAN"),
						className: `flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-black transition-all duration-200 ${tipePengeluaran === "KECAMATAN" ? "bg-indigo-600 text-white shadow-md ring-2 ring-indigo-500/20" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "🏛️ Setor ke Kecamatan" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setTipePengeluaran("INTERNAL"),
						className: `flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-black transition-all duration-200 ${tipePengeluaran === "INTERNAL" ? "bg-amber-600 text-white shadow-md ring-2 ring-amber-500/20" : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "💼 Pengeluaran Internal Desa" })]
					})]
				}),
				tipePengeluaran === "KECAMATAN" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-2.5 text-xs text-indigo-900 dark:text-indigo-200 bg-indigo-50/80 dark:bg-indigo-950/40 p-3 rounded-xl border border-indigo-200 dark:border-indigo-900/60",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-4 text-indigo-600 dark:text-indigo-400 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-extrabold",
						children: "Tujuan: Setoran PBB-P2 ke Kas Kecamatan / Kasda"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-[11px] text-indigo-700 dark:text-indigo-300 mt-0.5",
						children: [
							"Setoran ini akan dikirimkan untuk ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Verifikasi Tim Kecamatan" }),
							" sebelum sah memotong saldo kas desa dan menambah persentase capaian setoran kecamatan."
						]
					})] })]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-2.5 text-xs text-amber-900 dark:text-amber-200 bg-amber-50/80 dark:bg-amber-950/40 p-3 rounded-xl border border-amber-200 dark:border-amber-900/60",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-extrabold",
							children: "Tujuan: Pengeluaran Internal Desa (Otorisasi Kepala Desa)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] text-amber-700 dark:text-amber-300 mt-0.5",
							children: [
								"Pengeluaran internal desa memerlukan ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Persetujuan (ACC) Kepala Desa" }),
								". Data ini ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "TIDAK AKAN" }),
								" masuk ke antrean verifikasi Kecamatan."
							]
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
							className: "text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { className: "size-3.5 text-amber-600 dark:text-amber-400" }),
								" Kategori Pengeluaran Internal Desa ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-rose-500",
									children: "*"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: kategoriInternal,
							onValueChange: (val) => setKategoriInternal(val),
							disabled: isKasZero,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "w-full h-10 text-xs font-bold rounded-xl border-amber-200 dark:border-slate-800 bg-white dark:bg-slate-950",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Pilih Kategori Pengeluaran Internal" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "OPERASIONAL_DESA",
									children: "⚡ Operasional & Insentif Petugas Penagih"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "KEGIATAN_DESA",
									children: "🎉 Kegiatan Kemasyarakatan / PHBN Desa"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "ADMINISTRASI",
									children: "📄 Administrasi, ATK & Cetak Resi Office"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "LAINNYA",
									children: "🛠️ Pengeluaran Internal Lainnya"
								})
							] })]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `p-3.5 rounded-xl border flex items-center justify-between gap-3 ${isKasZero ? "bg-rose-500/10 border-rose-500/30 text-rose-800 dark:text-rose-300" : "bg-emerald-500/10 border-emerald-500/30 text-emerald-900 dark:text-emerald-200"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `size-8 rounded-lg grid place-items-center shrink-0 ${isKasZero ? "bg-rose-500 text-white" : "bg-emerald-600 text-white"}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-extrabold uppercase tracking-wider opacity-80",
							children: "Sisa Saldo Kas PBB-P2 Tersedia"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-black",
							children: formatRp(availableKas)
						})] })]
					}), isKasZero && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "px-2 py-0.5 rounded-md bg-rose-500 text-white text-[10px] font-black uppercase tracking-wider animate-pulse",
						children: "Kas Kosong"
					})]
				}),
				errorMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 text-xs font-semibold flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: errorMsg })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleSubmit,
					className: "space-y-4 pt-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
								className: "text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5 text-emerald-600 dark:text-emerald-400" }), " Asal Desa"]
							}), isSuperAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: desaId,
								onValueChange: setDesaId,
								disabled: isKasZero,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "w-full h-10 text-xs rounded-xl border-emerald-200 dark:border-slate-800",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Pilih Desa" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: desasList.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
									value: String(d.id),
									children: [
										d.nama_desa,
										" (",
										d.kode_desa,
										")"
									]
								}, d.id)) })]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "text",
								disabled: true,
								readOnly: true,
								value: `${tenant?.nama_desa || settings?.namaDesa || "Desa"} (${tenant?.kode_desa || settings?.kodeDesa || "Desa Terkunci"})`,
								className: "h-10 text-xs font-bold bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 rounded-xl cursor-not-allowed"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
									className: "text-xs font-bold text-slate-700 dark:text-slate-300",
									children: [
										tipePengeluaran === "KECAMATAN" ? "Tanggal Setoran Kas" : "Tanggal Pengeluaran Kas",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-rose-500",
											children: "*"
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: tanggalSetor,
									onChange: (e) => setTanggalSetor(e.target.value),
									disabled: isKasZero,
									required: true,
									className: "h-10 text-xs rounded-xl border-emerald-200 dark:border-slate-800"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
									className: "text-xs font-bold text-slate-700 dark:text-slate-300",
									children: ["Tahun Pajak Ketetapan ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-rose-500",
										children: "*"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: tahun,
									onChange: (e) => setTahun(Number(e.target.value)),
									disabled: isKasZero,
									required: true,
									className: "h-10 text-xs rounded-xl border-emerald-200 dark:border-slate-800"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
								className: "text-xs font-bold text-slate-700 dark:text-slate-300",
								children: [
									tipePengeluaran === "KECAMATAN" ? "Nominal Setoran ke Kecamatan (Rp)" : "Nominal Pengeluaran Internal (Rp)",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-rose-500",
										children: "*"
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute left-3.5 top-2.5 text-xs font-black text-emerald-600 dark:text-emerald-400",
									children: "Rp"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "text",
									value: nominal,
									onChange: (e) => setNominal(e.target.value),
									placeholder: "e.g. 5.000.000",
									disabled: isKasZero,
									required: true,
									className: "pl-10 h-11 text-sm font-black text-emerald-700 dark:text-emerald-400 rounded-xl border-emerald-200 dark:border-slate-800"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-bold text-slate-700 dark:text-slate-300",
									children: "Metode Penyaluran Dana"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: metodeSetoran,
									onValueChange: setMetodeSetoran,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "h-10 text-xs rounded-xl border-emerald-200 dark:border-slate-800",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Pilih Metode" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "TRANSFER",
											children: "🏦 Transfer Bank"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "TUNAI",
											children: "💵 Tunai Langsung"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "LAINNYA",
											children: "📄 Metode Lainnya"
										})
									] })]
								})]
							}), metodeSetoran === "TRANSFER" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-bold text-slate-700 dark:text-slate-300",
									children: "Bank Tujuan"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "text",
									value: bankTujuan,
									onChange: (e) => setBankTujuan(e.target.value),
									placeholder: "e.g. Bank Jabar Banten (BJB)",
									className: "h-10 text-xs rounded-xl border-emerald-200 dark:border-slate-800"
								})]
							})]
						}),
						metodeSetoran === "TRANSFER" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs font-bold text-slate-700 dark:text-slate-300",
								children: "Nomor Referensi / Resi Transfer"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "text",
								value: nomorReferensi,
								onChange: (e) => setNomorReferensi(e.target.value),
								placeholder: "e.g. REF8829102931",
								className: "h-10 text-xs rounded-xl border-emerald-200 dark:border-slate-800"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
									className: "text-xs font-bold text-slate-700 dark:text-slate-300",
									children: [
										tipePengeluaran === "KECAMATAN" ? "Nama Penyetor (Desa)" : "Penanggung Jawab / Pemohon Dana",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-rose-500",
											children: "*"
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "text",
									value: penyetorNama,
									onChange: (e) => setPenyetorNama(e.target.value),
									required: true,
									className: "h-10 text-xs rounded-xl border-emerald-200 dark:border-slate-800"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-bold text-slate-700 dark:text-slate-300",
									children: "Jabatan Petugas / Pemohon"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "text",
									value: penyetorJabatan,
									onChange: (e) => setPenyetorJabatan(e.target.value),
									className: "h-10 text-xs rounded-xl border-emerald-200 dark:border-slate-800"
								})]
							})]
						}),
						tipePengeluaran === "KECAMATAN" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs font-bold text-slate-700 dark:text-slate-300",
								children: "Tujuan / Pejabat Penerima di Kecamatan"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "text",
								value: penerimaKecamatan,
								onChange: (e) => setPenerimaKecamatan(e.target.value),
								placeholder: "e.g. Kasi Pemerintahan / Tim PBB Kecamatan",
								className: "h-10 text-xs rounded-xl border-emerald-200 dark:border-slate-800"
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs font-bold text-slate-700 dark:text-slate-300",
								children: "Penerima Dana / Pihak Pelaksana Kegiatan (Opsional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "text",
								value: penerimaInternal,
								onChange: (e) => setPenerimaInternal(e.target.value),
								placeholder: "e.g. Panitia PHBN, Bendahara Operasional, atau Tim Penagih Dusun",
								className: "h-10 text-xs rounded-xl border-emerald-200 dark:border-slate-800"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs font-bold text-slate-700 dark:text-slate-300",
								children: tipePengeluaran === "KECAMATAN" ? "Catatan / Keterangan Setoran" : "Uraian / Rincian Pengeluaran Internal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: catatanDesa,
								onChange: (e) => setCatatanDesa(e.target.value),
								rows: 2,
								placeholder: tipePengeluaran === "KECAMATAN" ? "Keterangan setoran (misal: Setoran Tahap 1 Dusun 1 & 2)..." : "Uraian kebutuhan dana (misal: Biaya konsumsi dan transportasi posko penagihan dusun 1)...",
								className: "text-xs rounded-xl border-emerald-200 dark:border-slate-800"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs font-bold text-slate-700 dark:text-slate-300",
								children: tipePengeluaran === "KECAMATAN" ? "Upload Bukti Transfer / Resi Setoran" : "Upload Nota / Kuitansi / Tanda Terima"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex-1 cursor-pointer flex items-center justify-center gap-2 h-11 px-4 rounded-xl border border-dashed border-emerald-300 dark:border-slate-700 bg-emerald-50/50 dark:bg-slate-900/50 hover:bg-emerald-100/50 transition text-xs font-bold text-emerald-800 dark:text-emerald-400",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4 text-emerald-600 dark:text-emerald-400" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: buktiFile ? "Ganti File Lampiran" : "Pilih File Bukti (Max 5MB)" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "file",
											accept: "image/*,.pdf",
											onChange: handleFileUpload,
											className: "hidden"
										})
									]
								}), buktiFile && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400 font-extrabold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Lampiran Terunggah" })]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
							className: "pt-4 border-t border-slate-100 dark:border-slate-800 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								onClick: onClose,
								className: "rounded-xl h-10 text-xs font-bold border-slate-200 dark:border-slate-800",
								children: "Batal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: isSubmitting || isKasZero,
								className: `rounded-xl h-10 text-xs font-extrabold text-white shadow-md disabled:opacity-50 disabled:cursor-not-allowed ${tipePengeluaran === "KECAMATAN" ? "bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700" : "bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700"}`,
								children: isSubmitting ? "Menyimpan..." : isKasZero ? "Kas Rp 0 (Terkunci)" : editData ? "Perbarui Data" : tipePengeluaran === "KECAMATAN" ? "Ajukan Setoran Kecamatan" : "Ajukan Pengeluaran Internal"
							})]
						})
					]
				})
			]
		})
	});
}
var RadioGroup = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroup$1, {
		className: cn("grid gap-2", className),
		...props,
		ref
	});
});
RadioGroup.displayName = RadioGroup$1.displayName;
var RadioGroupItem = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupItem$1, {
		ref,
		className: cn("aspect-square h-4 w-4 rounded-full border border-primary text-primary shadow cursor-pointer focus:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupIndicator, {
			className: "flex items-center justify-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "h-3.5 w-3.5 fill-primary" })
		})
	});
});
RadioGroupItem.displayName = RadioGroupItem$1.displayName;
function VerifikasiSetoranModal({ isOpen, onClose, onVerify, item }) {
	const [status, setStatus] = (0, import_react.useState)("DITERIMA");
	const [catatanKecamatan, setCatatanKecamatan] = (0, import_react.useState)("");
	const [tanggalDiterima, setTanggalDiterima] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
	const [isSubmitting, setIsSubmitting] = (0, import_react.useState)(false);
	const [errorMsg, setErrorMsg] = (0, import_react.useState)(null);
	const isPendingHapus = item?.status === "PENDING_HAPUS";
	(0, import_react.useEffect)(() => {
		if (item) {
			if (item.status === "PENDING_HAPUS") setStatus("APPROVE_DELETE");
			else setStatus(item.status || "DITERIMA");
			setCatatanKecamatan(item.catatanKecamatan || "");
			setTanggalDiterima(item.tanggalDiterima ? item.tanggalDiterima.slice(0, 10) : (/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
		}
		setErrorMsg(null);
	}, [item, isOpen]);
	if (!item) return null;
	const handleSubmit = async (e) => {
		e.preventDefault();
		setErrorMsg(null);
		setIsSubmitting(true);
		try {
			await onVerify(item.id, status, catatanKecamatan, tanggalDiterima);
			onClose();
		} catch (err) {
			setErrorMsg(err.message || "Gagal memproses verifikasi setoran.");
		} finally {
			setIsSubmitting(false);
		}
	};
	const formatRp = (val) => {
		return new Intl.NumberFormat("id-ID", {
			style: "currency",
			currency: "IDR",
			maximumFractionDigits: 0
		}).format(val);
	};
	const isInternal = item.kategori !== "SETOR_KECAMATAN";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: isOpen,
		onOpenChange: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-lg bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 rounded-2xl p-6 shadow-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `size-10 rounded-xl ${isPendingHapus ? "bg-gradient-to-tr from-rose-600 to-amber-500" : "bg-gradient-to-tr from-emerald-600 to-amber-500"} text-white grid place-items-center shadow-md shrink-0`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "text-lg font-extrabold text-slate-900 dark:text-white",
						children: isPendingHapus ? isInternal ? "Verifikasi Permohonan Hapus oleh Kepala Desa" : "Verifikasi Permohonan Hapus oleh Admin Kecamatan" : isInternal ? "Persetujuan Pengeluaran Internal Desa" : "Verifikasi Penerimaan Setoran Kecamatan"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-xs text-slate-500 dark:text-slate-400",
						children: isPendingHapus ? "Desa mengajukan permohonan penghapusan data ini. Silakan konfirmasi keputusan Anda." : isInternal ? "Konfirmasi persetujuan Kepala Desa untuk realisasi pengeluaran kas PBB-P2 desa." : "Konfirmasi penerimaan setoran PBB-P2 dari desa dan perbarui catatan verifikasi."
					})] })]
				}) }),
				errorMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 text-xs font-semibold flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: errorMsg })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/50 p-4 space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-slate-500 dark:text-slate-400",
								children: "Nomor Bukti"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-black text-slate-900 dark:text-white font-mono",
								children: item.nomorBukti
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-slate-500 dark:text-slate-400",
								children: "Desa"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-extrabold text-emerald-600 dark:text-emerald-400 flex items-center gap-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5" }),
									" ",
									item.namaDesa || "Desa"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-slate-500 dark:text-slate-400",
								children: "Penanggung Jawab / Penyetor"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-semibold text-slate-800 dark:text-slate-200",
								children: [
									item.penyetorNama,
									" (",
									item.penyetorJabatan || "Bendahara",
									")"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-xs pt-1 border-t border-slate-200 dark:border-slate-800",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-slate-700 dark:text-slate-300",
								children: "Nominal Pengeluaran"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-base font-black text-emerald-600 dark:text-emerald-400",
								children: formatRp(item.nominal)
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleSubmit,
					className: "space-y-4 pt-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs font-bold text-slate-700 dark:text-slate-300",
								children: isPendingHapus ? "Keputusan Permohonan Penghapusan" : isInternal ? "Keputusan Persetujuan Kepala Desa" : "Status Verifikasi Kecamatan"
							}), isPendingHapus ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadioGroup, {
								value: status,
								onValueChange: (val) => setStatus(val),
								className: "grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: `flex flex-col items-center justify-center p-3 rounded-xl border cursor-pointer transition text-center ${status === "APPROVE_DELETE" ? "bg-rose-50 dark:bg-rose-500/15 border-rose-500 text-rose-800 dark:text-rose-300 font-extrabold shadow-sm" : "border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-900"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupItem, {
											value: "APPROVE_DELETE",
											className: "sr-only"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: `size-5 mb-1 ${status === "APPROVE_DELETE" ? "text-rose-600 dark:text-rose-400" : "text-slate-400"}` }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs",
											children: "SETUJUI HAPUS (Hapus Permanen)"
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: `flex flex-col items-center justify-center p-3 rounded-xl border cursor-pointer transition text-center ${status === "REJECT_DELETE" ? "bg-emerald-50 dark:bg-emerald-500/15 border-emerald-500 text-emerald-800 dark:text-emerald-300 font-extrabold shadow-sm" : "border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-900"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupItem, {
											value: "REJECT_DELETE",
											className: "sr-only"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: `size-5 mb-1 ${status === "REJECT_DELETE" ? "text-emerald-600 dark:text-emerald-400" : "text-slate-400"}` }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs",
											children: "TOLAK HAPUS (Pertahankan Data)"
										})
									]
								})]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadioGroup, {
								value: status,
								onValueChange: (val) => setStatus(val),
								className: "grid grid-cols-3 gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: `flex flex-col items-center justify-center p-3 rounded-xl border cursor-pointer transition text-center ${status === "DITERIMA" ? "bg-emerald-50 dark:bg-emerald-500/15 border-emerald-500 text-emerald-800 dark:text-emerald-300 font-extrabold shadow-sm" : "border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-900"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupItem, {
												value: "DITERIMA",
												className: "sr-only"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: `size-5 mb-1 ${status === "DITERIMA" ? "text-emerald-600 dark:text-emerald-400" : "text-slate-400"}` }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs",
												children: isInternal ? "SETUJUI" : "DITERIMA"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: `flex flex-col items-center justify-center p-3 rounded-xl border cursor-pointer transition text-center ${status === "DITOLAK" ? "bg-rose-50 dark:bg-rose-500/15 border-rose-500 text-rose-800 dark:text-rose-300 font-extrabold shadow-sm" : "border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-900"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupItem, {
												value: "DITOLAK",
												className: "sr-only"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: `size-5 mb-1 ${status === "DITOLAK" ? "text-rose-600 dark:text-rose-400" : "text-slate-400"}` }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs",
												children: "TOLAK"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: `flex flex-col items-center justify-center p-3 rounded-xl border cursor-pointer transition text-center ${status === "PENDING" ? "bg-amber-50 dark:bg-amber-500/15 border-amber-500 text-amber-800 dark:text-amber-300 font-extrabold shadow-sm" : "border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-900"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupItem, {
												value: "PENDING",
												className: "sr-only"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: `size-5 mb-1 ${status === "PENDING" ? "text-amber-600 dark:text-amber-400" : "text-slate-400"}` }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs",
												children: "PENDING"
											})
										]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs font-bold text-slate-700 dark:text-slate-300",
								children: isInternal ? "Tanggal Disetujui" : "Tanggal Diterima / Diproses di Kecamatan"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: tanggalDiterima,
								onChange: (e) => setTanggalDiterima(e.target.value),
								className: "h-10 text-xs rounded-xl border-emerald-200 dark:border-slate-800"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs font-bold text-slate-700 dark:text-slate-300",
								children: isInternal ? "Catatan / Arahan Kepala Desa" : "Catatan / Alasan Verifikasi Kecamatan"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: catatanKecamatan,
								onChange: (e) => setCatatanKecamatan(e.target.value),
								rows: 3,
								placeholder: isInternal ? "Tambahkan catatan persetujuan Kepala Desa (misal: Disetujui untuk realisasi operasional penagihan dusun)..." : "Tambahkan catatan resmi dari Kecamatan (misal: Setoran telah dicocokkan dengan resi BJB dan dinyatakan sah)...",
								className: "text-xs rounded-xl border-emerald-200 dark:border-slate-800"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
							className: "pt-4 border-t border-slate-100 dark:border-slate-800 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								onClick: onClose,
								className: "rounded-xl h-10 text-xs font-bold border-slate-200 dark:border-slate-800",
								children: "Batal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: isSubmitting,
								className: "rounded-xl h-10 text-xs font-extrabold bg-gradient-to-r from-emerald-600 to-amber-500 text-white shadow-md hover:from-emerald-700 hover:to-amber-600",
								children: isSubmitting ? "Memproses..." : isInternal ? "Simpan Persetujuan" : "Simpan Status Verifikasi"
							})]
						})
					]
				})
			]
		})
	});
}
function DetailSetoranModal({ isOpen, onClose, item }) {
	const { settings } = useSettingsStore();
	if (!item) return null;
	const formatRp = (val) => {
		return new Intl.NumberFormat("id-ID", {
			style: "currency",
			currency: "IDR",
			maximumFractionDigits: 0
		}).format(val);
	};
	const handlePrintPdf = () => {
		generateBuktiSetorPdf(item, settings);
	};
	const isInternal = item.kategori !== "SETOR_KECAMATAN";
	const getStatusBadge = (status) => {
		if (status === "DITERIMA") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
			className: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/30 px-3 py-1 font-black text-xs gap-1.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5" }),
				" ",
				isInternal ? "DISETUJUI KEPALA DESA" : "DITERIMA KECAMATAN"
			]
		});
		if (status === "DITOLAK") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
			className: "bg-rose-500/15 text-rose-700 dark:text-rose-400 border-rose-500/30 px-3 py-1 font-black text-xs gap-1.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-3.5" }),
				" ",
				isInternal ? "DITOLAK KEPALA DESA" : "DITOLAK KECAMATAN"
			]
		});
		if (status === "PENDING_HAPUS") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
			className: "bg-rose-500/20 text-rose-700 dark:text-rose-400 border-rose-500/40 px-3 py-1 font-black text-xs gap-1.5 animate-pulse",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5" }),
				" ",
				isInternal ? "MENUNGGU VERIFIKASI HAPUS KADES" : "MENUNGGU VERIFIKASI HAPUS KECAMATAN"
			]
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
			className: "bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-500/30 px-3 py-1 font-black text-xs gap-1.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5" }),
				" ",
				isInternal ? "MENUNGGU PERSETUJUAN KADES" : "PENDING VERIFIKASI"
			]
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: isOpen,
		onOpenChange: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-xl max-h-[90vh] overflow-y-auto bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 rounded-2xl p-6 shadow-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white grid place-items-center shadow-md shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "text-lg font-extrabold text-slate-900 dark:text-white",
							children: isInternal ? "Pratinjau Pengeluaran Internal Desa" : "Pratinjau Bukti Setoran ke Kecamatan"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, {
							className: "text-xs text-slate-500 dark:text-slate-400 font-mono",
							children: ["No Bukti: ", item.nomorBukti]
						})] })]
					}), getStatusBadge(item.status)]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 pt-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl bg-gradient-to-br from-emerald-600 via-teal-700 to-emerald-800 p-5 text-white shadow-lg relative overflow-hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute right-0 top-0 translate-x-4 -translate-y-4 opacity-10 pointer-events-none",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-48" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative z-10 space-y-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-bold text-emerald-100 uppercase tracking-wider",
										children: isInternal ? "Total Nominal Pengeluaran Internal" : "Total Nominal Setoran PBB-P2"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-3xl font-black text-white tracking-tight",
										children: formatRp(item.nominal)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-4 text-xs text-emerald-100 font-medium pt-2 border-t border-white/20 mt-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Desa: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: item.namaDesa || "Desa" })] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "•" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Tanggal: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: item.tanggalSetor })] })
										]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3 flex justify-between items-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-slate-500 dark:text-slate-400",
										children: "Metode"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-extrabold text-slate-800 dark:text-slate-200",
										children: item.metodeSetoran === "TRANSFER" ? `Transfer (${item.bankTujuan || "BJB"})` : item.metodeSetoran
									})]
								}),
								item.nomorReferensi && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3 flex justify-between items-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-slate-500 dark:text-slate-400",
										children: "Nomor Resi / Ref"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono font-bold text-emerald-700 dark:text-emerald-400",
										children: item.nomorReferensi
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3 flex justify-between items-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-slate-500 dark:text-slate-400",
										children: "Penanggung Jawab"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-semibold text-slate-800 dark:text-slate-200",
										children: [
											item.penyetorNama,
											" (",
											item.penyetorJabatan || "Bendahara",
											")"
										]
									})]
								}),
								!isInternal && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3 flex justify-between items-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-slate-500 dark:text-slate-400",
										children: "Tujuan / Penerima Kecamatan"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold text-slate-800 dark:text-slate-200",
										children: item.penerimaKecamatan || "Pemerintah Kecamatan"
									})]
								}),
								item.catatanDesa && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3 space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-slate-500 dark:text-slate-400 block",
										children: "Catatan / Keterangan"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-slate-700 dark:text-slate-300 italic bg-slate-50 dark:bg-slate-900 p-2 rounded-lg border border-slate-200 dark:border-slate-800",
										children: [
											"\"",
											item.catatanDesa,
											"\""
										]
									})]
								}),
								item.catatanKecamatan && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3 space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-emerald-700 dark:text-emerald-400 block",
										children: isInternal ? "Catatan Persetujuan Kepala Desa" : "Catatan Verifikasi Kecamatan"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-slate-700 dark:text-slate-300 italic bg-emerald-50/50 dark:bg-emerald-900/20 p-2 rounded-lg border border-emerald-200 dark:border-emerald-800",
										children: [
											"\"",
											item.catatanKecamatan,
											"\""
										]
									})]
								})
							]
						}),
						item.buktiFile && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs font-bold text-slate-700 dark:text-slate-300",
								children: "Lampiran Resi / Bukti Transfer"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 p-3 overflow-hidden text-center",
								children: item.buktiFile.startsWith("data:image") || item.buktiFile.startsWith("http") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: item.buktiFile,
									alt: "Bukti Transfer",
									className: "max-h-60 mx-auto rounded-lg shadow-md object-contain border border-slate-200 dark:border-slate-800"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-4 flex items-center justify-center gap-2 text-xs font-bold text-emerald-700 dark:text-emerald-400",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "File Lampiran Resi Terlampir" })]
								})
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
					className: "pt-4 border-t border-slate-100 dark:border-slate-800 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: onClose,
						className: "rounded-xl h-10 text-xs font-bold border-slate-200 dark:border-slate-800",
						children: "Tutup"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						onClick: handlePrintPdf,
						className: "rounded-xl h-10 text-xs font-extrabold bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md hover:from-emerald-700 hover:to-teal-700 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), " Cetak Bukti Setoran (PDF)"]
					})]
				})
			]
		})
	});
}
function SetoranKecamatanPage() {
	const { user: authUser } = useAuthStore();
	const { getActiveUser } = useUserStore();
	const tenant = useTenantStore();
	const { settings } = useSettingsStore();
	const activeUser = authUser || getActiveUser();
	const userDesaId = activeUser?.desa_id || activeUser?.desa?.id || tenant?.id;
	const currentRole = activeUser?.role || "SUPER_ADMIN";
	const isSuperAdmin = currentRole === "SUPER_ADMIN_SYSTEM" || !userDesaId && currentRole !== "BENDAHARA" && currentRole !== "KOLEKTOR" && currentRole !== "KEPALA_DESA";
	const roleInfo = ROLE_LABELS[currentRole] || {
		label: "Super Admin",
		badgeClass: "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
	};
	const [activeTab, setActiveTab] = (0, import_react.useState)("setor_desa");
	const [filterDesa, setFilterDesa] = (0, import_react.useState)("all");
	const [desasList, setDesasList] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		if (!isSuperAdmin && activeTab === "rekap_desa") setActiveTab("setor_desa");
	}, [isSuperAdmin, activeTab]);
	const [isCreateOpen, setIsCreateOpen] = (0, import_react.useState)(false);
	const [createKategori, setCreateKategori] = (0, import_react.useState)("SETOR_KECAMATAN");
	const [editingItem, setEditingItem] = (0, import_react.useState)(null);
	const [detailItem, setDetailItem] = (0, import_react.useState)(null);
	const [isDetailOpen, setIsDetailOpen] = (0, import_react.useState)(false);
	const [verifyingItem, setVerifyingItem] = (0, import_react.useState)(null);
	const [isVerifyOpen, setIsVerifyOpen] = (0, import_react.useState)(false);
	const { items, summary, isLoading, fetchItems, fetchSummary, createSetoran, updateSetoran, verifySetoran, deleteSetoran } = useSetoranKecamatanStore();
	(0, import_react.useEffect)(() => {
		if (isSuperAdmin) desaService.getAll().then((res) => {
			if (res.data) setDesasList(res.data);
		}).catch((err) => console.error("Gagal memuat list desa:", err));
	}, [isSuperAdmin]);
	(0, import_react.useEffect)(() => {
		const desaParam = isSuperAdmin ? filterDesa !== "all" ? filterDesa : void 0 : void 0;
		fetchItems({ desa_id: desaParam });
		fetchSummary({
			desa_id: desaParam,
			tahun: 2026
		});
	}, [
		isSuperAdmin,
		filterDesa,
		fetchItems,
		fetchSummary
	]);
	const isKepalaDesa = currentRole === "KEPALA_DESA";
	const formatRp = (val) => {
		return new Intl.NumberFormat("id-ID", {
			style: "currency",
			currency: "IDR",
			maximumFractionDigits: 0
		}).format(val);
	};
	const selectedDesaObj = (0, import_react.useMemo)(() => {
		if (filterDesa === "all") return null;
		return desasList.find((d) => String(d.id) === filterDesa) || null;
	}, [filterDesa, desasList]);
	const pageTitle = (0, import_react.useMemo)(() => {
		if (isSuperAdmin) {
			if (filterDesa === "all") return `Pengeluaran PBB-P2 & Setoran Kecamatan ${settings.kecamatan || "Malangbong"}`;
			return `Pengeluaran PBB-P2 & Setoran Desa ${selectedDesaObj?.nama_desa || "Terpilih"}`;
		}
		return `Pengeluaran PBB-P2 & Setoran Desa ${tenant?.nama_desa || settings?.namaDesa || "Desa"}`;
	}, [
		isSuperAdmin,
		filterDesa,
		selectedDesaObj,
		tenant,
		settings
	]);
	const handleSaveSetoran = async (payload) => {
		try {
			if (editingItem) {
				await updateSetoran(editingItem.id, payload);
				Swal.fire({
					title: "Perubahan Disimpan!",
					text: "Data pengeluaran berhasil diperbarui dan status kembali ke PENDING untuk diverifikasi.",
					icon: "success",
					timer: 2500,
					showConfirmButton: false,
					customClass: { popup: "rounded-2xl shadow-2xl" }
				});
			} else {
				await createSetoran(payload);
				Swal.fire({
					title: "Berhasil Dibuat!",
					text: "Data pengeluaran/setoran berhasil dicatat ke dalam sistem.",
					icon: "success",
					timer: 2500,
					showConfirmButton: false,
					customClass: { popup: "rounded-2xl shadow-2xl" }
				});
			}
			fetchSummary({ desa_id: isSuperAdmin ? filterDesa !== "all" ? filterDesa : void 0 : void 0 });
			triggerGlobalNotifRefresh();
		} catch (err) {
			Swal.fire({
				title: "Gagal Menyimpan",
				text: err.message || "Terjadi kesalahan saat menyimpan data.",
				icon: "error",
				confirmButtonColor: "#e11d48",
				customClass: {
					popup: "rounded-2xl shadow-2xl",
					confirmButton: "rounded-xl font-bold px-4 py-2"
				}
			});
		}
	};
	const handleVerifySetoran = async (id, status, catatanKecamatan, tanggalDiterima) => {
		try {
			await verifySetoran(id, status, catatanKecamatan, tanggalDiterima);
			Swal.fire({
				title: "Verifikasi Berhasil!",
				text: status === "APPROVE_DELETE" ? "Permohonan hapus disetujui. Data telah dihapus permanen." : status === "REJECT_DELETE" ? "Permohonan hapus ditolak. Data tetap dipertahankan." : `Status pengeluaran berhasil diperbarui menjadi ${status}.`,
				icon: "success",
				timer: 2500,
				showConfirmButton: false,
				customClass: { popup: "rounded-2xl shadow-2xl" }
			});
			fetchSummary({ desa_id: isSuperAdmin ? filterDesa !== "all" ? filterDesa : void 0 : void 0 });
			triggerGlobalNotifRefresh();
		} catch (err) {
			Swal.fire({
				title: "Gagal Verifikasi",
				text: err.message || "Gagal memperbarui status verifikasi.",
				icon: "error",
				confirmButtonColor: "#e11d48",
				customClass: {
					popup: "rounded-2xl shadow-2xl",
					confirmButton: "rounded-xl font-bold px-4 py-2"
				}
			});
		}
	};
	const handleDeleteSetoran = async (item) => {
		const isInternal = item.kategori !== "SETOR_KECAMATAN";
		const verifikator = isInternal ? "Kepala Desa" : "Admin Kecamatan";
		if ((await Swal.fire({
			title: isInternal ? "Pengajuan Hapus Pengeluaran" : "Pengajuan Hapus Setoran",
			html: `
        <div style="text-align: left; font-size: 13px; line-height: 1.6;">
          <p style="color: #475569; margin-bottom: 8px;">Apakah Anda yakin ingin mengajukan penghapusan transaksi berikut?</p>
          <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 12px; margin-bottom: 12px;">
            <div><strong>No. Bukti:</strong> <span style="font-family: monospace; color: #0f172a;">${item.nomorBukti}</span></div>
            <div><strong>Kategori:</strong> <span>${isInternal ? "Internal Desa" : "Setor Kecamatan"}</span></div>
            <div><strong>Nominal:</strong> <span style="color: #059669; font-weight: 800;">${formatRp(item.nominal)}</span></div>
          </div>
          <div style="background: #fffbeb; border: 1px solid #fef3c7; border-radius: 8px; padding: 8px; color: #b45309; font-size: 11px; font-weight: 600;">
            ⚠️ Permohonan ini akan masuk ke antrean verifikasi <u>${verifikator}</u> sebelum data dihapus permanen.
          </div>
        </div>
      `,
			icon: "warning",
			showCancelButton: true,
			confirmButtonColor: "#e11d48",
			cancelButtonColor: "#64748b",
			confirmButtonText: "Ya, Ajukan Hapus",
			cancelButtonText: "Batal",
			reverseButtons: true,
			customClass: {
				popup: "rounded-2xl shadow-2xl",
				confirmButton: "rounded-xl font-bold px-5 py-2.5 text-xs",
				cancelButton: "rounded-xl font-bold px-5 py-2.5 text-xs"
			}
		})).isConfirmed) try {
			const res = await deleteSetoran(item.id);
			Swal.fire({
				title: "Permohonan Diajukan!",
				text: res.message || `Permohonan penghapusan telah dikirim ke ${verifikator} untuk diverifikasi.`,
				icon: "success",
				confirmButtonColor: "#059669",
				customClass: {
					popup: "rounded-2xl shadow-2xl",
					confirmButton: "rounded-xl font-bold px-5 py-2.5 text-xs"
				}
			});
			fetchSummary({ desa_id: isSuperAdmin ? filterDesa !== "all" ? filterDesa : void 0 : void 0 });
			triggerGlobalNotifRefresh();
		} catch (err) {
			Swal.fire({
				title: "Gagal Mengajukan",
				text: err.message || "Gagal memproses permohonan penghapusan.",
				icon: "error",
				confirmButtonColor: "#e11d48",
				customClass: {
					popup: "rounded-2xl shadow-2xl",
					confirmButton: "rounded-xl font-bold px-5 py-2.5 text-xs"
				}
			});
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 pb-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-emerald-500/30 dark:border-slate-800 bg-gradient-to-r from-emerald-800 via-teal-700 to-emerald-900 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 p-6 text-white shadow-xl relative overflow-hidden backdrop-blur-md",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute right-0 top-0 translate-x-4 -translate-y-4 opacity-10 pointer-events-none",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-64" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-white/15 dark:bg-emerald-500/10 border border-white/30 dark:border-emerald-500/30 text-emerald-50 dark:text-emerald-300 text-xs font-extrabold mb-2 backdrop-blur-md",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "size-3.5 text-amber-300" }), " Layanan Akuntabilitas Pengeluaran PBB-P2 & Setoran"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-2xl font-black tracking-tight text-white",
								children: pageTitle
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-emerald-100 dark:text-slate-300 mt-1 max-w-2xl font-medium",
								children: "Pencatatan realisasi pengeluaran PBB-P2 Desa (Setoran ke Kecamatan atau Kegiatan Internal), otorisasi persetujuan Kepala Desa, serta verifikasi penerimaan oleh Kecamatan."
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-white/30 dark:border-slate-700 bg-white/15 dark:bg-slate-800/80 p-3 backdrop-blur-md flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `size-10 rounded-xl bg-gradient-to-tr ${activeUser?.avatarBg || "from-emerald-600 to-teal-500"} text-white font-bold grid place-items-center text-xs shadow-md shrink-0`,
								children: (activeUser?.name || "AD").substring(0, 2).toUpperCase()
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-emerald-100 dark:text-slate-400 font-bold uppercase tracking-wider",
									children: "Pengguna Saat Ini"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-extrabold text-white",
									children: activeUser?.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `inline-block text-[9px] font-extrabold px-2 py-0.5 rounded-md border mt-0.5 ${roleInfo.badgeClass}`,
									children: roleInfo.label
								})
							] })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 flex items-center gap-2 pt-6 mt-6 border-t border-white/20 dark:border-slate-800 overflow-x-auto custom-scrollbar",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setActiveTab("setor_desa"),
								className: `px-4 py-2 rounded-xl text-xs font-extrabold flex items-center gap-2 transition shrink-0 ${activeTab === "setor_desa" ? "bg-white text-emerald-800 shadow-md" : "bg-white/15 text-white hover:bg-white/25"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" }), " 1. Catatan Pengeluaran PBB-P2"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setActiveTab("penerimaan_kecamatan"),
								className: `px-4 py-2 rounded-xl text-xs font-extrabold flex items-center gap-2 transition shrink-0 ${activeTab === "penerimaan_kecamatan" ? "bg-white text-emerald-800 shadow-md" : "bg-white/15 text-white hover:bg-white/25"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4" }),
									" ",
									isKepalaDesa ? "2. Antrean Persetujuan Kades" : "2. Verifikasi Setoran Kecamatan",
									(isKepalaDesa && items.filter((i) => i.kategori !== "SETOR_KECAMATAN" && (i.status === "PENDING" || i.status === "PENDING_HAPUS")).length > 0 || isSuperAdmin && items.filter((i) => i.kategori === "SETOR_KECAMATAN" && (i.status === "PENDING" || i.status === "PENDING_HAPUS")).length > 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "px-1.5 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-black animate-pulse",
										children: isKepalaDesa ? items.filter((i) => i.kategori !== "SETOR_KECAMATAN" && (i.status === "PENDING" || i.status === "PENDING_HAPUS")).length : items.filter((i) => i.kategori === "SETOR_KECAMATAN" && (i.status === "PENDING" || i.status === "PENDING_HAPUS")).length
									})
								]
							}),
							isSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setActiveTab("rekap_desa"),
								className: `px-4 py-2 rounded-xl text-xs font-extrabold flex items-center gap-2 transition shrink-0 ${activeTab === "rekap_desa" ? "bg-white text-emerald-800 shadow-md" : "bg-white/15 text-white hover:bg-white/25"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "size-4" }), " 3. Rekap Pengeluaran & Setoran Per Desa"]
							})
						]
					})
				]
			}),
			activeTab === "setor_desa" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SetorDesaTab, {
				items,
				summary,
				isLoading,
				onOpenCreate: (kat) => {
					setCreateKategori(kat || "SETOR_KECAMATAN");
					setEditingItem(null);
					setIsCreateOpen(true);
				},
				onOpenEdit: (item) => {
					setEditingItem(item);
					setIsCreateOpen(true);
				},
				onOpenDetail: (item) => {
					setDetailItem(item);
					setIsDetailOpen(true);
				},
				onOpenVerify: (item) => {
					setVerifyingItem(item);
					setIsVerifyOpen(true);
				},
				onDelete: handleDeleteSetoran,
				desasList,
				filterDesa,
				onFilterDesaChange: setFilterDesa,
				isSuperAdmin,
				isKepalaDesa
			}),
			activeTab === "penerimaan_kecamatan" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SetoranKecamatanTab, {
				items,
				summary,
				isLoading,
				onOpenVerify: (item) => {
					setVerifyingItem(item);
					setIsVerifyOpen(true);
				},
				onOpenDetail: (item) => {
					setDetailItem(item);
					setIsDetailOpen(true);
				},
				desasList,
				filterDesa,
				onFilterDesaChange: setFilterDesa,
				isSuperAdmin,
				isKepalaDesa
			}),
			isSuperAdmin && activeTab === "rekap_desa" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RekapDesaSetoranTab, {
				rekapList: summary?.rekapPerDesa || [],
				tahun: 2026,
				isLoading
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuatSetoranModal, {
				isOpen: isCreateOpen,
				onClose: () => setIsCreateOpen(false),
				onSave: handleSaveSetoran,
				editData: editingItem,
				initialKategori: createKategori,
				desasList,
				isSuperAdmin,
				sisaKasDesa: summary?.sisaKasDesa ?? 0
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerifikasiSetoranModal, {
				isOpen: isVerifyOpen,
				onClose: () => setIsVerifyOpen(false),
				onVerify: handleVerifySetoran,
				item: verifyingItem
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailSetoranModal, {
				isOpen: isDetailOpen,
				onClose: () => setIsDetailOpen(false),
				item: detailItem
			})
		]
	});
}
//#endregion
export { SetoranKecamatanPage as component };
