import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as apiClient } from "./authStore-CZRDvP0Z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settingsStore-BBOTJBY5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/**
* Setting API Service Layer
* Interfaces frontend with backend System Settings endpoints.
*/
var settingService = {
	async getSettings(desaId) {
		const params = desaId && desaId !== "all" && desaId !== "ALL" ? { desa_id: desaId } : void 0;
		return apiClient.get("/settings", params);
	},
	async updateSettings(settings, desaId) {
		const payload = { settings };
		if (desaId && desaId !== "all" && desaId !== "ALL") payload.desa_id = desaId;
		return apiClient.post("/settings", payload);
	}
};
var defaultSettings = {
	namaDesa: "Desa",
	kecamatan: "Malangbong",
	kabupaten: "Kabupaten Garut",
	kodeDesa: "",
	jabatanKades: "Kepala Desa",
	namaKades: "",
	nipKades: "",
	jabatanPetugas: "Bendahara / Kolektor Utama PBB",
	namaPetugas: "Kolektor PBB Desa",
	nipPetugas: "",
	teleponDesa: "",
	alamatDesa: "",
	tahunAktif: 2026,
	jatuhTempoBulan: 8,
	jatuhTempoTanggal: 31,
	pembulatanRibuan: true,
	enableFeeKolektorLuarDesa: true,
	feeKolektorLuarDesa: 5e3,
	printerFormat: "thermal58",
	tampilkanLogoKop: true,
	headerStruk: "PEMERINTAH KABUPATEN GARUT\nKECAMATAN MALANGBONG",
	footerStruk: "Terima kasih atas partisipasi Anda dalam pembayaran PBB-P2.",
	cetakOtomatis: true,
	jumlahSalinan: 1
};
var SETTINGS_STORAGE_KEY = "lentera_app_settings_v1";
var keyAliases = {
	nama_desa: "namaDesa",
	nama_kecamatan: "kecamatan",
	nama_instansi: "kabupaten",
	kode_desa: "kodeDesa",
	tahun_pajak: "tahunAktif",
	jabatan_kades: "jabatanKades",
	nama_kades: "namaKades",
	nip_kades: "nipKades",
	jabatan_bendahara: "jabatanPetugas",
	nama_bendahara: "namaPetugas",
	nip_bendahara: "nipPetugas",
	telepon_desa: "teleponDesa",
	alamat_desa: "alamatDesa",
	jatuh_tempo_bulan: "jatuhTempoBulan",
	jatuh_tempo_tanggal: "jatuhTempoTanggal",
	pembulatan_ribuan: "pembulatanRibuan",
	enable_fee_kolektor_luar_desa: "enableFeeKolektorLuarDesa",
	fee_kolektor_luar_desa: "feeKolektorLuarDesa",
	printer_format: "printerFormat",
	tampilkan_logo_kop: "tampilkanLogoKop",
	header_resi_thermal: "headerStruk",
	footer_resi_thermal: "footerStruk",
	cetak_otomatis: "cetakOtomatis",
	jumlah_salinan: "jumlahSalinan"
};
function parseApiSettings(data) {
	const parsed = {};
	Object.entries(data).forEach(([rawKey, val]) => {
		if (val === null || val === void 0) return;
		const key = keyAliases[rawKey] || rawKey;
		const defaultVal = defaultSettings[key];
		if (defaultVal === void 0) return;
		if (typeof defaultVal === "boolean") parsed[key] = val === true || val === "true" || val === "1" || val === 1;
		else if (typeof defaultVal === "number") {
			const num = Number(val);
			parsed[key] = isNaN(num) ? defaultVal : num;
		} else if (typeof defaultVal === "string") parsed[key] = String(val);
	});
	return parsed;
}
function loadInitialSettings() {
	if (typeof window === "undefined") return defaultSettings;
	try {
		const saved = localStorage.getItem(SETTINGS_STORAGE_KEY);
		if (saved) return {
			...defaultSettings,
			...JSON.parse(saved)
		};
	} catch (err) {
		console.error("Gagal memuat pengaturan dari localStorage:", err);
	}
	return defaultSettings;
}
var globalSettings = loadInitialSettings();
var settingsListeners = /* @__PURE__ */ new Set();
function notifySettingsListeners() {
	if (typeof window !== "undefined") try {
		localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(globalSettings));
	} catch (err) {
		console.error("Gagal menyimpan pengaturan ke localStorage:", err);
	}
	settingsListeners.forEach((fn) => fn());
}
function getGlobalSettings() {
	return globalSettings;
}
async function refreshSettingsFromApi(desaId) {
	try {
		const res = await settingService.getSettings(desaId);
		if (res.data && typeof res.data === "object" && Object.keys(res.data).length > 0) {
			const parsed = parseApiSettings(res.data);
			globalSettings = {
				...globalSettings,
				...parsed
			};
			notifySettingsListeners();
		}
	} catch (err) {
		console.warn("[settingsStore] API sync fallback ke local storage:", err);
	}
	return globalSettings;
}
async function updateSettings(newSettings, desaId) {
	globalSettings = {
		...globalSettings,
		...newSettings
	};
	notifySettingsListeners();
	try {
		const res = await settingService.updateSettings(newSettings, desaId);
		if (res.success && res.data) {
			const parsed = parseApiSettings(res.data);
			globalSettings = {
				...globalSettings,
				...parsed
			};
			notifySettingsListeners();
			return true;
		}
	} catch (err) {
		console.error("Gagal melakukan sinkronisasi pengaturan ke API backend:", err);
		throw err;
	}
	return false;
}
async function resetSettings(desaId) {
	globalSettings = { ...defaultSettings };
	notifySettingsListeners();
	try {
		const res = await settingService.updateSettings(defaultSettings, desaId);
		if (res.success && res.data) {
			const parsed = parseApiSettings(res.data);
			globalSettings = {
				...globalSettings,
				...parsed
			};
			notifySettingsListeners();
			return true;
		}
	} catch (err) {
		console.error("Gagal mengembalikan pengaturan pada API backend:", err);
		throw err;
	}
	return false;
}
var settingsApiFetchedOnce = false;
function useSettingsStore() {
	const [settings, setSettings] = (0, import_react.useState)(globalSettings);
	(0, import_react.useEffect)(() => {
		if (!settingsApiFetchedOnce) {
			settingsApiFetchedOnce = true;
			refreshSettingsFromApi();
		}
		const handleChange = () => {
			setSettings({ ...globalSettings });
		};
		settingsListeners.add(handleChange);
		return () => {
			settingsListeners.delete(handleChange);
		};
	}, []);
	return {
		settings,
		refreshFromApi: refreshSettingsFromApi,
		updateSettings,
		resetSettings
	};
}
//#endregion
export { useSettingsStore as i, getGlobalSettings as n, settingService as r, defaultSettings as t };
