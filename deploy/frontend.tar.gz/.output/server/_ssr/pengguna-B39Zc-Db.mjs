import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { i as useAuthStore, o as useUserStore, t as ROLE_LABELS } from "./authStore-CZRDvP0Z.mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-YtzMxdp3.mjs";
import { t as Input } from "./input-BBQFjwfK.mjs";
import { At as CircleX, C as ShieldAlert, F as Phone, G as Mail, J as Lock, Mt as CircleAlert, O as Search, P as Plus, R as Pen, S as ShieldCheck, W as MapPin, Wt as Building2, X as List, Y as LoaderCircle, Z as LayoutGrid, a as UserPlus, at as Hash, f as Trash2, ft as FileText, j as RefreshCw, jt as CircleCheck, k as Save, nt as KeyRound, o as UserCheck, r as Users, st as Globe, t as X, wt as Copy, x as Shield, y as Sparkles, zt as Check } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-BnDjHZuV.mjs";
import { t as desaService } from "./desaService-B2uJrXze.mjs";
import { t as Label } from "./label-CiVZqe-N.mjs";
import { t as formatDusunDisplay } from "./dusunHelper-BcA75wHe.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-B16iqma3.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as dusunService } from "./dusunService-AJ7_2sYC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pengguna-B39Zc-Db.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function UserModal({ open, onOpenChange, userToEdit, onSuccessMessage }) {
	const { addUserAsync, updateUserAsync } = useUserStore();
	const { user: authUser } = useAuthStore();
	const isGlobalSuperAdmin = authUser?.role === "SUPER_ADMIN_SYSTEM" || !authUser?.desa_id;
	const [desasList, setDesasList] = (0, import_react.useState)([]);
	const [selectedDesaId, setSelectedDesaId] = (0, import_react.useState)("");
	const [username, setUsername] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [nip, setNip] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [role, setRole] = (0, import_react.useState)("KOLEKTOR");
	const [selectedDusuns, setSelectedDusuns] = (0, import_react.useState)(["ALL"]);
	const [availableDusuns, setAvailableDusuns] = (0, import_react.useState)([]);
	const [isLoadingDusuns, setIsLoadingDusuns] = (0, import_react.useState)(false);
	const [newDusunInput, setNewDusunInput] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("AKTIF");
	const [password, setPassword] = (0, import_react.useState)("");
	const [isSubmitting, setIsSubmitting] = (0, import_react.useState)(false);
	const [errorMessage, setErrorMessage] = (0, import_react.useState)(null);
	const isEditing = !!userToEdit;
	(0, import_react.useEffect)(() => {
		if (open && isGlobalSuperAdmin) desaService.getAll().then((res) => {
			if (res.data) setDesasList(res.data);
		}).catch((err) => console.error("Gagal memuat list desa:", err));
	}, [open, isGlobalSuperAdmin]);
	const fetchDusunsForDesa = (0, import_react.useCallback)(async (targetDesaId) => {
		setIsLoadingDusuns(true);
		try {
			const res = await dusunService.getByDesa(targetDesaId || void 0);
			const apiDusuns = res.data && Array.isArray(res.data) ? res.data : [];
			setAvailableDusuns((prev) => {
				const merged = [...apiDusuns];
				prev.forEach((d) => {
					if (d && d.toUpperCase() !== "ALL" && !merged.some((m) => m.toUpperCase() === d.toUpperCase())) merged.push(d);
				});
				return merged;
			});
		} catch (err) {
			console.warn("Gagal memuat daftar dusun desa:", err);
		} finally {
			setIsLoadingDusuns(false);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		if (open) {
			const targetDesa = isGlobalSuperAdmin ? selectedDesaId : authUser?.desa_id ? String(authUser.desa_id) : void 0;
			fetchDusunsForDesa(targetDesa);
		}
	}, [
		open,
		isGlobalSuperAdmin,
		selectedDesaId,
		authUser?.desa_id,
		fetchDusunsForDesa
	]);
	(0, import_react.useEffect)(() => {
		setErrorMessage(null);
		if (userToEdit) {
			setUsername(userToEdit.username || "");
			setName(userToEdit.name || "");
			setNip(userToEdit.nip || "");
			setEmail(userToEdit.email || "");
			setPhone(userToEdit.phone || "");
			setRole(userToEdit.role || "KOLEKTOR");
			const desaIdStr = userToEdit.desa_id ? String(userToEdit.desa_id) : "";
			setSelectedDesaId(desaIdStr);
			const rawAssigned = userToEdit.dusunAssigned || "ALL";
			if (rawAssigned.toUpperCase() === "ALL" || rawAssigned.toUpperCase() === "SEMUA") setSelectedDusuns(["ALL"]);
			else {
				const list = rawAssigned.split(",").map((s) => s.trim()).filter(Boolean);
				setSelectedDusuns(list.length > 0 ? list : ["ALL"]);
				setAvailableDusuns((prev) => {
					const merged = [...prev];
					list.forEach((d) => {
						if (!merged.some((m) => m.toUpperCase() === d.toUpperCase())) merged.push(d);
					});
					return merged;
				});
			}
			setStatus(userToEdit.status || "AKTIF");
			setPassword("");
		} else {
			setUsername("");
			setName("");
			setNip("");
			setEmail("");
			setPhone("");
			setRole("KOLEKTOR");
			setSelectedDesaId(isGlobalSuperAdmin ? "" : authUser?.desa_id ? String(authUser.desa_id) : "");
			setSelectedDusuns(["ALL"]);
			setStatus("AKTIF");
			setPassword("");
		}
	}, [
		userToEdit,
		open,
		isGlobalSuperAdmin,
		authUser?.desa_id
	]);
	const handleAddCustomDusun = () => {
		const trimmed = newDusunInput.trim().toUpperCase();
		if (!trimmed) return;
		if (!availableDusuns.some((d) => d.toUpperCase() === trimmed)) setAvailableDusuns((prev) => [...prev, trimmed]);
		if (selectedDusuns.includes("ALL")) setSelectedDusuns([trimmed]);
		else if (!selectedDusuns.includes(trimmed)) setSelectedDusuns((prev) => [...prev, trimmed]);
		setNewDusunInput("");
	};
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!username.trim() || !name.trim()) return;
		setIsSubmitting(true);
		setErrorMessage(null);
		const dusunAssignedStr = selectedDusuns.includes("ALL") || availableDusuns.length > 0 && selectedDusuns.length === availableDusuns.length ? "ALL" : selectedDusuns.join(", ");
		const desaIdPayload = selectedDesaId ? Number(selectedDesaId) : null;
		try {
			if (isEditing && userToEdit) {
				await updateUserAsync(userToEdit.id, {
					username,
					name,
					nip: nip || void 0,
					email: email || void 0,
					phone: phone || void 0,
					role,
					dusunAssigned: role === "KOLEKTOR" ? dusunAssignedStr : void 0,
					status,
					password: password.trim() || void 0,
					desa_id: isGlobalSuperAdmin ? desaIdPayload : void 0
				});
				if (onSuccessMessage) onSuccessMessage(`Pengguna "${name}" berhasil diperbarui.`);
			} else {
				await addUserAsync({
					username,
					name,
					nip: nip || void 0,
					email: email || void 0,
					phone: phone || void 0,
					role,
					dusunAssigned: role === "KOLEKTOR" ? dusunAssignedStr : void 0,
					status,
					password: password.trim() || "password123",
					desa_id: isGlobalSuperAdmin ? desaIdPayload : void 0
				});
				if (onSuccessMessage) onSuccessMessage(`Pengguna baru "${name}" berhasil ditambahkan.`);
			}
			onOpenChange(false);
		} catch (err) {
			console.error("Gagal menyimpan pengguna:", err);
			setErrorMessage(err?.response?.data?.message || err?.message || "Terjadi kesalahan saat menyimpan data pengguna.");
		} finally {
			setIsSubmitting(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-xl max-h-[90vh] overflow-y-auto bg-card border-border shadow-2xl rounded-2xl p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-2.5 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20",
						children: isEditing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "text-lg font-extrabold text-foreground",
						children: isEditing ? "Edit Akun Pengguna" : "Tambah Pengguna Baru"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-xs text-muted-foreground",
						children: isEditing ? "Perbarui informasi profil dan penugasan peran (RBAC) pengguna." : "Daftarkan akun pengguna baru untuk mengelola operasional SIPABAR."
					})] })]
				}) }),
				errorMessage && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 text-xs font-semibold",
					children: errorMessage
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleSubmit,
					className: "space-y-4 my-2",
					children: [
						isGlobalSuperAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3.5 rounded-xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 space-y-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
									className: "text-xs font-bold text-foreground flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4 text-emerald-500" }), " Penugasan Wilayah Desa (Multi-Tenant)"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: selectedDesaId,
									onChange: (e) => setSelectedDesaId(e.target.value),
									className: "w-full bg-background border border-input rounded-xl text-xs font-semibold p-2.5 text-foreground focus:ring-2 focus:ring-emerald-500",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "-- Super Admin System (Global / Tanpa Desa) --"
									}), desasList.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: d.id,
										children: [
											d.nama_desa,
											" (",
											d.kode_desa,
											") - Subdomain: ",
											d.subdomain
										]
									}, d.id))]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-muted-foreground",
									children: "Super Admin System dapat menugaskan pengguna ke desa tertentu atau membiarkannya sebagai Global Admin."
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 text-xs font-medium flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4 text-emerald-500 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"Pengguna ini akan secara otomatis terdaftar untuk ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: authUser?.desa?.nama_desa || "Desa Anda" }),
								"."
							] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
										className: "text-xs font-bold text-foreground flex items-center gap-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hash, { className: "size-3.5 text-emerald-500" }),
											" Username ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-rose-500",
												children: "*"
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										required: true,
										value: username,
										onChange: (e) => setUsername(e.target.value),
										placeholder: "cth: kolektor.balok",
										className: "bg-background border-input text-xs font-mono rounded-xl focus-visible:ring-emerald-500"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
										className: "text-xs font-bold text-foreground flex items-center gap-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-3.5 text-emerald-500" }),
											" Nama Lengkap ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-rose-500",
												children: "*"
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										required: true,
										value: name,
										onChange: (e) => setName(e.target.value),
										placeholder: "cth: Deden Sudrajat",
										className: "bg-background border-input text-xs rounded-xl focus-visible:ring-emerald-500"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
										className: "text-xs font-bold text-foreground flex items-center gap-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5 text-amber-500" }),
											" ",
											isEditing ? "Password Baru (Opsional)" : "Password Awal"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "password",
										value: password,
										onChange: (e) => setPassword(e.target.value),
										placeholder: isEditing ? "Biarkan kosong jika tidak diubah" : "Bawaan: password123",
										className: "bg-background border-input text-xs rounded-xl focus-visible:ring-emerald-500"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-xs font-bold text-foreground",
										children: "NIP / NIK (Opsional)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: nip,
										onChange: (e) => setNip(e.target.value),
										placeholder: "cth: 19880512 201201 1 004",
										className: "bg-background border-input text-xs font-mono rounded-xl focus-visible:ring-emerald-500"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
										className: "text-xs font-bold text-foreground flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-3.5 text-muted-foreground" }), " Email"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "email",
										value: email,
										onChange: (e) => setEmail(e.target.value),
										placeholder: "cth: user@desa.id",
										className: "bg-background border-input text-xs rounded-xl focus-visible:ring-emerald-500"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
										className: "text-xs font-bold text-foreground flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3.5 text-muted-foreground" }), " No. Handphone / WA"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: phone,
										onChange: (e) => setPhone(e.target.value),
										placeholder: "cth: 081234567890",
										className: "bg-background border-input text-xs font-mono rounded-xl focus-visible:ring-emerald-500"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2 pt-2 border-t border-border",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
								className: "text-xs font-bold text-foreground flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-4 text-purple-500" }),
									" Peran & Hak Akses (Role RBAC) ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-rose-500",
										children: "*"
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
								children: Object.keys(ROLE_LABELS).filter((rKey) => isGlobalSuperAdmin || rKey !== "SUPER_ADMIN_SYSTEM").map((rKey) => {
									const info = ROLE_LABELS[rKey];
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setRole(rKey),
										className: `flex flex-col text-left p-3 rounded-xl border transition-all ${role === rKey ? "bg-emerald-500/10 border-emerald-500 dark:border-emerald-400 ring-1 ring-emerald-500" : "bg-background border-input hover:border-muted-foreground/40"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-extrabold text-foreground",
											children: info.label
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-muted-foreground line-clamp-2 mt-0.5 font-medium",
											children: info.description
										})]
									}, rKey);
								})
							})]
						}),
						role === "KOLEKTOR" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2.5 p-3.5 rounded-xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
										className: "text-xs font-bold text-foreground flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5 text-emerald-500" }), " Dusun Penugasan Kolektor (Multi-Dusun Scope)"]
									}), isLoadingDusuns && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[10px] text-muted-foreground flex items-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3 animate-spin text-emerald-500" }), " Memuat dusun..."]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-2 pt-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setSelectedDusuns(["ALL"]),
										className: `px-3 py-1 rounded-lg text-xs font-bold border transition ${selectedDusuns.includes("ALL") ? "bg-emerald-600 text-white border-emerald-600 shadow-sm" : "bg-background border-input text-foreground hover:bg-muted"}`,
										children: "Semua Dusun (ALL)"
									}), availableDusuns.map((dName) => {
										const isChecked = selectedDusuns.includes(dName);
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => {
												if (selectedDusuns.includes("ALL")) setSelectedDusuns([dName]);
												else if (isChecked) {
													const next = selectedDusuns.filter((d) => d !== dName);
													setSelectedDusuns(next.length === 0 ? ["ALL"] : next);
												} else setSelectedDusuns([...selectedDusuns, dName]);
											},
											className: `px-3 py-1 rounded-lg text-xs font-bold border transition ${isChecked && !selectedDusuns.includes("ALL") ? "bg-emerald-600 text-white border-emerald-600 shadow-sm" : "bg-background border-input text-foreground hover:bg-muted"}`,
											children: ["Dusun ", dName]
										}, dName);
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: newDusunInput,
										onChange: (e) => setNewDusunInput(e.target.value),
										onKeyDown: (e) => {
											if (e.key === "Enter") {
												e.preventDefault();
												handleAddCustomDusun();
											}
										},
										placeholder: "Tambah nama dusun baru (cth: DUSUN I)...",
										className: "bg-background text-xs h-8 rounded-lg"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "button",
										size: "sm",
										variant: "outline",
										onClick: handleAddCustomDusun,
										disabled: !newDusunInput.trim(),
										className: "h-8 px-2.5 text-xs font-bold shrink-0 rounded-lg text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 dark:hover:bg-emerald-950/30",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5 mr-1" }), " Tambah"]
									})]
								}),
								availableDusuns.length === 0 && !isLoadingDusuns && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-amber-600 dark:text-amber-400 font-medium",
									children: "💡 Belum ada riwayat DHKP di desa ini. Anda dapat menambahkan nama dusun manual di atas atau memilih Semua Dusun (ALL)."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
							className: "pt-3 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								onClick: () => onOpenChange(false),
								disabled: isSubmitting,
								className: "rounded-xl text-xs font-bold",
								children: "Batal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: isSubmitting,
								className: "bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-600/20 px-5",
								children: isSubmitting ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 mr-2 animate-spin" }), " Menyimpan..."] }) : isEditing ? "Simpan Perubahan" : "Tambah Pengguna"
							})]
						})
					]
				})
			]
		})
	});
}
function UserManagementTab() {
	const { users, toggleUserStatusAsync, deleteUserAsync, resetPasswordAsync, activeUserId, setActiveUser, isLoading, refreshFromApi } = useUserStore();
	const { user: authUser } = useAuthStore();
	const isGlobalSuperAdmin = authUser?.role === "SUPER_ADMIN_SYSTEM" || !authUser?.desa_id;
	const [desasList, setDesasList] = (0, import_react.useState)([]);
	const [desaFilter, setDesaFilter] = (0, import_react.useState)("ALL");
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [roleFilter, setRoleFilter] = (0, import_react.useState)("SEMUA");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("SEMUA");
	const [viewMode, setViewMode] = (0, import_react.useState)("table");
	const [isModalOpen, setIsModalOpen] = (0, import_react.useState)(false);
	const [userToEdit, setUserToEdit] = (0, import_react.useState)(null);
	const [userToDelete, setUserToDelete] = (0, import_react.useState)(null);
	const [isDeleting, setIsDeleting] = (0, import_react.useState)(false);
	const [actionNotice, setActionNotice] = (0, import_react.useState)(null);
	const showToast = (message, type = "success") => {
		setActionNotice({
			message,
			type
		});
		setTimeout(() => setActionNotice(null), 5e3);
	};
	(0, import_react.useEffect)(() => {
		if (isGlobalSuperAdmin) desaService.getAll().then((res) => {
			if (res.data) setDesasList(res.data);
		}).catch((err) => console.error("Gagal memuat list desa:", err));
	}, [isGlobalSuperAdmin]);
	const handleDesaFilterChange = (val) => {
		setDesaFilter(val);
		refreshFromApi({ desa_id: val });
	};
	const filteredUsers = (0, import_react.useMemo)(() => {
		return users.filter((u) => {
			const matchSearch = u.name.toLowerCase().includes(searchQuery.toLowerCase()) || u.username.toLowerCase().includes(searchQuery.toLowerCase()) || u.email && u.email.toLowerCase().includes(searchQuery.toLowerCase()) || u.nip && u.nip.includes(searchQuery);
			const matchRole = roleFilter === "SEMUA" || u.role === roleFilter;
			const matchStatus = statusFilter === "SEMUA" || u.status === statusFilter;
			const matchDesa = desaFilter === "ALL" || (desaFilter === "SYSTEM" ? !u.desa_id : String(u.desa_id) === desaFilter);
			return matchSearch && matchRole && matchStatus && matchDesa;
		});
	}, [
		users,
		searchQuery,
		roleFilter,
		statusFilter,
		desaFilter
	]);
	const totalUsers = users.length;
	const adminCount = users.filter((u) => u.role === "SUPER_ADMIN_SYSTEM" || u.role === "SUPER_ADMIN" || u.role === "BENDAHARA").length;
	const kolektorCount = users.filter((u) => u.role === "KOLEKTOR").length;
	const activeCount = users.filter((u) => u.status === "AKTIF").length;
	const handleOpenAdd = () => {
		setUserToEdit(null);
		setIsModalOpen(true);
	};
	const handleOpenEdit = (user) => {
		setUserToEdit(user);
		setIsModalOpen(true);
	};
	const handleToggleStatus = async (user) => {
		try {
			await toggleUserStatusAsync(user.id);
			showToast(`Status pengguna "${user.name}" berhasil diubah.`, "success");
		} catch (err) {
			showToast(err?.message || "Gagal mengubah status pengguna.", "amber");
		}
	};
	const handleResetPassword = async (user) => {
		try {
			await resetPasswordAsync(user.id, "password123");
			showToast(`Password pengguna "${user.name}" di-reset ke "password123".`, "info");
		} catch (err) {
			showToast(err?.message || "Gagal reset password pengguna.", "amber");
		}
	};
	const handleDeleteUser = async () => {
		if (!userToDelete) return;
		setIsDeleting(true);
		try {
			await deleteUserAsync(userToDelete.id);
			showToast(`Pengguna "${userToDelete.name}" berhasil dihapus.`, "success");
			setUserToDelete(null);
		} catch (err) {
			showToast(err?.message || "Gagal menghapus pengguna.", "amber");
		} finally {
			setIsDeleting(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			actionNotice && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `p-4 rounded-2xl border text-xs font-semibold flex items-center justify-between shadow-lg animate-in fade-in duration-200 ${actionNotice.type === "success" ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-300" : actionNotice.type === "amber" ? "bg-amber-500/10 border-amber-500/30 text-amber-600 dark:text-amber-300" : "bg-blue-500/10 border-blue-500/30 text-blue-600 dark:text-blue-300"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 shrink-0 text-emerald-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: actionNotice.message })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setActionNotice(null),
					className: "text-muted-foreground hover:text-foreground text-xs font-mono ml-4",
					children: "✕"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-4 shadow-sm hover:shadow-md transition-shadow",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-bold text-muted-foreground uppercase tracking-wider",
									children: "Total Pengguna"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-8 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400 grid place-items-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xl font-black text-foreground mt-2 font-mono",
								children: totalUsers
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-muted-foreground mt-1 font-medium",
								children: "Terdaftar di database API"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-4 shadow-sm hover:shadow-md transition-shadow",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-bold text-muted-foreground uppercase tracking-wider",
									children: "Admin Desa"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-8 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 grid place-items-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xl font-black text-foreground mt-2 font-mono",
								children: adminCount
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-muted-foreground mt-1 font-medium",
								children: "Pengelola keuangan & sistem"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-4 shadow-sm hover:shadow-md transition-shadow",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-bold text-muted-foreground uppercase tracking-wider",
									children: "Kolektor Pajak"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-8 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 grid place-items-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xl font-black text-foreground mt-2 font-mono",
								children: kolektorCount
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] text-muted-foreground mt-1 font-medium",
								children: "Petugas penagih & kasir dusun"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-4 shadow-sm hover:shadow-md transition-shadow",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-bold text-muted-foreground uppercase tracking-wider",
									children: "Status Aktif"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-8 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 grid place-items-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-2xl font-black text-foreground mt-2 font-mono",
								children: [
									activeCount,
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs text-muted-foreground font-normal",
										children: ["/ ", totalUsers]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[10px] text-emerald-600 dark:text-emerald-400 mt-1 font-bold",
								children: [Math.round(activeCount / (totalUsers || 1) * 100), "% Pengguna Siap Bertugas"]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl border border-border bg-card p-4 shadow-sm space-y-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: searchQuery,
							onChange: (e) => setSearchQuery(e.target.value),
							placeholder: "Cari pengguna berdasarkan nama, username, NIP, atau email...",
							className: "pl-9 bg-background border-input text-xs rounded-xl focus-visible:ring-emerald-500"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							isGlobalSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: desaFilter,
								onChange: (e) => handleDesaFilterChange(e.target.value),
								className: "bg-background border border-emerald-500/40 text-xs font-bold rounded-xl px-3 py-2 text-emerald-700 dark:text-emerald-300 focus:ring-emerald-500",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "ALL",
										children: "🌐 Semua Desa (Global)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "SYSTEM",
										children: "🛡️ Super Admin System Only"
									}),
									desasList.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: d.id,
										children: [
											"🏛️ ",
											d.nama_desa,
											" (",
											d.kode_desa,
											")"
										]
									}, d.id))
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: roleFilter,
								onChange: (e) => setRoleFilter(e.target.value),
								className: "bg-background border border-input text-xs font-semibold rounded-xl px-3 py-2 focus:ring-emerald-500",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "SEMUA",
										children: "Semua Peran (Role)"
									}),
									isGlobalSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "SUPER_ADMIN_SYSTEM",
										children: "Super Admin System"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "SUPER_ADMIN",
										children: "Admin Desa"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "KOLEKTOR",
										children: "Kolektor / Kasir"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "KEPALA_DESA",
										children: "Kepala Desa"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: statusFilter,
								onChange: (e) => setStatusFilter(e.target.value),
								className: "bg-background border border-input text-xs font-semibold rounded-xl px-3 py-2 focus:ring-emerald-500",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "SEMUA",
										children: "Semua Status"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "AKTIF",
										children: "Status: Aktif"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "NONAKTIF",
										children: "Status: Nonaktif"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => refreshFromApi({ desa_id: desaFilter }),
								disabled: isLoading,
								className: "p-2 border border-input rounded-xl bg-background text-muted-foreground hover:text-foreground transition-colors",
								title: "Refresh Data dari API Backend",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `size-4 ${isLoading ? "animate-spin text-emerald-500" : ""}` })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center border border-input rounded-xl p-1 bg-background",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setViewMode("table"),
									className: `p-1.5 rounded-lg transition-colors ${viewMode === "table" ? "bg-muted text-foreground" : "text-muted-foreground hover:text-foreground"}`,
									title: "Mode Tabel",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, { className: "size-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setViewMode("cards"),
									className: `p-1.5 rounded-lg transition-colors ${viewMode === "cards" ? "bg-muted text-foreground" : "text-muted-foreground hover:text-foreground"}`,
									title: "Mode Kartu",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, { className: "size-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: handleOpenAdd,
								className: "bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-xl text-xs px-4 py-2 shadow-lg shadow-emerald-600/20",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-4 mr-1.5" }), " Tambah User"]
							})
						]
					})]
				})
			}),
			isLoading && filteredUsers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-border bg-card p-12 text-center text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-8 mx-auto mb-3 animate-spin text-emerald-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-bold text-sm",
					children: "Memuat data pengguna dari API Backend..."
				})]
			}) : viewMode === "table" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl border border-border bg-card shadow-sm overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-left border-collapse",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border bg-muted/40 text-[11px] font-extrabold uppercase tracking-wider text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 px-4",
									children: "Pengguna & NIP"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 px-4",
									children: "Peran & Wilayah Desa"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 px-4",
									children: "Kontak & Dusun"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 px-4",
									children: "Status Akun"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 px-4 text-center",
									children: "Simulasi Aktif"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-3 px-4 text-right",
									children: "Kelola Aksi"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-border text-xs",
							children: filteredUsers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								colSpan: 6,
								className: "py-12 text-center text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-10 mx-auto mb-2 opacity-30" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-bold",
										children: "Tidak ada pengguna yang ditemukan"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] mt-0.5",
										children: "Coba sesuaikan kata kunci pencarian atau filter peran."
									})
								]
							}) }) : filteredUsers.map((user) => {
								const roleInfo = ROLE_LABELS[user.role] || ROLE_LABELS.KOLEKTOR;
								const isCurrentActive = activeUserId === user.id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "hover:bg-muted/30 transition-colors",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-3.5 px-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: `size-9 rounded-xl bg-gradient-to-tr ${user.avatarBg || "from-slate-700 to-slate-900"} text-white font-bold grid place-items-center text-xs shadow-md shrink-0`,
													children: user.name.substring(0, 2).toUpperCase()
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "font-bold text-foreground flex items-center gap-1.5",
													children: [user.name, isCurrentActive && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[9px] bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 font-black px-1.5 py-0.5 rounded-md border border-emerald-500/30",
														children: "AKUN ANDA"
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-[11px] text-muted-foreground font-mono",
													children: [
														"@",
														user.username,
														" ",
														user.nip ? `• NIP: ${user.nip}` : ""
													]
												})] })]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-3.5 px-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `inline-block text-[10px] font-extrabold px-2.5 py-0.5 rounded-full border ${roleInfo.badgeClass}`,
													children: roleInfo.label
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-1 text-[11px] text-muted-foreground font-medium",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3 text-emerald-500" }), user.desa?.nama_desa ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20",
														children: ["Desa ", user.desa.nama_desa]
													}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: user.desa_id ? `Desa #${user.desa_id}` : "Global System Admin" })]
												})]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-3.5 px-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-0.5 text-[11px]",
												children: [
													user.email && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "text-muted-foreground flex items-center gap-1",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-3 text-muted-foreground/70" }),
															" ",
															user.email
														]
													}),
													user.phone && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "text-muted-foreground flex items-center gap-1 font-mono",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3 text-muted-foreground/70" }),
															" ",
															user.phone
														]
													}),
													user.role === "KOLEKTOR" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "text-[10px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1 mt-1",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3 text-emerald-500" }),
															" ",
															formatDusunDisplay(user.dusunAssigned)
														]
													})
												]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-3.5 px-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => handleToggleStatus(user),
												className: `inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-extrabold border transition-colors ${user.status === "AKTIF" ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30 hover:bg-rose-500/15 hover:text-rose-600 hover:border-rose-500/30" : "bg-rose-500/15 text-rose-600 dark:text-rose-400 border-rose-500/30 hover:bg-emerald-500/15 hover:text-emerald-600 hover:border-emerald-500/30"}`,
												title: "Klik untuk ubah status aktif/nonaktif",
												children: user.status === "AKTIF" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3" }), " AKTIF"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-3" }), " NONAKTIF"] })
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-3.5 px-4 text-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												onClick: () => {
													setActiveUser(user.id);
													showToast(`Simulasi login diubah ke akun "${user.name}" (${roleInfo.label}).`, "info");
												},
												variant: isCurrentActive ? "default" : "outline",
												size: "sm",
												className: `rounded-xl text-[10px] font-bold h-7 px-2.5 ${isCurrentActive ? "bg-emerald-600 hover:bg-emerald-700 text-white shadow-md" : "text-muted-foreground hover:text-foreground"}`,
												children: isCurrentActive ? "Sedang Aktif" : "Simulasi Login"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-3.5 px-4 text-right",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-end gap-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														onClick: () => handleResetPassword(user),
														className: "p-1.5 rounded-lg text-amber-500 hover:bg-amber-500/10 transition-colors",
														title: "Reset Password ke default (password123)",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-4" })
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														onClick: () => handleOpenEdit(user),
														className: "p-1.5 rounded-lg text-blue-500 hover:bg-blue-500/10 transition-colors",
														title: "Edit Pengguna",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pen, { className: "size-4" })
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														onClick: () => setUserToDelete(user),
														className: "p-1.5 rounded-lg text-rose-500 hover:bg-rose-500/10 transition-colors",
														title: "Hapus Pengguna",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
													})
												]
											})
										})
									]
								}, user.id);
							})
						})]
					})
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
				children: filteredUsers.map((user) => {
					const roleInfo = ROLE_LABELS[user.role] || ROLE_LABELS.KOLEKTOR;
					const isCurrentActive = activeUserId === user.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `rounded-2xl border bg-card p-5 shadow-sm space-y-4 hover:shadow-md transition-all relative ${isCurrentActive ? "border-emerald-500 ring-1 ring-emerald-500/50" : "border-border"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `size-11 rounded-2xl bg-gradient-to-tr ${user.avatarBg || "from-slate-700 to-slate-900"} text-white font-bold grid place-items-center text-xs shadow-md shrink-0`,
										children: user.name.substring(0, 2).toUpperCase()
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "font-extrabold text-sm text-foreground leading-tight flex items-center gap-1.5",
										children: user.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[11px] text-muted-foreground font-mono",
										children: ["@", user.username]
									})] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `text-[10px] font-extrabold px-2.5 py-0.5 rounded-full border ${roleInfo.badgeClass}`,
									children: roleInfo.label
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3 rounded-xl bg-muted/40 text-xs space-y-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-muted-foreground flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5 text-slate-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-bold text-foreground",
											children: user.desa?.nama_desa || (user.desa_id ? `Desa #${user.desa_id}` : "Global System Admin")
										})]
									}),
									user.nip && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-muted-foreground font-mono",
										children: ["NIP: ", user.nip]
									}),
									user.email && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-muted-foreground",
										children: user.email
									}),
									user.phone && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-muted-foreground font-mono",
										children: user.phone
									}),
									user.role === "KOLEKTOR" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[11px] font-bold text-emerald-600 dark:text-emerald-400 pt-1",
										children: ["Dusun: ", formatDusunDisplay(user.dusunAssigned)]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between pt-2 border-t border-border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => handleToggleStatus(user),
									className: `inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold border ${user.status === "AKTIF" ? "bg-emerald-500/15 text-emerald-600 border-emerald-500/30" : "bg-rose-500/15 text-rose-600 border-rose-500/30"}`,
									children: user.status === "AKTIF" ? "AKTIF" : "NONAKTIF"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											onClick: () => {
												setActiveUser(user.id);
												showToast(`Simulasi login diubah ke akun "${user.name}".`, "info");
											},
											size: "sm",
											variant: isCurrentActive ? "default" : "outline",
											className: "rounded-xl text-[10px] font-bold h-7 px-2.5",
											children: isCurrentActive ? "Aktif" : "Simulasi"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => handleOpenEdit(user),
											className: "p-1.5 rounded-lg text-blue-500 hover:bg-blue-500/10",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pen, { className: "size-4" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => setUserToDelete(user),
											className: "p-1.5 rounded-lg text-rose-500 hover:bg-rose-500/10",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
										})
									]
								})]
							})
						]
					}, user.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserModal, {
				open: isModalOpen,
				onOpenChange: setIsModalOpen,
				userToEdit,
				onSuccessMessage: (msg) => showToast(msg, "success")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: !!userToDelete,
				onOpenChange: (open) => !open && setUserToDelete(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, {
					className: "rounded-2xl max-w-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogTitle, {
						className: "text-base font-extrabold text-foreground",
						children: [
							"Hapus Pengguna \"",
							userToDelete?.name,
							"\"?"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, {
						className: "text-xs text-muted-foreground",
						children: "Tindakan ini akan menghapus akun pengguna secara permanen dari basis data Laravel. Pengguna tidak akan dapat melakukan login lagi."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, {
						className: "gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
							disabled: isDeleting,
							className: "rounded-xl text-xs font-bold",
							children: "Batal"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
							onClick: (e) => {
								e.preventDefault();
								handleDeleteUser();
							},
							disabled: isDeleting,
							className: "bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold",
							children: isDeleting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin mr-1" }) : "Ya, Hapus Permanen"
						})]
					})]
				})
			})
		]
	});
}
function DesaModal({ isOpen, onClose, onSuccess, desaToEdit }) {
	const isEditing = !!desaToEdit;
	const [formData, setFormData] = (0, import_react.useState)({
		kode_desa: "",
		nama_desa: "",
		nama_kecamatan: "Malangbong",
		nama_kabupaten: "Garut",
		nama_provinsi: "Jawa Barat",
		nama_kades: "",
		nip_kades: "",
		subdomain: "",
		admin_password: "admin123",
		default_password: "password123"
	});
	const [isSubmitting, setIsSubmitting] = (0, import_react.useState)(false);
	const [errorMsg, setErrorMsg] = (0, import_react.useState)(null);
	const [createdResult, setCreatedResult] = (0, import_react.useState)(null);
	const [copiedIndex, setCopiedIndex] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (desaToEdit) setFormData({
			kode_desa: desaToEdit.kode_desa || "",
			nama_desa: desaToEdit.nama_desa || "",
			nama_kecamatan: desaToEdit.nama_kecamatan || "Malangbong",
			nama_kabupaten: desaToEdit.nama_kabupaten || "Garut",
			nama_provinsi: desaToEdit.nama_provinsi || "Jawa Barat",
			nama_kades: desaToEdit.nama_kades || "",
			nip_kades: desaToEdit.nip_kades || "",
			subdomain: desaToEdit.subdomain || "",
			admin_password: "",
			default_password: ""
		});
		else setFormData({
			kode_desa: "",
			nama_desa: "",
			nama_kecamatan: "Malangbong",
			nama_kabupaten: "Garut",
			nama_provinsi: "Jawa Barat",
			nama_kades: "",
			nip_kades: "",
			subdomain: "",
			admin_password: "admin123",
			default_password: "password123"
		});
		setErrorMsg(null);
		setCreatedResult(null);
	}, [desaToEdit, isOpen]);
	if (!isOpen) return null;
	const handleNamaDesaChange = (val) => {
		const slug = val.toLowerCase().replace(/^desa\s+/, "").replace(/[^a-z0-9]/g, "");
		setFormData((prev) => ({
			...prev,
			nama_desa: val,
			subdomain: prev.subdomain && isEditing ? prev.subdomain : slug
		}));
	};
	const handleSubmit = async (e) => {
		e.preventDefault();
		setIsSubmitting(true);
		setErrorMsg(null);
		try {
			if (isEditing && desaToEdit) {
				await desaService.update(desaToEdit.id, formData);
				onSuccess(`Data Desa ${formData.nama_desa} berhasil diperbarui.`);
				onClose();
			} else {
				const res = await desaService.create(formData);
				if (res.data && res.data.created_users) {
					setCreatedResult(res.data);
					onSuccess(`Desa ${formData.nama_desa} & 4 akun pengguna berhasil dibuat!`);
				} else onClose();
			}
		} catch (err) {
			setErrorMsg(err?.message || "Gagal menyimpan data Desa. Silakan periksa kembali formulir.");
		} finally {
			setIsSubmitting(false);
		}
	};
	const copyToClipboard = (text, index) => {
		navigator.clipboard.writeText(text);
		setCopiedIndex(index);
		setTimeout(() => setCopiedIndex(null), 2500);
	};
	const copyAllCredentials = () => {
		if (!createdResult) return;
		const text = createdResult.created_users.map((u) => `📌 ${u.name} (${u.role})\n   Username: ${u.username}\n   Password: ${u.plain_password}`).join("\n\n");
		navigator.clipboard.writeText(`🏛️ KREDENSIAL PENGGUNA TERDAFTAR - ${createdResult.desa.nama_desa.toUpperCase()}\n\n${text}`);
		setCopiedIndex(999);
		setTimeout(() => setCopiedIndex(null), 2500);
	};
	if (createdResult) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-md grid place-items-center p-4 overflow-y-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-white dark:bg-slate-900 border border-emerald-500/30 rounded-3xl max-w-2xl w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-200",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 grid place-items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-6" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-extrabold text-slate-900 dark:text-white",
							children: "Desa & 4 Akun Berhasil Dibuat!"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-slate-500 dark:text-slate-400 font-medium",
							children: [
								createdResult.desa.nama_desa,
								" (",
								createdResult.desa.kode_desa,
								") - Subdomain:",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("code", {
									className: "text-emerald-600 font-mono font-bold",
									children: [createdResult.desa.subdomain, ".lentera.id"]
								})
							]
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onClose,
						className: "p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-800 dark:text-emerald-300 text-xs flex items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5 shrink-0 text-emerald-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: "Sistem telah men-generate 4 akun default (Admin, Bendahara, Kolektor, Kades) secara otomatis."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						onClick: copyAllCredentials,
						variant: "outline",
						size: "sm",
						className: "bg-white dark:bg-slate-800 border-emerald-500/40 text-emerald-700 dark:text-emerald-300 text-xs font-bold shrink-0 hover:bg-emerald-50",
						children: copiedIndex === 999 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5 mr-1 text-emerald-600" }), " Tersalin Semua"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5 mr-1" }), " Salin Semua"] })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-3",
					children: createdResult.created_users.map((u, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 space-y-2 relative group hover:border-emerald-500/50 transition",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] font-black uppercase px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30",
									children: u.role
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => copyToClipboard(`Nama: ${u.name}\nUsername: ${u.username}\nPassword: ${u.plain_password}`, idx),
									className: "p-1 rounded-md hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition",
									title: "Salin Kredensial",
									children: copiedIndex === idx ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-emerald-500" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "text-sm font-extrabold text-slate-900 dark:text-white",
								children: u.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-slate-500 dark:text-slate-400",
								children: u.email
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pt-1 border-t border-slate-200 dark:border-slate-800 grid grid-cols-2 gap-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-slate-400 font-medium block",
									children: "Username"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
									className: "font-mono font-bold text-slate-800 dark:text-slate-200",
									children: u.username
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px] text-slate-400 font-medium block",
									children: "Password"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
									className: "font-mono font-bold text-emerald-600 dark:text-emerald-400",
									children: u.plain_password
								})] })]
							})
						]
					}, u.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-end pt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: onClose,
						className: "bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-6 rounded-xl shadow-lg shadow-emerald-600/20",
						children: "Selesai & Sempurna"
					})
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-md grid place-items-center p-4 overflow-y-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-6 animate-in fade-in zoom-in-95 duration-200 my-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-11 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 grid place-items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-6" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-extrabold text-slate-900 dark:text-white",
							children: isEditing ? "Edit Data Desa" : "Tambah Desa Baru (Multi-Tenant)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-500 dark:text-slate-400 font-medium",
							children: isEditing ? "Ubah informasi identitas dan kepala desa" : "Mendaftarkan desa baru & auto-generate 4 akun operasional"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onClose,
						className: "p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				errorMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 text-xs font-medium flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: errorMsg })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleSubmit,
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 md:grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1",
								children: ["Kode Desa (10 Digit Kemendagri) ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-rose-500",
									children: "*"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								maxLength: 10,
								placeholder: "Contoh: 3205120005",
								value: formData.kode_desa,
								onChange: (e) => setFormData({
									...formData,
									kode_desa: e.target.value
								}),
								className: "font-mono text-sm"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1",
								children: ["Nama Desa ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-rose-500",
									children: "*"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								placeholder: "Contoh: Desa Cisitu",
								value: formData.nama_desa,
								onChange: (e) => handleNamaDesaChange(e.target.value),
								className: "text-sm font-semibold"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 md:grid-cols-3 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1",
									children: "Kecamatan"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "Malangbong",
									value: formData.nama_kecamatan,
									onChange: (e) => setFormData({
										...formData,
										nama_kecamatan: e.target.value
									}),
									className: "text-xs"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1",
									children: "Kabupaten"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "Garut",
									value: formData.nama_kabupaten,
									onChange: (e) => setFormData({
										...formData,
										nama_kabupaten: e.target.value
									}),
									className: "text-xs"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1",
									children: "Subdomain Slug"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "cisitu",
									value: formData.subdomain,
									onChange: (e) => setFormData({
										...formData,
										subdomain: e.target.value
									}),
									className: "text-xs font-mono"
								})] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-slate-100 dark:border-slate-800",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1",
								children: "Nama Kepala Desa"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "H. Adang Sutisna, S.IP",
								value: formData.nama_kades,
								onChange: (e) => setFormData({
									...formData,
									nama_kades: e.target.value
								}),
								className: "text-xs font-medium"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1",
								children: "NIP / NIPD Kepala Desa"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "19780512 200801 1 003",
								value: formData.nip_kades,
								onChange: (e) => setFormData({
									...formData,
									nip_kades: e.target.value
								}),
								className: "text-xs font-mono"
							})] })]
						}),
						!isEditing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-xs font-extrabold text-emerald-800 dark:text-emerald-300",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4 text-emerald-600" }), " Daftar Master Dusun Awal (Opsional)"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-slate-600 dark:text-slate-400",
									children: "Masukkan nama dusun-dusun di desa ini (pisahkan dengan koma). Desa baru akan langsung memiliki master dusun tanpa harus menunggu import DHKP."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "Contoh: DUSUN I, DUSUN II, DUSUN III",
									value: formData.dusuns || "",
									onChange: (e) => setFormData({
										...formData,
										dusuns: e.target.value
									}),
									className: "text-xs bg-white dark:bg-slate-900 border-emerald-300 dark:border-slate-800"
								})
							]
						}),
						!isEditing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-xs font-extrabold text-slate-900 dark:text-white",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-4 text-amber-500" }), " Setting Auto-Generate Password"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-slate-500 dark:text-slate-400",
									children: "Sistem akan secara otomatis membuat 4 akun operasional (Admin Desa, Bendahara, Kolektor, Kades)."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 md:grid-cols-2 gap-3 pt-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "text-[11px] font-bold text-slate-600 dark:text-slate-400 block mb-1",
										children: "Password Admin Desa"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "text",
										value: formData.admin_password,
										onChange: (e) => setFormData({
											...formData,
											admin_password: e.target.value
										}),
										className: "text-xs font-mono"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "text-[11px] font-bold text-slate-600 dark:text-slate-400 block mb-1",
										children: "Password Default (Bendahara/Kolektor/Kades)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "text",
										value: formData.default_password,
										onChange: (e) => setFormData({
											...formData,
											default_password: e.target.value
										}),
										className: "text-xs font-mono"
									})] })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								onClick: onClose,
								disabled: isSubmitting,
								className: "rounded-xl border-slate-300 dark:border-slate-700 text-xs font-bold",
								children: "Batal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: isSubmitting,
								className: "bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-600/20 px-5",
								children: isSubmitting ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 mr-2 animate-spin" }), " Menyimpan..."] }) : isEditing ? "Simpan Perubahan" : "Buat Desa & Generate 4 Akun"
							})]
						})
					]
				})
			]
		})
	});
}
function DusunManagementModal({ isOpen, onClose, desaId, desaName, onUpdated }) {
	const [dusuns, setDusuns] = (0, import_react.useState)([]);
	const [isLoading, setIsLoading] = (0, import_react.useState)(false);
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [isFormOpen, setIsFormOpen] = (0, import_react.useState)(false);
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const [formData, setFormData] = (0, import_react.useState)({
		nama_dusun: "",
		kode_dusun: "",
		rt_rw: "",
		status_aktif: true
	});
	const [isSubmitting, setIsSubmitting] = (0, import_react.useState)(false);
	const fetchDusuns = async () => {
		if (!isOpen) return;
		setIsLoading(true);
		try {
			const res = await dusunService.getAll({ desa_id: desaId || void 0 });
			if (res.data) setDusuns(res.data);
		} catch (err) {
			console.error("Gagal memuat master dusun:", err);
			toast.error("Gagal memuat data master dusun.");
		} finally {
			setIsLoading(false);
		}
	};
	(0, import_react.useEffect)(() => {
		if (isOpen) {
			fetchDusuns();
			resetForm();
		}
	}, [isOpen, desaId]);
	const resetForm = () => {
		setEditingId(null);
		setFormData({
			nama_dusun: "",
			kode_dusun: "",
			rt_rw: "",
			status_aktif: true
		});
		setIsFormOpen(false);
	};
	const handleOpenAdd = () => {
		resetForm();
		setIsFormOpen(true);
	};
	const handleOpenEdit = (item) => {
		setEditingId(item.id);
		setFormData({
			nama_dusun: item.nama_dusun,
			kode_dusun: item.kode_dusun || "",
			rt_rw: item.rt_rw || "",
			status_aktif: item.status_aktif
		});
		setIsFormOpen(true);
	};
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!formData.nama_dusun.trim()) {
			toast.error("Nama dusun wajib diisi.");
			return;
		}
		setIsSubmitting(true);
		try {
			if (editingId) {
				await dusunService.update(editingId, {
					nama_dusun: formData.nama_dusun.trim().toUpperCase(),
					kode_dusun: formData.kode_dusun?.trim() || void 0,
					rt_rw: formData.rt_rw?.trim() || void 0,
					status_aktif: formData.status_aktif
				});
				toast.success(`Dusun ${formData.nama_dusun} berhasil diperbarui.`);
			} else {
				await dusunService.create({
					desa_id: desaId || void 0,
					nama_dusun: formData.nama_dusun.trim().toUpperCase(),
					kode_dusun: formData.kode_dusun?.trim() || void 0,
					rt_rw: formData.rt_rw?.trim() || void 0,
					status_aktif: formData.status_aktif ?? true
				});
				toast.success(`Dusun ${formData.nama_dusun} berhasil ditambahkan.`);
			}
			resetForm();
			fetchDusuns();
			if (onUpdated) onUpdated();
		} catch (err) {
			toast.error(err?.message || "Gagal menyimpan data dusun.");
		} finally {
			setIsSubmitting(false);
		}
	};
	const handleToggleStatus = async (item) => {
		try {
			await dusunService.toggleStatus(item.id);
			toast.success(`Status dusun ${item.nama_dusun} diperbarui.`);
			fetchDusuns();
			if (onUpdated) onUpdated();
		} catch (err) {
			toast.error("Gagal mengubah status dusun.");
		}
	};
	const handleDelete = async (item) => {
		if (window.confirm(`Apakah Anda yakin ingin menghapus master dusun "${item.nama_dusun}"?`)) try {
			await dusunService.delete(item.id);
			toast.success(`Dusun ${item.nama_dusun} berhasil dihapus.`);
			fetchDusuns();
			if (onUpdated) onUpdated();
		} catch (err) {
			toast.error("Gagal menghapus dusun.");
		}
	};
	const filteredDusuns = dusuns.filter((d) => d.nama_dusun.toLowerCase().includes(searchQuery.toLowerCase()) || d.kode_dusun && d.kode_dusun.toLowerCase().includes(searchQuery.toLowerCase()) || d.rt_rw && d.rt_rw.toLowerCase().includes(searchQuery.toLowerCase()));
	if (!isOpen) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm animate-in fade-in duration-200",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative w-full max-w-2xl rounded-2xl border border-emerald-500/30 bg-white/95 dark:bg-slate-900/95 p-6 shadow-2xl backdrop-blur-xl text-slate-900 dark:text-slate-100 max-h-[90vh] flex flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-emerald-100 dark:border-slate-800 pb-4 mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-2.5 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-black text-slate-900 dark:text-slate-100",
							children: "Kelola Master Wilayah Dusun"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-slate-500 dark:text-slate-400",
							children: [desaName ? `Desa ${desaName}` : "Seluruh Wilayah Desa", " · Data mandiri tanpa tergantung file DHKP"]
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						onClick: onClose,
						className: "rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				isFormOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleSubmit,
					className: "mb-4 rounded-xl border border-emerald-200 dark:border-slate-800 bg-emerald-50/50 dark:bg-slate-950/50 p-4 space-y-3 animate-in slide-in-from-top-2 duration-200",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between border-b border-emerald-100 dark:border-slate-800 pb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-black uppercase tracking-wider text-emerald-800 dark:text-emerald-400",
								children: editingId ? "✏️ Edit Data Dusun" : "➕ Tambah Master Dusun Baru"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								size: "sm",
								onClick: resetForm,
								className: "h-6 px-2 text-[11px] text-slate-500 hover:text-slate-700",
								children: "Batal"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "sm:col-span-1 space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
										htmlFor: "nama_dusun",
										className: "text-xs font-bold",
										children: ["Nama Dusun ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-rose-500",
											children: "*"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "nama_dusun",
										value: formData.nama_dusun,
										onChange: (e) => setFormData((p) => ({
											...p,
											nama_dusun: e.target.value
										})),
										placeholder: "Contoh: DUSUN I",
										className: "bg-white dark:bg-slate-900 text-xs font-bold uppercase",
										required: true,
										autoFocus: true
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "kode_dusun",
										className: "text-xs font-bold",
										children: "Kode Wilayah"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "kode_dusun",
										value: formData.kode_dusun || "",
										onChange: (e) => setFormData((p) => ({
											...p,
											kode_dusun: e.target.value
										})),
										placeholder: "Contoh: 001 / RW 01",
										className: "bg-white dark:bg-slate-900 text-xs font-mono"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "rt_rw",
										className: "text-xs font-bold",
										children: "Cakupan RT/RW"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "rt_rw",
										value: formData.rt_rw || "",
										onChange: (e) => setFormData((p) => ({
											...p,
											rt_rw: e.target.value
										})),
										placeholder: "Contoh: RT 01-04 / RW 01",
										className: "bg-white dark:bg-slate-900 text-xs"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex justify-end gap-2 pt-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: isSubmitting,
								className: "bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-4 py-1.5 rounded-lg shadow-sm gap-1.5",
								children: isSubmitting ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }), " Menyimpan..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-3.5" }), " Simpan Dusun"] })
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 mb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-slate-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: searchQuery,
							onChange: (e) => setSearchQuery(e.target.value),
							placeholder: "Cari nama dusun, kode, atau RT/RW...",
							className: "pl-8 bg-white dark:bg-slate-950 text-xs h-9"
						})]
					}), !isFormOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						onClick: handleOpenAdd,
						className: "bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-3.5 h-9 rounded-xl shadow-sm gap-1.5 shrink-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), " Tambah Dusun"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 overflow-y-auto rounded-xl border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800",
					children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col items-center justify-center py-12 gap-2 text-slate-400",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-6 animate-spin text-emerald-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs",
							children: "Memuat master dusun..."
						})]
					}) : filteredDusuns.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col items-center justify-center py-12 px-4 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "p-3 rounded-full bg-emerald-50 dark:bg-slate-800 text-emerald-500 mb-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-6" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-bold text-slate-700 dark:text-slate-300",
								children: "Belum ada master dusun terdaftar"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-slate-400 mt-1 max-w-sm",
								children: "Tambahkan dusun secara manual agar bisa ditugaskan ke Kolektor dan menjadi referensi pelaporan PBB-P2."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								onClick: handleOpenAdd,
								variant: "outline",
								className: "mt-3 text-xs font-bold border-emerald-300 dark:border-slate-700 text-emerald-700 dark:text-emerald-300 gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), " Buat Dusun Pertama"]
							})
						]
					}) : filteredDusuns.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between p-3 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `size-2.5 rounded-full ${item.status_aktif ? "bg-emerald-500" : "bg-slate-400"}`,
								title: item.status_aktif ? "Aktif" : "Non-aktif"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-black uppercase text-slate-900 dark:text-slate-100",
										children: item.nama_dusun
									}),
									item.kode_dusun && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400",
										children: item.kode_dusun
									}),
									!item.status_aktif && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-100 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400",
										children: "Non-Aktif"
									})
								]
							}), item.rt_rw && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[11px] text-slate-500 dark:text-slate-400",
								children: ["Cakupan: ", item.rt_rw]
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									size: "sm",
									onClick: () => handleToggleStatus(item),
									title: item.status_aktif ? "Nonaktifkan" : "Aktifkan",
									className: `h-7 px-2 text-[11px] font-semibold ${item.status_aktif ? "text-slate-500 hover:text-rose-600" : "text-emerald-600 hover:text-emerald-700"}`,
									children: item.status_aktif ? "Nonaktifkan" : "Aktifkan"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									size: "icon",
									onClick: () => handleOpenEdit(item),
									className: "size-7 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200",
									title: "Edit Dusun",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pen, { className: "size-3.5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									size: "icon",
									onClick: () => handleDelete(item),
									className: "size-7 rounded-lg text-rose-400 hover:text-rose-600",
									title: "Hapus Dusun",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
								})
							]
						})]
					}, item.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-t border-slate-100 dark:border-slate-800 pt-3 mt-3 text-xs text-slate-400",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"Total ",
						dusuns.length,
						" Master Dusun terdaftar"
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						size: "sm",
						onClick: onClose,
						className: "text-xs font-bold",
						children: "Tutup"
					})]
				})
			]
		})
	});
}
function DesaManagementTab() {
	const [desas, setDesas] = (0, import_react.useState)([]);
	const [isLoading, setIsLoading] = (0, import_react.useState)(true);
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [isModalOpen, setIsModalOpen] = (0, import_react.useState)(false);
	const [desaToEdit, setDesaToEdit] = (0, import_react.useState)(null);
	const [desaToDelete, setDesaToDelete] = (0, import_react.useState)(null);
	const [isDeleting, setIsDeleting] = (0, import_react.useState)(false);
	const [selectedDesaDetail, setSelectedDesaDetail] = (0, import_react.useState)(null);
	const [selectedDesaForDusun, setSelectedDesaForDusun] = (0, import_react.useState)(null);
	const [notice, setNotice] = (0, import_react.useState)(null);
	const showToast = (message, type = "success") => {
		setNotice({
			message,
			type
		});
		setTimeout(() => setNotice(null), 5e3);
	};
	const fetchDesas = async () => {
		setIsLoading(true);
		try {
			const res = await desaService.getAll();
			if (res.data) setDesas(res.data);
		} catch (err) {
			console.error("[DesaManagementTab] Failed to load desas.", err);
		} finally {
			setIsLoading(false);
		}
	};
	(0, import_react.useEffect)(() => {
		fetchDesas();
	}, []);
	const filteredDesas = (0, import_react.useMemo)(() => {
		return desas.filter((d) => d.nama_desa.toLowerCase().includes(searchQuery.toLowerCase()) || d.kode_desa.includes(searchQuery) || d.subdomain.toLowerCase().includes(searchQuery.toLowerCase()) || d.nama_kades && d.nama_kades.toLowerCase().includes(searchQuery.toLowerCase()));
	}, [desas, searchQuery]);
	const handleOpenAdd = () => {
		setDesaToEdit(null);
		setIsModalOpen(true);
	};
	const handleOpenEdit = (desa) => {
		setDesaToEdit(desa);
		setIsModalOpen(true);
	};
	const handleToggleStatus = async (desa) => {
		try {
			await desaService.toggleStatus(desa.id);
			showToast(`Status Desa ${desa.nama_desa} berhasil diubah.`);
			fetchDesas();
		} catch (err) {
			showToast(err?.message || "Gagal mengubah status desa.", "amber");
		}
	};
	const handleDelete = async () => {
		if (!desaToDelete) return;
		setIsDeleting(true);
		try {
			await desaService.delete(desaToDelete.id);
			showToast(`Desa ${desaToDelete.nama_desa} berhasil dihapus.`);
			setDesaToDelete(null);
			fetchDesas();
		} catch (err) {
			showToast(err?.message || "Gagal menghapus desa.", "amber");
		} finally {
			setIsDeleting(false);
		}
	};
	const handleShowDetail = async (desa) => {
		try {
			const res = await desaService.getById(desa.id);
			if (res.data) setSelectedDesaDetail(res.data);
		} catch (err) {
			setSelectedDesaDetail(desa);
		}
	};
	const totalDesas = desas.length;
	const activeDesas = desas.filter((d) => d.status_aktif).length;
	const totalUsersInDesas = desas.reduce((acc, d) => acc + (d.users_count || 0), 0);
	const totalSpptInDesas = desas.reduce((acc, d) => acc + (d.dhkp_rows_count || 0), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `p-4 rounded-2xl border text-xs font-bold flex items-center justify-between shadow-lg animate-in fade-in duration-200 ${notice.type === "success" ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-700 dark:text-emerald-300" : "bg-amber-500/10 border-amber-500/30 text-amber-700 dark:text-amber-300"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 shrink-0 text-emerald-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: notice.message })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setNotice(null),
					className: "opacity-70 hover:opacity-100",
					children: "×"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-11 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 grid place-items-center shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider",
							children: "Total Desa Terdaftar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xl font-black text-slate-900 dark:text-white",
							children: totalDesas
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-11 rounded-xl bg-teal-500/10 text-teal-600 dark:text-teal-400 grid place-items-center shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider",
							children: "Desa Status Aktif"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xl font-black text-slate-900 dark:text-white",
							children: activeDesas
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-11 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 grid place-items-center shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider",
							children: "Total Akun Operasional"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xl font-black text-slate-900 dark:text-white",
							children: totalUsersInDesas
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-11 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 grid place-items-center shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider",
							children: "Total SPPT DHKP"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xl font-black text-slate-900 dark:text-white",
							children: totalSpptInDesas
						})] })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative w-full sm:w-80",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-4 text-slate-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "Cari desa, kode, subdomain, kades...",
						value: searchQuery,
						onChange: (e) => setSearchQuery(e.target.value),
						className: "pl-9 text-xs rounded-xl border-slate-200 dark:border-slate-800"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 w-full sm:w-auto justify-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: fetchDesas,
						variant: "outline",
						size: "sm",
						disabled: isLoading,
						className: "rounded-xl text-xs font-bold border-slate-200 dark:border-slate-800",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `size-3.5 mr-1.5 ${isLoading ? "animate-spin" : ""}` }), "Refresh"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: handleOpenAdd,
						className: "bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-lg shadow-emerald-600/20 px-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 mr-1.5" }), "Tambah Desa Baru"]
					})]
				})]
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-12 text-center space-y-3 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-8 animate-spin text-emerald-500 mx-auto" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-slate-500 font-bold",
					children: "Memuat Daftar Desa Multi-Tenant..."
				})]
			}) : filteredDesas.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-12 text-center space-y-3 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-12 text-slate-300 dark:text-slate-700 mx-auto" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-base font-extrabold text-slate-800 dark:text-white",
						children: "Desa Tidak Ditemukan"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto",
						children: [
							"Tidak ada data desa yang cocok dengan pencarian \"",
							searchQuery,
							"\". Tekan tombol Tambah Desa Baru di atas untuk mendaftarkan desa baru."
						]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
				children: filteredDesas.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-sm space-y-4 hover:border-emerald-500/40 hover:shadow-md transition relative group flex flex-col justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-12 rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-700 text-white font-black grid place-items-center text-sm shadow-md shrink-0",
										children: d.nama_desa.replace(/^desa\s+/i, "").substring(0, 2).toUpperCase()
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-base font-extrabold text-slate-900 dark:text-white leading-snug",
										children: d.nama_desa
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-slate-500 dark:text-slate-400 font-mono",
										children: ["Kode: ", d.kode_desa]
									})] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => handleToggleStatus(d),
									className: `px-2.5 py-1 rounded-full text-[10px] font-extrabold border transition ${d.status_aktif ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-400 hover:bg-rose-500/10 hover:border-rose-500/30 hover:text-rose-600" : "bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-500 hover:bg-emerald-500/10 hover:border-emerald-500/30 hover:text-emerald-600"}`,
									title: "Klik untuk ubah status aktif/non-aktif",
									children: d.status_aktif ? "AKTIF" : "NON-AKTIF"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5 text-xs border-t border-b border-slate-100 dark:border-slate-800/80 py-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between text-slate-600 dark:text-slate-400",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5 text-slate-400" }), " Wilayah"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-semibold text-slate-800 dark:text-slate-200",
											children: [
												"Kec. ",
												d.nama_kecamatan,
												", ",
												d.nama_kabupaten
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between text-slate-600 dark:text-slate-400",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-3.5 text-slate-400" }), " Subdomain"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("code", {
											className: "font-mono text-emerald-600 dark:text-emerald-400 font-bold",
											children: [d.subdomain, ".lentera.id"]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between text-slate-600 dark:text-slate-400",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-3.5 text-slate-400" }), " Kepala Desa"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-bold text-slate-800 dark:text-slate-200",
											children: d.nama_kades || "-"
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2 text-center pt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-2 rounded-xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-slate-400 font-bold uppercase block",
										children: "Akun User"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-sm font-black text-slate-800 dark:text-slate-200",
										children: [d.users_count || 0, " Pengguna"]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-2 rounded-xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-slate-400 font-bold uppercase block",
										children: "Data DHKP"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-sm font-black text-slate-800 dark:text-slate-200",
										children: [d.dhkp_rows_count || 0, " SPPT"]
									})]
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2 pt-4 border-t border-slate-100 dark:border-slate-800",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => handleShowDetail(d),
								variant: "outline",
								size: "sm",
								className: "rounded-xl text-[11px] font-bold border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-slate-800 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-3.5 mr-1" }), " Lihat User"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => setSelectedDesaForDusun(d),
								variant: "outline",
								size: "sm",
								className: "rounded-xl text-[11px] font-bold border-emerald-200 dark:border-slate-800 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-50 dark:hover:bg-slate-800 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5 mr-1 text-emerald-600" }), " Dusun"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => handleOpenEdit(d),
									className: "p-2 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition",
									title: "Edit Data Desa",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pen, { className: "size-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setDesaToDelete(d),
									className: "p-2 rounded-xl border border-rose-200 dark:border-rose-950 hover:bg-rose-50 dark:hover:bg-rose-950/50 text-rose-600 dark:text-rose-400 transition",
									title: "Hapus Desa",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
								})]
							})
						]
					})]
				}, d.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DesaModal, {
				isOpen: isModalOpen,
				onClose: () => setIsModalOpen(false),
				onSuccess: (msg) => {
					showToast(msg);
					fetchDesas();
				},
				desaToEdit
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DusunManagementModal, {
				isOpen: !!selectedDesaForDusun,
				onClose: () => setSelectedDesaForDusun(null),
				desaId: selectedDesaForDusun?.id,
				desaName: selectedDesaForDusun?.nama_desa,
				onUpdated: fetchDesas
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: !!desaToDelete,
				onOpenChange: (open) => !open && setDesaToDelete(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, {
					className: "rounded-3xl max-w-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, {
						className: "text-lg font-extrabold text-slate-900 dark:text-white",
						children: "Hapus Desa & Seluruh Penggunanya?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogDescription, {
						className: "text-xs text-slate-500 dark:text-slate-400",
						children: [
							"Apakah Anda yakin ingin menghapus ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: desaToDelete?.nama_desa }),
							"? Seluruh akun pengguna yang terhubung ke desa ini akan terhapus. Tindakan ini tidak dapat dibatalkan."
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, {
						className: "gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
							disabled: isDeleting,
							className: "rounded-xl text-xs font-bold",
							children: "Batal"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
							onClick: (e) => {
								e.preventDefault();
								handleDelete();
							},
							disabled: isDeleting,
							className: "bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold",
							children: isDeleting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin mr-1" }) : "Ya, Hapus Permanen"
						})]
					})]
				})
			}),
			selectedDesaDetail && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-md grid place-items-center p-4 overflow-y-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-2xl w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-200",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-11 rounded-2xl bg-emerald-500/10 text-emerald-600 grid place-items-center font-bold",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-base font-extrabold text-slate-900 dark:text-white",
									children: ["Daftar Pengguna - ", selectedDesaDetail.nama_desa]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-slate-500 dark:text-slate-400",
									children: [
										"Kode Desa: ",
										selectedDesaDetail.kode_desa,
										" | Total:",
										" ",
										selectedDesaDetail.users?.length || 0,
										" Akun"
									]
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setSelectedDesaDetail(null),
								className: "p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition",
								children: "×"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-2 max-h-96 overflow-y-auto pr-1",
							children: !selectedDesaDetail.users || selectedDesaDetail.users.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-slate-500 text-center py-6",
								children: "Belum ada akun pengguna terdaftar untuk desa ini."
							}) : selectedDesaDetail.users.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 flex items-center justify-between gap-3 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-9 rounded-xl bg-emerald-600 text-white font-bold grid place-items-center text-xs",
										children: u.name.substring(0, 2).toUpperCase()
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-extrabold text-slate-900 dark:text-white",
										children: u.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[11px] text-slate-500 dark:text-slate-400 font-mono",
										children: [
											u.username,
											" • ",
											u.email
										]
									})] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 text-[10px] font-black uppercase",
										children: u.role
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `size-2 rounded-full ${u.status_aktif ? "bg-emerald-500" : "bg-rose-500"}`,
										title: u.status_aktif ? "Status: Aktif" : "Status: Non-Aktif"
									})]
								})]
							}, u.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex justify-end pt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => setSelectedDesaDetail(null),
								variant: "outline",
								className: "rounded-xl text-xs font-bold",
								children: "Tutup"
							})
						})
					]
				})
			})
		]
	});
}
function UserManagementPage() {
	const { user: authUser } = useAuthStore();
	const { getActiveUser } = useUserStore();
	const activeUser = authUser || getActiveUser();
	const roleInfo = ROLE_LABELS[activeUser?.role || "SUPER_ADMIN"] || {
		label: "Super Admin",
		badgeClass: "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
	};
	const [activeTab, setActiveTab] = (0, import_react.useState)("users");
	const isRestricted = !(activeUser?.role === "SUPER_ADMIN" || activeUser?.role === "SUPER_ADMIN_SYSTEM" || !activeUser?.desa_id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 pb-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-emerald-500/30 dark:border-slate-800 bg-gradient-to-r from-emerald-700 via-emerald-600 to-teal-700 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 p-6 text-white shadow-xl relative overflow-hidden backdrop-blur-md",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute right-0 top-0 translate-x-4 -translate-y-4 opacity-10 pointer-events-none",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-64" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-white/15 dark:bg-emerald-500/10 border border-white/30 dark:border-emerald-500/30 text-emerald-50 dark:text-emerald-300 text-xs font-extrabold mb-2 backdrop-blur-md",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-3.5 text-amber-300" }), " Manajemen Multi-Desa & Pengguna (RBAC)"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-2xl font-black tracking-tight text-white",
								children: "Kelola Desa & Akun Pengguna"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-emerald-50 dark:text-slate-300 mt-1 max-w-2xl font-medium",
								children: "Kelola pendaftaran desa baru (Multi-Tenant), auto-generate 4 akun operasional per desa, serta kontrol hak akses pengguna."
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-white/30 dark:border-slate-700 bg-white/15 dark:bg-slate-800/80 p-3 backdrop-blur-md flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `size-10 rounded-xl bg-gradient-to-tr ${activeUser?.avatarBg || "from-emerald-600 to-teal-500"} text-white font-bold grid place-items-center text-xs shadow-md shrink-0`,
								children: (activeUser?.name || "AD").substring(0, 2).toUpperCase()
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-emerald-100 dark:text-slate-400 font-bold uppercase tracking-wider",
									children: "Pengguna Aktif Saat Ini"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-extrabold text-white",
									children: activeUser?.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `inline-block text-[9px] font-extrabold px-2 py-0.5 rounded-md border mt-0.5 ${roleInfo.badgeClass}`,
									children: roleInfo.label
								})
							] })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 flex items-center gap-2 pt-6 mt-6 border-t border-white/20 dark:border-slate-800",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setActiveTab("users"),
							className: `px-4 py-2 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${activeTab === "users" ? "bg-white text-emerald-800 shadow-md" : "bg-white/15 text-white hover:bg-white/25"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4" }), " Akun Pengguna Desa"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setActiveTab("desas"),
							className: `px-4 py-2 rounded-xl text-xs font-extrabold flex items-center gap-2 transition ${activeTab === "desas" ? "bg-white text-emerald-800 shadow-md" : "bg-white/15 text-white hover:bg-white/25"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4" }), " Kelola Desa Multi-Tenant"]
						})]
					})
				]
			}),
			isRestricted && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-300 text-xs font-medium flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-5 shrink-0 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-bold",
					children: [
						"Mode Terbatas (Akses Peran: ",
						roleInfo.label,
						")"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] opacity-90",
					children: [
						"Anda sedang melihat sistem sebagai ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: roleInfo.label }),
						". Perubahan pengguna dan pembuatan desa disarankan dilakukan oleh ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Super Admin" }),
						"."
					]
				})] })]
			}),
			activeTab === "users" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserManagementTab, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DesaManagementTab, {})
		]
	});
}
//#endregion
export { UserManagementPage as component };
