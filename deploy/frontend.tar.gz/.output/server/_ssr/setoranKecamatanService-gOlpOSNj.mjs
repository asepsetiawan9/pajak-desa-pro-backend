import { n as apiClient } from "./authStore-CZRDvP0Z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/setoranKecamatanService-gOlpOSNj.js
function mapBackendToFrontend(raw) {
	return {
		id: raw.id,
		desaId: raw.desa_id ?? raw.desa?.id,
		namaDesa: raw.desa?.nama_desa ?? "",
		kodeDesa: raw.desa?.kode_desa ?? "",
		namaKecamatan: raw.desa?.nama_kecamatan ?? "",
		nomorBukti: raw.nomor_bukti ?? "",
		kategori: raw.kategori ?? "SETOR_KECAMATAN",
		perluVerifikasiKecamatan: Boolean(raw.perlu_verifikasi_kecamatan ?? true),
		tanggalSetor: raw.tanggal_setor ?? "",
		tahun: Number(raw.tahun || 2026),
		nominal: Number(raw.nominal || 0),
		metodeSetoran: raw.metode_setoran ?? "TRANSFER",
		bankTujuan: raw.bank_tujuan ?? "",
		nomorReferensi: raw.nomor_referensi ?? "",
		penyetorNama: raw.penyetor_nama ?? "",
		penyetorJabatan: raw.penyetor_jabatan ?? "",
		penerimaKecamatan: raw.penerima_kecamatan ?? "",
		catatanDesa: raw.catatan_desa ?? "",
		buktiFile: raw.bukti_file ?? "",
		status: raw.status ?? "PENDING",
		tanggalDiterima: raw.tanggal_diterima ?? "",
		penerimaUserId: raw.penerima_user_id ?? void 0,
		penerimaNama: raw.penerima_user?.name ?? "",
		catatanKecamatan: raw.catatan_kecamatan ?? "",
		createdBy: raw.created_by ?? void 0,
		creatorNama: raw.creator?.name ?? "",
		createdAt: raw.created_at ?? "",
		updatedAt: raw.updated_at ?? ""
	};
}
function mapRekapDesaBackendToFrontend(raw) {
	return {
		desaId: raw.desa_id,
		namaDesa: raw.nama_desa ?? "",
		kodeDesa: raw.kode_desa ?? "",
		targetPbb: Number(raw.target_pbb || 0),
		realisasiPbb: Number(raw.realisasi_pbb || 0),
		totalDisetorDiterima: Number(raw.total_disetor_diterima || 0),
		totalPengeluaranInternal: Number(raw.total_pengeluaran_internal || 0),
		totalPengeluaranDesa: Number(raw.total_pengeluaran_desa || 0),
		totalDisetorPending: Number(raw.total_disetor_pending || 0),
		sisaKasDesa: Number(raw.sisa_kas_desa || 0),
		persentaseDisetor: Number(raw.persentase_disetor || 0),
		tanggalSetorTerakhir: raw.tanggal_setor_terakhir ?? void 0,
		statusTerakhir: raw.status_terakhir ?? void 0
	};
}
var setoranKecamatanService = {
	async getAll(params) {
		const res = await apiClient.get("/setoran-kecamatan", params);
		return {
			data: Array.isArray(res.data) ? res.data.map(mapBackendToFrontend) : [],
			pagination: res.pagination || res.meta
		};
	},
	async getSummary(params) {
		const rawData = (await apiClient.get("/setoran-kecamatan/summary", params)).data || {};
		return {
			totalDisetorkan: Number(rawData.total_disetorkan || 0),
			totalDiterima: Number(rawData.total_diterima || 0),
			totalPengeluaranInternal: Number(rawData.total_pengeluaran_internal || 0),
			totalPengeluaranDesa: Number(rawData.total_pengeluaran_desa || 0),
			totalPending: Number(rawData.total_pending || 0),
			totalDitolak: Number(rawData.total_ditolak || 0),
			totalRealisasiDesa: Number(rawData.total_realisasi_desa || 0),
			sisaKasDesa: Number(rawData.sisa_kas_desa || 0),
			counts: {
				total: Number(rawData.counts?.total || 0),
				diterima: Number(rawData.counts?.diterima || 0),
				pending: Number(rawData.counts?.pending || 0),
				ditolak: Number(rawData.counts?.ditolak || 0)
			},
			rekapPerDesa: Array.isArray(rawData.rekap_per_desa) ? rawData.rekap_per_desa.map(mapRekapDesaBackendToFrontend) : []
		};
	},
	async getPendingReviews(params) {
		const raw = (await apiClient.get("/setoran-kecamatan/pending-reviews", params)).data || {};
		return {
			roleContext: raw.role_context || "ADMIN_DESA",
			reviewLabel: raw.review_label || "Status Pengajuan Pengeluaran",
			needActionCount: Number(raw.need_action_count || 0),
			counts: {
				tambahEdit: Number(raw.counts?.tambah_edit || 0),
				permohonanHapus: Number(raw.counts?.permohonan_hapus || 0),
				ditolak: Number(raw.counts?.ditolak || 0),
				totalPending: Number(raw.counts?.total_pending || 0)
			},
			items: Array.isArray(raw.items) ? raw.items.map(mapBackendToFrontend) : []
		};
	},
	async getById(id) {
		return mapBackendToFrontend((await apiClient.get(`/setoran-kecamatan/${id}`)).data);
	},
	async create(payload) {
		const body = {
			tanggal_setor: payload.tanggalSetor,
			kategori: payload.kategori || "SETOR_KECAMATAN",
			tahun: payload.tahun || 2026,
			nominal: payload.nominal,
			metode_setoran: payload.metodeSetoran || "TRANSFER",
			bank_tujuan: payload.bankTujuan,
			nomor_referensi: payload.nomorReferensi,
			penyetor_nama: payload.penyetorNama,
			penyetor_jabatan: payload.penyetorJabatan,
			penerima_kecamatan: payload.penerimaKecamatan,
			catatan_desa: payload.catatanDesa,
			bukti_file: payload.buktiFile,
			desa_id: payload.desaId
		};
		return mapBackendToFrontend((await apiClient.post("/setoran-kecamatan", body)).data);
	},
	async update(id, payload) {
		const body = {
			tanggal_setor: payload.tanggalSetor,
			kategori: payload.kategori,
			tahun: payload.tahun,
			nominal: payload.nominal,
			metode_setoran: payload.metodeSetoran,
			bank_tujuan: payload.bankTujuan,
			nomor_referensi: payload.nomorReferensi,
			penyetor_nama: payload.penyetorNama,
			penyetor_jabatan: payload.penyetorJabatan,
			penerima_kecamatan: payload.penerimaKecamatan,
			catatan_desa: payload.catatanDesa,
			bukti_file: payload.buktiFile,
			desa_id: payload.desaId
		};
		return mapBackendToFrontend((await apiClient.put(`/setoran-kecamatan/${id}`, body)).data);
	},
	async verify(id, status, catatanKecamatan, tanggalDiterima) {
		const body = {
			status,
			catatan_kecamatan: catatanKecamatan,
			tanggal_diterima: tanggalDiterima || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10)
		};
		const res = await apiClient.post(`/setoran-kecamatan/${id}/verify`, body);
		return res.data ? mapBackendToFrontend(res.data) : null;
	},
	async delete(id) {
		const res = await apiClient.delete(`/setoran-kecamatan/${id}`);
		return {
			action: res.data?.action || "DELETED",
			is_deleted: res.data?.is_deleted ?? true,
			message: res.message || res.data?.message || "Data berhasil diproses.",
			setoran: res.data?.setoran ? mapBackendToFrontend(res.data.setoran) : void 0
		};
	}
};
//#endregion
export { setoranKecamatanService as t };
