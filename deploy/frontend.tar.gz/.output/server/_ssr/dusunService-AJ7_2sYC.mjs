import { n as apiClient } from "./authStore-CZRDvP0Z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dusunService-AJ7_2sYC.js
var dusunService = {
	/**
	* Mengambil daftar master dusun lengkap dengan filter desa/search
	*/
	async getAll(params) {
		const cleanParams = params && params.desa_id && (params.desa_id === "ALL" || params.desa_id === "all") ? {
			...params,
			desa_id: void 0
		} : params;
		return apiClient.get("dusuns", cleanParams);
	},
	/**
	* Mengambil daftar nama dusun (string array) untuk dropdown/selector
	*/
	async getByDesa(desaId) {
		const params = { format: "names" };
		if (desaId && desaId !== "ALL" && desaId !== "all") params.desa_id = desaId;
		return apiClient.get("dusun", params);
	},
	/**
	* Mengambil detail satu master dusun
	*/
	async getById(id) {
		return apiClient.get(`dusuns/${id}`);
	},
	/**
	* Membuat master dusun baru
	*/
	async create(payload) {
		return apiClient.post("dusuns", payload);
	},
	/**
	* Memperbarui data master dusun
	*/
	async update(id, payload) {
		return apiClient.put(`dusuns/${id}`, payload);
	},
	/**
	* Menghapus master dusun
	*/
	async delete(id) {
		return apiClient.delete(`dusuns/${id}`);
	},
	/**
	* Toggle status aktif master dusun
	*/
	async toggleStatus(id) {
		return apiClient.patch(`dusuns/${id}/toggle-status`);
	}
};
//#endregion
export { dusunService as t };
