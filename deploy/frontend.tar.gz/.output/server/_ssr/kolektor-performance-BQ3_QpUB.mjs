import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { a as useTenantStore, i as useAuthStore, n as apiClient, s as userService } from "./authStore-CZRDvP0Z.mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useSettingsStore } from "./settingsStore-BBOTJBY5.mjs";
import { Jt as Award, P as Plus, R as Pen, Rt as ChevronDown, U as Medal, Vt as ChartColumn, W as MapPin, Y as LoaderCircle, _ as Star, bt as Download, d as TrendingUp, dt as Flame, f as Trash2, ft as FileText, i as User, j as RefreshCw, l as Trophy, mt as FileSpreadsheet, n as Wallet, p as Target, r as Users } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-BnDjHZuV.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, o as formatRp, t as Card } from "./card-CfCIYh5x.mjs";
import { t as desaService } from "./desaService-B2uJrXze.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-HQswfJbV.mjs";
import { n as utils, r as writeFileSync } from "../_libs/xlsx.mjs";
import { n as DropdownMenuContent, o as DropdownMenuTrigger, r as DropdownMenuItem, t as DropdownMenu } from "./dropdown-menu-BXTy_n6Y.mjs";
import { t as Progress } from "./progress-D8ag4YZx.mjs";
import { a as Line, c as Cell, d as Legend, i as XAxis, l as ResponsiveContainer, n as LineChart, o as CartesianGrid, r as YAxis, s as Bar, t as BarChart, u as Tooltip } from "../_libs/recharts+[...].mjs";
import { t as require_jspdf_node_min } from "../_libs/jspdf.mjs";
import { t as autoTable } from "../_libs/jspdf-autotable.mjs";
import { t as Swal } from "../_libs/sweetalert2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kolektor-performance-BQ3_QpUB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_jspdf_node_min = /* @__PURE__ */ __toESM(require_jspdf_node_min());
/**
* Kolektor Target & Performance API Service Layer
* Interfaces frontend with backend Kolektor Target endpoints.
*/
var kolektorTargetService = {
	async listTargets(params) {
		const queryParams = {};
		if (params?.tahun) queryParams.tahun = params.tahun;
		if (params?.desa_id && params.desa_id !== "ALL") queryParams.desa_id = params.desa_id;
		return apiClient.get("/kolektor-targets", queryParams);
	},
	async getMyPerformance(tahun) {
		const queryParams = {};
		if (tahun) queryParams.tahun = tahun;
		return apiClient.get("/kolektor-targets/my-performance", queryParams);
	},
	async getLeaderboard(params) {
		const queryParams = {};
		if (params?.tahun) queryParams.tahun = params.tahun;
		if (params?.desa_id && params.desa_id !== "ALL") queryParams.desa_id = params.desa_id;
		return apiClient.get("/kolektor-targets/leaderboard", queryParams);
	},
	async setTarget(data) {
		return apiClient.post("/kolektor-targets", data);
	},
	async getKolektorDetail(kolektorId, tahun) {
		const queryParams = {};
		if (tahun) queryParams.tahun = tahun;
		return apiClient.get(`/kolektor-targets/${kolektorId}`, queryParams);
	},
	async getDusunBreakdown(kolektorId, tahun) {
		const queryParams = {};
		if (tahun) queryParams.tahun = tahun;
		return apiClient.get(`/kolektor-targets/${kolektorId}/dusun-breakdown`, queryParams);
	},
	async deleteTarget(id) {
		return apiClient.delete(`/kolektor-targets/${id}`);
	}
};
function useKolektorTargetStore() {
	const [targets, setTargets] = (0, import_react.useState)([]);
	const [leaderboard, setLeaderboard] = (0, import_react.useState)([]);
	const [selectedDetail, setSelectedDetail] = (0, import_react.useState)(null);
	const [isLoading, setIsLoading] = (0, import_react.useState)(false);
	const [isLeaderboardLoading, setIsLeaderboardLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	return {
		targets,
		leaderboard,
		selectedDetail,
		isLoading,
		isLeaderboardLoading,
		error,
		fetchTargets: (0, import_react.useCallback)(async (params) => {
			setIsLoading(true);
			setError(null);
			try {
				const res = await kolektorTargetService.listTargets(params);
				setTargets(Array.isArray(res.data) ? res.data : []);
			} catch (err) {
				console.error("Gagal memuat target kolektor:", err);
				setError(err.message || "Gagal memuat data target.");
			} finally {
				setIsLoading(false);
			}
		}, []),
		fetchLeaderboard: (0, import_react.useCallback)(async (params) => {
			setIsLeaderboardLoading(true);
			try {
				const res = await kolektorTargetService.getLeaderboard(params);
				setLeaderboard(Array.isArray(res.data) ? res.data : []);
			} catch (err) {
				console.error("Gagal memuat leaderboard:", err);
			} finally {
				setIsLeaderboardLoading(false);
			}
		}, []),
		fetchKolektorDetail: (0, import_react.useCallback)(async (kolektorId, tahun) => {
			try {
				const res = await kolektorTargetService.getKolektorDetail(kolektorId, tahun);
				setSelectedDetail(res.data || null);
				return res.data;
			} catch (err) {
				console.error("Gagal memuat detail kolektor:", err);
				return null;
			}
		}, []),
		saveTarget: (0, import_react.useCallback)(async (data) => {
			try {
				return {
					success: true,
					data: (await kolektorTargetService.setTarget(data)).data
				};
			} catch (err) {
				return {
					success: false,
					message: err.message || "Gagal menyimpan target."
				};
			}
		}, []),
		deleteTarget: (0, import_react.useCallback)(async (id) => {
			try {
				return {
					success: true,
					message: (await kolektorTargetService.deleteTarget(id)).message || "Target kolektor berhasil dihapus."
				};
			} catch (err) {
				return {
					success: false,
					message: err.message || "Gagal menghapus target."
				};
			}
		}, []),
		setSelectedDetail
	};
}
/**
* Generate & Download PDF Leaderboard Kinerja Kolektor
*/
var exportKolektorLeaderboardPdf = (options) => {
	const { leaderboard, tahun, settings, isSuperAdmin, filterDesa, selectedDesaName } = options;
	const doc = new import_jspdf_node_min.default({
		orientation: "landscape",
		unit: "pt",
		format: "a4"
	});
	const pageWidth = doc.internal.pageSize.getWidth();
	const pageHeight = doc.internal.pageSize.getHeight();
	const isKecamatanLevel = isSuperAdmin && (filterDesa === "all" || !filterDesa);
	const activeNamaDesa = selectedDesaName || settings.namaDesa || "Desa";
	const targetDesaText = isSuperAdmin ? isKecamatanLevel ? "SELURUH WILAYAH DESA" : `DESA ${activeNamaDesa.toUpperCase()}` : `DESA ${settings.namaDesa.toUpperCase()}`;
	const drawKopSurat = () => {
		doc.setFillColor(5, 150, 105);
		doc.rect(0, 0, pageWidth, 8, "F");
		doc.setFont("helvetica", "bold");
		doc.setFontSize(13);
		doc.setTextColor(15, 23, 42);
		doc.text(`PEMERINTAH KABUPATEN ${settings.kabupaten.toUpperCase()}`, pageWidth / 2, 32, { align: "center" });
		doc.setFontSize(11);
		doc.setFont("helvetica", "bold");
		doc.setTextColor(5, 150, 105);
		const kopTitle = isKecamatanLevel ? `KECAMATAN ${settings.kecamatan.toUpperCase()} - KOORDINASI KOLEKTOR SE-KECAMATAN` : `KECAMATAN ${settings.kecamatan.toUpperCase()} - ${targetDesaText}`;
		doc.text(kopTitle, pageWidth / 2, 48, { align: "center" });
		doc.setFont("helvetica", "normal");
		doc.setFontSize(8.5);
		doc.setTextColor(100, 116, 139);
		const kopSub = isKecamatanLevel ? `Kantor Kecamatan ${settings.kecamatan} - Sekretariat Pengawasan & Evaluasi Kinerja Kolektor PBB-P2` : settings.alamatDesa || "Kantor Sekretariat Pelayanan Pajak Daerah & PBB-P2 Desa";
		doc.text(kopSub, pageWidth / 2, 60, { align: "center" });
		doc.setDrawColor(5, 150, 105);
		doc.setLineWidth(1.5);
		doc.line(36, 68, pageWidth - 36, 68);
		doc.setDrawColor(245, 158, 11);
		doc.setLineWidth(.5);
		doc.line(36, 71, pageWidth - 36, 71);
	};
	drawKopSurat();
	let startY = 86;
	const titleText = `LEADERBOARD & EVALUASI KINERJA KOLEKTOR PBB-P2 TAHUN ${tahun}`;
	doc.setFont("helvetica", "bold");
	doc.setFontSize(11);
	doc.setTextColor(15, 23, 42);
	doc.text(titleText, pageWidth / 2, startY, { align: "center" });
	startY += 14;
	doc.setFont("helvetica", "normal");
	doc.setFontSize(8);
	doc.setTextColor(71, 85, 105);
	doc.text(`Wilayah: ${isKecamatanLevel ? `Kecamatan ${settings.kecamatan}` : activeNamaDesa} • Tanggal Cetak: ${(/* @__PURE__ */ new Date()).toLocaleDateString("id-ID", {
		day: "numeric",
		month: "long",
		year: "numeric"
	})} • Total Kolektor: ${leaderboard.length} Petugas`, pageWidth / 2, startY, { align: "center" });
	startY += 14;
	const totalTarget = leaderboard.reduce((acc, item) => acc + item.target_nominal, 0);
	const totalRealisasi = leaderboard.reduce((acc, item) => acc + item.realisasi_nominal, 0);
	const totalSisa = leaderboard.reduce((acc, item) => acc + item.sisa_nominal, 0);
	const totalFee = leaderboard.reduce((acc, item) => acc + item.total_fee, 0);
	const avgPersen = leaderboard.length > 0 ? leaderboard.reduce((acc, item) => acc + item.persentase_nominal, 0) / leaderboard.length : 0;
	doc.setFillColor(240, 253, 244);
	doc.setDrawColor(167, 243, 208);
	doc.roundedRect(36, startY, pageWidth - 72, 28, 6, 6, "FD");
	doc.setFontSize(8);
	doc.setFont("helvetica", "bold");
	doc.setTextColor(30, 41, 59);
	doc.text(`Total Target: ${formatRp(totalTarget)}`, 48, startY + 17);
	doc.setTextColor(5, 150, 105);
	doc.text(`Realisasi: ${formatRp(totalRealisasi)}`, 210, startY + 17);
	doc.setTextColor(225, 29, 72);
	doc.text(`Sisa Target: ${formatRp(totalSisa)}`, 380, startY + 17);
	doc.setTextColor(147, 51, 234);
	doc.text(`Total Fee: ${formatRp(totalFee)}`, 540, startY + 17);
	doc.setTextColor(4, 120, 87);
	doc.text(`Rata-rata: ${avgPersen.toFixed(1)}%`, pageWidth - 110, startY + 17);
	startY += 36;
	const tableHeaders = [
		"Rank",
		"Nama Kolektor",
		"Desa / Dusun",
		"Target Nominal",
		"Target SPPT",
		"Realisasi Nominal",
		"Realisasi SPPT",
		"Sisa Target",
		"Capaian (%)",
		"Badge",
		"Status",
		"Fee Kolektor"
	];
	const tableData = leaderboard.map((item, idx) => {
		const dusunText = item.lokasi_tanah || (typeof item.dusun_akses === "string" ? item.dusun_akses : Array.isArray(item.dusun_akses) ? item.dusun_akses.join(", ") : "Semua");
		const desaPrefix = item.nama_desa ? `${item.nama_desa} - ` : "";
		return [
			String(item.rank || idx + 1),
			item.kolektor_name,
			`${desaPrefix}${dusunText}`,
			formatRp(item.target_nominal),
			`${(item.target_sppt || 0).toLocaleString("id-ID")}`,
			formatRp(item.realisasi_nominal),
			`${(item.realisasi_sppt || 0).toLocaleString("id-ID")}`,
			formatRp(item.sisa_nominal),
			`${item.persentase_nominal.toFixed(1)}%`,
			item.badge || "NONE",
			item.status || "CRITICAL",
			formatRp(item.total_fee)
		];
	});
	const totalTargetSppt = leaderboard.reduce((acc, item) => acc + (item.target_sppt || 0), 0);
	const totalRealisasiSppt = leaderboard.reduce((acc, item) => acc + (item.realisasi_sppt || 0), 0);
	const footerRow = [
		"TOTAL",
		"-",
		"-",
		formatRp(totalTarget),
		totalTargetSppt.toLocaleString("id-ID"),
		formatRp(totalRealisasi),
		totalRealisasiSppt.toLocaleString("id-ID"),
		formatRp(totalSisa),
		`${avgPersen.toFixed(1)}%`,
		"-",
		"-",
		formatRp(totalFee)
	];
	autoTable(doc, {
		startY,
		head: [tableHeaders],
		body: tableData,
		foot: [footerRow],
		theme: "grid",
		styles: {
			fontSize: 7.5,
			cellPadding: 4,
			valign: "middle"
		},
		headStyles: {
			fillColor: [
				5,
				150,
				105
			],
			textColor: [
				255,
				255,
				255
			],
			fontStyle: "bold",
			halign: "center"
		},
		footStyles: {
			fillColor: [
				241,
				245,
				249
			],
			textColor: [
				15,
				23,
				42
			],
			fontStyle: "bold"
		},
		columnStyles: {
			0: {
				halign: "center",
				cellWidth: 32
			},
			1: {
				halign: "left",
				cellWidth: 95
			},
			2: {
				halign: "left",
				cellWidth: 100
			},
			3: {
				halign: "right",
				cellWidth: 70
			},
			4: {
				halign: "center",
				cellWidth: 50
			},
			5: {
				halign: "right",
				cellWidth: 70
			},
			6: {
				halign: "center",
				cellWidth: 50
			},
			7: {
				halign: "right",
				cellWidth: 65
			},
			8: {
				halign: "center",
				cellWidth: 55
			},
			9: {
				halign: "center",
				cellWidth: 45
			},
			10: {
				halign: "center",
				cellWidth: 55
			},
			11: {
				halign: "right",
				cellWidth: 65
			}
		},
		didDrawPage: () => {}
	});
	let lastY = doc.lastAutoTable.finalY + 25;
	if (lastY + 80 > pageHeight - 30) {
		doc.addPage();
		lastY = 40;
	}
	const leftColX = 140;
	const rightColX = pageWidth - 140;
	doc.setFontSize(8.5);
	doc.setFont("helvetica", "normal");
	doc.setTextColor(30, 41, 59);
	const pejabat1Title = isKecamatanLevel ? `CAMAT ${settings.kecamatan.toUpperCase()}` : `KEPALA DESA ${activeNamaDesa.toUpperCase()}`;
	const pejabat1Name = isKecamatanLevel ? settings.namaKades || `Camat ${settings.kecamatan}` : settings.namaKades || "________________________";
	const pejabat1Sub = isKecamatanLevel ? settings.nipKades ? `NIP. ${settings.nipKades}` : `Pemerintah Kecamatan ${settings.kecamatan}` : settings.nipKades ? `NIP. ${settings.nipKades}` : `Kepala Desa ${activeNamaDesa}`;
	doc.text("Mengetahui,", leftColX, lastY, { align: "center" });
	doc.setFont("helvetica", "bold");
	doc.text(pejabat1Title, leftColX, lastY + 12, { align: "center" });
	doc.text(pejabat1Name, leftColX, lastY + 52, { align: "center" });
	doc.setFont("helvetica", "normal");
	doc.setFontSize(8);
	doc.text(pejabat1Sub, leftColX, lastY + 63, { align: "center" });
	const pejabat2Title = isKecamatanLevel ? "KOORDINATOR PBB KECAMATAN" : "PETUGAS KOLEKTOR UTAMA / BENDAHARA";
	const pejabat2Name = settings.namaPetugas || "________________________";
	const pejabat2Sub = settings.nipPetugas ? `NIP. ${settings.nipPetugas}` : `Desa ${activeNamaDesa}`;
	doc.text(`${settings.kecamatan}, ${(/* @__PURE__ */ new Date()).toLocaleDateString("id-ID", {
		day: "numeric",
		month: "long",
		year: "numeric"
	})}`, rightColX, lastY, { align: "center" });
	doc.setFont("helvetica", "bold");
	doc.text(pejabat2Title, rightColX, lastY + 12, { align: "center" });
	doc.text(pejabat2Name, rightColX, lastY + 52, { align: "center" });
	doc.setFont("helvetica", "normal");
	doc.setFontSize(8);
	doc.text(pejabat2Sub, rightColX, lastY + 63, { align: "center" });
	const totalPages = doc.internal.getNumberOfPages();
	for (let i = 1; i <= totalPages; i++) {
		doc.setPage(i);
		doc.setFont("helvetica", "normal");
		doc.setFontSize(7.5);
		doc.setTextColor(148, 163, 184);
		doc.text(`SIPABAR (Sistem Informasi Pajak Barudua) • Halaman ${i} dari ${totalPages}`, pageWidth / 2, pageHeight - 14, { align: "center" });
	}
	const filename = `Leaderboard_Kolektor_PBB_${tahun}_${(isKecamatanLevel ? `Kecamatan_${settings.kecamatan}` : activeNamaDesa).replace(/\s+/g, "_")}_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.pdf`;
	doc.save(filename);
	return filename;
};
/**
* Generate & Download Excel (XLSX) Leaderboard Kinerja Kolektor
*/
var exportKolektorLeaderboardExcel = (options) => {
	const { leaderboard, tahun, settings, isSuperAdmin, filterDesa, selectedDesaName } = options;
	const isKecamatanLevel = isSuperAdmin && (filterDesa === "all" || !filterDesa);
	const activeNamaDesa = selectedDesaName || settings.namaDesa || "Desa";
	const wilayahName = isKecamatanLevel ? `Kecamatan ${settings.kecamatan}` : `Desa ${activeNamaDesa}`;
	const sheetData = [
		["PEMERINTAH KABUPATEN " + settings.kabupaten.toUpperCase()],
		[`LEADERBOARD & EVALUASI KINERJA KOLEKTOR PBB-P2 TAHUN ${tahun}`],
		[`Wilayah: ${wilayahName} | Tanggal Ekspor: ${(/* @__PURE__ */ new Date()).toLocaleDateString("id-ID", {
			day: "numeric",
			month: "long",
			year: "numeric"
		})}`],
		[],
		[
			"Rank",
			"Nama Kolektor",
			"Username",
			"Desa",
			"Dusun Akses",
			"Target Nominal (Rp)",
			"Target SPPT",
			"Realisasi Nominal (Rp)",
			"Realisasi SPPT",
			"Sisa Nominal (Rp)",
			"Sisa SPPT",
			"Capaian Nominal (%)",
			"Capaian SPPT (%)",
			"Badge",
			"Status",
			"Total Fee (Rp)",
			"Catatan"
		]
	];
	leaderboard.forEach((item, idx) => {
		const dusunText = item.lokasi_tanah || (typeof item.dusun_akses === "string" ? item.dusun_akses : Array.isArray(item.dusun_akses) ? item.dusun_akses.join(", ") : "Semua");
		sheetData.push([
			item.rank || idx + 1,
			item.kolektor_name,
			item.kolektor_username || "-",
			item.nama_desa || activeNamaDesa,
			dusunText,
			item.target_nominal,
			item.target_sppt || 0,
			item.realisasi_nominal,
			item.realisasi_sppt || 0,
			item.sisa_nominal,
			item.sisa_sppt || 0,
			item.persentase_nominal,
			item.persentase_sppt || 0,
			item.badge || "NONE",
			item.status || "CRITICAL",
			item.total_fee,
			item.catatan || "-"
		]);
	});
	const totalTarget = leaderboard.reduce((acc, item) => acc + item.target_nominal, 0);
	const totalTargetSppt = leaderboard.reduce((acc, item) => acc + (item.target_sppt || 0), 0);
	const totalRealisasi = leaderboard.reduce((acc, item) => acc + item.realisasi_nominal, 0);
	const totalRealisasiSppt = leaderboard.reduce((acc, item) => acc + (item.realisasi_sppt || 0), 0);
	const totalSisa = leaderboard.reduce((acc, item) => acc + item.sisa_nominal, 0);
	const totalSisaSppt = leaderboard.reduce((acc, item) => acc + (item.sisa_sppt || 0), 0);
	const totalFee = leaderboard.reduce((acc, item) => acc + item.total_fee, 0);
	const avgPersen = leaderboard.length > 0 ? leaderboard.reduce((acc, item) => acc + item.persentase_nominal, 0) / leaderboard.length : 0;
	sheetData.push([]);
	sheetData.push([
		"TOTAL",
		"-",
		"-",
		"-",
		"-",
		totalTarget,
		totalTargetSppt,
		totalRealisasi,
		totalRealisasiSppt,
		totalSisa,
		totalSisaSppt,
		Number(avgPersen.toFixed(2)),
		"-",
		"-",
		"-",
		totalFee,
		"-"
	]);
	const ws = utils.aoa_to_sheet(sheetData);
	ws["!cols"] = [
		{ wch: 6 },
		{ wch: 24 },
		{ wch: 18 },
		{ wch: 18 },
		{ wch: 22 },
		{ wch: 20 },
		{ wch: 14 },
		{ wch: 22 },
		{ wch: 14 },
		{ wch: 18 },
		{ wch: 12 },
		{ wch: 18 },
		{ wch: 16 },
		{ wch: 12 },
		{ wch: 16 },
		{ wch: 18 },
		{ wch: 25 }
	];
	const wb = utils.book_new();
	utils.book_append_sheet(wb, ws, "Leaderboard Kolektor");
	const filename = `Leaderboard_Kolektor_PBB_${tahun}_${(isKecamatanLevel ? `Kecamatan_${settings.kecamatan}` : activeNamaDesa).replace(/\s+/g, "_")}_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.xlsx`;
	writeFileSync(wb, filename);
	return filename;
};
var BADGE_CONFIG = {
	LEGEND: {
		icon: Flame,
		label: "Legend",
		color: "text-orange-500",
		bg: "bg-gradient-to-br from-orange-500/15 to-red-500/10",
		border: "border-orange-400/40",
		gradient: "from-orange-500 to-red-500"
	},
	GOLD: {
		icon: Trophy,
		label: "Gold",
		color: "text-amber-500",
		bg: "bg-gradient-to-br from-amber-500/15 to-yellow-500/10",
		border: "border-amber-400/40",
		gradient: "from-amber-400 to-yellow-500"
	},
	SILVER: {
		icon: Medal,
		label: "Silver",
		color: "text-slate-400",
		bg: "bg-gradient-to-br from-slate-400/15 to-gray-300/10",
		border: "border-slate-400/40",
		gradient: "from-slate-300 to-gray-400"
	},
	BRONZE: {
		icon: Award,
		label: "Bronze",
		color: "text-amber-700",
		bg: "bg-gradient-to-br from-amber-700/15 to-orange-700/10",
		border: "border-amber-700/40",
		gradient: "from-amber-600 to-orange-700"
	},
	NONE: {
		icon: Star,
		label: "Pemula",
		color: "text-slate-500",
		bg: "bg-slate-500/10",
		border: "border-slate-500/20",
		gradient: "from-slate-400 to-slate-500"
	}
};
var STATUS_CONFIG = {
	EXCEEDED: {
		label: "Melebihi Target 🔥",
		color: "text-orange-600 dark:text-orange-400",
		bg: "bg-orange-100 dark:bg-orange-500/15"
	},
	ON_TRACK: {
		label: "Sesuai Target ✅",
		color: "text-emerald-600 dark:text-emerald-400",
		bg: "bg-emerald-100 dark:bg-emerald-500/15"
	},
	MODERATE: {
		label: "Cukup Baik 📊",
		color: "text-blue-600 dark:text-blue-400",
		bg: "bg-blue-100 dark:bg-blue-500/15"
	},
	BEHIND: {
		label: "Perlu Peningkatan ⚠️",
		color: "text-amber-600 dark:text-amber-400",
		bg: "bg-amber-100 dark:bg-amber-500/15"
	},
	CRITICAL: {
		label: "Kritis ❗",
		color: "text-red-600 dark:text-red-400",
		bg: "bg-red-100 dark:bg-red-500/15"
	}
};
function formatLokasiTanah(lokasi) {
	if (!lokasi) return "Semua Dusun";
	const val = Array.isArray(lokasi) ? lokasi.join(", ") : String(lokasi);
	const upper = val.toUpperCase().trim();
	if (upper === "ALL") return "Semua Dusun";
	if (upper.includes("BALOK") && upper.includes("CIDERES")) return "Dusun 1 & Dusun 2";
	if (upper.includes("PUNCAK") && upper.includes("CIPEDES")) return "Dusun 3";
	if (upper === "BALOK" || upper === "DUSUN 1") return "Dusun 1";
	if (upper === "CIDERES" || upper === "DUSUN 2") return "Dusun 2";
	if (upper === "PUNCAK SARI" || upper === "DUSUN 3" || upper === "CIPEDES") return "Dusun 3";
	if (upper === "LUAR_DESA" || upper === "LUAR DESA") return "Luar Desa";
	return val;
}
function KolektorPerformancePage() {
	const { user: authUser } = useAuthStore();
	const { settings } = useSettingsStore();
	const tenant = useTenantStore();
	const currentRole = authUser?.role;
	const userDesaId = authUser?.desa_id;
	const isSuperAdmin = currentRole === "SUPER_ADMIN_SYSTEM" || !userDesaId && currentRole === "SUPER_ADMIN";
	const canManageTargets = isSuperAdmin || currentRole === "SUPER_ADMIN" || currentRole === "KEPALA_DESA";
	const { targets, leaderboard, selectedDetail, isLoading, isLeaderboardLoading, fetchTargets, fetchLeaderboard, fetchKolektorDetail, saveTarget, deleteTarget, setSelectedDetail } = useKolektorTargetStore();
	const [filterDesa, setFilterDesa] = (0, import_react.useState)("all");
	const [desasList, setDesasList] = (0, import_react.useState)([]);
	const [kolektorUsers, setKolektorUsers] = (0, import_react.useState)([]);
	const [isRefreshing, setIsRefreshing] = (0, import_react.useState)(false);
	const [showTargetModal, setShowTargetModal] = (0, import_react.useState)(false);
	const [showDetailModal, setShowDetailModal] = (0, import_react.useState)(false);
	const [editingTarget, setEditingTarget] = (0, import_react.useState)(null);
	const [formKolektorId, setFormKolektorId] = (0, import_react.useState)("");
	const [formLokasiTanah, setFormLokasiTanah] = (0, import_react.useState)("Balok");
	const [formTargetNominal, setFormTargetNominal] = (0, import_react.useState)("");
	const [formTargetSppt, setFormTargetSppt] = (0, import_react.useState)("");
	const [formCatatan, setFormCatatan] = (0, import_react.useState)("");
	const [isSaving, setIsSaving] = (0, import_react.useState)(false);
	const currentYear = (/* @__PURE__ */ new Date()).getFullYear();
	const [tahun, setTahun] = (0, import_react.useState)(currentYear);
	const availableYears = (0, import_react.useMemo)(() => {
		const years = [];
		for (let y = currentYear - 2; y <= currentYear + 2; y++) years.push(y);
		return years;
	}, [currentYear]);
	const namaWilayah = isSuperAdmin ? `Kecamatan ${settings.kecamatan || "Malangbong"}` : tenant?.nama_desa || settings.namaDesa || "Desa";
	const loadData = (0, import_react.useCallback)(async () => {
		const params = {
			tahun,
			desa_id: filterDesa !== "all" ? filterDesa : void 0
		};
		await Promise.all([fetchTargets(params), fetchLeaderboard(params)]);
	}, [
		fetchTargets,
		fetchLeaderboard,
		filterDesa,
		tahun
	]);
	(0, import_react.useEffect)(() => {
		loadData();
	}, [loadData]);
	(0, import_react.useEffect)(() => {
		if (isSuperAdmin) desaService.getAll().then((res) => {
			if (Array.isArray(res.data)) setDesasList(res.data);
		});
	}, [isSuperAdmin]);
	(0, import_react.useEffect)(() => {
		if (canManageTargets) {
			const params = filterDesa !== "all" ? { desa_id: filterDesa } : {};
			userService.getUsers(params).then((res) => {
				const kolektors = (res.data || []).filter((u) => u.role === "KOLEKTOR" && u.status === "AKTIF");
				setKolektorUsers(kolektors);
			});
		}
	}, [canManageTargets, filterDesa]);
	const handleRefresh = (0, import_react.useCallback)(async () => {
		setIsRefreshing(true);
		await loadData();
		setIsRefreshing(false);
	}, [loadData]);
	const summaryStats = (0, import_react.useMemo)(() => {
		const data = targets.length > 0 ? targets : leaderboard;
		const total = data.length;
		return {
			total,
			avgPersen: total > 0 ? data.reduce((a, b) => a + b.persentase_nominal, 0) / total : 0,
			onTrack: data.filter((d) => d.persentase_nominal >= 75).length,
			best: data.length > 0 ? [...data].sort((a, b) => b.persentase_nominal - a.persentase_nominal)[0] : null,
			totalRealisasi: data.reduce((a, b) => a + b.realisasi_nominal, 0),
			totalTarget: data.reduce((a, b) => a + b.target_nominal, 0),
			totalFee: data.reduce((a, b) => a + b.total_fee, 0)
		};
	}, [targets, leaderboard]);
	const chartData = (0, import_react.useMemo)(() => {
		return (targets.length > 0 ? targets : leaderboard).map((item) => ({
			name: item.kolektor_name?.split(" ")[0] || "?",
			target: item.target_nominal,
			realisasi: item.realisasi_nominal,
			persentase: item.persentase_nominal
		}));
	}, [targets, leaderboard]);
	const handleOpenTargetModal = (item) => {
		if (item) {
			setEditingTarget(item);
			setFormKolektorId(String(item.kolektor_id));
			setFormTargetNominal(String(item.target_nominal));
			setFormTargetSppt(String(item.target_sppt));
			setFormLokasiTanah(item.lokasi_tanah || (Array.isArray(item.dusun_akses) ? item.dusun_akses.join(", ") : item.dusun_akses) || "Balok");
			setFormCatatan(item.catatan || "");
		} else {
			setEditingTarget(null);
			setFormKolektorId("");
			setFormTargetNominal("");
			setFormTargetSppt("");
			setFormLokasiTanah("Balok");
			setFormCatatan("");
		}
		setShowTargetModal(true);
	};
	const handleKolektorChange = (kolektorId) => {
		setFormKolektorId(kolektorId);
		const selectedUser = kolektorUsers.find((u) => String(u.id) === kolektorId);
		const assignedDusun = selectedUser?.dusun_akses || selectedUser?.dusunAssigned;
		if (assignedDusun) setFormLokasiTanah(assignedDusun);
	};
	const handleSaveTarget = async () => {
		if (!formKolektorId || !formTargetNominal) return;
		setIsSaving(true);
		const payload = {
			kolektor_id: Number(formKolektorId),
			tahun,
			target_nominal: Number(formTargetNominal),
			target_sppt: Number(formTargetSppt) || 0,
			lokasi_tanah: formLokasiTanah,
			dusun_akses: formLokasiTanah,
			catatan: formCatatan || void 0
		};
		if (filterDesa !== "all") payload.desa_id = Number(filterDesa);
		const result = await saveTarget(payload);
		setIsSaving(false);
		if (result.success) {
			setShowTargetModal(false);
			Swal.fire({
				title: "Target Disimpan!",
				text: `Target kinerja tahun ${tahun} untuk kolektor berhasil disimpan.`,
				icon: "success",
				confirmButtonColor: "#059669",
				customClass: {
					popup: "rounded-2xl shadow-2xl",
					confirmButton: "rounded-xl font-bold px-5 py-2.5 text-xs"
				}
			});
			loadData();
		} else Swal.fire({
			title: "Gagal Menyimpan",
			text: result.message || "Gagal menyimpan target kolektor.",
			icon: "error",
			confirmButtonColor: "#e11d48",
			customClass: {
				popup: "rounded-2xl shadow-2xl",
				confirmButton: "rounded-xl font-bold px-5 py-2.5 text-xs"
			}
		});
	};
	const handleDeleteTarget = async (item) => {
		if ((await Swal.fire({
			title: "Hapus Target Kolektor",
			html: `
        <div style="text-align: left; font-size: 13px; line-height: 1.6;">
          <p style="color: #475569; margin-bottom: 8px;">Apakah Anda yakin ingin menghapus target untuk kolektor berikut?</p>
          <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 12px; margin-bottom: 12px;">
            <div><strong>Nama Kolektor:</strong> <span style="font-weight: 700; color: #0f172a;">${item.kolektor_name}</span></div>
            <div><strong>Desa:</strong> <span>${item.nama_desa || tenant?.nama_desa || "Desa"}</span></div>
            <div><strong>Tahun Target:</strong> <span>${tahun}</span></div>
            <div><strong>Target Nominal:</strong> <span style="color: #059669; font-weight: 800;">${formatRp(item.target_nominal)}</span></div>
            <div><strong>Target SPPT:</strong> <span>${(item.target_sppt || 0).toLocaleString("id-ID")} SPPT</span></div>
          </div>
          <div style="background: #fffbeb; border: 1px solid #fef3c7; border-radius: 8px; padding: 8px; color: #b45309; font-size: 11px; font-weight: 600;">
            ⚠️ Data realisasi pembayaran DHKP tidak akan terhapus, tetapi riwayat target tahun ${tahun} untuk kolektor ini akan direset.
          </div>
        </div>
      `,
			icon: "warning",
			showCancelButton: true,
			confirmButtonColor: "#e11d48",
			cancelButtonColor: "#64748b",
			confirmButtonText: "Ya, Hapus Target",
			cancelButtonText: "Batal",
			reverseButtons: true,
			customClass: {
				popup: "rounded-2xl shadow-2xl",
				confirmButton: "rounded-xl font-bold px-5 py-2.5 text-xs",
				cancelButton: "rounded-xl font-bold px-5 py-2.5 text-xs"
			}
		})).isConfirmed) try {
			const res = await deleteTarget(item.id);
			if (res.success) {
				Swal.fire({
					title: "Berhasil Dihapus!",
					text: res.message || `Target kolektor ${item.kolektor_name} tahun ${tahun} berhasil dihapus.`,
					icon: "success",
					confirmButtonColor: "#059669",
					customClass: {
						popup: "rounded-2xl shadow-2xl",
						confirmButton: "rounded-xl font-bold px-5 py-2.5 text-xs"
					}
				});
				loadData();
			} else Swal.fire({
				title: "Gagal Menghapus",
				text: res.message || "Gagal menghapus target kolektor.",
				icon: "error",
				confirmButtonColor: "#e11d48",
				customClass: {
					popup: "rounded-2xl shadow-2xl",
					confirmButton: "rounded-xl font-bold px-5 py-2.5 text-xs"
				}
			});
		} catch (err) {
			Swal.fire({
				title: "Terjadi Kesalahan",
				text: err.message || "Terjadi kesalahan saat menghapus target kolektor.",
				icon: "error",
				confirmButtonColor: "#e11d48",
				customClass: {
					popup: "rounded-2xl shadow-2xl",
					confirmButton: "rounded-xl font-bold px-5 py-2.5 text-xs"
				}
			});
		}
	};
	const handleShowDetail = async (item) => {
		setShowDetailModal(true);
		await fetchKolektorDetail(item.kolektor_id, tahun);
	};
	const handleExportPdf = () => {
		try {
			const dataToExport = leaderboard.length > 0 ? leaderboard : targets;
			if (dataToExport.length === 0) {
				Swal.fire({
					title: "Tidak Ada Data",
					text: "Tidak ada data kinerja kolektor untuk diekspor.",
					icon: "info",
					confirmButtonColor: "#059669"
				});
				return;
			}
			const filename = exportKolektorLeaderboardPdf({
				leaderboard: dataToExport,
				tahun,
				namaWilayah,
				settings,
				isSuperAdmin,
				filterDesa,
				selectedDesaName: desasList.find((d) => String(d.id) === String(filterDesa))?.nama_desa
			});
			Swal.fire({
				title: "PDF Berhasil Dibuat!",
				text: `Berkas ${filename} berhasil diunduh.`,
				icon: "success",
				timer: 2500,
				confirmButtonColor: "#059669",
				customClass: {
					popup: "rounded-2xl shadow-2xl",
					confirmButton: "rounded-xl font-bold px-5 py-2.5 text-xs"
				}
			});
		} catch (err) {
			Swal.fire({
				title: "Gagal Ekspor PDF",
				text: err.message || "Terjadi kesalahan saat memproses ekspor PDF.",
				icon: "error",
				confirmButtonColor: "#e11d48",
				customClass: {
					popup: "rounded-2xl shadow-2xl",
					confirmButton: "rounded-xl font-bold px-5 py-2.5 text-xs"
				}
			});
		}
	};
	const handleExportExcel = () => {
		try {
			const dataToExport = leaderboard.length > 0 ? leaderboard : targets;
			if (dataToExport.length === 0) {
				Swal.fire({
					title: "Tidak Ada Data",
					text: "Tidak ada data kinerja kolektor untuk diekspor.",
					icon: "info",
					confirmButtonColor: "#059669"
				});
				return;
			}
			const filename = exportKolektorLeaderboardExcel({
				leaderboard: dataToExport,
				tahun,
				namaWilayah,
				settings,
				isSuperAdmin,
				filterDesa,
				selectedDesaName: desasList.find((d) => String(d.id) === String(filterDesa))?.nama_desa
			});
			Swal.fire({
				title: "Excel Berhasil Dibuat!",
				text: `Berkas ${filename} berhasil diunduh.`,
				icon: "success",
				timer: 2500,
				confirmButtonColor: "#059669",
				customClass: {
					popup: "rounded-2xl shadow-2xl",
					confirmButton: "rounded-xl font-bold px-5 py-2.5 text-xs"
				}
			});
		} catch (err) {
			Swal.fire({
				title: "Gagal Ekspor Excel",
				text: err.message || "Terjadi kesalahan saat memproses ekspor Excel.",
				icon: "error",
				confirmButtonColor: "#e11d48",
				customClass: {
					popup: "rounded-2xl shadow-2xl",
					confirmButton: "rounded-xl font-bold px-5 py-2.5 text-xs"
				}
			});
		}
	};
	const renderBadge = (badge) => {
		const cfg = BADGE_CONFIG[badge] || BADGE_CONFIG.NONE;
		const IconComp = cfg.icon;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: `inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${cfg.bg} ${cfg.color} border ${cfg.border}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconComp, { className: "size-3" }), cfg.label]
		});
	};
	const renderStatus = (status) => {
		const cfg = STATUS_CONFIG[status] || STATUS_CONFIG.CRITICAL;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${cfg.bg} ${cfg.color}`,
			children: cfg.label
		});
	};
	const renderRankBadge = (rank) => {
		if (rank === 1) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "inline-flex items-center justify-center size-7 rounded-full bg-gradient-to-br from-amber-400 to-yellow-500 text-white text-xs font-black shadow-lg shadow-amber-500/30",
			children: "🥇"
		});
		if (rank === 2) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "inline-flex items-center justify-center size-7 rounded-full bg-gradient-to-br from-slate-300 to-gray-400 text-white text-xs font-black shadow-lg shadow-slate-400/30",
			children: "🥈"
		});
		if (rank === 3) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "inline-flex items-center justify-center size-7 rounded-full bg-gradient-to-br from-amber-600 to-orange-700 text-white text-xs font-black shadow-lg shadow-amber-700/30",
			children: "🥉"
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "inline-flex items-center justify-center size-7 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-bold",
			children: rank
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 p-4 sm:p-6",
		id: "kolektor-performance-page",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-black tracking-tight text-slate-900 dark:text-slate-100",
					children: "🎯 Kinerja Kolektor"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-slate-500 dark:text-slate-400 mt-1",
					children: [
						"Target, Capaian & Ranking Kolektor PBB-P2 — ",
						namaWilayah,
						" (",
						tahun,
						")"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: String(tahun),
							onValueChange: (val) => setTahun(Number(val)),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "w-28 h-9 text-xs",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Pilih Tahun" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: availableYears.map((y) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
								value: String(y),
								children: ["📅 ", y]
							}, y)) })]
						}),
						isSuperAdmin && desasList.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: filterDesa,
							onValueChange: setFilterDesa,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								className: "w-48 h-9 text-xs",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Semua Desa" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "all",
								children: "🏛️ Semua Desa"
							}), desasList.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: String(d.id),
								children: d.nama_desa
							}, d.id))] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 rounded-xl shadow-xs transition-all",
								title: "Ekspor Laporan Kinerja",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5 text-emerald-600 dark:text-emerald-400" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Ekspor" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-3 text-slate-400" })
								]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
							align: "end",
							className: "w-44",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
								onClick: handleExportPdf,
								className: "flex items-center gap-2 text-xs cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4 text-rose-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Unduh PDF (.pdf)" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
								onClick: handleExportExcel,
								className: "flex items-center gap-2 text-xs cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, { className: "size-4 text-emerald-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Unduh Excel (.xlsx)" })]
							})]
						})] }),
						canManageTargets && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => handleOpenTargetModal(),
							className: "inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-white bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 rounded-xl shadow-lg shadow-emerald-500/20 transition-all",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), " Set Target"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: handleRefresh,
							disabled: isRefreshing,
							className: "inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-all",
							title: "Muat Ulang Data",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `size-3.5 ${isRefreshing ? "animate-spin" : ""}` })
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "border-slate-200/70 dark:border-slate-800 shadow-sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
							className: "p-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-10 rounded-xl bg-gradient-to-br from-blue-500/15 to-indigo-500/10 grid place-items-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5 text-blue-500" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold text-slate-500 uppercase tracking-wider",
									children: "Total Kolektor"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-slate-900 dark:text-white",
									children: summaryStats.total
								})] })]
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "border-slate-200/70 dark:border-slate-800 shadow-sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
							className: "p-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-10 rounded-xl bg-gradient-to-br from-emerald-500/15 to-teal-500/10 grid place-items-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-5 text-emerald-500" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold text-slate-500 uppercase tracking-wider",
									children: "Rata-rata Capaian"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xl font-black text-emerald-600 dark:text-emerald-400",
									children: [summaryStats.avgPersen.toFixed(1), "%"]
								})] })]
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "border-slate-200/70 dark:border-slate-800 shadow-sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
							className: "p-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-10 rounded-xl bg-gradient-to-br from-amber-500/15 to-yellow-500/10 grid place-items-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "size-5 text-amber-500" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold text-slate-500 uppercase tracking-wider",
									children: "On Track (≥75%)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-amber-600 dark:text-amber-400",
									children: summaryStats.onTrack
								})] })]
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "border-slate-200/70 dark:border-slate-800 shadow-sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
							className: "p-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-10 rounded-xl bg-gradient-to-br from-purple-500/15 to-pink-500/10 grid place-items-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-5 text-purple-500" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold text-slate-500 uppercase tracking-wider",
									children: "Total Realisasi"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-lg font-black text-purple-600 dark:text-purple-400 truncate",
									children: formatRp(summaryStats.totalRealisasi)
								})] })]
							})
						})
					})
				]
			}),
			summaryStats.best && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "border-0 bg-gradient-to-r from-amber-500/10 via-yellow-500/5 to-orange-500/10 dark:from-amber-500/15 dark:via-yellow-500/5 dark:to-orange-500/15 shadow-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "p-4 flex flex-col sm:flex-row items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-14 rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-500 grid place-items-center shadow-xl shadow-amber-500/30",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "size-7 text-white" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase tracking-widest",
								children: "⭐ Kolektor Terbaik"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-lg font-black text-slate-900 dark:text-white",
								children: summaryStats.best.kolektor_name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 mt-1",
								children: [renderBadge(summaryStats.best.badge), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-slate-500",
									children: [
										formatRp(summaryStats.best.realisasi_nominal),
										" / ",
										formatRp(summaryStats.best.target_nominal)
									]
								})]
							})
						] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center sm:text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-3xl font-black bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent",
							children: [summaryStats.best.persentase_nominal.toFixed(1), "%"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-500 font-semibold",
							children: "Capaian Target"
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid lg:grid-cols-5 gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "border-slate-200/70 dark:border-slate-800 shadow-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
							className: "pb-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
								className: "text-base font-extrabold flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "size-4 text-amber-500" }), " Leaderboard Kolektor"]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
							className: "p-0",
							children: isLoading || isLeaderboardLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-center py-16",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-6 text-emerald-500 animate-spin" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-2 text-sm text-slate-500",
									children: "Memuat data..."
								})]
							}) : leaderboard.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center py-16",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "size-12 mx-auto text-slate-300 mb-3" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-bold text-slate-500",
										children: "Belum ada target kolektor ditetapkan."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-slate-400 mt-1",
										children: "Klik \"Set Target\" untuk mulai menambahkan."
									})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-x-auto",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-b border-slate-200 dark:border-slate-700 bg-slate-50/80 dark:bg-slate-900/50",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-2.5 px-3 text-left font-extrabold text-slate-500 w-10",
												children: "#"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-2.5 px-3 text-left font-extrabold text-slate-500",
												children: "Kolektor"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-2.5 px-3 text-right font-extrabold text-slate-500",
												children: "Target"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-2.5 px-3 text-right font-extrabold text-slate-500",
												children: "Realisasi"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-2.5 px-3 text-center font-extrabold text-slate-500 w-28",
												children: "Capaian"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-2.5 px-3 text-center font-extrabold text-slate-500",
												children: "Badge"
											}),
											canManageTargets && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "py-2.5 px-3 text-center font-extrabold text-slate-500 w-20",
												children: "Aksi"
											})
										]
									}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
										className: "divide-y divide-slate-100 dark:divide-slate-800",
										children: leaderboard.map((item, idx) => {
											const rank = item.rank || idx + 1;
											return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
												className: "hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors cursor-pointer",
												onClick: () => handleShowDetail(item),
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "py-3 px-3",
														children: renderRankBadge(rank)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "py-3 px-3",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "font-bold text-slate-800 dark:text-slate-200",
															children: item.kolektor_name
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
															className: "text-[10px] text-slate-400 flex items-center gap-1 mt-0.5",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-2.5 text-emerald-500" }),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																	className: "font-semibold text-emerald-700 dark:text-emerald-400",
																	children: formatLokasiTanah(item.lokasi_tanah || item.dusun_akses)
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["· ", item.nama_desa || "Desa"] })
															]
														})] })
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "py-3 px-3 text-right font-mono font-bold text-slate-600 dark:text-slate-300",
														children: formatRp(item.target_nominal)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "py-3 px-3 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400",
														children: formatRp(item.realisasi_nominal)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "py-3 px-3",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex flex-col items-center gap-1",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: `text-sm font-black ${item.persentase_nominal >= 100 ? "text-orange-500" : item.persentase_nominal >= 75 ? "text-emerald-500" : item.persentase_nominal >= 50 ? "text-blue-500" : "text-red-500"}`,
																children: [item.persentase_nominal.toFixed(1), "%"]
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
																value: Math.min(item.persentase_nominal, 100),
																className: "h-1.5 w-full"
															})]
														})
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "py-3 px-3 text-center",
														children: renderBadge(item.badge)
													}),
													canManageTargets && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "py-3 px-3 text-center",
														onClick: (e) => e.stopPropagation(),
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center justify-center gap-1",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																onClick: () => handleOpenTargetModal(item),
																className: "size-7 rounded-lg bg-blue-50 dark:bg-blue-500/15 text-blue-500 hover:bg-blue-100 grid place-items-center transition-colors",
																title: "Edit Target",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pen, { className: "size-3" })
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																onClick: () => handleDeleteTarget(item),
																className: "size-7 rounded-lg bg-red-50 dark:bg-red-500/15 text-red-500 hover:bg-red-100 grid place-items-center transition-colors",
																title: "Hapus Target",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3" })
															})]
														})
													})
												]
											}, `${item.kolektor_id}-${item.desa_id}`);
										})
									})]
								})
							})
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-2 space-y-4",
					children: [
						chartData.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "border-slate-200/70 dark:border-slate-800 shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
								className: "pb-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
									className: "text-sm font-extrabold flex items-center gap-2",
									children: "📊 Target vs Realisasi"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
								className: "pb-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
									width: "100%",
									height: 240,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
										data: chartData,
										margin: {
											top: 5,
											right: 5,
											left: -15,
											bottom: 5
										},
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
												strokeDasharray: "3 3",
												className: "stroke-slate-200 dark:stroke-slate-700"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
												dataKey: "name",
												tick: { fontSize: 10 },
												className: "fill-slate-500"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
												tick: { fontSize: 9 },
												tickFormatter: (v) => `${(v / 1e6).toFixed(0)}jt`,
												className: "fill-slate-500"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
												formatter: (value, name) => [formatRp(value), name === "target" ? "Target" : "Realisasi"],
												contentStyle: {
													fontSize: 11,
													borderRadius: 12,
													borderColor: "#e2e8f0"
												}
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
												dataKey: "target",
												fill: "#94a3b8",
												radius: [
													6,
													6,
													0,
													0
												],
												name: "Target"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
												dataKey: "realisasi",
												radius: [
													6,
													6,
													0,
													0
												],
												name: "Realisasi",
												children: chartData.map((entry, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: entry.persentase >= 100 ? "#f97316" : entry.persentase >= 75 ? "#10b981" : entry.persentase >= 50 ? "#3b82f6" : "#ef4444" }, i))
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, { wrapperStyle: { fontSize: 10 } })
										]
									})
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
							className: "border-slate-200/70 dark:border-slate-800 shadow-sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
								className: "p-4 space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-sm font-extrabold text-slate-800 dark:text-slate-200",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-4 text-emerald-500" }), " Ringkasan Finansial"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-xl bg-emerald-50 dark:bg-emerald-500/10 p-3 text-center",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] font-bold text-emerald-600 dark:text-emerald-400",
												children: "Total Target"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-black text-emerald-700 dark:text-emerald-300",
												children: formatRp(summaryStats.totalTarget)
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-xl bg-blue-50 dark:bg-blue-500/10 p-3 text-center",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] font-bold text-blue-600 dark:text-blue-400",
												children: "Total Realisasi"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-black text-blue-700 dark:text-blue-300",
												children: formatRp(summaryStats.totalRealisasi)
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "col-span-2 rounded-xl bg-purple-50 dark:bg-purple-500/10 p-3 text-center",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] font-bold text-purple-600 dark:text-purple-400",
												children: "Total Fee Kolektor (Luar Desa)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-lg font-black text-purple-700 dark:text-purple-300",
												children: formatRp(summaryStats.totalFee)
											})]
										})
									]
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
							className: "border-slate-200/70 dark:border-slate-800 shadow-sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
								className: "p-4 space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-extrabold text-slate-600 dark:text-slate-300",
									children: "🏅 Sistem Badge"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-1.5",
									children: Object.entries(BADGE_CONFIG).map(([key, cfg]) => {
										const IconC = cfg.icon;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: `flex items-center gap-2 px-2.5 py-1.5 rounded-lg ${cfg.bg} border ${cfg.border}`,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconC, { className: `size-3.5 ${cfg.color}` }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `text-[10px] font-bold ${cfg.color}`,
													children: cfg.label
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[10px] text-slate-500 ml-auto",
													children: {
														LEGEND: "≥ 100%",
														GOLD: "≥ 75%",
														SILVER: "≥ 50%",
														BRONZE: "≥ 25%",
														NONE: "< 25%"
													}[key]
												})
											]
										}, key);
									})
								})]
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: showTargetModal,
				onOpenChange: setShowTargetModal,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "sm:max-w-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "flex items-center gap-2 text-base font-extrabold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "size-5 text-emerald-500" }), editingTarget ? "Edit Target Kolektor" : "Set Target Kolektor Baru"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, {
						className: "text-xs text-slate-500",
						children: [
							"Tetapkan target nominal dan jumlah SPPT tahun ",
							tahun,
							" yang harus dicapai kolektor."
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4 mt-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-bold text-slate-600 dark:text-slate-300 mb-1 block",
								children: "Kolektor"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: formKolektorId,
								onChange: (e) => handleKolektorChange(e.target.value),
								disabled: !!editingTarget,
								className: "w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 outline-none",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Pilih Kolektor..."
								}), kolektorUsers.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: u.id,
									children: [
										u.name,
										" (",
										u.username,
										")"
									]
								}, u.id))]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-bold text-slate-600 dark:text-slate-300 mb-1 block",
								children: "Lokasi Tanah / Dusun Penugasan"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: formLokasiTanah,
								onChange: (e) => setFormLokasiTanah(e.target.value),
								className: "w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 outline-none",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Dusun 1",
										children: "Dusun 1"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Dusun 2",
										children: "Dusun 2"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Dusun 3",
										children: "Dusun 3"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Dusun 1, Dusun 2",
										children: "Dusun 1 & Dusun 2"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "Luar Desa",
										children: "Luar Desa"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "ALL",
										children: "Semua Dusun"
									})
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-bold text-slate-600 dark:text-slate-300 mb-1 block",
									children: "Target Nominal (Rp)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									value: formTargetNominal,
									onChange: (e) => setFormTargetNominal(e.target.value),
									placeholder: "1000000",
									className: "w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 outline-none"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-bold text-slate-600 dark:text-slate-300 mb-1 block",
									children: "Target SPPT"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									value: formTargetSppt,
									onChange: (e) => setFormTargetSppt(e.target.value),
									placeholder: "100",
									className: "w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 outline-none"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-bold text-slate-600 dark:text-slate-300 mb-1 block",
								children: "Catatan (Opsional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: formCatatan,
								onChange: (e) => setFormCatatan(e.target.value),
								placeholder: "Catatan untuk kolektor...",
								rows: 2,
								className: "w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 outline-none resize-none"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-end gap-2 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setShowTargetModal(false),
									className: "px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-700 transition-colors",
									children: "Batal"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: handleSaveTarget,
									disabled: isSaving || !formKolektorId || !formTargetNominal,
									className: "inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 rounded-xl shadow-lg shadow-emerald-500/20 transition-all disabled:opacity-50",
									children: [isSaving ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }) : null, "Simpan Target"]
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: showDetailModal,
				onOpenChange: setShowDetailModal,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "sm:max-w-2xl max-h-[85vh] overflow-y-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "flex items-center gap-2 text-base font-extrabold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-5 text-blue-500" }), "Detail Kinerja Kolektor"]
					}) }), selectedDetail ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-5 mt-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-4 p-4 rounded-2xl bg-gradient-to-r from-slate-50 to-slate-100/50 dark:from-slate-800/60 dark:to-slate-900/40 border border-slate-200/60 dark:border-slate-700/50",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "size-14 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-500 grid place-items-center text-white shadow-xl shadow-emerald-500/20",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-7" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-black text-lg text-slate-900 dark:text-white",
												children: selectedDetail.kolektor_name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-xs text-slate-500",
												children: [
													"@",
													selectedDetail.kolektor_username,
													" · ",
													selectedDetail.nama_desa || "Desa"
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2 mt-1.5",
												children: [renderBadge(selectedDetail.badge), renderStatus(selectedDetail.status)]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: `text-3xl font-black ${selectedDetail.persentase_nominal >= 100 ? "text-orange-500" : selectedDetail.persentase_nominal >= 75 ? "text-emerald-500" : "text-blue-500"}`,
											children: [selectedDetail.persentase_nominal.toFixed(1), "%"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] text-slate-500 font-bold",
											children: "Capaian"
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 sm:grid-cols-4 gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-xl bg-blue-50 dark:bg-blue-500/10 p-3 text-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] font-bold text-blue-500",
											children: "Target Nominal"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-black text-blue-700 dark:text-blue-300",
											children: formatRp(selectedDetail.target_nominal)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-xl bg-emerald-50 dark:bg-emerald-500/10 p-3 text-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] font-bold text-emerald-500",
											children: "Realisasi"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-black text-emerald-700 dark:text-emerald-300",
											children: formatRp(selectedDetail.realisasi_nominal)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-xl bg-amber-50 dark:bg-amber-500/10 p-3 text-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] font-bold text-amber-500",
											children: "Sisa Target"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-black text-amber-700 dark:text-amber-300",
											children: formatRp(selectedDetail.sisa_nominal)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-xl bg-purple-50 dark:bg-purple-500/10 p-3 text-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] font-bold text-purple-500",
											children: "Total Fee"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-black text-purple-700 dark:text-purple-300",
											children: formatRp(selectedDetail.total_fee)
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-slate-200 dark:border-slate-700 p-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between mb-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] font-bold text-slate-500",
												children: "SPPT Progress"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs font-black text-blue-500",
												children: [
													selectedDetail.realisasi_sppt,
													"/",
													selectedDetail.target_sppt
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
											value: selectedDetail.persentase_sppt,
											className: "h-2"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[10px] text-slate-400 mt-1 text-center",
											children: [selectedDetail.persentase_sppt.toFixed(1), "%"]
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-slate-200 dark:border-slate-700 p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mb-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-bold text-slate-500",
											children: "Nominal Progress"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs font-black text-emerald-500",
											children: [selectedDetail.persentase_nominal.toFixed(1), "%"]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
										value: Math.min(selectedDetail.persentase_nominal, 100),
										className: "h-2"
									})]
								})]
							}),
							selectedDetail.dusun_breakdown && selectedDetail.dusun_breakdown.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2.5 pt-2 border-t border-slate-100 dark:border-slate-800",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs font-extrabold text-slate-700 dark:text-slate-200 flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5 text-emerald-500" }), "Capaian per Dusun Binaan & Target Dusun"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold",
										children: [selectedDetail.dusun_breakdown.length, " Dusun"]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "overflow-x-auto rounded-xl border border-slate-200/80 dark:border-slate-700",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
										className: "w-full text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200/80 dark:border-slate-700 text-slate-500",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "py-2 px-3 text-left font-extrabold",
													children: "Nama Dusun"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "py-2 px-3 text-right font-extrabold",
													children: "Target Dusun"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "py-2 px-3 text-right font-extrabold",
													children: "Realisasi Kolektor"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "py-2 px-3 text-center font-extrabold",
													children: "SPPT Lunas"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "py-2 px-3 text-center font-extrabold w-28",
													children: "Capaian"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "py-2 px-3 text-right font-extrabold",
													children: "Fee Insentif"
												})
											]
										}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
											className: "divide-y divide-slate-100 dark:divide-slate-800",
											children: selectedDetail.dusun_breakdown.map((db, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
												className: "hover:bg-slate-50/60 dark:hover:bg-slate-800/40",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "py-2 px-3 font-bold text-slate-800 dark:text-slate-200",
														children: db.nama_dusun
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "py-2 px-3 text-right font-mono font-medium text-slate-500",
														children: db.target_dusun_nominal > 0 ? formatRp(db.target_dusun_nominal) : "-"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "py-2 px-3 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400",
														children: formatRp(db.realisasi_nominal)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "py-2 px-3 text-center font-bold text-slate-600 dark:text-slate-300",
														children: db.realisasi_sppt.toLocaleString("id-ID")
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "py-2 px-3",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex flex-col items-center gap-0.5",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: `text-[11px] font-black ${db.persentase_dusun >= 100 ? "text-orange-500" : db.persentase_dusun >= 75 ? "text-emerald-500" : db.persentase_dusun >= 50 ? "text-blue-500" : "text-slate-500"}`,
																children: db.target_dusun_nominal > 0 ? `${db.persentase_dusun.toFixed(1)}%` : "-"
															}), db.target_dusun_nominal > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
																value: Math.min(db.persentase_dusun, 100),
																className: "h-1.5 w-full"
															})]
														})
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
														className: "py-2 px-3 text-right font-mono font-bold text-purple-600 dark:text-purple-400",
														children: formatRp(db.total_fee)
													})
												]
											}, idx))
										})]
									})
								})]
							}),
							selectedDetail.trend_harian && selectedDetail.trend_harian.length > 0 || selectedDetail.trend_mingguan && selectedDetail.trend_mingguan.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-4 pt-2 border-t border-slate-100 dark:border-slate-800",
								children: [selectedDetail.trend_harian && selectedDetail.trend_harian.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3.5 rounded-2xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-700/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mb-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs font-extrabold text-slate-700 dark:text-slate-200 flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-3.5 text-emerald-500" }), "Trend Realisasi Harian (30 Hari Terakhir)"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-slate-400 font-medium",
											children: "Harian (Rp)"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
										width: "100%",
										height: 160,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
											data: selectedDetail.trend_harian,
											margin: {
												top: 5,
												right: 10,
												left: -15,
												bottom: 5
											},
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
													strokeDasharray: "3 3",
													className: "stroke-slate-200 dark:stroke-slate-700",
													opacity: .5
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
													dataKey: "tanggal",
													tick: { fontSize: 9 },
													tickFormatter: (v) => {
														const d = new Date(v);
														return `${d.getDate()}/${d.getMonth() + 1}`;
													}
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
													tick: { fontSize: 9 },
													tickFormatter: (v) => `${(v / 1e3).toFixed(0)}rb`
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
													formatter: (value) => [formatRp(Number(value) || 0), "Nominal"],
													labelFormatter: (v) => `Tanggal: ${v}`,
													contentStyle: {
														fontSize: 11,
														borderRadius: 12,
														backgroundColor: "rgba(15, 23, 42, 0.95)",
														borderColor: "rgba(51, 65, 85, 0.8)",
														color: "#fff"
													}
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
													type: "monotone",
													dataKey: "nominal",
													stroke: "#10b981",
													strokeWidth: 2.5,
													dot: {
														r: 3,
														fill: "#10b981"
													},
													activeDot: { r: 5 }
												})
											]
										})
									})]
								}), selectedDetail.trend_mingguan && selectedDetail.trend_mingguan.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3.5 rounded-2xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-700/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mb-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs font-extrabold text-slate-700 dark:text-slate-200 flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "size-3.5 text-blue-500" }), "Trend Realisasi Mingguan (12 Minggu Terakhir)"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] text-slate-400 font-medium",
											children: "Mingguan (Rp & Volume SPPT)"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
										width: "100%",
										height: 170,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
											data: selectedDetail.trend_mingguan,
											margin: {
												top: 5,
												right: 10,
												left: -15,
												bottom: 5
											},
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
													strokeDasharray: "3 3",
													className: "stroke-slate-200 dark:stroke-slate-700",
													opacity: .5
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
													dataKey: "mulai",
													tick: { fontSize: 8 },
													tickFormatter: (_, index) => {
														const item = selectedDetail.trend_mingguan?.[index];
														if (!item) return "";
														const d1 = new Date(item.mulai);
														const d2 = new Date(item.selesai);
														return `${d1.getDate()}/${d1.getMonth() + 1}-${d2.getDate()}/${d2.getMonth() + 1}`;
													}
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
													tick: { fontSize: 9 },
													tickFormatter: (v) => v >= 1e6 ? `${(v / 1e6).toFixed(1)}jt` : `${(v / 1e3).toFixed(0)}rb`
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
													formatter: (value, name) => [name === "nominal" ? formatRp(Number(value) || 0) : `${value} Lembar`, name === "nominal" ? "Nominal Realisasi" : "Jumlah SPPT"],
													labelFormatter: (_, payload) => {
														const item = payload?.[0]?.payload;
														if (!item) return "Minggu";
														return `Rentang: ${item.mulai} s/d ${item.selesai} (${item.jumlah_sppt || 0} SPPT)`;
													},
													contentStyle: {
														fontSize: 11,
														borderRadius: 12,
														backgroundColor: "rgba(15, 23, 42, 0.95)",
														borderColor: "rgba(51, 65, 85, 0.8)",
														color: "#fff"
													}
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
													dataKey: "nominal",
													fill: "#3b82f6",
													radius: [
														6,
														6,
														0,
														0
													],
													maxBarSize: 36
												})
											]
										})
									})]
								})]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "py-6 text-center text-slate-400 text-xs rounded-xl bg-slate-50 dark:bg-slate-800/30 border border-dashed border-slate-200 dark:border-slate-700",
								children: "Belum ada riwayat transaksi pembayaran tercatat untuk kolektor ini."
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center justify-center py-12",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-6 text-emerald-500 animate-spin" })
					})]
				})
			})
		]
	});
}
//#endregion
export { KolektorPerformancePage as component };
