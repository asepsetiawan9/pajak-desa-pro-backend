import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { t as setoranKecamatanService } from "./setoranKecamatanService-gOlpOSNj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/setoranKecamatanStore-9CbL7icp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function useSetoranKecamatanStore() {
	const [items, setItems] = (0, import_react.useState)([]);
	const [summary, setSummary] = (0, import_react.useState)(null);
	const [isLoading, setIsLoading] = (0, import_react.useState)(false);
	const [isSummaryLoading, setIsSummaryLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const fetchItems = (0, import_react.useCallback)(async (params) => {
		setIsLoading(true);
		setError(null);
		try {
			const res = await setoranKecamatanService.getAll(params);
			setItems(res.data);
		} catch (err) {
			console.error("Gagal memuat list setoran kecamatan:", err);
			setError(err.message || "Gagal memuat data setoran.");
		} finally {
			setIsLoading(false);
		}
	}, []);
	const fetchSummary = (0, import_react.useCallback)(async (params) => {
		setIsSummaryLoading(true);
		try {
			const res = await setoranKecamatanService.getSummary(params);
			setSummary(res);
		} catch (err) {
			console.error("Gagal memuat summary setoran kecamatan:", err);
		} finally {
			setIsSummaryLoading(false);
		}
	}, []);
	const createSetoran = async (payload) => {
		const newItem = await setoranKecamatanService.create(payload);
		setItems((prev) => [newItem, ...prev]);
		return newItem;
	};
	const updateSetoran = async (id, payload) => {
		const updated = await setoranKecamatanService.update(id, payload);
		setItems((prev) => prev.map((item) => item.id === id ? updated : item));
		return updated;
	};
	const verifySetoran = async (id, status, catatanKecamatan, tanggalDiterima) => {
		const verified = await setoranKecamatanService.verify(id, status, catatanKecamatan, tanggalDiterima);
		if (status === "APPROVE_DELETE" || verified === null) {
			setItems((prev) => prev.filter((item) => item.id !== id));
			return null;
		}
		setItems((prev) => prev.map((item) => item.id === id ? verified : item));
		return verified;
	};
	const deleteSetoran = async (id) => {
		const res = await setoranKecamatanService.delete(id);
		if (res.is_deleted) setItems((prev) => prev.filter((item) => item.id !== id));
		else if (res.setoran) setItems((prev) => prev.map((item) => item.id === id ? res.setoran : item));
		return {
			is_deleted: res.is_deleted,
			message: res.message
		};
	};
	return {
		items,
		summary,
		isLoading,
		isSummaryLoading,
		error,
		fetchItems,
		fetchSummary,
		createSetoran,
		updateSetoran,
		verifySetoran,
		deleteSetoran
	};
}
//#endregion
export { useSetoranKecamatanStore as t };
