import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { i as useAuthStore, n as apiClient, o as useUserStore, t as ROLE_LABELS } from "./authStore-CZRDvP0Z.mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-YtzMxdp3.mjs";
import { t as Input } from "./input-BBQFjwfK.mjs";
import { i as useSettingsStore, r as settingService, t as defaultSettings } from "./settingsStore-BBOTJBY5.mjs";
import { $ as Layers, A as RotateCcw, C as ShieldAlert, Dt as Clock, E as Server, H as Moon, I as Percent, N as Printer, P as Plus, Qt as Archive, S as ShieldCheck, St as Database, T as Settings, V as Palette, W as MapPin, Wt as Building2, Y as LoaderCircle, Zt as ArrowDownToLine, b as SlidersVertical, bt as Download, et as Laptop, f as Trash2, ft as FileText, g as Sun, ht as FileCode, it as History, j as RefreshCw, jt as CircleCheck, k as Save, nt as KeyRound, ot as HardDrive, s as Upload, u as TriangleAlert, ut as FolderArchive, zt as Check } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-BnDjHZuV.mjs";
import { t as Badge } from "./badge-DeRhpfUp.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, o as formatRp, r as CardDescription, t as Card } from "./card-CfCIYh5x.mjs";
import { t as desaService } from "./desaService-B2uJrXze.mjs";
import { t as Label } from "./label-CiVZqe-N.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-HQswfJbV.mjs";
import { t as Switch } from "./switch-CXK2mflC.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Swal } from "../_libs/sweetalert2.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-B4v5HtqW.mjs";
import { t as useThemeStore } from "./themeStore-CN2DoDyW.mjs";
import { t as dusunService } from "./dusunService-AJ7_2sYC.mjs";
import { t as Textarea } from "./textarea-DnDCSoN1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pengaturan-D4olifMC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var backupService = {
	async getSummary(desaId) {
		const params = {};
		if (desaId && desaId !== "all") params.desa_id = desaId;
		return apiClient.get("/backups/summary", params);
	},
	async listBackups(desaId) {
		const params = {};
		if (desaId && desaId !== "all") params.desa_id = desaId;
		return apiClient.get("/backups", params);
	},
	async createBackup(payload) {
		return apiClient.post("/backups", payload);
	},
	async downloadBackup(filename) {
		const cleanName = encodeURIComponent(filename);
		return apiClient.downloadBlob(`/backups/${cleanName}/download`, filename);
	},
	async deleteBackup(filename, password) {
		const cleanName = encodeURIComponent(filename);
		return apiClient.delete(`/backups/${cleanName}`, { password });
	},
	async restoreBackup(payload) {
		return apiClient.post("/backups/restore", payload);
	}
};
function Pengaturan() {
	const { settings, updateSettings, resetSettings } = useSettingsStore();
	const { theme, setTheme } = useThemeStore();
	const { user: authUser } = useAuthStore();
	const { getActiveUser } = useUserStore();
	const currentUser = authUser || getActiveUser();
	const currentRole = currentUser?.role || "SUPER_ADMIN";
	const userDesaId = currentUser?.desa_id;
	const isSuperAdmin = currentRole === "SUPER_ADMIN_SYSTEM" || !userDesaId && currentRole === "SUPER_ADMIN";
	const isReadOnlyMode = !isSuperAdmin;
	const [filterDesa, setFilterDesa] = (0, import_react.useState)("all");
	const [desasList, setDesasList] = (0, import_react.useState)([]);
	const [formData, setFormData] = (0, import_react.useState)(settings);
	const [isSaving, setIsSaving] = (0, import_react.useState)(false);
	const [isLoadingDesaSettings, setIsLoadingDesaSettings] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (isSuperAdmin) desaService.getAll().then((res) => {
			if (res.data) setDesasList(res.data);
		}).catch((err) => console.error("Gagal memuat daftar desa di Pengaturan:", err));
	}, [isSuperAdmin]);
	(0, import_react.useEffect)(() => {
		if (isSuperAdmin && filterDesa !== "all") {
			setIsLoadingDesaSettings(true);
			settingService.getSettings(filterDesa).then((res) => {
				if (res.data) setFormData((prev) => ({
					...defaultSettings,
					...prev,
					...res.data
				}));
			}).catch((err) => {
				console.error("Gagal memuat pengaturan desa:", err);
				toast.error("Gagal mengambil pengaturan khusus desa terpilih.");
			}).finally(() => setIsLoadingDesaSettings(false));
		} else setFormData(settings);
	}, [
		settings,
		filterDesa,
		isSuperAdmin
	]);
	const [dusunsList, setDusunsList] = (0, import_react.useState)([]);
	const [isLoadingDusuns, setIsLoadingDusuns] = (0, import_react.useState)(false);
	const [newDusunName, setNewDusunName] = (0, import_react.useState)("");
	const [newDusunKode, setNewDusunKode] = (0, import_react.useState)("");
	const [newDusunRtRw, setNewDusunRtRw] = (0, import_react.useState)("");
	const [isAddingDusun, setIsAddingDusun] = (0, import_react.useState)(false);
	const targetDesaForDusun = (0, import_react.useMemo)(() => {
		if (isSuperAdmin) return filterDesa !== "all" ? filterDesa : void 0;
		return userDesaId;
	}, [
		isSuperAdmin,
		filterDesa,
		userDesaId
	]);
	const fetchDusuns = async () => {
		setIsLoadingDusuns(true);
		try {
			const res = await dusunService.getAll({ desa_id: targetDesaForDusun });
			if (res.data) setDusunsList(res.data);
		} catch (err) {
			console.error("Gagal memuat master dusun di pengaturan:", err);
		} finally {
			setIsLoadingDusuns(false);
		}
	};
	(0, import_react.useEffect)(() => {
		fetchDusuns();
	}, [targetDesaForDusun]);
	const handleAddDusun = async (e) => {
		e.preventDefault();
		if (!newDusunName.trim()) {
			toast.error("Nama dusun wajib diisi.");
			return;
		}
		setIsAddingDusun(true);
		try {
			await dusunService.create({
				desa_id: targetDesaForDusun,
				nama_dusun: newDusunName.trim().toUpperCase(),
				kode_dusun: newDusunKode.trim() || void 0,
				rt_rw: newDusunRtRw.trim() || void 0,
				status_aktif: true
			});
			toast.success(`Master Dusun ${newDusunName.toUpperCase()} berhasil ditambahkan.`);
			setNewDusunName("");
			setNewDusunKode("");
			setNewDusunRtRw("");
			fetchDusuns();
		} catch (err) {
			toast.error(err?.message || "Gagal menambahkan dusun.");
		} finally {
			setIsAddingDusun(false);
		}
	};
	const handleDeleteDusun = async (item) => {
		if (window.confirm(`Hapus master dusun "${item.nama_dusun}"?`)) try {
			await dusunService.delete(item.id);
			toast.success(`Dusun ${item.nama_dusun} dihapus.`);
			fetchDusuns();
		} catch (err) {
			toast.error("Gagal menghapus dusun.");
		}
	};
	const handleToggleDusun = async (item) => {
		try {
			await dusunService.toggleStatus(item.id);
			toast.success(`Status dusun ${item.nama_dusun} diperbarui.`);
			fetchDusuns();
		} catch (err) {
			toast.error("Gagal mengubah status dusun.");
		}
	};
	const handleChange = (key, value) => {
		setFormData((prev) => {
			const updated = {
				...prev,
				[key]: value
			};
			if (key === "namaDesa" || key === "kecamatan" || key === "kabupaten") {
				const kab = key === "kabupaten" ? value : prev.kabupaten;
				const kec = key === "kecamatan" ? value : prev.kecamatan;
				const desa = key === "namaDesa" ? value : prev.namaDesa;
				if (!prev.headerStruk || prev.headerStruk.includes("DESA MALANGBONG") || prev.headerStruk.includes("DESA BARUDUA") || prev.headerStruk.startsWith("PEMERINTAH KABUPATEN")) updated.headerStruk = `PEMERINTAH KABUPATEN ${kab.toUpperCase().replace(/^KABUPATEN\s+/, "").replace(/^KOTA\s+/, "")}\nKECAMATAN ${kec.toUpperCase()} - ${desa.toUpperCase().startsWith("DESA") ? desa.toUpperCase() : `DESA ${desa.toUpperCase()}`}`;
			}
			return updated;
		});
	};
	const handleSave = async () => {
		setIsSaving(true);
		try {
			const targetDesaParam = isSuperAdmin && filterDesa !== "all" ? filterDesa : void 0;
			await updateSettings(formData, targetDesaParam);
			toast.success("Pengaturan sistem berhasil diperbarui!", {
				description: targetDesaParam ? `Pengaturan khusus desa ${desasList.find((d) => String(d.id) === filterDesa)?.nama_desa || ""} tersimpan.` : "Seluruh modul aplikasi telah disesuaikan dan tersimpan di database backend.",
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-emerald-400" })
			});
		} catch (err) {
			toast.error("Gagal menyimpan pengaturan ke database backend.", { description: "Periksa koneksi ke server backend Laravel." });
		} finally {
			setIsSaving(false);
		}
	};
	const handleReset = async () => {
		if (window.confirm("Apakah Anda yakin ingin mengembalikan seluruh pengaturan ke standar pabrik?")) {
			setIsSaving(true);
			try {
				await resetSettings(isSuperAdmin && filterDesa !== "all" ? filterDesa : void 0);
				setFormData(defaultSettings);
				toast.info("Pengaturan dikembalikan ke standar awal database.");
			} catch (err) {
				toast.error("Gagal mengembalikan pengaturan pada database backend.");
			} finally {
				setIsSaving(false);
			}
		}
	};
	const [backupSummary, setBackupSummary] = (0, import_react.useState)(null);
	const [backupsList, setBackupsList] = (0, import_react.useState)([]);
	const [isLoadingBackups, setIsLoadingBackups] = (0, import_react.useState)(false);
	const [downloadingFilename, setDownloadingFilename] = (0, import_react.useState)(null);
	const [isCreateBackupModalOpen, setIsCreateBackupModalOpen] = (0, import_react.useState)(false);
	const [createFormat, setCreateFormat] = (0, import_react.useState)("zip");
	const [createScopeDesa, setCreateScopeDesa] = (0, import_react.useState)("all");
	const [createNotes, setCreateNotes] = (0, import_react.useState)("");
	const [isCreatingBackup, setIsCreatingBackup] = (0, import_react.useState)(false);
	const [directExportFormat, setDirectExportFormat] = (0, import_react.useState)(null);
	const [isRestoreModalOpen, setIsRestoreModalOpen] = (0, import_react.useState)(false);
	const [restoreSource, setRestoreSource] = (0, import_react.useState)("server");
	const [selectedServerBackup, setSelectedServerBackup] = (0, import_react.useState)("");
	const [uploadFileContent, setUploadFileContent] = (0, import_react.useState)("");
	const [uploadFileName, setUploadFileName] = (0, import_react.useState)("");
	const [restorePassword, setRestorePassword] = (0, import_react.useState)("");
	const [isRestoring, setIsRestoring] = (0, import_react.useState)(false);
	const fetchBackupsData = async () => {
		setIsLoadingBackups(true);
		try {
			const targetDesa = isSuperAdmin && filterDesa !== "all" ? filterDesa : userDesaId;
			const [sumRes, listRes] = await Promise.all([backupService.getSummary(targetDesa), backupService.listBackups(targetDesa)]);
			if (sumRes.data) setBackupSummary(sumRes.data);
			if (listRes.data) setBackupsList(listRes.data);
		} catch (err) {
			console.error("Gagal memuat data backup:", err);
		} finally {
			setIsLoadingBackups(false);
		}
	};
	(0, import_react.useEffect)(() => {
		fetchBackupsData();
	}, [
		filterDesa,
		userDesaId,
		isSuperAdmin
	]);
	const handleCreateBackup = async (e) => {
		e.preventDefault();
		setIsCreatingBackup(true);
		try {
			const targetDesa = isSuperAdmin && createScopeDesa !== "all" ? createScopeDesa : userDesaId || void 0;
			const res = await backupService.createBackup({
				format: createFormat,
				desa_id: targetDesa,
				notes: createNotes.trim() || void 0
			});
			toast.success("Cadangan database berhasil dibuat!", {
				description: `Berkas ${res.data.filename} (${res.data.size_human}, ${res.data.total_records} baris data) tersimpan aman di server.`,
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-emerald-400" })
			});
			setIsCreateBackupModalOpen(false);
			setCreateNotes("");
			fetchBackupsData();
		} catch (err) {
			toast.error(err?.message || "Gagal membuat backup database.");
		} finally {
			setIsCreatingBackup(false);
		}
	};
	const handleDirectExport = async (format) => {
		setDirectExportFormat(format);
		try {
			toast.info(`Menyiapkan paket cadangan ${format.toUpperCase()}...`);
			const targetDesa = isSuperAdmin && filterDesa !== "all" ? filterDesa : userDesaId || void 0;
			const res = await backupService.createBackup({
				format,
				desa_id: targetDesa,
				notes: `Direct export download (${format.toUpperCase()})`
			});
			if (res.data?.filename) {
				await backupService.downloadBackup(res.data.filename);
				toast.success(`Cadangan ${format.toUpperCase()} (${res.data.size_human || ""}) berhasil diunduh ke laptop Anda!`, { icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-emerald-400" }) });
			}
			fetchBackupsData();
		} catch (err) {
			toast.error(err?.message || "Gagal melakukan direct export backup.");
		} finally {
			setDirectExportFormat(null);
		}
	};
	const handleDownloadFile = async (item) => {
		setDownloadingFilename(item.filename);
		try {
			toast.info(`Mengunduh berkas ${item.filename}...`);
			await backupService.downloadBackup(item.filename);
			toast.success(`Berkas ${item.filename} berhasil diunduh ke komputer Anda.`, { icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-emerald-400" }) });
		} catch (err) {
			toast.error(err?.message || "Gagal mengunduh file cadangan.");
		} finally {
			setDownloadingFilename(null);
		}
	};
	const handleDeleteBackup = async (item) => {
		const { value: password, isConfirmed } = await Swal.fire({
			title: "Hapus File Cadangan?",
			html: `
        <div class="text-left text-xs space-y-2">
          <p class="text-slate-600 dark:text-slate-300">Anda akan menghapus berkas backup server berikut secara permanen:</p>
          <div class="p-3 bg-slate-100 dark:bg-slate-800 rounded-xl font-mono text-[11px] text-slate-800 dark:text-slate-200">
            <strong>${item.filename}</strong><br/>
            Ukuran: ${item.size_human} | Dibuat: ${item.created_at}
          </div>
          <p class="text-rose-600 dark:text-rose-400 font-bold">Masukkan password akun Anda untuk konfirmasi keamanan:</p>
        </div>
      `,
			input: "password",
			inputPlaceholder: "Password akun Anda...",
			inputAttributes: {
				autocapitalize: "off",
				autocorrect: "off"
			},
			showCancelButton: true,
			confirmButtonText: "Ya, Hapus Permanen",
			cancelButtonText: "Batal",
			confirmButtonColor: "#e11d48",
			cancelButtonColor: "#64748b",
			showLoaderOnConfirm: true,
			preConfirm: async (pass) => {
				if (!pass) {
					Swal.showValidationMessage("Password akun wajib diisi.");
					return false;
				}
				try {
					await backupService.deleteBackup(item.filename, pass);
					return true;
				} catch (err) {
					Swal.showValidationMessage(err?.message || "Password salah atau gagal menghapus backup.");
					return false;
				}
			},
			allowOutsideClick: () => !Swal.isLoading()
		});
		if (isConfirmed) {
			toast.success(`Berkas ${item.filename} berhasil dihapus dari server.`);
			fetchBackupsData();
		}
	};
	const handleOpenRestoreForFile = (item) => {
		setRestoreSource("server");
		setSelectedServerBackup(item.filename);
		setRestorePassword("");
		setIsRestoreModalOpen(true);
	};
	const handleUploadFileForRestore = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		setUploadFileName(file.name);
		const fileReader = new FileReader();
		fileReader.onload = (event) => {
			try {
				const content = event.target?.result;
				setUploadFileContent(content);
				toast.info(`File ${file.name} siap dipulihkan.`);
			} catch (err) {
				toast.error("Gagal membaca berkas upload.");
			}
		};
		fileReader.readAsText(file, "UTF-8");
	};
	const handleExecuteRestore = async (e) => {
		e.preventDefault();
		if (!restorePassword) {
			toast.error("Password akun wajib diisi demi keamanan.");
			return;
		}
		if (restoreSource === "server" && !selectedServerBackup) {
			toast.error("Pilih file cadangan server yang ingin dipulihkan.");
			return;
		}
		if (restoreSource === "upload" && !uploadFileContent) {
			toast.error("Pilih file JSON cadangan dari komputer Anda.");
			return;
		}
		if (!(await Swal.fire({
			title: "⚠️ Konfirmasi Pemulihan Database",
			html: `
        <div class="text-left text-xs space-y-2">
          <p class="text-slate-700 dark:text-slate-300">
            Proses pemulihan akan menggantikan data tabel operasional saat ini dengan data yang tersimpan pada cadangan:
          </p>
          <div class="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700/50 rounded-xl font-semibold text-amber-800 dark:text-amber-300 text-[11px]">
            Sumber: ${restoreSource === "server" ? selectedServerBackup : uploadFileName}
          </div>
          <p class="text-rose-600 dark:text-rose-400 font-bold">
            Pastikan tidak ada transaksi kasir yang sedang berlangsung saat proses pemulihan. Lanjutkan?
          </p>
        </div>
      `,
			icon: "warning",
			showCancelButton: true,
			confirmButtonText: "Ya, Mulai Pemulihan Data",
			cancelButtonText: "Batalkan",
			confirmButtonColor: "#059669",
			cancelButtonColor: "#64748b"
		})).isConfirmed) return;
		setIsRestoring(true);
		try {
			const targetDesa = isSuperAdmin && filterDesa !== "all" ? filterDesa : userDesaId;
			const res = await backupService.restoreBackup({
				password: restorePassword,
				filename: restoreSource === "server" ? selectedServerBackup : void 0,
				file_content: restoreSource === "upload" ? uploadFileContent : void 0,
				desa_id: targetDesa
			});
			await Swal.fire({
				title: "✅ Pemulihan Database Berhasil!",
				html: `
          <div class="text-left text-xs space-y-2">
            <p class="text-emerald-700 dark:text-emerald-300 font-bold">
              Database berhasil dipulihkan secara utuh tanpa error (${res.data?.total_restored || 0} baris data).
            </p>
            <p class="text-slate-600 dark:text-slate-400 text-[11px]">
              Seluruh modul sistem kini telah tersinkronisasi dengan kondisi data cadangan.
            </p>
          </div>
        `,
				icon: "success",
				confirmButtonColor: "#059669"
			});
			setIsRestoreModalOpen(false);
			setRestorePassword("");
			setUploadFileContent("");
			setUploadFileName("");
			fetchBackupsData();
		} catch (err) {
			toast.error(err?.message || "Gagal memulihkan database. Periksa kembali password dan keutuhan file.");
		} finally {
			setIsRestoring(false);
		}
	};
	const handleExportBackup = () => {
		try {
			const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(formData, null, 2));
			const downloadAnchor = document.createElement("a");
			downloadAnchor.setAttribute("href", dataStr);
			downloadAnchor.setAttribute("download", `BACKUP_PENGATURAN_SIPABAR_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.json`);
			document.body.appendChild(downloadAnchor);
			downloadAnchor.click();
			downloadAnchor.remove();
			toast.success("Backup file konfigurasi JSON berhasil diunduh.");
		} catch (err) {
			toast.error("Gagal mengunduh backup file.");
		}
	};
	const handleImportBackup = (e) => {
		const fileReader = new FileReader();
		if (e.target.files && e.target.files[0]) {
			fileReader.readAsText(e.target.files[0], "UTF-8");
			fileReader.onload = async (event) => {
				try {
					const parsed = JSON.parse(event.target?.result);
					if (parsed && typeof parsed === "object") {
						const merged = {
							...defaultSettings,
							...parsed
						};
						setIsSaving(true);
						await updateSettings(merged, isSuperAdmin && filterDesa !== "all" ? filterDesa : void 0);
						setFormData(merged);
						toast.success("Konfigurasi dari file backup berhasil diimpor & tersimpan ke backend!");
					}
				} catch (err) {
					toast.error("File JSON tidak valid atau terkorupsi.");
				} finally {
					setIsSaving(false);
				}
			};
		}
	};
	const selectedDesaObj = (0, import_react.useMemo)(() => {
		if (filterDesa === "all") return null;
		return desasList.find((d) => String(d.id) === filterDesa) || null;
	}, [filterDesa, desasList]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-5xl space-y-6 pb-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-700 via-emerald-600 to-teal-700 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 p-6 text-white shadow-xl border border-emerald-500/30 dark:border-slate-800 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "inline-flex items-center gap-2 rounded-full bg-white/15 dark:bg-emerald-500/10 border border-white/30 dark:border-emerald-500/30 px-3 py-1 text-xs font-bold uppercase tracking-wider text-emerald-50 dark:text-emerald-400 backdrop-blur-md",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-3.5 text-amber-300" }), " Konfigurasi Portal SIPABAR"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-2xl font-black tracking-tight text-white sm:text-3xl",
								children: "Pengaturan Sistem & Parameter"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs sm:text-sm text-emerald-50 dark:text-slate-300 font-medium",
								children: "Sesuaikan identitas instansi, pejabat penandatangan, fee kolektor PBB-P2, format resi thermal, dan kelola data."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-2.5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: handleSave,
							disabled: isSaving || isReadOnlyMode || isLoadingDesaSettings,
							title: isReadOnlyMode ? "Hanya Super Admin yang dapat menyimpan perubahan" : "Simpan Pengaturan",
							className: "bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs px-5 py-2.5 rounded-xl shadow-md gap-1.5 transition-transform active:scale-95 disabled:opacity-50",
							children: isSaving ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), " Menyimpan..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), " Simpan Pengaturan"] })
						})
					})]
				})
			}),
			isSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white/80 dark:bg-slate-900/80 border border-emerald-500/30 rounded-2xl p-4 shadow-sm backdrop-blur-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-2 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-black uppercase text-slate-800 dark:text-slate-200 tracking-wide",
						children: "Target Wilayah / Pengaturan Desa"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-slate-500 dark:text-slate-400",
						children: filterDesa === "all" ? "Mengatur konfigurasi Templat Utama / Global seluruh desa" : `Mengatur konfigurasi spesifik Desa ${selectedDesaObj?.nama_desa || ""}`
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: filterDesa,
						onValueChange: (val) => setFilterDesa(val),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "w-full sm:w-[260px] text-xs font-bold bg-white dark:bg-slate-950 border-emerald-300 dark:border-slate-800 text-emerald-800 dark:text-emerald-300",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Filter Desa..." })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "all",
							children: "🏘️ Seluruh Desa (Global Template)"
						}), desasList.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
							value: String(d.id),
							children: [
								"🏛️ ",
								d.nama_desa,
								" (",
								d.kode_desa,
								")"
							]
						}, d.id))] })]
					}), isLoadingDesaSettings && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin text-emerald-500" })]
				})]
			}),
			isReadOnlyMode && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-300 text-xs font-medium flex items-center gap-3 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-5 shrink-0 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-bold",
					children: [
						"Mode Lihat Pengaturan (Akses Peran: ",
						ROLE_LABELS[currentRole]?.label || currentRole,
						")"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] opacity-90",
					children: [
						"Anda memiliki hak akses ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Read-Only" }),
						" pada konfigurasi sistem. Perubahan nilai fee, identitas instansi, dan parameter portal hanya dapat disimpan oleh ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Super Admin" }),
						"."
					]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				defaultValue: "instansi",
				className: "space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
						className: "grid w-full grid-cols-2 gap-1.5 rounded-2xl border border-emerald-200 dark:border-border bg-emerald-50/70 dark:bg-card/80 p-1.5 text-muted-foreground sm:grid-cols-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "instansi",
								className: "rounded-xl text-xs font-extrabold data-[state=active]:bg-emerald-600 data-[state=active]:text-white dark:data-[state=active]:bg-primary dark:data-[state=active]:text-primary-foreground gap-1.5 py-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4" }), " Instansi"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "dusun",
								className: "rounded-xl text-xs font-extrabold data-[state=active]:bg-emerald-600 data-[state=active]:text-white dark:data-[state=active]:bg-primary dark:data-[state=active]:text-primary-foreground gap-1.5 py-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }), " Master Dusun"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "keuangan",
								className: "rounded-xl text-xs font-extrabold data-[state=active]:bg-emerald-600 data-[state=active]:text-white dark:data-[state=active]:bg-primary dark:data-[state=active]:text-primary-foreground gap-1.5 py-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Percent, { className: "size-4" }), " Parameter PBB"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "cetak",
								className: "rounded-xl text-xs font-extrabold data-[state=active]:bg-emerald-600 data-[state=active]:text-white dark:data-[state=active]:bg-primary dark:data-[state=active]:text-primary-foreground gap-1.5 py-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), " Cetak & Resi"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "tampilan",
								className: "rounded-xl text-xs font-extrabold data-[state=active]:bg-emerald-600 data-[state=active]:text-white dark:data-[state=active]:bg-primary dark:data-[state=active]:text-primary-foreground gap-1.5 py-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Palette, { className: "size-4" }), " Tampilan"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "data",
								className: "rounded-xl text-xs font-extrabold data-[state=active]:bg-emerald-600 data-[state=active]:text-white dark:data-[state=active]:bg-primary dark:data-[state=active]:text-primary-foreground gap-1.5 py-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "size-4" }), " Data"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "instansi",
						className: "space-y-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "border-emerald-100/80 dark:border-slate-800/80 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md shadow-xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
								className: "border-b border-emerald-100/80 dark:border-slate-800/80 bg-emerald-50/60 dark:bg-slate-950/60 px-6 py-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center justify-between",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
										className: "text-base font-extrabold text-slate-900 dark:text-slate-100 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), " Identitas Wilayah & Instansi"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, {
										className: "text-xs text-slate-600 dark:text-slate-400",
										children: "Informasi ini digunakan pada Kop Resi STTS, Laporan 21-Kolom, dan Header Aplikasi."
									})] })
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
								className: "grid gap-4 p-6 sm:grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "namaDesa",
											className: "text-xs font-bold text-slate-700 dark:text-slate-300",
											children: "Nama Desa / Kelurahan"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "namaDesa",
											value: formData.namaDesa,
											onChange: (e) => handleChange("namaDesa", e.target.value),
											className: "bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-xs text-slate-900 dark:text-slate-100 font-semibold focus:border-emerald-500"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "kecamatan",
											className: "text-xs font-bold text-slate-700 dark:text-slate-300",
											children: "Kecamatan"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "kecamatan",
											value: formData.kecamatan,
											onChange: (e) => handleChange("kecamatan", e.target.value),
											className: "bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-xs text-slate-900 dark:text-slate-100 font-semibold focus:border-emerald-500"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "kabupaten",
											className: "text-xs font-bold text-slate-700 dark:text-slate-300",
											children: "Kabupaten / Kota"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "kabupaten",
											value: formData.kabupaten,
											onChange: (e) => handleChange("kabupaten", e.target.value),
											className: "bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-xs text-slate-900 dark:text-slate-100 font-semibold focus:border-emerald-500"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "kodeDesa",
											className: "text-xs font-bold text-slate-700 dark:text-slate-300",
											children: "Kode NOP Pemda / Desa"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "kodeDesa",
											value: formData.kodeDesa,
											onChange: (e) => handleChange("kodeDesa", e.target.value),
											className: "bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-xs text-amber-600 dark:text-amber-400 font-mono font-bold focus:border-emerald-500"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "teleponDesa",
											className: "text-xs font-bold text-slate-700 dark:text-slate-300",
											children: "No. Telepon Kantor Desa"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "teleponDesa",
											value: formData.teleponDesa,
											onChange: (e) => handleChange("teleponDesa", e.target.value),
											className: "bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-xs text-slate-900 dark:text-slate-100 focus:border-emerald-500"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "alamatDesa",
											className: "text-xs font-bold text-slate-700 dark:text-slate-300",
											children: "Alamat Lengkap Kantor Desa"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "alamatDesa",
											value: formData.alamatDesa,
											onChange: (e) => handleChange("alamatDesa", e.target.value),
											className: "bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-xs text-slate-900 dark:text-slate-100 focus:border-emerald-500"
										})]
									})
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "border-emerald-100/80 dark:border-slate-800/80 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md shadow-xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
								className: "border-b border-emerald-100/80 dark:border-slate-800/80 bg-emerald-50/60 dark:bg-slate-950/60 px-6 py-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
									className: "text-base font-extrabold text-slate-900 dark:text-slate-100 flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersVertical, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), " Pejabat Penandatangan & Kolektor (Konfigurasi Dinamis)"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, {
									className: "text-xs text-slate-600 dark:text-slate-400",
									children: "Tentukan struktur jabatan (Camat, Kepala Desa, Lurah, Kasi, Kolektor, dsb.) dan nama pejabat penandatangan dokumen resmi."
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
								className: "space-y-6 p-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-emerald-200/80 dark:border-slate-800 bg-emerald-50/30 dark:bg-slate-950/40 p-4 space-y-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between border-b border-emerald-100 dark:border-slate-800 pb-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "text-xs font-black uppercase text-emerald-800 dark:text-emerald-400 tracking-wider flex items-center gap-1.5",
											children: "🏛️ Pejabat Penandatangan 1 (Penandatangan Utama / Mengetahui)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300",
											children: "Posisi Kiri / Atas Laporan"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-4 sm:grid-cols-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													htmlFor: "jabatanKades",
													className: "text-xs font-bold text-slate-700 dark:text-slate-300",
													children: "Jabatan Penandatangan 1"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "space-y-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
														value: [
															"Kepala Desa",
															"Camat",
															"Lurah"
														].includes(formData.jabatanKades || "Kepala Desa") ? formData.jabatanKades || "Kepala Desa" : "Custom",
														onValueChange: (val) => {
															if (val !== "Custom") handleChange("jabatanKades", val);
														},
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
															className: "w-full text-xs font-bold bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Pilih Preset Jabatan..." })
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "Kepala Desa",
																children: "Kepala Desa"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "Camat",
																children: "Camat"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "Lurah",
																children: "Lurah"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "Custom",
																children: "✍️ Kustom (Input Manual)"
															})
														] })]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														id: "jabatanKades",
														value: formData.jabatanKades || "Kepala Desa",
														onChange: (e) => handleChange("jabatanKades", e.target.value),
														placeholder: "Contoh: Camat Malangbong / Kepala Desa",
														className: "bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-xs font-bold text-emerald-800 dark:text-emerald-300 focus:border-emerald-500"
													})]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													htmlFor: "namaKades",
													className: "text-xs font-bold text-slate-700 dark:text-slate-300",
													children: "Nama Pejabat Penandatangan 1"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													id: "namaKades",
													value: formData.namaKades,
													onChange: (e) => handleChange("namaKades", e.target.value),
													placeholder: "Nama Lengkap Pejabat",
													className: "bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-xs text-slate-900 dark:text-slate-100 font-semibold focus:border-emerald-500"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													htmlFor: "nipKades",
													className: "text-xs font-bold text-slate-700 dark:text-slate-300",
													children: "NIP / NIK Pejabat 1 (Jika ada)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													id: "nipKades",
													value: formData.nipKades,
													onChange: (e) => handleChange("nipKades", e.target.value),
													placeholder: "NIP / NIK Official",
													className: "bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 font-mono focus:border-emerald-500"
												})]
											})
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-teal-200/80 dark:border-slate-800 bg-teal-50/30 dark:bg-slate-950/40 p-4 space-y-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between border-b border-teal-100 dark:border-slate-800 pb-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
											className: "text-xs font-black uppercase text-teal-800 dark:text-teal-400 tracking-wider flex items-center gap-1.5",
											children: "✍️ Pejabat Penandatangan 2 / Kolektor (Pelaksana / Pembuat Laporan)"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-bold px-2 py-0.5 rounded bg-teal-100 dark:bg-teal-900/40 text-teal-700 dark:text-teal-300",
											children: "Posisi Kanan / Kasir Struk"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-4 sm:grid-cols-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													htmlFor: "jabatanPetugas",
													className: "text-xs font-bold text-slate-700 dark:text-slate-300",
													children: "Jabatan Penandatangan 2 / Kolektor"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "space-y-1.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
														value: [
															"Bendahara / Kolektor Utama PBB",
															"Kasi Pemerintahan",
															"Sekretaris Desa",
															"Kolektor PBB Desa"
														].includes(formData.jabatanPetugas || "Bendahara / Kolektor Utama PBB") ? formData.jabatanPetugas || "Bendahara / Kolektor Utama PBB" : "Custom",
														onValueChange: (val) => {
															if (val !== "Custom") handleChange("jabatanPetugas", val);
														},
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
															className: "w-full text-xs font-bold bg-white dark:bg-slate-950 border-teal-200 dark:border-slate-800",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Pilih Preset Jabatan..." })
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "Bendahara / Kolektor Utama PBB",
																children: "Bendahara / Kolektor Utama PBB"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "Kasi Pemerintahan",
																children: "Kasi Pemerintahan"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "Sekretaris Desa",
																children: "Sekretaris Desa"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "Kolektor PBB Desa",
																children: "Kolektor PBB Desa"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "Custom",
																children: "✍️ Kustom (Input Manual)"
															})
														] })]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														id: "jabatanPetugas",
														value: formData.jabatanPetugas || "Bendahara / Kolektor Utama PBB",
														onChange: (e) => handleChange("jabatanPetugas", e.target.value),
														placeholder: "Contoh: Kasi Pemerintahan / Kolektor Desa",
														className: "bg-white dark:bg-slate-950/80 border-teal-200 dark:border-slate-800 text-xs font-bold text-teal-800 dark:text-teal-300 focus:border-teal-500"
													})]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													htmlFor: "namaPetugas",
													className: "text-xs font-bold text-slate-700 dark:text-slate-300",
													children: "Nama Pejabat Penandatangan 2"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													id: "namaPetugas",
													value: formData.namaPetugas,
													onChange: (e) => handleChange("namaPetugas", e.target.value),
													placeholder: "Nama Lengkap Pejabat 2",
													className: "bg-white dark:bg-slate-950/80 border-teal-200 dark:border-slate-800 text-xs text-slate-900 dark:text-slate-100 font-semibold focus:border-teal-500"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													htmlFor: "nipPetugas",
													className: "text-xs font-bold text-slate-700 dark:text-slate-300",
													children: "NIP / NIK Pejabat 2 (Jika ada)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													id: "nipPetugas",
													value: formData.nipPetugas,
													onChange: (e) => handleChange("nipPetugas", e.target.value),
													placeholder: "NIP / NIK Kolektor/Petugas",
													className: "bg-white dark:bg-slate-950/80 border-teal-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 font-mono focus:border-teal-500"
												})]
											})
										]
									})]
								})]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "dusun",
						className: "space-y-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "border-emerald-100/80 dark:border-slate-800/80 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md shadow-xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
								className: "border-b border-emerald-100/80 dark:border-slate-800/80 bg-emerald-50/60 dark:bg-slate-950/60 px-6 py-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
										className: "text-base font-extrabold text-slate-900 dark:text-slate-100 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), " Master Wilayah Dusun"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, {
										className: "text-xs text-slate-600 dark:text-slate-400",
										children: "Kelola daftar dusun desa secara mandiri tanpa harus menunggu import file DHKP. Dusun ini menjadi pilihan penugasan akun Kolektor dan filter laporan."
									})] })
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
								className: "space-y-6 p-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: handleAddDusun,
									className: "p-4 rounded-2xl border border-emerald-200 dark:border-slate-800 bg-emerald-50/40 dark:bg-slate-950/40 space-y-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between border-b border-emerald-100 dark:border-slate-800 pb-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs font-black uppercase text-emerald-800 dark:text-emerald-400 flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), " Tambah Dusun Baru"]
										}), targetDesaForDusun && isSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[11px] font-bold text-emerald-600 dark:text-emerald-400",
											children: ["Desa: ", desasList.find((d) => String(d.id) === String(targetDesaForDusun))?.nama_desa || targetDesaForDusun]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-3 sm:grid-cols-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
													htmlFor: "inputNewDusun",
													className: "text-xs font-bold",
													children: ["Nama Dusun ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-rose-500",
														children: "*"
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													id: "inputNewDusun",
													value: newDusunName,
													onChange: (e) => setNewDusunName(e.target.value),
													placeholder: "Contoh: DUSUN I",
													className: "text-xs font-bold uppercase bg-white dark:bg-slate-950",
													disabled: isAddingDusun
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													htmlFor: "inputNewKode",
													className: "text-xs font-bold",
													children: "Kode Wilayah (Opsional)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													id: "inputNewKode",
													value: newDusunKode,
													onChange: (e) => setNewDusunKode(e.target.value),
													placeholder: "Contoh: 001 / RW 01",
													className: "text-xs font-mono bg-white dark:bg-slate-950",
													disabled: isAddingDusun
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													htmlFor: "inputNewRtRw",
													className: "text-xs font-bold",
													children: "Cakupan RT/RW (Opsional)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														id: "inputNewRtRw",
														value: newDusunRtRw,
														onChange: (e) => setNewDusunRtRw(e.target.value),
														placeholder: "Contoh: RT 01-04",
														className: "text-xs bg-white dark:bg-slate-950 flex-1",
														disabled: isAddingDusun
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														type: "submit",
														disabled: isAddingDusun || !newDusunName.trim(),
														className: "bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-4 shrink-0 rounded-xl gap-1",
														children: [isAddingDusun ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), "Tambah"]
													})]
												})]
											})
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
											className: "text-xs font-black uppercase text-slate-700 dark:text-slate-300",
											children: [
												"Daftar Master Dusun (",
												dusunsList.length,
												" Dusun)"
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											type: "button",
											variant: "ghost",
											size: "sm",
											onClick: fetchDusuns,
											disabled: isLoadingDusuns,
											className: "h-7 text-xs text-slate-500 gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: `size-3 ${isLoadingDusuns ? "animate-spin" : ""}` }), " Refresh"]
										})]
									}), isLoadingDusuns ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-8 text-center text-slate-400",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-6 animate-spin mx-auto text-emerald-500 mb-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs",
											children: "Memuat daftar dusun..."
										})]
									}) : dusunsList.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-8 rounded-2xl border border-dashed border-slate-300 dark:border-slate-800 text-center space-y-2 bg-slate-50/50 dark:bg-slate-950/30",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-8 text-slate-400 mx-auto" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-bold text-slate-700 dark:text-slate-300",
												children: "Belum ada master dusun tersimpan"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-slate-500 max-w-sm mx-auto",
												children: "Gunakan formulir di atas untuk menambahkan dusun pertama di desa ini."
											})
										]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
										children: dusunsList.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/60 flex items-center justify-between hover:border-emerald-500/40 transition-colors shadow-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `size-2.5 rounded-full ${d.status_aktif ? "bg-emerald-500" : "bg-slate-400"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-black uppercase text-slate-900 dark:text-slate-100",
													children: d.nama_dusun
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-[11px] text-slate-500 dark:text-slate-400",
													children: [
														d.kode_dusun ? `Kode: ${d.kode_dusun}` : "",
														" ",
														d.rt_rw ? `· RT: ${d.rt_rw}` : ""
													]
												})] })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => handleToggleDusun(d),
													className: `text-[10px] font-bold px-2 py-0.5 rounded-md ${d.status_aktif ? "bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300" : "bg-slate-200 dark:bg-slate-800 text-slate-500"}`,
													children: d.status_aktif ? "Aktif" : "Nonaktif"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => handleDeleteDusun(d),
													className: "p-1 rounded-lg text-rose-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition",
													title: "Hapus Dusun",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
												})]
											})]
										}, d.id))
									})]
								})]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "keuangan",
						className: "space-y-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "border-emerald-100/80 dark:border-slate-800/80 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md shadow-xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
								className: "border-b border-emerald-100/80 dark:border-slate-800/80 bg-emerald-50/60 dark:bg-slate-950/60 px-6 py-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
									className: "text-base font-extrabold text-slate-900 dark:text-slate-100 flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Percent, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), " Parameter Fee Kolektor & Tahun Pajak"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, {
									className: "text-xs text-slate-600 dark:text-slate-400",
									children: "Atur nominal fee kolektor pajak untuk Wajib Pajak luar desa dan tahun berjalan PBB-P2."
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
								className: "grid gap-6 p-6 sm:grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												htmlFor: "tahunAktif",
												className: "text-xs font-bold text-slate-700 dark:text-slate-300",
												children: "Tahun Pajak Aktif / Berjalan"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												id: "tahunAktif",
												type: "number",
												value: formData.tahunAktif,
												onChange: (e) => handleChange("tahunAktif", parseInt(e.target.value) || 2026),
												className: "bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-sm font-black text-amber-600 dark:text-amber-400 font-mono focus:border-emerald-500"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] text-slate-500 dark:text-slate-400",
												children: "Menentukan filter bawaan pada DHKP dan Laporan."
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												htmlFor: "feeKolektorLuarDesa",
												className: "text-xs font-bold text-slate-700 dark:text-slate-300",
												children: "Fee Kolektor Pajak (Warga Luar Desa)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "relative",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400",
													children: "Rp"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													id: "feeKolektorLuarDesa",
													type: "number",
													value: formData.feeKolektorLuarDesa,
													onChange: (e) => handleChange("feeKolektorLuarDesa", parseInt(e.target.value) || 0),
													className: "bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-sm font-black text-emerald-700 dark:text-emerald-400 font-mono pl-9 focus:border-emerald-500"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] text-slate-500 dark:text-slate-400",
												children: "Nominal fee kolektor per SPPT untuk Wajib Pajak berdomisili Luar Desa."
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "jatuhTempoBulan",
											className: "text-xs font-bold text-slate-700 dark:text-slate-300",
											children: "Bulan Jatuh Tempo Standar"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											id: "jatuhTempoBulan",
											value: formData.jatuhTempoBulan,
											onChange: (e) => handleChange("jatuhTempoBulan", parseInt(e.target.value) || 8),
											className: "w-full rounded-md border border-emerald-200 dark:border-slate-800 bg-white dark:bg-slate-950/80 px-3 py-2 text-xs font-semibold text-slate-900 dark:text-slate-100 focus:border-emerald-500 focus:outline-none",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: 6,
													className: "bg-white dark:bg-slate-900 text-slate-900 dark:text-white",
													children: "Juni (Bulan 6)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: 7,
													className: "bg-white dark:bg-slate-900 text-slate-900 dark:text-white",
													children: "Juli (Bulan 7)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: 8,
													className: "bg-white dark:bg-slate-900 text-slate-900 dark:text-white",
													children: "Agustus (Bulan 8 - Standar)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: 9,
													className: "bg-white dark:bg-slate-900 text-slate-900 dark:text-white",
													children: "September (Bulan 9)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: 10,
													className: "bg-white dark:bg-slate-900 text-slate-900 dark:text-white",
													children: "Oktober (Bulan 10)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: 12,
													className: "bg-white dark:bg-slate-900 text-slate-900 dark:text-white",
													children: "Desember (Bulan 12)"
												})
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-4 rounded-xl border border-emerald-200 dark:border-slate-800 bg-emerald-50/50 dark:bg-slate-950/60 p-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-bold text-slate-900 dark:text-slate-100",
											children: "Aktifkan Fee Kolektor Warga Luar Desa"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5",
											children: "Otomatis tambahkan fee kolektor untuk Wajib Pajak berdomisili Luar Desa."
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
											checked: formData.enableFeeKolektorLuarDesa,
											onCheckedChange: (v) => handleChange("enableFeeKolektorLuarDesa", v),
											className: "data-[state=checked]:bg-emerald-600"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-4 rounded-xl border border-emerald-200 dark:border-slate-800 bg-emerald-50/50 dark:bg-slate-950/60 p-4 sm:col-span-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-bold text-slate-900 dark:text-slate-100",
											children: "Pembulatan Otomatis ke Ribuan"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5",
											children: "Memudahkan transaksi tunai dengan membulatkan pecahan rupiah."
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
											checked: formData.pembulatanRibuan,
											onCheckedChange: (v) => handleChange("pembulatanRibuan", v),
											className: "data-[state=checked]:bg-emerald-600"
										})]
									})
								]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "cetak",
						className: "space-y-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-6 lg:grid-cols-12",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
								className: "border-emerald-100/80 dark:border-slate-800/80 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md shadow-xl lg:col-span-7",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
									className: "border-b border-emerald-100/80 dark:border-slate-800/80 bg-emerald-50/60 dark:bg-slate-950/60 px-6 py-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
										className: "text-base font-extrabold text-slate-900 dark:text-slate-100 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), " Preferensi Cetak & Printer Thermal"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, {
										className: "text-xs text-slate-600 dark:text-slate-400",
										children: "Konfigurasi tata letak dan ukuran resi tanda terima setoran (STTS)."
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
									className: "space-y-4 p-6",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												htmlFor: "printerFormat",
												className: "text-xs font-bold text-slate-700 dark:text-slate-300",
												children: "Ukuran Printer Resi"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
												id: "printerFormat",
												value: formData.printerFormat,
												onChange: (e) => handleChange("printerFormat", e.target.value),
												className: "w-full rounded-md border border-emerald-200 dark:border-slate-800 bg-white dark:bg-slate-950/80 px-3 py-2 text-xs font-semibold text-slate-900 dark:text-slate-100 focus:border-emerald-500 focus:outline-none",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "thermal58",
														className: "bg-white dark:bg-slate-900 text-slate-900 dark:text-white",
														children: "Printer Thermal 58mm (Kolektor Lapangan)"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "thermal80",
														className: "bg-white dark:bg-slate-900 text-slate-900 dark:text-white",
														children: "Printer Thermal 80mm (Kasir Desaku)"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "a5",
														className: "bg-white dark:bg-slate-900 text-slate-900 dark:text-white",
														children: "Format Cetak Kertas A5 / Formal Legal"
													})
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												htmlFor: "headerStruk",
												className: "text-xs font-bold text-slate-700 dark:text-slate-300",
												children: "Header Struk Custom"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
												id: "headerStruk",
												rows: 2,
												value: formData.headerStruk,
												onChange: (e) => handleChange("headerStruk", e.target.value),
												className: "bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-xs text-slate-900 dark:text-slate-100 font-mono focus:border-emerald-500"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												htmlFor: "footerStruk",
												className: "text-xs font-bold text-slate-700 dark:text-slate-300",
												children: "Pesan Footer Struk"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
												id: "footerStruk",
												rows: 2,
												value: formData.footerStruk,
												onChange: (e) => handleChange("footerStruk", e.target.value),
												className: "bg-white dark:bg-slate-950/80 border-emerald-200 dark:border-slate-800 text-xs text-slate-900 dark:text-slate-100 focus:border-emerald-500"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid gap-4 sm:grid-cols-2 pt-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between gap-3 rounded-xl border border-emerald-200 dark:border-slate-800 bg-emerald-50/50 dark:bg-slate-950/60 p-3.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-bold text-slate-900 dark:text-slate-100",
													children: "Cetak Otomatis"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[10px] text-slate-500 dark:text-slate-400",
													children: "Buka dialog cetak pasca bayar."
												})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
													checked: formData.cetakOtomatis,
													onCheckedChange: (v) => handleChange("cetakOtomatis", v),
													className: "data-[state=checked]:bg-emerald-600"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between gap-3 rounded-xl border border-emerald-200 dark:border-slate-800 bg-emerald-50/50 dark:bg-slate-950/60 p-3.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-bold text-slate-900 dark:text-slate-100",
													children: "Tampilkan Logo Kop"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[10px] text-slate-500 dark:text-slate-400",
													children: "Cetak lambang instansi."
												})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
													checked: formData.tampilkanLogoKop,
													onCheckedChange: (v) => handleChange("tampilkanLogoKop", v),
													className: "data-[state=checked]:bg-emerald-600"
												})]
											})]
										})
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
								className: "border-emerald-100/80 dark:border-slate-800/80 bg-white/90 dark:bg-slate-900/60 backdrop-blur-md shadow-xl lg:col-span-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
									className: "border-b border-emerald-100/80 dark:border-slate-800/80 bg-emerald-50/60 dark:bg-slate-950/60 px-6 py-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
										className: "text-base font-extrabold text-slate-900 dark:text-slate-100 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4 text-amber-600 dark:text-amber-400" }), " Pratinjau Struk Thermal"]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
									className: "p-6",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "receipt mx-auto w-full max-w-[260px] rounded-lg border border-slate-700 bg-white p-4 text-center uppercase text-slate-950 font-mono text-[11px] leading-tight shadow-2xl",
										children: [
											formData.tampilkanLogoKop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mb-2 text-[10px] font-black text-slate-600 tracking-wider",
												children: "🏛️ KOP OFFICIAL"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-extrabold text-[12px] whitespace-pre-line",
												children: formData.headerStruk || formData.namaDesa
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] mt-1",
												children: "Tanda Terima Setoran PBB-P2"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "font-bold",
												children: ["Tahun Pajak ", formData.tahunAktif]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-slate-400 my-1",
												children: "----------------------------"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-0.5 text-left normal-case text-[10px]",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["NOP : ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-bold",
														children: "32.05.080.001.002"
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Nama : ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-bold",
														children: "CONTOH WAJIB PAJAK"
													})] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
														formData.jabatanPetugas || "Petugas",
														" : ",
														formData.namaPetugas
													] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Tgl : ", (/* @__PURE__ */ new Date()).toLocaleDateString("id-ID")] })
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-slate-400 my-1",
												children: "----------------------------"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-bold",
												children: "TOTAL SETORAN"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[15px] font-black text-slate-950",
												children: formatRp(15e4)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-slate-400 my-1",
												children: "----------------------------"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-black text-emerald-800 text-[12px] border border-emerald-600 rounded py-0.5 my-1 bg-emerald-50",
												children: "*** LUNAS ***"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "normal-case text-[10px] leading-tight text-slate-700 mt-2",
												children: formData.footerStruk
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-2 text-[9px] text-slate-500",
												children: ["FORMAT: ", formData.printerFormat.toUpperCase()]
											})
										]
									})
								})]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "tampilan",
						className: "space-y-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "border-border bg-card/90 backdrop-blur-md shadow-xl overflow-hidden rounded-2xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
								className: "border-b border-border bg-muted/30 px-6 py-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "p-2.5 rounded-xl bg-amber-500/15 text-amber-500",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Palette, { className: "size-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
										className: "text-base font-black text-foreground",
										children: "Tema Tampilan Aplikasi (Light & Dark Mode)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, {
										className: "text-xs text-muted-foreground",
										children: "Pilih skema warna antarmuka sesuai kenyamanan visual dan kondisi pencahayaan kerja Anda."
									})] })]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
								className: "p-6 space-y-6",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 md:grid-cols-3 gap-5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											onClick: () => setTheme("light"),
											className: `cursor-pointer group relative rounded-2xl border-2 p-5 transition-all duration-200 hover:scale-[1.02] ${theme === "light" ? "border-emerald-500 bg-emerald-500/10 shadow-lg shadow-emerald-500/10" : "border-border bg-muted/40 hover:border-slate-400 dark:hover:border-slate-700"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "p-2.5 rounded-xl bg-amber-500/20 text-amber-500",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-6" })
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
														className: "text-sm font-black text-foreground",
														children: "Mode Terang (Light)"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-[11px] text-muted-foreground",
														children: "Latar putih & kontras tinggi"
													})] })]
												}), theme === "light" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "flex size-6 items-center justify-center rounded-full bg-emerald-500 text-slate-950 font-bold text-xs shadow-md",
													children: "✓"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-5 rounded-xl border border-slate-200 bg-slate-50 p-3.5 space-y-2 shadow-inner",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-between",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2.5 w-16 rounded bg-emerald-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2 w-6 rounded bg-amber-500" })]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2 w-full rounded bg-slate-200" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2 w-3/4 rounded bg-slate-300" })
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											onClick: () => setTheme("dark"),
											className: `cursor-pointer group relative rounded-2xl border-2 p-5 transition-all duration-200 hover:scale-[1.02] ${theme === "dark" ? "border-emerald-500 bg-emerald-500/10 shadow-lg shadow-emerald-500/10" : "border-border bg-muted/40 hover:border-slate-400 dark:hover:border-slate-700"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "p-2.5 rounded-xl bg-indigo-500/20 text-indigo-400",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-6" })
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
														className: "text-sm font-black text-foreground",
														children: "Mode Gelap (Dark)"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-[11px] text-muted-foreground",
														children: "Executive Navy & Slate"
													})] })]
												}), theme === "dark" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "flex size-6 items-center justify-center rounded-full bg-emerald-500 text-slate-950 font-bold text-xs shadow-md",
													children: "✓"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-5 rounded-xl border border-slate-800 bg-slate-950 p-3.5 space-y-2 shadow-inner",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center justify-between",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2.5 w-16 rounded bg-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2 w-6 rounded bg-amber-400" })]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2 w-full rounded bg-slate-800" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2 w-3/4 rounded bg-slate-700" })
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											onClick: () => setTheme("system"),
											className: `cursor-pointer group relative rounded-2xl border-2 p-5 transition-all duration-200 hover:scale-[1.02] ${theme === "system" ? "border-emerald-500 bg-emerald-500/10 shadow-lg shadow-emerald-500/10" : "border-border bg-muted/40 hover:border-slate-400 dark:hover:border-slate-700"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "p-2.5 rounded-xl bg-slate-500/20 text-slate-400",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Laptop, { className: "size-6" })
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
														className: "text-sm font-black text-foreground",
														children: "Ikuti Perangkat (System)"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-[11px] text-muted-foreground",
														children: "Otomatis sesuaikan preferensi OS"
													})] })]
												}), theme === "system" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "flex size-6 items-center justify-center rounded-full bg-emerald-500 text-slate-950 font-bold text-xs shadow-md",
													children: "✓"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-5 flex rounded-xl border border-border overflow-hidden shadow-inner",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "w-1/2 bg-slate-100 p-3.5 space-y-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2.5 w-10 rounded bg-emerald-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2 w-full rounded bg-slate-300" })]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "w-1/2 bg-slate-950 p-3.5 space-y-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2.5 w-10 rounded bg-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2 w-full rounded bg-slate-800" })]
												})]
											})]
										})
									]
								})
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "data",
						className: "space-y-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 lg:grid-cols-4 gap-3.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "group relative overflow-hidden rounded-2xl border border-emerald-200/80 dark:border-emerald-500/20 bg-gradient-to-br from-white via-white/95 to-emerald-50/40 dark:from-slate-900/90 dark:via-slate-900/80 dark:to-emerald-950/30 p-4 shadow-sm hover:shadow-md hover:border-emerald-400/50 transition-all",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] font-black uppercase tracking-wider text-emerald-800 dark:text-emerald-400",
												children: "Data Operasional"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "p-2.5 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 group-hover:scale-110 transition-transform",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "size-4" })
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-2xl font-black text-slate-900 dark:text-white mt-1 tracking-tight",
											children: backupSummary ? (backupSummary.total_records || 0).toLocaleString("id-ID") : "..."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-1.5 mt-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "inline-block size-1.5 rounded-full bg-emerald-500 animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] font-medium text-slate-500 dark:text-slate-400",
												children: backupSummary ? `${backupSummary.total_tables} tabel aktif` : "Menghitung..."
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "group relative overflow-hidden rounded-2xl border border-teal-200/80 dark:border-teal-500/20 bg-gradient-to-br from-white via-white/95 to-teal-50/40 dark:from-slate-900/90 dark:via-slate-900/80 dark:to-teal-950/30 p-4 shadow-sm hover:shadow-md hover:border-teal-400/50 transition-all",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] font-black uppercase tracking-wider text-teal-800 dark:text-teal-400",
												children: "Cadangan Server"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "p-2.5 rounded-xl bg-teal-500/10 text-teal-600 dark:text-teal-400 group-hover:scale-110 transition-transform",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Server, { className: "size-4" })
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-2xl font-black text-slate-900 dark:text-white mt-1 tracking-tight",
											children: [
												backupSummary ? backupSummary.total_backups_stored : 0,
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-semibold text-slate-400",
													children: "Berkas"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-1.5 mt-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HardDrive, { className: "size-3 text-teal-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] font-medium text-slate-500 dark:text-slate-400",
												children: "Tersimpan di storage server"
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "group relative overflow-hidden rounded-2xl border border-amber-200/80 dark:border-amber-500/20 bg-gradient-to-br from-white via-white/95 to-amber-50/40 dark:from-slate-900/90 dark:via-slate-900/80 dark:to-amber-950/30 p-4 shadow-sm hover:shadow-md hover:border-amber-400/50 transition-all",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] font-black uppercase tracking-wider text-amber-800 dark:text-amber-400",
												children: "Ukuran Disk"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "p-2.5 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 group-hover:scale-110 transition-transform",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HardDrive, { className: "size-4" })
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-2xl font-black text-slate-900 dark:text-white mt-1 tracking-tight font-mono",
											children: backupSummary?.total_backup_size_human || "0 B"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-1.5 mt-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] font-medium text-slate-500 dark:text-slate-400",
												children: "Kapasitas arsip data"
											})]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "group relative overflow-hidden rounded-2xl border border-indigo-200/80 dark:border-indigo-500/20 bg-gradient-to-br from-white via-white/95 to-indigo-50/40 dark:from-slate-900/90 dark:via-slate-900/80 dark:to-indigo-950/30 p-4 shadow-sm hover:shadow-md hover:border-indigo-400/50 transition-all",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] font-black uppercase tracking-wider text-indigo-800 dark:text-indigo-400",
												children: "Cadangan Terakhir"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "p-2.5 rounded-xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 group-hover:scale-110 transition-transform",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4" })
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-bold text-slate-800 dark:text-slate-100 mt-2 truncate font-mono",
											title: backupSummary?.last_backup?.created_at || "Belum ada",
											children: backupSummary?.last_backup ? backupSummary.last_backup.created_at : "Belum Ada"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex items-center gap-1.5 mt-1 truncate",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[11px] font-medium text-slate-500 dark:text-slate-400 truncate",
												children: backupSummary?.last_backup?.size_human ? `${backupSummary.last_backup.size_human} • ${backupSummary.last_backup.scope}` : "Siap dicadangkan"
											})
										})
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "border-emerald-200/70 dark:border-slate-800/80 bg-white dark:bg-slate-900/80 backdrop-blur-xl shadow-lg rounded-3xl overflow-hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
								className: "border-b border-emerald-100/80 dark:border-slate-800/80 bg-gradient-to-r from-emerald-50/90 via-teal-50/40 to-slate-50/60 dark:from-slate-950/90 dark:via-slate-900/80 dark:to-slate-950/90 px-6 py-5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start sm:items-center gap-3.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "p-3 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-md shadow-emerald-500/20 shrink-0",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderArchive, { className: "size-6" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
												className: "text-lg font-black text-slate-900 dark:text-white tracking-tight",
												children: "Cadangan Database Operasional (Disaster Recovery)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-300 border border-emerald-300/80 dark:border-emerald-700/60 shadow-xs",
												children: "Zero-Loss Guard"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, {
											className: "text-xs text-slate-600 dark:text-slate-400 mt-1",
											children: "Pusat perlindungan & pemulihan data terpadu: DHKP, kasir pembayaran, setor kecamatan, master dusun, & akun pengguna."
										})] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 shrink-0",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												type: "button",
												variant: "outline",
												size: "sm",
												onClick: fetchBackupsData,
												disabled: isLoadingBackups,
												title: "Muat Ulang Data Cadangan",
												className: "h-9 px-3 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-xl hover:bg-slate-100 dark:hover:bg-slate-700 shadow-xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: `size-3.5 ${isLoadingBackups ? "animate-spin" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "hidden sm:inline",
													children: "Refresh"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												type: "button",
												onClick: () => {
													setRestoreSource("server");
													setSelectedServerBackup(backupsList[0]?.filename || "");
													setRestorePassword("");
													setIsRestoreModalOpen(true);
												},
												variant: "outline",
												className: "h-9 px-3.5 border-amber-300 dark:border-amber-700/60 bg-amber-50/90 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/50 text-amber-900 dark:text-amber-200 text-xs font-black gap-1.5 rounded-xl shadow-xs transition-all",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3.5 text-amber-600 dark:text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Pulihkan Data (Restore)" })]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												type: "button",
												onClick: () => {
													setCreateFormat("zip");
													setCreateScopeDesa(isSuperAdmin && filterDesa !== "all" ? filterDesa : "all");
													setCreateNotes("");
													setIsCreateBackupModalOpen(true);
												},
												className: "h-9 px-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black gap-1.5 rounded-xl shadow-md shadow-emerald-600/20 active:scale-95 transition-all",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Buat Cadangan Baru" })]
											})
										]
									})]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
								className: "p-6 space-y-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownToLine, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: "text-xs font-black uppercase text-slate-800 dark:text-slate-200 tracking-wider",
												children: "Unduh Cadangan Langsung (Direct Export)"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-1 md:grid-cols-3 gap-4",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "relative overflow-hidden rounded-2xl border border-emerald-200 dark:border-emerald-500/20 bg-gradient-to-b from-emerald-50/60 via-white to-white dark:from-emerald-950/20 dark:via-slate-900/80 dark:to-slate-900/90 p-4 shadow-sm flex flex-col justify-between hover:shadow-md hover:border-emerald-400/50 transition-all",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center justify-between",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "p-2.5 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { className: "size-5" })
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800",
																children: "Rekomendasi Utama"
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
															className: "text-sm font-black text-slate-900 dark:text-white mt-3",
															children: "Paket Lengkap (.ZIP)"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-relaxed",
															children: "Arsip kompresi berisi database SQL dump, structured JSON, dan manifest integritas."
														})
													] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														type: "button",
														disabled: directExportFormat !== null,
														onClick: () => handleDirectExport("zip"),
														className: "mt-4 w-full h-9 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold rounded-xl gap-1.5 shadow-sm active:scale-95 transition-all",
														children: [directExportFormat === "zip" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: directExportFormat === "zip" ? "Menyiapkan ZIP..." : "Unduh Berkas ZIP" })]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "relative overflow-hidden rounded-2xl border border-blue-200 dark:border-blue-500/20 bg-gradient-to-b from-blue-50/60 via-white to-white dark:from-blue-950/20 dark:via-slate-900/80 dark:to-slate-900/90 p-4 shadow-sm flex flex-col justify-between hover:shadow-md hover:border-blue-400/50 transition-all",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center justify-between",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "p-2.5 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCode, { className: "size-5" })
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 border border-blue-300 dark:border-blue-800",
																children: "Skrip Database"
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
															className: "text-sm font-black text-slate-900 dark:text-white mt-3",
															children: "Dump Database (.SQL)"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-relaxed",
															children: "Skrip SQL transaksional kompatibel MySQL/MariaDB siap eksekusi impor command line."
														})
													] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														type: "button",
														variant: "outline",
														disabled: directExportFormat !== null,
														onClick: () => handleDirectExport("sql"),
														className: "mt-4 w-full h-9 border-blue-200 dark:border-blue-800/60 bg-blue-50/80 dark:bg-blue-950/40 hover:bg-blue-100 dark:hover:bg-blue-900/50 text-blue-900 dark:text-blue-200 text-xs font-bold rounded-xl gap-1.5 transition-all",
														children: [directExportFormat === "sql" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin text-blue-600" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4 text-blue-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: directExportFormat === "sql" ? "Menyiapkan SQL..." : "Unduh Skrip SQL" })]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "relative overflow-hidden rounded-2xl border border-amber-200 dark:border-amber-500/20 bg-gradient-to-b from-amber-50/60 via-white to-white dark:from-amber-950/20 dark:via-slate-900/80 dark:to-slate-900/90 p-4 shadow-sm flex flex-col justify-between hover:shadow-md hover:border-amber-400/50 transition-all",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex items-center justify-between",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "p-2.5 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-5" })
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border border-amber-300 dark:border-amber-800",
																children: "Structured Raw"
															})]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
															className: "text-sm font-black text-slate-900 dark:text-white mt-3",
															children: "Dokumen Data (.JSON)"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-relaxed",
															children: "Data mentah terstruktur JSON lengkap beserta metadata dan kalkulasi SHA-256."
														})
													] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														type: "button",
														variant: "outline",
														disabled: directExportFormat !== null,
														onClick: () => handleDirectExport("json"),
														className: "mt-4 w-full h-9 border-amber-200 dark:border-amber-800/60 bg-amber-50/80 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/50 text-amber-900 dark:text-amber-200 text-xs font-bold rounded-xl gap-1.5 transition-all",
														children: [directExportFormat === "json" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin text-amber-600" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4 text-amber-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: directExportFormat === "json" ? "Menyiapkan JSON..." : "Unduh Dokumen JSON" })]
													})]
												})
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
													className: "text-xs font-black uppercase text-slate-800 dark:text-slate-200 tracking-wider",
													children: [
														"Riwayat Berkas Cadangan di Server (",
														backupsList.length,
														")"
													]
												})]
											}), targetDesaForDusun && isSuperAdmin && filterDesa !== "all" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
												variant: "outline",
												className: "text-[10px] font-bold border-emerald-300 dark:border-emerald-700 text-emerald-700 dark:text-emerald-300",
												children: ["Desa: ", desasList.find((d) => String(d.id) === String(filterDesa))?.nama_desa || filterDesa]
											})]
										}), isLoadingBackups ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-12 text-center rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-7 animate-spin mx-auto text-emerald-500 mb-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-semibold text-slate-600 dark:text-slate-400",
												children: "Memeriksa penyimpanan berkas cadangan di server..."
											})]
										}) : backupsList.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-12 text-center rounded-2xl border border-dashed border-slate-300 dark:border-slate-800 bg-slate-50/40 dark:bg-slate-950/30 space-y-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "size-12 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-slate-400",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { className: "size-6" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm font-bold text-slate-700 dark:text-slate-200",
													children: "Belum ada file cadangan tersimpan di server."
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-xs text-slate-500 max-w-sm mx-auto",
													children: [
														"Klik tombol ",
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "\"Buat Cadangan Baru\"" }),
														" atau ",
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "\"Unduh Cadangan Langsung\"" }),
														" di atas untuk membuat snapshot pertama Anda."
													]
												})
											]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "overflow-x-auto rounded-2xl border border-emerald-100 dark:border-slate-800 shadow-sm",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
												className: "w-full text-left text-xs",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
													className: "border-b border-emerald-100 dark:border-slate-800 bg-emerald-50/80 dark:bg-slate-950 text-slate-700 dark:text-slate-300 uppercase font-black text-[10px]",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "px-4 py-3.5",
															children: "Nama Berkas Cadangan"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "px-4 py-3.5",
															children: "Format"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "px-4 py-3.5",
															children: "Cakupan Wilayah"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "px-4 py-3.5",
															children: "Ukuran"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "px-4 py-3.5",
															children: "Waktu Pembuatan"
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
															className: "px-4 py-3.5 text-right",
															children: "Aksi Terpadu"
														})
													] })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
													className: "divide-y divide-emerald-50 dark:divide-slate-800/60 bg-white dark:bg-slate-900/40",
													children: backupsList.map((item) => {
														const isThisDownloading = downloadingFilename === item.filename;
														return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
															className: "hover:bg-emerald-50/30 dark:hover:bg-slate-800/40 transition-colors",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																	className: "px-4 py-3.5 font-mono font-bold text-slate-900 dark:text-slate-100 text-[11px]",
																	children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																		className: "flex items-center gap-3",
																		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																			className: `p-2 rounded-xl shrink-0 ${item.format === "zip" ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" : item.format === "sql" ? "bg-blue-500/10 text-blue-600 dark:text-blue-400" : "bg-amber-500/10 text-amber-600 dark:text-amber-400"}`,
																			children: item.format === "zip" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { className: "size-4" }) : item.format === "sql" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCode, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4" })
																		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																			className: "truncate max-w-[240px] sm:max-w-xs",
																			children: item.filename
																		}), item.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																			className: "text-[10px] text-slate-400 font-sans font-normal truncate max-w-[240px] mt-0.5",
																			children: item.notes
																		})] })]
																	})
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																	className: "px-4 py-3.5",
																	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																		variant: "secondary",
																		className: `text-[10px] uppercase font-black px-2 py-0.5 ${item.format === "zip" ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800" : item.format === "sql" ? "bg-blue-100 text-blue-800 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200 dark:border-blue-800" : "bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-200 dark:border-amber-800"}`,
																		children: item.format
																	})
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																	className: "px-4 py-3.5",
																	children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																		className: "inline-flex items-center gap-1.5 text-[11px] font-semibold text-slate-700 dark:text-slate-300",
																		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "size-3.5 text-slate-400" }), item.scope]
																	})
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																	className: "px-4 py-3.5 font-mono font-bold text-slate-700 dark:text-slate-300 text-[11px]",
																	children: item.size_human
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
																	className: "px-4 py-3.5 text-[11px] text-slate-600 dark:text-slate-400",
																	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																		className: "font-semibold text-slate-800 dark:text-slate-200",
																		children: item.created_at
																	}), item.created_by && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
																		className: "text-[10px] text-slate-400",
																		children: ["Oleh: ", item.created_by]
																	})]
																}),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
																	className: "px-4 py-3.5 text-right",
																	children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																		className: "flex items-center justify-end gap-1.5",
																		children: [
																			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
																				type: "button",
																				size: "sm",
																				variant: "outline",
																				disabled: isThisDownloading,
																				onClick: () => handleDownloadFile(item),
																				title: "Unduh File Cadangan Ini ke Laptop",
																				className: "h-8 px-2.5 border-emerald-200 dark:border-emerald-800/60 bg-emerald-50/60 dark:bg-emerald-950/40 hover:bg-emerald-100 text-emerald-700 dark:text-emerald-300 text-xs font-bold rounded-lg gap-1 transition-all",
																				children: [isThisDownloading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin text-emerald-600" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5 text-emerald-600 dark:text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																					className: "hidden sm:inline",
																					children: "Unduh"
																				})]
																			}),
																			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
																				type: "button",
																				size: "sm",
																				variant: "outline",
																				onClick: () => handleOpenRestoreForFile(item),
																				title: "Pulihkan Database dari File Ini",
																				className: "h-8 px-2.5 border-amber-200 dark:border-amber-800/60 bg-amber-50/60 dark:bg-amber-950/40 hover:bg-amber-100 text-amber-700 dark:text-amber-300 text-xs font-bold rounded-lg gap-1 transition-all",
																				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3.5 text-amber-600 dark:text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																					className: "hidden sm:inline",
																					children: "Pulihkan"
																				})]
																			}),
																			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																				type: "button",
																				size: "sm",
																				variant: "outline",
																				onClick: () => handleDeleteBackup(item),
																				title: "Hapus File Cadangan Ini dari Server",
																				className: "h-8 px-2 border-rose-200 dark:border-rose-800/60 bg-rose-50/60 dark:bg-rose-950/40 hover:bg-rose-100 text-rose-700 dark:text-rose-300 text-xs font-bold rounded-lg transition-all",
																				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5 text-rose-600 dark:text-rose-400" })
																			})
																		]
																	})
																})
															]
														}, item.filename);
													})
												})]
											})
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "pt-4 border-t border-emerald-100 dark:border-slate-800 space-y-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
												className: "text-xs font-black uppercase text-slate-800 dark:text-slate-200 tracking-wider",
												children: "Pengaturan File Konfigurasi JSON & Standar Pabrik"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid gap-4 sm:grid-cols-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "rounded-2xl border border-emerald-100 dark:border-slate-800 bg-emerald-50/40 dark:bg-slate-950/60 p-4 space-y-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-3",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "rounded-xl bg-emerald-500/10 p-2 text-emerald-600 dark:text-emerald-400",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" })
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-xs font-bold text-slate-900 dark:text-slate-100",
															children: "Ekspor Pengaturan (JSON)"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-[10px] text-slate-500 dark:text-slate-400",
															children: "Unduh teks konfigurasi identitas & resi."
														})] })]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
														onClick: handleExportBackup,
														variant: "outline",
														size: "sm",
														className: "w-full border-emerald-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:bg-emerald-50 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-bold gap-1.5",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5" }), " Unduh Konfigurasi JSON"]
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "rounded-2xl border border-emerald-100 dark:border-slate-800 bg-emerald-50/40 dark:bg-slate-950/60 p-4 space-y-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-3",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "rounded-xl bg-amber-500/10 p-2 text-amber-600 dark:text-amber-400",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" })
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-xs font-bold text-slate-900 dark:text-slate-100",
															children: "Impor Pengaturan (JSON)"
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-[10px] text-slate-500 dark:text-slate-400",
															children: "Pulihkan preferensi identitas dari file."
														})] })]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
														className: "flex w-full cursor-pointer items-center justify-center rounded-xl border border-emerald-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-3 py-1.5 text-xs font-bold text-slate-800 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-slate-800 transition-colors gap-1.5",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-3.5" }),
															" Pilih File JSON...",
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
																type: "file",
																accept: ".json",
																onChange: handleImportBackup,
																className: "hidden"
															})
														]
													})]
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "rounded-2xl border border-rose-500/20 bg-rose-500/5 p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-start gap-3",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-5 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-xs font-bold text-rose-700 dark:text-rose-200",
														children: "Reset Seluruh Pengaturan ke Standar Awal"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-[10px] text-slate-600 dark:text-slate-400",
														children: "Mengembalikan konfigurasi identitas instansi, parameter fee kolektor, dan preferensi cetak ke bawaan sistem."
													})] })]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
													onClick: handleReset,
													variant: "destructive",
													size: "sm",
													className: "bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs gap-1.5 shrink-0 rounded-xl",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5" }), " Reset Pengaturan"]
												})]
											})
										]
									})
								]
							})]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: isCreateBackupModalOpen,
				onOpenChange: setIsCreateBackupModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-md bg-white dark:bg-slate-900 border-emerald-200 dark:border-slate-800 rounded-2xl shadow-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "text-base font-extrabold text-slate-900 dark:text-slate-100 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderArchive, { className: "size-5 text-emerald-600 dark:text-emerald-400" }), " Buat Cadangan Database Baru"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-xs text-slate-600 dark:text-slate-400",
						children: "Pilih format arsip dan cakupan data yang akan disimpan ke repositori server."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleCreateBackup,
						className: "space-y-4 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-bold text-slate-800 dark:text-slate-200",
									children: "Pilih Format Arsip Cadangan"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setCreateFormat("zip"),
											className: `p-3 rounded-xl border text-center transition-all ${createFormat === "zip" ? "border-emerald-600 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-300 font-bold ring-2 ring-emerald-500/20" : "border-slate-200 dark:border-slate-800 hover:border-slate-300 text-slate-600 dark:text-slate-400"}`,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { className: "size-5 mx-auto mb-1 text-emerald-600 dark:text-emerald-400" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-black",
													children: "ZIP Archive"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[9px] text-slate-400",
													children: "Direkomendasikan"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setCreateFormat("sql"),
											className: `p-3 rounded-xl border text-center transition-all ${createFormat === "sql" ? "border-blue-600 bg-blue-50 dark:bg-blue-950/50 text-blue-800 dark:text-blue-300 font-bold ring-2 ring-blue-500/20" : "border-slate-200 dark:border-slate-800 hover:border-slate-300 text-slate-600 dark:text-slate-400"}`,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCode, { className: "size-5 mx-auto mb-1 text-blue-600 dark:text-blue-400" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-black",
													children: "SQL Dump"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[9px] text-slate-400",
													children: "Standar DB"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setCreateFormat("json"),
											className: `p-3 rounded-xl border text-center transition-all ${createFormat === "json" ? "border-amber-600 bg-amber-50 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 font-bold ring-2 ring-amber-500/20" : "border-slate-200 dark:border-slate-800 hover:border-slate-300 text-slate-600 dark:text-slate-400"}`,
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-5 mx-auto mb-1 text-amber-600 dark:text-amber-400" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs font-black",
													children: "JSON Data"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-[9px] text-slate-400",
													children: "Portable Raw"
												})
											]
										})
									]
								})]
							}),
							isSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-bold text-slate-800 dark:text-slate-200",
									children: "Cakupan Wilayah Data"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: createScopeDesa,
									onValueChange: setCreateScopeDesa,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "text-xs font-semibold bg-white dark:bg-slate-950",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Pilih Cakupan Wilayah..." })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "all",
										children: "🌐 Seluruh Desa (Full Database)"
									}), desasList.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
										value: String(d.id),
										children: [
											"🏛️ Desa ",
											d.nama_desa,
											" (",
											d.kode_desa,
											")"
										]
									}, d.id))] })]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "backupNotes",
									className: "text-xs font-bold text-slate-800 dark:text-slate-200",
									children: "Catatan Cadangan (Opsional)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "backupNotes",
									value: createNotes,
									onChange: (e) => setCreateNotes(e.target.value),
									placeholder: "Contoh: Cadangan rutin akhir bulan...",
									className: "text-xs bg-white dark:bg-slate-950"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
								className: "pt-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									onClick: () => setIsCreateBackupModalOpen(false),
									disabled: isCreatingBackup,
									className: "text-xs",
									children: "Batal"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									disabled: isCreatingBackup,
									className: "bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs gap-1.5 rounded-xl shadow-md",
									children: isCreatingBackup ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }), " Memproses Cadangan..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }), " Buat & Simpan Cadangan"] })
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: isRestoreModalOpen,
				onOpenChange: setIsRestoreModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-lg bg-white dark:bg-slate-900 border-amber-300/80 dark:border-slate-800 rounded-2xl shadow-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "text-base font-extrabold text-slate-900 dark:text-slate-100 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-5 text-amber-600 dark:text-amber-400" }), " Pulihkan Database dari Cadangan"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-xs text-slate-600 dark:text-slate-400",
						children: "Pilih sumber arsip dan otentikasi password akun Anda untuk memulai proses pemulihan data."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleExecuteRestore,
						className: "space-y-4 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700/50 flex items-start gap-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] text-amber-900 dark:text-amber-200 space-y-0.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-bold",
										children: "Peringatan Keamanan Database"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-amber-800 dark:text-amber-300",
										children: "Data tabel operasional yang ada saat ini akan digantikan dengan data yang termuat dalam berkas cadangan. Pastikan tidak ada transaksi bayar aktif."
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-bold text-slate-800 dark:text-slate-200",
									children: "Pilih Sumber Berkas Cadangan"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setRestoreSource("server"),
										className: `p-3 rounded-xl border text-left transition-all ${restoreSource === "server" ? "border-emerald-600 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-300 font-bold" : "border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Server, { className: "size-4 mb-1 text-emerald-600 dark:text-emerald-400" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-black",
												children: "Dari Server"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-slate-400 font-normal",
												children: "Pilih file tersimpan di server"
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setRestoreSource("upload"),
										className: `p-3 rounded-xl border text-left transition-all ${restoreSource === "upload" ? "border-emerald-600 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-300 font-bold" : "border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4 mb-1 text-amber-600 dark:text-amber-400" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-black",
												children: "Upload File JSON"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-slate-400 font-normal",
												children: "Unggah file dari laptop/PC"
											})
										]
									})]
								})]
							}),
							restoreSource === "server" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-bold text-slate-800 dark:text-slate-200",
									children: "Pilih File Cadangan Server"
								}), backupsList.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-rose-500 font-semibold p-2 bg-rose-50 dark:bg-rose-950/30 rounded-lg",
									children: "Tidak ada berkas cadangan di server. Silakan buat cadangan baru atau gunakan opsi Upload."
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: selectedServerBackup,
									onValueChange: setSelectedServerBackup,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "text-xs font-mono font-semibold bg-white dark:bg-slate-950",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Pilih berkas cadangan..." })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: backupsList.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
										value: b.filename,
										children: [
											"📦 ",
											b.filename,
											" (",
											b.size_human,
											" - ",
											b.created_at,
											")"
										]
									}, b.filename)) })]
								})]
							}),
							restoreSource === "upload" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-bold text-slate-800 dark:text-slate-200",
									children: "Unggah Berkas Cadangan (.JSON)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center gap-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex flex-1 cursor-pointer items-center justify-center rounded-xl border border-dashed border-emerald-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-4 py-3 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-emerald-50/50 transition-colors gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4 text-emerald-600" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "truncate",
												children: uploadFileName || "Pilih file .json cadangan dari komputer..."
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "file",
												accept: ".json",
												onChange: handleUploadFileForRestore,
												className: "hidden"
											})
										]
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
									htmlFor: "restorePasswordInput",
									className: "text-xs font-bold text-rose-600 dark:text-rose-400 flex items-center gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-3.5" }),
										" Konfirmasi Password Akun Anda ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-rose-500",
											children: "*"
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "restorePasswordInput",
									type: "password",
									value: restorePassword,
									onChange: (e) => setRestorePassword(e.target.value),
									placeholder: "Masukkan password akun login Anda...",
									className: "text-xs bg-white dark:bg-slate-950 border-rose-300 dark:border-rose-900/50 focus:border-rose-500",
									required: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
								className: "pt-2 gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									onClick: () => setIsRestoreModalOpen(false),
									disabled: isRestoring,
									className: "text-xs",
									children: "Batal"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									disabled: isRestoring || !restorePassword || restoreSource === "server" && !selectedServerBackup || restoreSource === "upload" && !uploadFileContent,
									className: "bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs gap-1.5 rounded-xl shadow-md",
									children: isRestoring ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }), " Memulihkan Database..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3.5" }), " Mulai Pemulihan Data"] })
								})]
							})
						]
					})]
				})
			})
		]
	});
}
//#endregion
export { Pengaturan as component };
