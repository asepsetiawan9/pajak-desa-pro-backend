import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { i as useAuthStore, o as useUserStore } from "./authStore-CZRDvP0Z.mjs";
import { t as setoranKecamatanService } from "./setoranKecamatanService-gOlpOSNj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pengeluaranNotifStore-B2Fwq7FT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var globalListeners = [];
var cachedData = null;
var isFetching = false;
function triggerGlobalNotifRefresh() {
	globalListeners.forEach((listener) => listener());
}
function usePengeluaranNotifStore() {
	const { user: authUser } = useAuthStore();
	const { getActiveUser } = useUserStore();
	const activeUser = authUser || getActiveUser();
	const [data, setData] = (0, import_react.useState)(cachedData);
	const [isLoading, setIsLoading] = (0, import_react.useState)(false);
	const fetchNotif = (0, import_react.useCallback)(async () => {
		if (!activeUser || isFetching) return;
		isFetching = true;
		try {
			const res = await setoranKecamatanService.getPendingReviews({ desa_id: activeUser.desa_id || void 0 });
			cachedData = res;
			setData(res);
		} catch (err) {
			console.warn("Gagal sinkronisasi notifikasi pengeluaran:", err);
		} finally {
			isFetching = false;
			setIsLoading(false);
		}
	}, [activeUser]);
	(0, import_react.useEffect)(() => {
		fetchNotif();
		const onRefresh = () => {
			fetchNotif();
		};
		globalListeners.push(onRefresh);
		const interval = setInterval(() => {
			fetchNotif();
		}, 3e4);
		return () => {
			globalListeners = globalListeners.filter((l) => l !== onRefresh);
			clearInterval(interval);
		};
	}, [fetchNotif]);
	return {
		notifData: data,
		isLoading,
		refreshNotif: fetchNotif,
		pendingCount: data?.needActionCount || 0,
		counts: data?.counts || {
			tambahEdit: 0,
			permohonanHapus: 0,
			ditolak: 0,
			totalPending: 0
		},
		items: data?.items || [],
		roleContext: data?.roleContext || "ADMIN_DESA",
		reviewLabel: data?.reviewLabel || "Status Pengajuan Pengeluaran"
	};
}
//#endregion
export { usePengeluaranNotifStore as n, triggerGlobalNotifRefresh as t };
