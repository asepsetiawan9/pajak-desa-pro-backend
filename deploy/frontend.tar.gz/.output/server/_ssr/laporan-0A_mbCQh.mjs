import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { a as useTenantStore, i as useAuthStore, o as useUserStore } from "./authStore-CZRDvP0Z.mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Button } from "./button-YtzMxdp3.mjs";
import { i as useSettingsStore } from "./settingsStore-BBOTJBY5.mjs";
import { $ as Layers, Bt as ChartPie, C as ShieldAlert, Ht as Calendar, It as ChevronRight, Kt as BookOpen, L as Pencil, Lt as ChevronLeft, M as Receipt, Mt as CircleAlert, N as Printer, Nt as ChevronsRight, O as Search, Ot as ClipboardList, P as Plus, Pt as ChevronsLeft, Tt as Coins, Vt as ChartColumn, W as MapPin, Wt as Building2, _t as FileChartColumn, bt as Download, f as Trash2, ft as FileText, j as RefreshCw, jt as CircleCheck, m as Tag, mt as FileSpreadsheet, n as Wallet, o as UserCheck, t as X, u as TriangleAlert, v as SquarePen, xt as DollarSign } from "../_libs/lucide-react.mjs";
import { t as Badge } from "./badge-DeRhpfUp.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, o as formatRp, t as Card } from "./card-CfCIYh5x.mjs";
import { t as desaService } from "./desaService-B2uJrXze.mjs";
import { a as TableHeader, i as TableHead, n as TableBody, o as TableRow, r as TableCell, t as Table } from "./table-C2Ya5HzI.mjs";
import { n as computeLaporanRow, o as useDhkpStore, r as defaultLaporanRows } from "./penerimaanStore-Dy63tgZo.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-HQswfJbV.mjs";
import { r as isDusunAllowed } from "./dusunHelper-BcA75wHe.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as require_jspdf_node_min } from "../_libs/jspdf.mjs";
import { t as autoTable } from "../_libs/jspdf-autotable.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/laporan-0A_mbCQh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_jspdf_node_min = /* @__PURE__ */ __toESM(require_jspdf_node_min());
var generatePdfReport = (options) => {
	const { activeTab, settings, selectedTahun, selectedBulan, selectedMinggu, filterDusun, showDesaColumn, isSuperAdmin, filterDesa, selectedDesaName, signerInfo, computed21Rows, grandTotal21, dhkpRecapGrouped, dhkpRecapTotal, piutangList, piutangSummary, feeKolektorList, feeKolektorTotal } = options;
	const doc = new import_jspdf_node_min.default({
		orientation: activeTab === "realisasi_21" || activeTab === "piutang_kendali" || activeTab === "fee_kolektor" ? "landscape" : "portrait",
		unit: "pt",
		format: "a4"
	});
	const pageWidth = doc.internal.pageSize.getWidth();
	const pageHeight = doc.internal.pageSize.getHeight();
	const targetDesaText = isSuperAdmin ? filterDesa === "all" ? "SELURUH DESA TERDAFTAR" : `DESA ${(selectedDesaName || settings.namaDesa).toUpperCase()}` : `DESA ${settings.namaDesa.toUpperCase()}`;
	const isKecamatanLevel = isSuperAdmin && filterDesa === "all";
	const activeNamaDesa = selectedDesaName || settings.namaDesa || "Desa";
	const drawKopSurat = () => {
		doc.setFillColor(5, 150, 105);
		doc.rect(0, 0, pageWidth, 8, "F");
		doc.setFont("helvetica", "bold");
		doc.setFontSize(13);
		doc.setTextColor(15, 23, 42);
		doc.text(`PEMERINTAH KABUPATEN ${settings.kabupaten.toUpperCase()}`, pageWidth / 2, 32, { align: "center" });
		doc.setFontSize(11);
		doc.setFont("helvetica", "bold");
		doc.setTextColor(5, 150, 105);
		const kopTitle = isKecamatanLevel ? `KECAMATAN ${settings.kecamatan.toUpperCase()} - SELURUH WILAYAH DESA` : `KECAMATAN ${settings.kecamatan.toUpperCase()} - ${targetDesaText}`;
		doc.text(kopTitle, pageWidth / 2, 48, { align: "center" });
		doc.setFont("helvetica", "normal");
		doc.setFontSize(8.5);
		doc.setTextColor(100, 116, 139);
		const kopSub = isKecamatanLevel ? `Kantor Kecamatan ${settings.kecamatan} - Sekretariat Pengawasan Pajak Daerah & PBB-P2` : settings.alamatDesa || "Kantor Sekretariat Pelayanan Pajak Daerah & PBB-P2 Desa";
		doc.text(kopSub, pageWidth / 2, 60, { align: "center" });
		doc.setDrawColor(5, 150, 105);
		doc.setLineWidth(1.5);
		doc.line(36, 68, pageWidth - 36, 68);
		doc.setDrawColor(245, 158, 11);
		doc.setLineWidth(.5);
		doc.line(36, 71, pageWidth - 36, 71);
	};
	drawKopSurat();
	let startY = 86;
	let titleText = "";
	if (activeTab === "realisasi_21") titleText = `LAPORAN REKAPITULASI PENERIMAAN PBB-P2 PER DUSUN TAHUN ${selectedTahun}`;
	else if (activeTab === "rekap_dhkp") titleText = `REKAPITULASI KETETAPAN & REALISASI DHKP PER DUSUN TAHUN ${selectedTahun}`;
	else if (activeTab === "piutang_kendali") titleText = `LEMBAR KENDALI PENAGIHAN PIUTANG PBB-P2 (DOOR-TO-DOOR) TAHUN ${selectedTahun}`;
	else if (activeTab === "fee_kolektor") titleText = `LAPORAN AUDIT & FEE KOLEKTOR PAJAK (WARGA LUAR DESA)`;
	doc.setFont("helvetica", "bold");
	doc.setFontSize(11);
	doc.setTextColor(15, 23, 42);
	doc.text(titleText, pageWidth / 2, startY, { align: "center" });
	startY += 14;
	doc.setFont("helvetica", "normal");
	doc.setFontSize(8);
	doc.setTextColor(71, 85, 105);
	doc.text(`Periode: ${selectedBulan} (${selectedMinggu}) • Wilayah: ${filterDusun === "ALL" ? "Semua Dusun" : filterDusun} • Tanggal Cetak: ${(/* @__PURE__ */ new Date()).toLocaleDateString("id-ID", {
		day: "numeric",
		month: "long",
		year: "numeric"
	})}`, pageWidth / 2, startY, { align: "center" });
	startY += 16;
	doc.setFillColor(240, 253, 244);
	doc.setDrawColor(167, 243, 208);
	doc.roundedRect(36, startY, pageWidth - 72, 30, 6, 6, "FD");
	doc.setFontSize(8.5);
	doc.setFont("helvetica", "bold");
	if (activeTab === "realisasi_21") {
		const ket = formatRp(grandTotal21.ketetapanRp || 0);
		const real = formatRp(grandTotal21.jumlahRp || 0);
		const sisa = formatRp(grandTotal21.sisaPokokRp || 0);
		const pct = `${(grandTotal21.persentase || 0).toFixed(2)}%`;
		doc.setTextColor(30, 41, 59);
		doc.text(`Target Ketetapan: ${ket}`, 48, startY + 18);
		doc.setTextColor(5, 150, 105);
		doc.text(`Total Realisasi: ${real}`, 220, startY + 18);
		doc.setTextColor(225, 29, 72);
		doc.text(`Sisa Piutang: ${sisa}`, 400, startY + 18);
		doc.setTextColor(4, 120, 87);
		doc.text(`Capaian: ${pct}`, pageWidth - 120, startY + 18);
	} else if (activeTab === "rekap_dhkp") {
		const ket = formatRp(dhkpRecapTotal.totalKetetapan || 0);
		const real = formatRp(dhkpRecapTotal.lunasRp || 0);
		const piutang = formatRp(dhkpRecapTotal.piutangRp || 0);
		const pct = `${(dhkpRecapTotal.totalKetetapan > 0 ? dhkpRecapTotal.lunasRp / dhkpRecapTotal.totalKetetapan * 100 : 0).toFixed(2)}%`;
		doc.setTextColor(30, 41, 59);
		doc.text(`Total Ketetapan DHKP: ${ket}`, 48, startY + 18);
		doc.setTextColor(5, 150, 105);
		doc.text(`Realisasi Lunas: ${real}`, 200, startY + 18);
		doc.setTextColor(225, 29, 72);
		doc.text(`Sisa Piutang: ${piutang}`, 350, startY + 18);
		doc.setTextColor(4, 120, 87);
		doc.text(`Capaian: ${pct}`, pageWidth - 100, startY + 18);
	} else if (activeTab === "piutang_kendali") {
		doc.setTextColor(30, 41, 59);
		doc.text(`Jumlah SPPT Piutang: ${piutangSummary.count} Lembar`, 48, startY + 18);
		doc.setTextColor(14, 116, 144);
		doc.text(`Pokok Pajak: ${formatRp(piutangSummary.totalPokok)}`, 230, startY + 18);
		doc.setTextColor(217, 119, 6);
		doc.text(`Fee Kolektor: ${formatRp(piutangSummary.totalFee)}`, 410, startY + 18);
		doc.setTextColor(5, 150, 105);
		doc.text(`Grand Total Tagihan: ${formatRp(piutangSummary.totalTagihan)}`, pageWidth - 190, startY + 18);
	} else if (activeTab === "fee_kolektor") {
		doc.setTextColor(30, 41, 59);
		doc.text(`Jumlah Transaksi: ${feeKolektorTotal.totalTrx} STTS`, 48, startY + 18);
		doc.setTextColor(5, 150, 105);
		doc.text(`Pokok Setoran: ${formatRp(feeKolektorTotal.totalPokok)}`, 220, startY + 18);
		doc.setTextColor(217, 119, 6);
		doc.text(`Total Fee Kolektor: ${formatRp(feeKolektorTotal.totalFee)}`, 410, startY + 18);
		doc.setTextColor(4, 120, 87);
		doc.text(`Total Akumulasi: ${formatRp(feeKolektorTotal.totalSetoran)}`, pageWidth - 180, startY + 18);
	}
	startY += 40;
	if (activeTab === "realisasi_21") {
		const tableHeaders = [[
			{
				content: "NO",
				rowSpan: 2
			},
			...showDesaColumn ? [{
				content: "DESA",
				rowSpan: 2
			}] : [],
			{
				content: "DUSUN",
				rowSpan: 2
			},
			{
				content: `KETETAPAN (Rp)`,
				rowSpan: 2
			},
			{
				content: "SPPT",
				rowSpan: 2
			},
			{
				content: "POKOK PAJAK TAHUN INI (Rp)",
				colSpan: 3
			},
			{
				content: "TUNGGAKAN PAJAK TAHUN LALU (Rp)",
				colSpan: 3
			},
			{
				content: "TOTAL SETORAN",
				colSpan: 2
			},
			{
				content: "SISA PIUTANG",
				colSpan: 2
			},
			{
				content: "% CAP",
				rowSpan: 2
			}
		], [
			{ content: "LALU" },
			{ content: "INI" },
			{ content: "s/d INI" },
			{ content: "LALU" },
			{ content: "INI" },
			{ content: "s/d INI" },
			{ content: "STTS" },
			{ content: "RUPIAH" },
			{ content: "STTS" },
			{ content: "RUPIAH" }
		]];
		const bodyRows = computed21Rows.map((r, idx) => [
			r.no || idx + 1,
			...showDesaColumn ? [r.namaDesa || "-"] : [],
			r.dusun,
			formatRp(r.ketetapanRp),
			r.jumlahSppt,
			formatRp(r.pokokMingguLaluRp),
			formatRp(r.pokokMingguIniRp),
			formatRp(r.pokokSdMingguIniRp),
			formatRp(r.tunggakanMingguLaluRp),
			formatRp(r.tunggakanMingguIniRp),
			formatRp(r.tunggakanSdMingguIniRp),
			r.jumlahStts,
			formatRp(r.jumlahRp),
			r.sisaStts,
			formatRp(r.sisaPokokRp),
			`${(r.persentase || 0).toFixed(2)}%`
		]);
		const grandTotalRow = [
			"JUMLAH TOTAL",
			...showDesaColumn ? [""] : [],
			"",
			formatRp(grandTotal21.ketetapanRp),
			grandTotal21.jumlahSppt,
			formatRp(grandTotal21.pokokMingguLaluRp),
			formatRp(grandTotal21.pokokMingguIniRp),
			formatRp(grandTotal21.pokokSdMingguIniRp),
			formatRp(grandTotal21.tunggakanMingguLaluRp),
			formatRp(grandTotal21.tunggakanMingguIniRp),
			formatRp(grandTotal21.tunggakanSdMingguIniRp),
			grandTotal21.jumlahStts,
			formatRp(grandTotal21.jumlahRp),
			grandTotal21.sisaStts,
			formatRp(grandTotal21.sisaPokokRp),
			`${(grandTotal21.persentase || 0).toFixed(2)}%`
		];
		autoTable(doc, {
			startY,
			head: tableHeaders,
			body: [...bodyRows, grandTotalRow],
			theme: "grid",
			styles: {
				fontSize: 7,
				cellPadding: 4,
				halign: "center",
				font: "helvetica"
			},
			headStyles: {
				fillColor: [
					5,
					150,
					105
				],
				textColor: 255,
				fontStyle: "bold",
				halign: "center"
			},
			alternateRowStyles: { fillColor: [
				248,
				250,
				252
			] },
			columnStyles: {
				0: { cellWidth: 22 },
				2: {
					halign: "left",
					fontStyle: "bold"
				},
				3: { halign: "right" },
				5: { halign: "right" },
				6: { halign: "right" },
				7: {
					halign: "right",
					fontStyle: "bold",
					textColor: [
						4,
						120,
						87
					]
				},
				8: { halign: "right" },
				9: { halign: "right" },
				10: {
					halign: "right",
					fontStyle: "bold",
					textColor: [
						217,
						119,
						6
					]
				},
				12: {
					halign: "right",
					fontStyle: "bold",
					textColor: [
						4,
						120,
						87
					]
				},
				14: {
					halign: "right",
					fontStyle: "bold",
					textColor: [
						225,
						29,
						72
					]
				},
				15: {
					fontStyle: "bold",
					textColor: [
						4,
						120,
						87
					]
				}
			},
			didParseCell: (data) => {
				if (data.row.index === bodyRows.length) {
					data.cell.styles.fillColor = [
						209,
						250,
						229
					];
					data.cell.styles.fontStyle = "bold";
					data.cell.styles.textColor = [
						6,
						78,
						59
					];
				}
			},
			margin: {
				left: 36,
				right: 36
			}
		});
	} else if (activeTab === "rekap_dhkp") {
		const tableHeaders = [[
			"NO",
			...showDesaColumn ? ["DESA"] : [],
			"DUSUN / LOKASI TANAH",
			"TOTAL SPPT",
			"TOTAL KETETAPAN (Rp)",
			"SPPT LUNAS",
			"REALISASI LUNAS (Rp)",
			"PIUTANG SPPT",
			"PIUTANG (Rp)",
			"% CAPAIAN"
		]];
		const bodyRows = dhkpRecapGrouped.map((g, idx) => {
			const pct = g.totalKetetapan > 0 ? g.lunasRp / g.totalKetetapan * 100 : 0;
			return [
				idx + 1,
				...showDesaColumn ? [g.namaDesa || "-"] : [],
				g.dusun,
				g.totalSppt,
				formatRp(g.totalKetetapan),
				g.lunasSppt,
				formatRp(g.lunasRp),
				g.piutangSppt,
				formatRp(g.piutangRp),
				`${pct.toFixed(2)}%`
			];
		});
		const grandPct = dhkpRecapTotal.totalKetetapan > 0 ? dhkpRecapTotal.lunasRp / dhkpRecapTotal.totalKetetapan * 100 : 0;
		const grandTotalRow = [
			"JUMLAH TOTAL",
			...showDesaColumn ? [""] : [],
			"",
			dhkpRecapTotal.totalSppt,
			formatRp(dhkpRecapTotal.totalKetetapan),
			dhkpRecapTotal.lunasSppt,
			formatRp(dhkpRecapTotal.lunasRp),
			dhkpRecapTotal.piutangSppt,
			formatRp(dhkpRecapTotal.piutangRp),
			`${grandPct.toFixed(2)}%`
		];
		autoTable(doc, {
			startY,
			head: tableHeaders,
			body: [...bodyRows, grandTotalRow],
			theme: "grid",
			styles: {
				fontSize: 8,
				cellPadding: 5,
				halign: "center",
				font: "helvetica"
			},
			headStyles: {
				fillColor: [
					5,
					150,
					105
				],
				textColor: 255,
				fontStyle: "bold"
			},
			alternateRowStyles: { fillColor: [
				248,
				250,
				252
			] },
			columnStyles: {
				0: { cellWidth: 30 },
				2: {
					halign: "left",
					fontStyle: "bold"
				},
				4: { halign: "right" },
				6: {
					halign: "right",
					fontStyle: "bold",
					textColor: [
						4,
						120,
						87
					]
				},
				8: {
					halign: "right",
					fontStyle: "bold",
					textColor: [
						225,
						29,
						72
					]
				},
				9: {
					fontStyle: "bold",
					textColor: [
						4,
						120,
						87
					]
				}
			},
			didParseCell: (data) => {
				if (data.row.index === bodyRows.length) {
					data.cell.styles.fillColor = [
						209,
						250,
						229
					];
					data.cell.styles.fontStyle = "bold";
					data.cell.styles.textColor = [
						6,
						78,
						59
					];
				}
			},
			margin: {
				left: 36,
				right: 36
			}
		});
	} else if (activeTab === "piutang_kendali") {
		const tableHeaders = [[
			"NO",
			...showDesaColumn ? ["DESA"] : [],
			"NOP & TAHUN",
			"NAMA SPPT & PEMILIK",
			"ALAMAT",
			"DUSUN",
			"DOMISILI",
			"POKOK (Rp)",
			"FEE KOLEKTOR",
			"TOTAL TAGIHAN",
			"PARAF WP"
		]];
		const bodyRows = piutangList.map((p, idx) => {
			const fee = p.domisili === "LUAR_DESA" && settings.enableFeeKolektorLuarDesa ? settings.feeKolektorLuarDesa || 5e3 : 0;
			const pokok = p.tagihan ?? p.dibulatkan ?? 0;
			return [
				idx + 1,
				...showDesaColumn ? [p.namaDesa || "-"] : [],
				`${p.nop}\nThn ${p.tahun}`,
				`${p.namaSppt}\n(Pemilik: ${p.namaAktual || p.namaSppt})`,
				p.alamatPemilik || "-",
				`${p.dusun}\n${p.blok}`,
				p.domisili === "LUAR_DESA" ? "Luar Desa" : "Dalam Desa",
				formatRp(pokok),
				fee > 0 ? formatRp(fee) : "-",
				formatRp(pokok + fee),
				".................."
			];
		});
		const grandTotalRow = [
			"JUMLAH TOTAL PIUTANG",
			...showDesaColumn ? [""] : [],
			"",
			"",
			"",
			"",
			"",
			formatRp(piutangSummary.totalPokok),
			formatRp(piutangSummary.totalFee),
			formatRp(piutangSummary.totalTagihan),
			""
		];
		autoTable(doc, {
			startY,
			head: tableHeaders,
			body: [...bodyRows, grandTotalRow],
			theme: "grid",
			styles: {
				fontSize: 7.5,
				cellPadding: 4,
				halign: "center",
				font: "helvetica"
			},
			headStyles: {
				fillColor: [
					5,
					150,
					105
				],
				textColor: 255,
				fontStyle: "bold"
			},
			alternateRowStyles: { fillColor: [
				248,
				250,
				252
			] },
			columnStyles: {
				0: { cellWidth: 25 },
				2: {
					fontStyle: "bold",
					halign: "left"
				},
				3: { halign: "left" },
				4: { halign: "left" },
				7: { halign: "right" },
				8: {
					halign: "right",
					textColor: [
						217,
						119,
						6
					]
				},
				9: {
					halign: "right",
					fontStyle: "bold",
					textColor: [
						4,
						120,
						87
					]
				}
			},
			didParseCell: (data) => {
				if (data.row.index === bodyRows.length) {
					data.cell.styles.fillColor = [
						254,
						243,
						199
					];
					data.cell.styles.fontStyle = "bold";
					data.cell.styles.textColor = [
						146,
						64,
						14
					];
				}
			},
			margin: {
				left: 36,
				right: 36
			}
		});
	} else if (activeTab === "fee_kolektor") {
		const tableHeaders = [[
			"NO",
			...showDesaColumn ? ["DESA"] : [],
			"NO STTS",
			"TANGGAL",
			"NOP",
			"WAJIB PAJAK",
			"DUSUN / LOKASI",
			"POKOK PAJAK (Rp)",
			"FEE KOLEKTOR (Rp)",
			"TOTAL SETORAN (Rp)",
			"PETUGAS KASIR"
		]];
		const bodyRows = feeKolektorList.map((f, idx) => [
			idx + 1,
			...showDesaColumn ? [f.namaDesa || "-"] : [],
			f.noStts,
			f.tanggal,
			f.nop,
			f.namaSppt,
			`${f.dusun} - ${f.blok}`,
			formatRp(f.pokok),
			formatRp(f.feeKolektor),
			formatRp(f.totalBayar),
			f.petugas
		]);
		const grandTotalRow = [
			"JUMLAH TOTAL FEE KOLEKTOR",
			...showDesaColumn ? [""] : [],
			"",
			"",
			"",
			"",
			"",
			formatRp(feeKolektorTotal.totalPokok),
			formatRp(feeKolektorTotal.totalFee),
			formatRp(feeKolektorTotal.totalSetoran),
			""
		];
		autoTable(doc, {
			startY,
			head: tableHeaders,
			body: [...bodyRows, grandTotalRow],
			theme: "grid",
			styles: {
				fontSize: 7.5,
				cellPadding: 4,
				halign: "center",
				font: "helvetica"
			},
			headStyles: {
				fillColor: [
					5,
					150,
					105
				],
				textColor: 255,
				fontStyle: "bold"
			},
			alternateRowStyles: { fillColor: [
				248,
				250,
				252
			] },
			columnStyles: {
				0: { cellWidth: 25 },
				2: { fontStyle: "bold" },
				4: { fontStyle: "bold" },
				5: { halign: "left" },
				7: { halign: "right" },
				8: {
					halign: "right",
					fontStyle: "bold",
					textColor: [
						217,
						119,
						6
					]
				},
				9: {
					halign: "right",
					fontStyle: "bold",
					textColor: [
						4,
						120,
						87
					]
				}
			},
			didParseCell: (data) => {
				if (data.row.index === bodyRows.length) {
					data.cell.styles.fillColor = [
						254,
						243,
						199
					];
					data.cell.styles.fontStyle = "bold";
					data.cell.styles.textColor = [
						146,
						64,
						14
					];
				}
			},
			margin: {
				left: 36,
				right: 36
			}
		});
	}
	const finalY = doc.lastAutoTable ? doc.lastAutoTable.finalY + 30 : startY + 100;
	if (finalY + 90 > pageHeight) doc.addPage();
	const sigY = finalY + 90 > pageHeight ? 50 : finalY;
	const leftColX = pageWidth * .25;
	const rightColX = pageWidth * .75;
	doc.setFont("helvetica", "normal");
	doc.setFontSize(8.5);
	doc.setTextColor(30, 41, 59);
	const targetNamaKades = signerInfo?.namaKades || settings.namaKades;
	const targetNipKades = signerInfo?.nipKades || settings.nipKades;
	const targetJabatanKades = signerInfo?.jabatanKades || settings.jabatanKades || "Kepala Desa";
	const pejabat1Title = isKecamatanLevel ? `CAMAT ${settings.kecamatan.toUpperCase()}` : `${targetJabatanKades} ${activeNamaDesa}`;
	const pejabat1Name = isKecamatanLevel ? settings.namaKades || `Camat ${settings.kecamatan}` : targetNamaKades || "________________________";
	const pejabat1Sub = isKecamatanLevel ? settings.nipKades ? `NIP. ${settings.nipKades}` : `Pemerintah Kecamatan ${settings.kecamatan}` : targetNipKades ? `NIP. ${targetNipKades}` : `${targetJabatanKades} ${activeNamaDesa}`;
	doc.text("Mengetahui,", leftColX, sigY, { align: "center" });
	doc.setFont("helvetica", "bold");
	doc.text(pejabat1Title, leftColX, sigY + 12, { align: "center" });
	doc.setFont("helvetica", "bold");
	doc.text(pejabat1Name, leftColX, sigY + 55, { align: "center" });
	doc.setFont("helvetica", "normal");
	doc.setFontSize(8);
	doc.text(pejabat1Sub, leftColX, sigY + 66, { align: "center" });
	const targetNamaPetugas = signerInfo?.namaPetugas || settings.namaPetugas;
	const targetNipPetugas = signerInfo?.nipPetugas || settings.nipPetugas;
	const targetJabatanPetugas = signerInfo?.jabatanPetugas || settings.jabatanPetugas || "Bendahara / Kolektor Utama PBB-P2";
	const pejabat2Title = isKecamatanLevel ? "KASI PEMERINTAHAN / TIM PBB KECAMATAN" : targetJabatanPetugas;
	const pejabat2Name = isKecamatanLevel ? settings.namaPetugas || "Tim Pajak Kecamatan" : targetNamaPetugas || "________________________";
	const pejabat2Sub = isKecamatanLevel ? settings.nipPetugas ? `NIP/NIK. ${settings.nipPetugas}` : `Kecamatan ${settings.kecamatan}` : targetNipPetugas ? `NIP/NIK. ${targetNipPetugas}` : `${targetJabatanPetugas} ${activeNamaDesa}`;
	doc.text(`${settings.kecamatan}, ${(/* @__PURE__ */ new Date()).toLocaleDateString("id-ID", {
		day: "numeric",
		month: "long",
		year: "numeric"
	})}`, rightColX, sigY, { align: "center" });
	doc.setFont("helvetica", "bold");
	doc.text(pejabat2Title, rightColX, sigY + 12, { align: "center" });
	doc.setFont("helvetica", "bold");
	doc.text(pejabat2Name, rightColX, sigY + 55, { align: "center" });
	doc.setFont("helvetica", "normal");
	doc.setFontSize(8);
	doc.text(pejabat2Sub, rightColX, sigY + 66, { align: "center" });
	const totalPages = doc.internal.getNumberOfPages();
	for (let i = 1; i <= totalPages; i++) {
		doc.setPage(i);
		doc.setFont("helvetica", "normal");
		doc.setFontSize(7.5);
		doc.setTextColor(148, 163, 184);
		doc.text(`SIPABAR (Sistem Informasi Pajak Barudua) • Halaman ${i} dari ${totalPages}`, pageWidth / 2, pageHeight - 14, { align: "center" });
	}
	const filename = `${titleText.replace(/[\s\/\(\)]+/g, "_")}_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.pdf`;
	doc.save(filename);
	return filename;
};
var Realisasi21KolomTab = ({ calculatedRows, totalRow, onOpenEdit, onDeleteDusun, showDesaColumn = false }) => {
	const cap = totalRow?.persentase || 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 print:hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "border-sky-200/60 dark:border-slate-800 bg-gradient-to-br from-sky-50/70 via-white to-blue-50/30 dark:from-slate-900 dark:via-slate-900 dark:to-slate-950 shadow-md hover:shadow-lg transition-all rounded-2xl overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-5 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold uppercase tracking-wider text-sky-800 dark:text-sky-400 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, { className: "size-4 text-sky-600 dark:text-sky-400 shrink-0" }), "Total Ketetapan PBB-P2"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-sky-700 dark:text-sky-300",
									children: formatRp(totalRow?.ketetapanRp || 0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] text-slate-500 font-medium",
									children: [(totalRow?.jumlahSppt || 0).toLocaleString("id-ID"), " Lembar SPPT"]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-3 bg-sky-500/10 dark:bg-sky-500/20 text-sky-600 dark:text-sky-400 rounded-xl shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-6" })
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "border-emerald-200/60 dark:border-slate-800 bg-gradient-to-br from-emerald-50/70 via-white to-teal-50/30 dark:from-slate-900 dark:via-slate-900 dark:to-slate-950 shadow-md hover:shadow-lg transition-all rounded-2xl overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-5 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold uppercase tracking-wider text-emerald-800 dark:text-emerald-400 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-emerald-600 dark:text-emerald-400 shrink-0" }), "Total Setoran Realisasi"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-emerald-700 dark:text-emerald-300",
									children: formatRp(totalRow?.jumlahRp || 0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] text-slate-500 font-medium",
									children: [(totalRow?.jumlahStts || 0).toLocaleString("id-ID"), " Transaksi STTS"]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-3 bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-xl shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-6" })
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "border-rose-200/60 dark:border-slate-800 bg-gradient-to-br from-rose-50/70 via-white to-pink-50/30 dark:from-slate-900 dark:via-slate-900 dark:to-slate-950 shadow-md hover:shadow-lg transition-all rounded-2xl overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-5 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold uppercase tracking-wider text-rose-800 dark:text-rose-400 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-4 text-rose-600 dark:text-rose-400 shrink-0" }), "Sisa Piutang Belum Bayar"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-rose-700 dark:text-rose-400",
									children: formatRp(totalRow?.sisaPokokRp || 0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] text-slate-500 font-medium",
									children: [(totalRow?.sisaStts || 0).toLocaleString("id-ID"), " SPPT Terutang"]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-3 bg-rose-500/10 dark:bg-rose-500/20 text-rose-600 dark:text-rose-400 rounded-xl shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-6" })
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "border-emerald-500/40 dark:border-emerald-600/50 bg-gradient-to-br from-emerald-600 to-teal-700 text-white shadow-lg hover:shadow-xl transition-all rounded-2xl overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-5 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold uppercase tracking-wider text-emerald-100 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartPie, { className: "size-4 text-emerald-200 shrink-0" }), "Persentase Capaian"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-2xl font-black text-white drop-shadow-sm",
									children: [cap.toFixed(2), "%"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-emerald-100/80 font-medium",
									children: "Realisasi vs Ketetapan"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-3 bg-white/10 text-white rounded-xl backdrop-blur-md shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartPie, { className: "size-6" })
						})]
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "border-emerald-200 dark:border-slate-800 bg-white dark:bg-slate-900/90 shadow-xl rounded-3xl overflow-hidden print:shadow-none print:border-none print:rounded-none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
				className: "border-b border-emerald-100 dark:border-slate-800 bg-gradient-to-r from-emerald-50/50 to-teal-50/20 dark:from-slate-900 dark:to-slate-950 p-6 print:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center justify-between",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
						className: "text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-5 text-emerald-600 dark:text-emerald-400" }), " REKAPITULASI SETORAN PBB-P2 PER DUSUN (FORMAT 21 KOLOM BAPENDA)"]
					})
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "p-0 overflow-x-auto custom-scrollbar print:overflow-visible",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
					className: "w-full text-[11px] border-collapse min-w-[1300px] print:min-w-full",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableHeader, {
						className: "bg-emerald-900 dark:bg-slate-950 text-white font-bold text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
								className: "border-b border-emerald-800 dark:border-slate-800",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										rowSpan: 3,
										className: "text-center w-10 text-white border-r border-emerald-800 dark:border-slate-800",
										children: "NO"
									}),
									showDesaColumn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										rowSpan: 3,
										className: "text-center w-36 text-emerald-300 dark:text-emerald-400 font-black border-r border-emerald-800 dark:border-slate-800 bg-emerald-950/60",
										children: "DESA"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										rowSpan: 3,
										className: "text-center w-36 text-white border-r border-emerald-800 dark:border-slate-800",
										children: "DUSUN"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										rowSpan: 3,
										className: "text-center w-28 text-white border-r border-emerald-800 dark:border-slate-800",
										children: "KETETAPAN (Rp)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										rowSpan: 3,
										className: "text-center w-20 text-white border-r border-emerald-800 dark:border-slate-800",
										children: "JUMLAH SPPT"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										colSpan: 6,
										className: "text-center text-white border-r border-emerald-800 dark:border-slate-800 border-b",
										children: "PENERIMAAN POKOK PAJAK TAHUN INI"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										colSpan: 6,
										className: "text-center text-white border-r border-emerald-800 dark:border-slate-800 border-b",
										children: "PENERIMAAN TUNGGAKAN PAJAK TAHUN LALU"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										colSpan: 2,
										className: "text-center text-white border-r border-emerald-800 dark:border-slate-800 border-b",
										children: "TOTAL PENERIMAAN (s/d MINGGU INI)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										colSpan: 2,
										className: "text-center text-white border-r border-emerald-800 dark:border-slate-800 border-b",
										children: "SISA PBB BELUM TERBAYAR"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										rowSpan: 3,
										className: "text-center w-20 text-white border-r border-emerald-800 dark:border-slate-800",
										children: "% CAPAIAN"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										rowSpan: 3,
										className: "text-center w-20 text-white print:hidden",
										children: "AKSI"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
								className: "border-b border-emerald-800 dark:border-slate-800",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										colSpan: 2,
										className: "text-center text-emerald-100 border-r border-emerald-800 border-b",
										children: "s/d MINGGU LALU"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										colSpan: 2,
										className: "text-center text-emerald-100 border-r border-emerald-800 border-b",
										children: "MINGGU INI"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										colSpan: 2,
										className: "text-center text-emerald-100 border-r border-emerald-800 border-b",
										children: "s/d MINGGU INI"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										colSpan: 2,
										className: "text-center text-emerald-100 border-r border-emerald-800 border-b",
										children: "s/d MINGGU LALU"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										colSpan: 2,
										className: "text-center text-emerald-100 border-r border-emerald-800 border-b",
										children: "MINGGU INI"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										colSpan: 2,
										className: "text-center text-emerald-100 border-r border-emerald-800 border-b",
										children: "s/d MINGGU INI"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										rowSpan: 2,
										className: "text-center text-emerald-100 border-r border-emerald-800",
										children: "STTS"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										rowSpan: 2,
										className: "text-center text-emerald-100 border-r border-emerald-800",
										children: "RUPIAH (Rp)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										rowSpan: 2,
										className: "text-center text-emerald-100 border-r border-emerald-800",
										children: "STTS"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										rowSpan: 2,
										className: "text-center text-emerald-100 border-r border-emerald-800",
										children: "RUPIAH (Rp)"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
								className: "border-b border-emerald-800 text-[10px]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										className: "text-center text-slate-200 border-r border-emerald-800",
										children: "STTS"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										className: "text-center text-slate-200 border-r border-emerald-800",
										children: "RUPIAH"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										className: "text-center text-slate-200 border-r border-emerald-800",
										children: "STTS"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										className: "text-center text-slate-200 border-r border-emerald-800",
										children: "RUPIAH"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										className: "text-center text-slate-200 border-r border-emerald-800",
										children: "STTS"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										className: "text-center text-slate-200 border-r border-emerald-800",
										children: "RUPIAH"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										className: "text-center text-slate-200 border-r border-emerald-800",
										children: "STTS"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										className: "text-center text-slate-200 border-r border-emerald-800",
										children: "RUPIAH"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										className: "text-center text-slate-200 border-r border-emerald-800",
										children: "STTS"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										className: "text-center text-slate-200 border-r border-emerald-800",
										children: "RUPIAH"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										className: "text-center text-slate-200 border-r border-emerald-800",
										children: "STTS"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
										className: "text-center text-slate-200 border-r border-emerald-800",
										children: "RUPIAH"
									})
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableBody, {
						className: "divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-slate-900",
						children: [calculatedRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							colSpan: showDesaColumn ? 23 : 22,
							className: "text-center py-10 text-slate-500 font-medium",
							children: "Belum ada data DHKP atau transaksi per Dusun di database backend. Silakan import atau buat data DHKP."
						}) }) : calculatedRows.map((r, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
							className: "hover:bg-emerald-50/50 dark:hover:bg-slate-800/40",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-bold text-slate-500",
									children: r.no || idx + 1
								}),
								showDesaColumn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-50/40 dark:bg-emerald-950/20",
									children: r.namaDesa || "-"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "font-bold text-slate-900 dark:text-slate-100",
									children: r.dusun
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono font-semibold",
									children: formatRp(r.ketetapanRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono",
									children: r.jumlahSppt
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono",
									children: r.pokokMingguLaluStts
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono",
									children: formatRp(r.pokokMingguLaluRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono",
									children: r.pokokMingguIniStts
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono",
									children: formatRp(r.pokokMingguIniRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono font-bold text-emerald-600 dark:text-emerald-400",
									children: r.pokokSdMingguIniStts
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono font-bold text-emerald-600 dark:text-emerald-400",
									children: formatRp(r.pokokSdMingguIniRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono",
									children: r.tunggakanMingguLaluStts
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono",
									children: formatRp(r.tunggakanMingguLaluRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono",
									children: r.tunggakanMingguIniStts
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono",
									children: formatRp(r.tunggakanMingguIniRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono font-bold text-amber-600 dark:text-amber-400",
									children: r.tunggakanSdMingguIniStts
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono font-bold text-amber-600 dark:text-amber-400",
									children: formatRp(r.tunggakanSdMingguIniRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono font-black text-emerald-700 dark:text-emerald-400",
									children: r.jumlahStts
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono font-black text-emerald-700 dark:text-emerald-400",
									children: formatRp(r.jumlahRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono font-bold text-rose-600 dark:text-rose-400",
									children: r.sisaStts
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono font-bold text-rose-600 dark:text-rose-400",
									children: formatRp(r.sisaPokokRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
									className: "text-center font-mono font-black bg-emerald-50 dark:bg-slate-800/80 text-emerald-700 dark:text-emerald-300",
									children: [(r.persentase || 0).toFixed(2), "%"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center print:hidden",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "ghost",
											size: "icon",
											onClick: () => onOpenEdit(idx),
											className: "h-7 w-7 text-amber-600 hover:bg-amber-50",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3.5" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "ghost",
											size: "icon",
											onClick: () => onDeleteDusun(idx),
											className: "h-7 w-7 text-rose-600 hover:bg-rose-50",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
										})]
									})
								})
							]
						}, idx)), totalRow && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
							className: "bg-emerald-100 dark:bg-slate-950 font-black text-slate-900 dark:text-white border-t-2 border-slate-900",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									colSpan: showDesaColumn ? 3 : 2,
									className: "text-center uppercase font-black",
									children: "JUMLAH TOTAL"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono",
									children: formatRp(totalRow.ketetapanRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono",
									children: totalRow.jumlahSppt
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono",
									children: totalRow.pokokMingguLaluStts
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono",
									children: formatRp(totalRow.pokokMingguLaluRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono",
									children: totalRow.pokokMingguIniStts
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono",
									children: formatRp(totalRow.pokokMingguIniRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono text-emerald-700 dark:text-emerald-400",
									children: totalRow.pokokSdMingguIniStts
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono text-emerald-700 dark:text-emerald-400",
									children: formatRp(totalRow.pokokSdMingguIniRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono",
									children: totalRow.tunggakanMingguLaluStts
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono",
									children: formatRp(totalRow.tunggakanMingguLaluRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono",
									children: totalRow.tunggakanMingguIniStts
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono",
									children: formatRp(totalRow.tunggakanMingguIniRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono text-amber-700 dark:text-amber-400",
									children: totalRow.tunggakanSdMingguIniStts
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono text-amber-700 dark:text-amber-400",
									children: formatRp(totalRow.tunggakanSdMingguIniRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono text-emerald-800 dark:text-emerald-300",
									children: totalRow.jumlahStts
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono text-emerald-800 dark:text-emerald-300",
									children: formatRp(totalRow.jumlahRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono text-rose-700 dark:text-rose-400",
									children: totalRow.sisaStts
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono text-rose-700 dark:text-rose-400",
									children: formatRp(totalRow.sisaPokokRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
									className: "text-center font-mono text-emerald-900 dark:text-emerald-300 bg-emerald-200 dark:bg-emerald-950",
									children: [(totalRow.persentase || 0).toFixed(2), "%"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { className: "print:hidden" })
							]
						})]
					})]
				})
			})]
		})]
	});
};
var RekapDhkpBlokTab = ({ recapGroupedList, dhkpRecapTotal, showDesaColumn = false }) => {
	const totalKetetapan = dhkpRecapTotal?.totalKetetapan || 0;
	const lunasRp = dhkpRecapTotal?.lunasRp || 0;
	const piutangRp = dhkpRecapTotal?.piutangRp || 0;
	const pctCapaian = totalKetetapan > 0 ? lunasRp / totalKetetapan * 100 : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 print:hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "border-sky-200/60 dark:border-slate-800 bg-gradient-to-br from-sky-50/70 via-white to-blue-50/30 dark:from-slate-900 dark:via-slate-900 dark:to-slate-950 shadow-md hover:shadow-lg transition-all rounded-2xl overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-5 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold uppercase tracking-wider text-sky-800 dark:text-sky-400 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4 text-sky-600 dark:text-sky-400 shrink-0" }), "Total Ketetapan DHKP"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-sky-700 dark:text-sky-300",
									children: formatRp(totalKetetapan)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] text-slate-500 font-medium",
									children: [(dhkpRecapTotal?.totalSppt || 0).toLocaleString("id-ID"), " Lembar SPPT"]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-3 bg-sky-500/10 dark:bg-sky-500/20 text-sky-600 dark:text-sky-400 rounded-xl shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-6" })
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "border-emerald-200/60 dark:border-slate-800 bg-gradient-to-br from-emerald-50/70 via-white to-teal-50/30 dark:from-slate-900 dark:via-slate-900 dark:to-slate-950 shadow-md hover:shadow-lg transition-all rounded-2xl overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-5 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold uppercase tracking-wider text-emerald-800 dark:text-emerald-400 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-4 text-emerald-600 dark:text-emerald-400 shrink-0" }), "Realisasi Lunas"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-emerald-700 dark:text-emerald-300",
									children: formatRp(lunasRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] text-slate-500 font-medium",
									children: [(dhkpRecapTotal?.lunasSppt || 0).toLocaleString("id-ID"), " SPPT Terbayar"]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-3 bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-xl shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-6" })
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "border-rose-200/60 dark:border-slate-800 bg-gradient-to-br from-rose-50/70 via-white to-pink-50/30 dark:from-slate-900 dark:via-slate-900 dark:to-slate-950 shadow-md hover:shadow-lg transition-all rounded-2xl overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-5 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold uppercase tracking-wider text-rose-800 dark:text-rose-400 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4 text-rose-600 dark:text-rose-400 shrink-0" }), "Sisa Piutang Terutang"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-rose-700 dark:text-rose-400",
									children: formatRp(piutangRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-[11px] text-slate-500 font-medium",
									children: [(dhkpRecapTotal?.piutangSppt || 0).toLocaleString("id-ID"), " SPPT Belum Bayar"]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-3 bg-rose-500/10 dark:bg-rose-500/20 text-rose-600 dark:text-rose-400 rounded-xl shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-6" })
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "border-emerald-500/40 dark:border-emerald-600/50 bg-gradient-to-br from-emerald-600 to-teal-700 text-white shadow-lg hover:shadow-xl transition-all rounded-2xl overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-5 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold uppercase tracking-wider text-emerald-100 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "size-4 text-emerald-200 shrink-0" }), "Capaian DHKP"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-2xl font-black text-white drop-shadow-sm",
									children: [pctCapaian.toFixed(2), "%"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-emerald-100/80 font-medium",
									children: "Rasio Lunas / Ketetapan"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-3 bg-white/10 text-white rounded-xl backdrop-blur-md shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "size-6" })
						})]
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "border-emerald-200 dark:border-slate-800 bg-white dark:bg-slate-900/90 shadow-xl rounded-3xl overflow-hidden print:shadow-none print:border-none print:rounded-none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
				className: "border-b border-emerald-100 dark:border-slate-800 bg-gradient-to-r from-emerald-50/50 to-teal-50/20 dark:from-slate-900 dark:to-slate-950 p-6 print:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
					className: "text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5 text-emerald-600 dark:text-emerald-400" }), " REKAPITULASI KETETAPAN & REALISASI DHKP PER DUSUN / LOKASI TANAH"]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "p-0 overflow-x-auto custom-scrollbar print:overflow-visible",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
					className: "w-full text-xs print:min-w-full",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, {
						className: "bg-emerald-900 dark:bg-slate-950 text-white font-bold",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-center w-12 text-white",
								children: "NO"
							}),
							showDesaColumn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-white",
								children: "DESA"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-white",
								children: "DUSUN / LOKASI TANAH"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-center text-white",
								children: "TOTAL SPPT"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-right text-white",
								children: "TOTAL KETETAPAN (Rp)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-center text-white",
								children: "SPPT LUNAS"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-right text-white",
								children: "REALISASI LUNAS (Rp)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-center text-white",
								children: "SPPT PIUTANG"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-right text-white",
								children: "PIUTANG TERUTANG (Rp)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-center text-white",
								children: "% CAPAIAN"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableBody, {
						className: "divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-slate-900",
						children: [recapGroupedList.map((g, idx) => {
							const pct = g.totalKetetapan > 0 ? g.lunasRp / g.totalKetetapan * 100 : 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
								className: "hover:bg-emerald-50/50 dark:hover:bg-slate-800/40",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										className: "text-center font-bold text-slate-500",
										children: idx + 1
									}),
									showDesaColumn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										className: "font-bold text-slate-900 dark:text-slate-100",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "outline",
											className: "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300 dark:border-emerald-800",
											children: g.namaDesa || "-"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										className: "font-bold text-slate-900 dark:text-slate-100",
										children: g.dusun
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										className: "text-center font-mono",
										children: g.totalSppt
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										className: "text-right font-mono font-semibold",
										children: formatRp(g.totalKetetapan)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										className: "text-center font-mono text-emerald-600 font-bold",
										children: g.lunasSppt
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										className: "text-right font-mono font-bold text-emerald-600 dark:text-emerald-400",
										children: formatRp(g.lunasRp)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										className: "text-center font-mono text-rose-600 font-bold",
										children: g.piutangSppt
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										className: "text-right font-mono font-bold text-rose-600 dark:text-rose-400",
										children: formatRp(g.piutangRp)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
										className: "text-center font-mono font-bold text-emerald-700 dark:text-emerald-300",
										children: [pct.toFixed(2), "%"]
									})
								]
							}, idx);
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
							className: "bg-amber-100 dark:bg-slate-950 font-black text-slate-900 dark:text-white border-t-2 border-slate-900",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									colSpan: showDesaColumn ? 3 : 2,
									className: "text-center uppercase font-black",
									children: "JUMLAH TOTAL REKAPITULASI DHKP"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono",
									children: dhkpRecapTotal.totalSppt
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono",
									children: formatRp(dhkpRecapTotal.totalKetetapan)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono text-emerald-700 dark:text-emerald-400",
									children: dhkpRecapTotal.lunasSppt
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono text-emerald-700 dark:text-emerald-400",
									children: formatRp(dhkpRecapTotal.lunasRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono text-rose-700 dark:text-rose-400",
									children: dhkpRecapTotal.piutangSppt
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono text-rose-700 dark:text-rose-400",
									children: formatRp(dhkpRecapTotal.piutangRp)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
									className: "text-center font-mono text-emerald-900 dark:text-emerald-300",
									children: [(dhkpRecapTotal.totalKetetapan > 0 ? dhkpRecapTotal.lunasRp / dhkpRecapTotal.totalKetetapan * 100 : 0).toFixed(2), "%"]
								})
							]
						})]
					})]
				})
			})]
		})]
	});
};
var PiutangKendaliTab = ({ piutangList, piutangSummary, settings, showDesaColumn = false }) => {
	const [currentPage, setCurrentPage] = (0, import_react.useState)(1);
	const [pageSize, setPageSize] = (0, import_react.useState)(25);
	(0, import_react.useEffect)(() => {
		setCurrentPage(1);
	}, [piutangList]);
	const totalItems = piutangList.length;
	const totalPages = pageSize === 0 ? 1 : Math.max(1, Math.ceil(totalItems / pageSize));
	const effectivePage = Math.min(currentPage, totalPages);
	const startIndex = pageSize === 0 ? 0 : (effectivePage - 1) * pageSize;
	const endIndex = pageSize === 0 ? totalItems : Math.min(startIndex + pageSize, totalItems);
	pageSize === 0 || piutangList.slice(startIndex, endIndex);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 print:hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "border-emerald-200/60 dark:border-slate-800 bg-gradient-to-br from-emerald-50/70 via-white to-teal-50/30 dark:from-slate-900 dark:via-slate-900 dark:to-slate-950 shadow-md hover:shadow-lg transition-all rounded-2xl overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-5 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold uppercase tracking-wider text-emerald-800 dark:text-emerald-400 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4 text-emerald-600 dark:text-emerald-400 shrink-0" }), "Jumlah SPPT Piutang"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-2xl font-black text-slate-900 dark:text-white",
										children: piutangSummary.count.toLocaleString("id-ID")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold text-slate-500",
										children: "Lembar"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-slate-500 font-medium",
									children: "Tagihan Door-to-Door"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-3 bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-xl shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "size-6" })
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "border-sky-200/60 dark:border-slate-800 bg-gradient-to-br from-sky-50/70 via-white to-blue-50/30 dark:from-slate-900 dark:via-slate-900 dark:to-slate-950 shadow-md hover:shadow-lg transition-all rounded-2xl overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-5 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold uppercase tracking-wider text-sky-800 dark:text-sky-400 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, { className: "size-4 text-sky-600 dark:text-sky-400 shrink-0" }), "Total Pokok PBB-P2"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-sky-700 dark:text-sky-300",
									children: formatRp(piutangSummary.totalPokok)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-slate-500 font-medium",
									children: "Ketetapan Murni Pajak"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-3 bg-sky-500/10 dark:bg-sky-500/20 text-sky-600 dark:text-sky-400 rounded-xl shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, { className: "size-6" })
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "border-amber-200/60 dark:border-slate-800 bg-gradient-to-br from-amber-50/70 via-white to-orange-50/30 dark:from-slate-900 dark:via-slate-900 dark:to-slate-950 shadow-md hover:shadow-lg transition-all rounded-2xl overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-5 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold uppercase tracking-wider text-amber-800 dark:text-amber-400 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { className: "size-4 text-amber-600 dark:text-amber-400 shrink-0" }), "Total Fee Kolektor"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-amber-700 dark:text-amber-400",
									children: formatRp(piutangSummary.totalFee)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-slate-500 font-medium",
									children: "Insentif WP Luar Desa"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-3 bg-amber-500/10 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 rounded-xl shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { className: "size-6" })
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "border-emerald-500/40 dark:border-emerald-600/50 bg-gradient-to-br from-emerald-600 to-teal-700 text-white shadow-lg hover:shadow-xl transition-all rounded-2xl overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-5 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold uppercase tracking-wider text-emerald-100 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "size-4 text-emerald-200 shrink-0" }), "Grand Total Piutang"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-white drop-shadow-sm",
									children: formatRp(piutangSummary.totalTagihan)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-emerald-100/80 font-medium",
									children: "Pokok + Fee Kolektor"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-3 bg-white/10 text-white rounded-xl backdrop-blur-md shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "size-6" })
						})]
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "border-emerald-200 dark:border-slate-800 bg-white dark:bg-slate-900/90 shadow-xl rounded-3xl overflow-hidden print:shadow-none print:border-none print:rounded-none",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
					className: "border-b border-emerald-100 dark:border-slate-800 bg-gradient-to-r from-emerald-50/50 to-teal-50/20 dark:from-slate-900 dark:to-slate-950 p-6 print:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
							className: "text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2 flex-wrap",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "size-5 text-emerald-600 dark:text-emerald-400 shrink-0" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "LEMBAR KENDALI PENAGIHAN PIUTANG PAJAK (DOOR-TO-DOOR)" }),
								showDesaColumn && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "outline",
									className: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-500/30 text-xs font-bold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3 mr-1 inline" }), " Seluruh Desa"]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-left sm:text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-slate-500 font-medium",
								children: "Total Piutang Belum Lunas:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm font-black text-amber-600 dark:text-amber-400",
								children: [
									piutangSummary.count,
									" SPPT (",
									formatRp(piutangSummary.totalTagihan),
									")"
								]
							})]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
					className: "p-0 overflow-x-auto custom-scrollbar print:overflow-visible",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
						className: "w-full text-xs min-w-[1000px] print:min-w-full",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, {
							className: "bg-emerald-900 dark:bg-slate-950 text-white font-bold print:bg-slate-100 print:text-black",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "text-center w-12 text-white print:text-black",
									children: "NO"
								}),
								showDesaColumn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "text-white print:text-black",
									children: "DESA"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "text-white print:text-black",
									children: "NOP & TAHUN"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "text-white print:text-black",
									children: "WAJIB PAJAK & PEMILIK"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "text-white print:text-black",
									children: "ALAMAT PEMILIK"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "text-center text-white print:text-black",
									children: "DUSUN / BLOK"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "text-center text-white print:text-black",
									children: "DOMISILI"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "text-right text-white print:text-black",
									children: "POKOK (Rp)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "text-right text-white print:text-black",
									children: "FEE KOLEKTOR"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "text-right text-white print:text-black",
									children: "TOTAL TAGIHAN"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									className: "text-center text-white print:text-black w-28",
									children: "PARAF / TTD WP"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableBody, {
							className: "divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-slate-900",
							children: [piutangList.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								colSpan: showDesaColumn ? 11 : 10,
								className: "text-center py-8 text-slate-400 font-medium",
								children: "Tidak ada data piutang penagihan untuk filter yang dipilih."
							}) }) : piutangList.map((p, i) => {
								const globalIdx = i + 1;
								const isVisibleOnScreen = pageSize === 0 || i >= startIndex && i < endIndex;
								const fee = p.domisili === "LUAR_DESA" && settings.enableFeeKolektorLuarDesa ? settings.feeKolektorLuarDesa || 5e3 : 0;
								const pokok = p.tagihan ?? p.dibulatkan ?? 0;
								const total = pokok + fee;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
									className: isVisibleOnScreen ? "hover:bg-amber-50/50 dark:hover:bg-slate-800/40" : "hidden print:table-row hover:bg-amber-50/50 dark:hover:bg-slate-800/40",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
											className: "text-center font-mono font-bold text-slate-500",
											children: globalIdx
										}),
										showDesaColumn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
											variant: "outline",
											className: "bg-sky-500/10 text-sky-700 dark:text-sky-300 border-sky-500/30 text-[10px] font-bold",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3 mr-1 inline" }), p.namaDesa || "Desa"]
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
											className: "font-mono",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-extrabold text-amber-700 dark:text-amber-400 text-xs",
												children: p.nop
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[10px] text-slate-400",
												children: ["Tahun ", p.tahun]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-bold text-slate-900 dark:text-white text-xs",
											children: p.namaSppt
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[10px] text-slate-500",
											children: ["Pemilik: ", p.namaAktual || p.namaSppt]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
											className: "text-xs text-slate-600 dark:text-slate-300",
											children: p.alamatPemilik || "Alamat belum tercatat"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
											className: "text-center text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-bold text-slate-800 dark:text-slate-200",
												children: p.dusun
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-slate-400",
												children: p.blok
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
											className: "text-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												variant: "outline",
												className: p.domisili === "LUAR_DESA" ? "bg-amber-500/10 text-amber-700 border-amber-500/30 text-[10px]" : "bg-emerald-500/10 text-emerald-700 border-emerald-500/30 text-[10px]",
												children: p.domisili === "LUAR_DESA" ? "Luar Desa" : "Dalam Desa"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
											className: "text-right font-mono font-semibold",
											children: formatRp(pokok)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
											className: "text-right font-mono text-amber-700 dark:text-amber-400 font-bold",
											children: fee > 0 ? formatRp(fee) : "-"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
											className: "text-right font-mono font-black text-emerald-700 dark:text-emerald-400",
											children: formatRp(total)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
											className: "text-center text-slate-300 font-serif italic text-xs",
											children: "...................."
										})
									]
								}, p.id);
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
								className: "bg-amber-100 dark:bg-slate-950 font-black text-slate-900 dark:text-white border-t-2 border-slate-900",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										colSpan: showDesaColumn ? 7 : 6,
										className: "text-center uppercase font-black",
										children: "JUMLAH TOTAL PIUTANG TERUTANG"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										className: "text-right font-mono",
										children: formatRp(piutangSummary.totalPokok)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										className: "text-right font-mono text-amber-800 dark:text-amber-400",
										children: formatRp(piutangSummary.totalFee)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
										className: "text-right font-mono text-emerald-800 dark:text-emerald-300",
										children: formatRp(piutangSummary.totalTagihan)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {})
								]
							})]
						})]
					})
				}),
				totalItems > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4 bg-slate-50/80 dark:bg-slate-950/80 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 print:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs text-slate-600 dark:text-slate-400 font-medium flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"Menampilkan ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-slate-900 dark:text-white",
								children: startIndex + 1
							}),
							" -",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-slate-900 dark:text-white",
								children: endIndex
							}),
							" dari",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-slate-900 dark:text-white",
								children: totalItems
							}),
							" data SPPT"
						] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-slate-500 font-medium hidden md:inline",
								children: "Tampilkan:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: String(pageSize),
								onValueChange: (val) => {
									setPageSize(Number(val));
									setCurrentPage(1);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "h-8 w-[110px] text-xs font-semibold bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
									className: "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "10",
											children: "10 / hal"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "25",
											children: "25 / hal"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "50",
											children: "50 / hal"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "100",
											children: "100 / hal"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "0",
											children: "Semua Data"
										})
									]
								})]
							})]
						}), pageSize > 0 && totalPages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "icon",
									className: "h-8 w-8 rounded-lg border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-40",
									disabled: effectivePage === 1,
									onClick: () => setCurrentPage(1),
									title: "Halaman Pertama",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsLeft, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "icon",
									className: "h-8 w-8 rounded-lg border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-40",
									disabled: effectivePage === 1,
									onClick: () => setCurrentPage((p) => Math.max(1, p - 1)),
									title: "Sebelumnya",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-semibold px-2 text-slate-700 dark:text-slate-300 min-w-[70px] text-center",
									children: [
										effectivePage,
										" / ",
										totalPages
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "icon",
									className: "h-8 w-8 rounded-lg border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-40",
									disabled: effectivePage === totalPages,
									onClick: () => setCurrentPage((p) => Math.min(totalPages, p + 1)),
									title: "Selanjutnya",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "icon",
									className: "h-8 w-8 rounded-lg border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-40",
									disabled: effectivePage === totalPages,
									onClick: () => setCurrentPage(totalPages),
									title: "Halaman Terakhir",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsRight, { className: "size-4" })
								})
							]
						})]
					})]
				})
			]
		})]
	});
};
var FeeKolektorTab = ({ feeKolektorList, feeKolektorTotal, showDesaColumn = false }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 print:hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "border-sky-200/60 dark:border-slate-800 bg-gradient-to-br from-sky-50/70 via-white to-blue-50/30 dark:from-slate-900 dark:via-slate-900 dark:to-slate-950 shadow-md hover:shadow-lg transition-all rounded-2xl overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-5 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold uppercase tracking-wider text-sky-800 dark:text-sky-400 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "size-4 text-sky-600 dark:text-sky-400 shrink-0" }), "Transaksi WP Luar Desa"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-2xl font-black text-slate-900 dark:text-white",
										children: (feeKolektorTotal?.totalTrx || 0).toLocaleString("id-ID")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-bold text-slate-500",
										children: "Transaksi"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-slate-500 font-medium",
									children: "Pembayaran Terverifikasi"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-3 bg-sky-500/10 dark:bg-sky-500/20 text-sky-600 dark:text-sky-400 rounded-xl shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "size-6" })
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "border-emerald-200/60 dark:border-slate-800 bg-gradient-to-br from-emerald-50/70 via-white to-teal-50/30 dark:from-slate-900 dark:via-slate-900 dark:to-slate-950 shadow-md hover:shadow-lg transition-all rounded-2xl overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-5 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold uppercase tracking-wider text-emerald-800 dark:text-emerald-400 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, { className: "size-4 text-emerald-600 dark:text-emerald-400 shrink-0" }), "Total Pokok Setoran"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-emerald-700 dark:text-emerald-300",
									children: formatRp(feeKolektorTotal?.totalPokok || 0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-slate-500 font-medium",
									children: "Nilai Murni Pokok PBB"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-3 bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-xl shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, { className: "size-6" })
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "border-amber-200/60 dark:border-slate-800 bg-gradient-to-br from-amber-50/70 via-white to-orange-50/30 dark:from-slate-900 dark:via-slate-900 dark:to-slate-950 shadow-md hover:shadow-lg transition-all rounded-2xl overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-5 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold uppercase tracking-wider text-amber-800 dark:text-amber-400 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { className: "size-4 text-amber-600 dark:text-amber-400 shrink-0" }), "Total Fee Kolektor"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-amber-700 dark:text-amber-400",
									children: formatRp(feeKolektorTotal?.totalFee || 0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-slate-500 font-medium",
									children: "Hak Insentif Petugas"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-3 bg-amber-500/10 dark:bg-amber-500/20 text-amber-600 dark:text-amber-400 rounded-xl shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { className: "size-6" })
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "border-emerald-500/40 dark:border-emerald-600/50 bg-gradient-to-br from-emerald-600 to-teal-700 text-white shadow-lg hover:shadow-xl transition-all rounded-2xl overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "p-5 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-semibold uppercase tracking-wider text-emerald-100 flex items-center gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-4 text-emerald-200 shrink-0" }), "Total Akumulasi Setoran"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-white drop-shadow-sm",
									children: formatRp(feeKolektorTotal?.totalSetoran || 0)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-emerald-100/80 font-medium",
									children: "Pokok + Fee Kolektor"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-3 bg-white/10 text-white rounded-xl backdrop-blur-md shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-6" })
						})]
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "border-emerald-200 dark:border-slate-800 bg-white dark:bg-slate-900/90 shadow-xl rounded-3xl overflow-hidden print:shadow-none print:border-none print:rounded-none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, {
				className: "border-b border-emerald-100 dark:border-slate-800 bg-gradient-to-r from-emerald-50/50 to-teal-50/20 dark:from-slate-900 dark:to-slate-950 p-6 print:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
						className: "text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2 flex-wrap",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DollarSign, { className: "size-5 text-amber-500 shrink-0" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "BUKU AUDIT & PERHITUNGAN FEE KOLEKTOR PAJAK (WARGA LUAR DESA)" }),
							showDesaColumn && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								variant: "outline",
								className: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-500/30 text-xs font-bold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3 mr-1 inline" }), " Seluruh Desa"]
							})
						]
					})
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "p-0 overflow-x-auto custom-scrollbar print:overflow-visible",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
					className: "w-full text-xs min-w-[900px] print:min-w-full",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, {
						className: "bg-emerald-900 dark:bg-slate-950 text-white font-bold",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-center w-10 text-white",
								children: "NO"
							}),
							showDesaColumn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-white",
								children: "DESA"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-white",
								children: "NO STTS"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-white",
								children: "TANGGAL SETORAN"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-white",
								children: "NOP & SPPT"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-white",
								children: "DUSUN / LOKASI"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-right text-white",
								children: "POKOK PAJAK (Rp)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-right text-white",
								children: "FEE KOLEKTOR (Rp)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-right text-white",
								children: "TOTAL SETORAN (Rp)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-white",
								children: "PETUGAS KASIR"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableBody, {
						className: "divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-slate-900",
						children: [feeKolektorList.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
							colSpan: showDesaColumn ? 10 : 9,
							className: "text-center py-8 text-slate-500",
							children: "Belum ada transaksi pembayaran PBB dari Wajib Pajak Luar Desa."
						}) }) : feeKolektorList.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
							className: "hover:bg-amber-50/50 dark:hover:bg-slate-800/40",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-center font-mono font-bold text-slate-500",
									children: i + 1
								}),
								showDesaColumn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "outline",
									className: "bg-sky-500/10 text-sky-700 dark:text-sky-300 border-sky-500/30 text-[10px] font-bold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3 mr-1 inline" }), f.namaDesa || "Desa"]
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "font-mono text-slate-700 dark:text-slate-300 font-bold",
									children: f.noStts
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "font-mono text-slate-600 dark:text-slate-400",
									children: f.tanggal
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono font-bold text-emerald-700 dark:text-emerald-400 text-xs",
									children: f.nop
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-bold text-slate-900 dark:text-white text-xs",
									children: f.namaSppt
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-xs font-bold text-slate-800 dark:text-slate-200",
									children: f.dusun
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono font-semibold",
									children: formatRp(f.pokok)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono text-amber-700 dark:text-amber-400 font-extrabold text-sm",
									children: formatRp(f.feeKolektor)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono font-black text-emerald-700 dark:text-emerald-400",
									children: formatRp(f.totalBayar)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "font-semibold text-slate-700 dark:text-slate-300",
									children: f.petugas
								})
							]
						}, f.id)), feeKolektorList.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
							className: "bg-amber-100 dark:bg-slate-950 font-black text-slate-900 dark:text-white border-t-2 border-slate-900",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									colSpan: showDesaColumn ? 6 : 5,
									className: "text-center uppercase font-black",
									children: "JUMLAH TOTAL AKUMULASI FEE KOLEKTOR"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono",
									children: formatRp(feeKolektorTotal.totalPokok)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono text-amber-800 dark:text-amber-400 text-sm",
									children: formatRp(feeKolektorTotal.totalFee)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-mono text-emerald-800 dark:text-emerald-300",
									children: formatRp(feeKolektorTotal.totalSetoran)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {})
							]
						})]
					})]
				})
			})]
		})]
	});
};
function LaporanPbbP2() {
	const { dhkpList, transactions } = useDhkpStore();
	const { settings } = useSettingsStore();
	const { user: authUser } = useAuthStore();
	const { getActiveUser } = useUserStore();
	const tenant = useTenantStore();
	const currentUser = authUser || getActiveUser();
	const currentRole = currentUser?.role || "SUPER_ADMIN";
	const isKolektorRestricted = currentRole === "KOLEKTOR";
	const isSuperAdmin = currentRole === "SUPER_ADMIN_SYSTEM" || !currentUser?.desa_id && currentRole === "SUPER_ADMIN";
	const [filterDesa, setFilterDesa] = (0, import_react.useState)("all");
	const [desasList, setDesasList] = (0, import_react.useState)([]);
	import_react.useEffect(() => {
		if (isSuperAdmin) desaService.getAll().then((res) => {
			if (res.data) setDesasList(res.data);
		}).catch((err) => console.error("Gagal memuat list desa:", err));
	}, [isSuperAdmin]);
	const selectedDesaObj = (0, import_react.useMemo)(() => {
		if (filterDesa === "all") return null;
		return desasList.find((d) => String(d.id) === filterDesa) || null;
	}, [filterDesa, desasList]);
	const pageTitle = (0, import_react.useMemo)(() => {
		if (isSuperAdmin) {
			if (filterDesa === "all") return `Laporan Realisasi PBB-P2 Kecamatan ${settings.kecamatan || "Malangbong"}`;
			return `Laporan Realisasi PBB-P2 Desa ${selectedDesaObj?.nama_desa || "Terpilih"}`;
		}
		return `Laporan Realisasi & Piutang ${tenant?.nama_desa || settings?.namaDesa || "Desa"}`;
	}, [
		isSuperAdmin,
		filterDesa,
		selectedDesaObj,
		tenant,
		settings
	]);
	const pageSubtitle = (0, import_react.useMemo)(() => {
		if (isSuperAdmin) {
			if (filterDesa === "all") return `Buku Laporan Realisasi PBB-P2 21-Kolom, Rekapitulasi DHKP, Piutang, dan Fee Kolektor se-Kecamatan ${settings.kecamatan || "Malangbong"}.`;
			return `Buku Laporan Realisasi PBB-P2 21-Kolom, Rekapitulasi DHKP, Piutang, dan Fee Kolektor Desa ${selectedDesaObj?.nama_desa || ""}.`;
		}
		return `Buku Laporan Realisasi PBB-P2 21-Kolom, Rekapitulasi DHKP per Dusun, Lembar Kendali Penagihan Piutang Lapangan, dan Audit Fee Kolektor Pajak Daerah ${tenant?.nama_desa || settings.namaDesa}.`;
	}, [
		isSuperAdmin,
		filterDesa,
		selectedDesaObj,
		tenant,
		settings
	]);
	const [activeTab, setActiveTab] = (0, import_react.useState)("realisasi_21");
	const [selectedTahun, setSelectedTahun] = (0, import_react.useState)(settings.tahunAktif || 2026);
	const [selectedBulan, setSelectedBulan] = (0, import_react.useState)("Januari");
	const [selectedMinggu, setSelectedMinggu] = (0, import_react.useState)("Minggu Keempat");
	const [filterDusun, setFilterDusun] = (0, import_react.useState)("ALL");
	const [filterBlok, setFilterBlok] = (0, import_react.useState)("ALL");
	const [filterDomisili, setFilterDomisili] = (0, import_react.useState)("ALL");
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [rawRows, setRawRows] = (0, import_react.useState)([]);
	const [isEditModalOpen, setIsEditModalOpen] = (0, import_react.useState)(false);
	const [editingIndex, setEditingIndex] = (0, import_react.useState)(null);
	const [editForm, setEditForm] = (0, import_react.useState)({
		dusun: "",
		ketetapanRp: 0,
		jumlahSppt: 0,
		pokokMingguLaluStts: 0,
		pokokMingguLaluRp: 0,
		pokokMingguIniStts: 0,
		pokokMingguIniRp: 0,
		tunggakanMingguLaluStts: 0,
		tunggakanMingguLaluRp: 0,
		tunggakanMingguIniStts: 0,
		tunggakanMingguIniRp: 0
	});
	const [isAddModalOpen, setIsAddModalOpen] = (0, import_react.useState)(false);
	const [addForm, setAddForm] = (0, import_react.useState)({
		dusun: "",
		ketetapanRp: 0,
		jumlahSppt: 0,
		pokokMingguLaluStts: 0,
		pokokMingguLaluRp: 0,
		pokokMingguIniStts: 0,
		pokokMingguIniRp: 0,
		tunggakanMingguLaluStts: 0,
		tunggakanMingguLaluRp: 0,
		tunggakanMingguIniStts: 0,
		tunggakanMingguIniRp: 0
	});
	const userDusunAkses = currentUser?.dusun_akses || currentUser?.dusunAssigned || "ALL";
	const userDesaId = currentUser?.desa_id ? String(currentUser.desa_id) : tenant?.id ? String(tenant.id) : null;
	const filteredDhkpByDesa = (0, import_react.useMemo)(() => {
		if (isSuperAdmin) {
			if (filterDesa !== "all") return dhkpList.filter((item) => String(item.desaId || item.desa_id) === filterDesa);
			return dhkpList;
		}
		if (userDesaId) return dhkpList.filter((item) => {
			const itemDesaId = item.desaId ? String(item.desaId) : item.desa_id ? String(item.desa_id) : null;
			return !itemDesaId || itemDesaId === userDesaId;
		});
		return dhkpList;
	}, [
		dhkpList,
		isSuperAdmin,
		filterDesa,
		userDesaId
	]);
	const filteredTrxByDesa = (0, import_react.useMemo)(() => {
		if (isSuperAdmin) {
			if (filterDesa !== "all") return transactions.filter((trx) => String(trx.desaId || trx.desa_id) === filterDesa);
			return transactions;
		}
		if (userDesaId) return transactions.filter((trx) => {
			const trxDesaId = trx.desaId ? String(trx.desaId) : trx.desa_id ? String(trx.desa_id) : null;
			return !trxDesaId || trxDesaId === userDesaId;
		});
		return transactions;
	}, [
		transactions,
		isSuperAdmin,
		filterDesa,
		userDesaId
	]);
	const activeDusunEntries = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		const addEntry = (dusun, namaDesa) => {
			if (!dusun || !dusun.trim()) return;
			const trimmedDusun = dusun.trim();
			const upperDusun = trimmedDusun.toUpperCase();
			const desaName = namaDesa || "";
			const key = isSuperAdmin && filterDesa === "all" ? `${upperDusun}::${desaName.toUpperCase()}` : upperDusun;
			if (!map.has(key)) map.set(key, {
				dusun: trimmedDusun,
				namaDesa: desaName
			});
		};
		if (filteredDhkpByDesa.length > 0 || filteredTrxByDesa.length > 0) {
			filteredDhkpByDesa.forEach((r) => addEntry(r.dusun, r.namaDesa));
			filteredTrxByDesa.forEach((t) => addEntry(t.dusun, t.namaDesa));
		} else rawRows.forEach((r) => addEntry(r.dusun));
		let entries = Array.from(map.values()).sort((a, b) => {
			const desaCmp = (a.namaDesa || "").localeCompare(b.namaDesa || "");
			if (desaCmp !== 0) return desaCmp;
			return a.dusun.localeCompare(b.dusun);
		});
		if (isKolektorRestricted) entries = entries.filter((e) => isDusunAllowed(e.dusun, userDusunAkses, currentRole));
		return entries;
	}, [
		rawRows,
		filteredDhkpByDesa,
		filteredTrxByDesa,
		isKolektorRestricted,
		userDusunAkses,
		currentRole,
		isSuperAdmin,
		filterDesa
	]);
	const availableDusuns = (0, import_react.useMemo)(() => {
		const set = /* @__PURE__ */ new Set();
		activeDusunEntries.forEach((e) => set.add(e.dusun.toUpperCase()));
		return Array.from(set).sort();
	}, [activeDusunEntries]);
	(0, import_react.useMemo)(() => {
		const set = /* @__PURE__ */ new Set();
		filteredDhkpByDesa.forEach((item) => {
			if (item.blok && item.blok.trim()) set.add(item.blok.trim().toUpperCase());
		});
		if (set.size === 0) [
			"Blok 01",
			"Blok 02",
			"Blok 03",
			"Blok 04"
		].forEach((b) => set.add(b));
		return Array.from(set).sort();
	}, [filteredDhkpByDesa]);
	const showDesaColumn = isSuperAdmin && filterDesa === "all";
	const computed21Rows = (0, import_react.useMemo)(() => {
		return (filterDusun === "ALL" ? activeDusunEntries : activeDusunEntries.filter((e) => e.dusun.toUpperCase() === filterDusun.toUpperCase())).map((entry, index) => {
			const dusunUpper = entry.dusun.toUpperCase();
			const desaName = entry.namaDesa;
			const dhkpInDusun = filteredDhkpByDesa.filter((d) => d.tahun === selectedTahun && (d.dusun || "").trim().toUpperCase() === dusunUpper && (!showDesaColumn || !desaName || !d.namaDesa || d.namaDesa === desaName));
			const dynamicKetetapanRp = dhkpInDusun.reduce((a, c) => a + (c.tagihan ?? c.dibulatkan ?? 0), 0);
			const dynamicJumlahSppt = dhkpInDusun.length;
			const dusunTrx = filteredTrxByDesa.filter((t) => (t.dusun || "").trim().toUpperCase() === dusunUpper && (!showDesaColumn || !desaName || !t.namaDesa || t.namaDesa === desaName));
			const lunasDhkp = dhkpInDusun.filter((d) => d.status === "LUNAS");
			const dynamicPokokStts = Math.max(lunasDhkp.length, dusunTrx.filter((t) => t.tahun >= selectedTahun).length);
			const dynamicPokokRp = Math.max(lunasDhkp.reduce((a, c) => a + (c.tagihan ?? c.dibulatkan ?? 0), 0), dusunTrx.filter((t) => t.tahun >= selectedTahun).reduce((a, c) => a + c.pokok, 0));
			const dynamicTunggakanStts = dusunTrx.filter((t) => t.tahun < selectedTahun).length;
			const dynamicTunggakanRp = dusunTrx.filter((t) => t.tahun < selectedTahun).reduce((a, c) => a + c.pokok, 0);
			const customRow = rawRows.find((r) => r.dusun.toUpperCase() === dusunUpper);
			return computeLaporanRow({
				dusun: entry.dusun,
				namaDesa: entry.namaDesa,
				ketetapanRp: dynamicKetetapanRp || (filteredDhkpByDesa.length === 0 ? customRow?.ketetapanRp || 0 : 0),
				jumlahSppt: dynamicJumlahSppt || (filteredDhkpByDesa.length === 0 ? customRow?.jumlahSppt || 0 : 0),
				pokokMingguLaluStts: customRow?.pokokMingguLaluStts || 0,
				pokokMingguLaluRp: customRow?.pokokMingguLaluRp || 0,
				pokokMingguIniStts: dynamicPokokStts,
				pokokMingguIniRp: dynamicPokokRp,
				tunggakanMingguLaluStts: customRow?.tunggakanMingguLaluStts || 0,
				tunggakanMingguLaluRp: customRow?.tunggakanMingguLaluRp || 0,
				tunggakanMingguIniStts: dynamicTunggakanStts,
				tunggakanMingguIniRp: dynamicTunggakanRp
			}, index);
		});
	}, [
		activeDusunEntries,
		filteredDhkpByDesa,
		filteredTrxByDesa,
		selectedTahun,
		filterDusun,
		rawRows,
		showDesaColumn
	]);
	const grandTotal21 = (0, import_react.useMemo)(() => {
		const res = computed21Rows.reduce((acc, r) => ({
			ketetapanRp: acc.ketetapanRp + r.ketetapanRp,
			jumlahSppt: acc.jumlahSppt + r.jumlahSppt,
			pokokMingguLaluStts: acc.pokokMingguLaluStts + r.pokokMingguLaluStts,
			pokokMingguLaluRp: acc.pokokMingguLaluRp + r.pokokMingguLaluRp,
			pokokMingguIniStts: acc.pokokMingguIniStts + r.pokokMingguIniStts,
			pokokMingguIniRp: acc.pokokMingguIniRp + r.pokokMingguIniRp,
			pokokSdMingguIniStts: acc.pokokSdMingguIniStts + r.pokokSdMingguIniStts,
			pokokSdMingguIniRp: acc.pokokSdMingguIniRp + r.pokokSdMingguIniRp,
			tunggakanMingguLaluStts: acc.tunggakanMingguLaluStts + r.tunggakanMingguLaluStts,
			tunggakanMingguLaluRp: acc.tunggakanMingguLaluRp + r.tunggakanMingguLaluRp,
			tunggakanMingguIniStts: acc.tunggakanMingguIniStts + r.tunggakanMingguIniStts,
			tunggakanMingguIniRp: acc.tunggakanMingguIniRp + r.tunggakanMingguIniRp,
			tunggakanSdMingguIniStts: acc.tunggakanSdMingguIniStts + r.tunggakanSdMingguIniStts,
			tunggakanSdMingguIniRp: acc.tunggakanSdMingguIniRp + r.tunggakanSdMingguIniRp,
			jumlahStts: acc.jumlahStts + r.jumlahStts,
			jumlahRp: acc.jumlahRp + r.jumlahRp,
			sisaStts: acc.sisaStts + r.sisaStts,
			sisaPokokRp: acc.sisaPokokRp + r.sisaPokokRp
		}), {
			ketetapanRp: 0,
			jumlahSppt: 0,
			pokokMingguLaluStts: 0,
			pokokMingguLaluRp: 0,
			pokokMingguIniStts: 0,
			pokokMingguIniRp: 0,
			pokokSdMingguIniStts: 0,
			pokokSdMingguIniRp: 0,
			tunggakanMingguLaluStts: 0,
			tunggakanMingguLaluRp: 0,
			tunggakanMingguIniStts: 0,
			tunggakanMingguIniRp: 0,
			tunggakanSdMingguIniStts: 0,
			tunggakanSdMingguIniRp: 0,
			jumlahStts: 0,
			jumlahRp: 0,
			sisaStts: 0,
			sisaPokokRp: 0
		});
		const persentase = res.ketetapanRp > 0 ? res.jumlahRp / res.ketetapanRp * 100 : 0;
		return {
			...res,
			persentase: Math.round(persentase * 100) / 100
		};
	}, [computed21Rows]);
	const dhkpRecapGrouped = (0, import_react.useMemo)(() => {
		const filtered = filteredDhkpByDesa.filter((d) => {
			if (isKolektorRestricted && !isDusunAllowed(d.dusun, userDusunAkses, currentRole)) return false;
			if (selectedTahun && d.tahun !== selectedTahun) return false;
			if (filterDusun !== "ALL" && d.dusun.toUpperCase() !== filterDusun.toUpperCase()) return false;
			if (filterDomisili !== "ALL" && (d.domisili || "DALAM_DESA") !== filterDomisili) return false;
			if (searchQuery.trim()) {
				const q = searchQuery.toLowerCase();
				return d.nop.toLowerCase().includes(q) || d.namaSppt.toLowerCase().includes(q) || d.namaAktual && d.namaAktual.toLowerCase().includes(q) || d.dusun.toLowerCase().includes(q) || d.blok && d.blok.toLowerCase().includes(q);
			}
			return true;
		});
		const map = /* @__PURE__ */ new Map();
		filtered.forEach((item) => {
			const desaName = (item.namaDesa || "Desa").trim();
			const dusunRaw = (item.dusun || "-").trim();
			const dusunUpper = dusunRaw.toUpperCase();
			const key = showDesaColumn ? `${desaName.toUpperCase()} - ${dusunUpper}` : dusunUpper;
			if (!map.has(key)) map.set(key, {
				namaDesa: desaName,
				dusun: dusunRaw,
				blok: "",
				totalSppt: 0,
				totalKetetapan: 0,
				lunasSppt: 0,
				lunasRp: 0,
				piutangSppt: 0,
				piutangRp: 0
			});
			const grp = map.get(key);
			grp.totalSppt += 1;
			grp.totalKetetapan += item.tagihan ?? item.dibulatkan ?? 0;
			if (item.status === "LUNAS") {
				grp.lunasSppt += 1;
				grp.lunasRp += item.tagihan ?? item.dibulatkan ?? 0;
			} else {
				grp.piutangSppt += 1;
				grp.piutangRp += item.tagihan ?? item.dibulatkan ?? 0;
			}
		});
		return Array.from(map.values()).sort((a, b) => {
			if (showDesaColumn && a.namaDesa && b.namaDesa) {
				const desaCmp = a.namaDesa.localeCompare(b.namaDesa);
				if (desaCmp !== 0) return desaCmp;
			}
			return a.dusun.localeCompare(b.dusun);
		});
	}, [
		filteredDhkpByDesa,
		selectedTahun,
		filterDusun,
		filterDomisili,
		searchQuery,
		showDesaColumn
	]);
	const dhkpRecapTotal = (0, import_react.useMemo)(() => {
		return dhkpRecapGrouped.reduce((acc, curr) => {
			acc.totalSppt += curr.totalSppt;
			acc.totalKetetapan += curr.totalKetetapan;
			acc.lunasSppt += curr.lunasSppt;
			acc.lunasRp += curr.lunasRp;
			acc.piutangSppt += curr.piutangSppt;
			acc.piutangRp += curr.piutangRp;
			return acc;
		}, {
			totalSppt: 0,
			totalKetetapan: 0,
			lunasSppt: 0,
			lunasRp: 0,
			piutangSppt: 0,
			piutangRp: 0
		});
	}, [dhkpRecapGrouped]);
	const piutangList = (0, import_react.useMemo)(() => {
		const list = filteredDhkpByDesa.filter((d) => {
			if (d.status !== "BELUM") return false;
			if (isKolektorRestricted && !isDusunAllowed(d.dusun, userDusunAkses, currentRole)) return false;
			if (selectedTahun && d.tahun !== selectedTahun) return false;
			if (filterDusun !== "ALL" && (d.dusun || "").trim().toUpperCase() !== filterDusun.toUpperCase()) return false;
			if (filterDomisili !== "ALL" && (d.domisili || "DALAM_DESA") !== filterDomisili) return false;
			if (searchQuery.trim()) {
				const q = searchQuery.toLowerCase();
				return (d.nop || "").toLowerCase().includes(q) || (d.namaSppt || "").toLowerCase().includes(q) || d.namaAktual && d.namaAktual.toLowerCase().includes(q) || (d.dusun || "").toLowerCase().includes(q) || d.namaDesa && d.namaDesa.toLowerCase().includes(q);
			}
			return true;
		});
		if (showDesaColumn) return list.sort((a, b) => {
			const desaA = a.namaDesa || "";
			const desaB = b.namaDesa || "";
			const desaCmp = desaA.localeCompare(desaB);
			if (desaCmp !== 0) return desaCmp;
			const dusunCmp = (a.dusun || "").localeCompare(b.dusun || "");
			if (dusunCmp !== 0) return dusunCmp;
			return (a.nop || "").localeCompare(b.nop || "");
		});
		return list;
	}, [
		filteredDhkpByDesa,
		selectedTahun,
		filterDusun,
		filterDomisili,
		searchQuery,
		isKolektorRestricted,
		userDusunAkses,
		currentRole,
		showDesaColumn
	]);
	const piutangSummary = (0, import_react.useMemo)(() => {
		const count = piutangList.length;
		const totalPokok = piutangList.reduce((a, c) => a + Number(c.tagihan ?? c.dibulatkan ?? 0), 0);
		const totalFee = piutangList.reduce((a, c) => {
			if (c.domisili === "LUAR_DESA" && settings.enableFeeKolektorLuarDesa) return a + (settings.feeKolektorLuarDesa || 5e3);
			return a;
		}, 0);
		return {
			count,
			totalPokok,
			totalFee,
			totalTagihan: totalPokok + totalFee
		};
	}, [piutangList, settings]);
	const feeKolektorList = (0, import_react.useMemo)(() => {
		const list = filteredTrxByDesa.filter((t) => {
			if (t.feeKolektor <= 0) return false;
			if (isKolektorRestricted && !isDusunAllowed(t.dusun, userDusunAkses, currentRole)) return false;
			if (filterDusun !== "ALL" && (t.dusun || "").trim().toUpperCase() !== filterDusun.toUpperCase()) return false;
			if (searchQuery.trim()) {
				const q = searchQuery.toLowerCase();
				return (t.nop || "").toLowerCase().includes(q) || (t.namaSppt || "").toLowerCase().includes(q) || (t.noStts || "").toLowerCase().includes(q) || t.petugas && t.petugas.toLowerCase().includes(q);
			}
			return true;
		});
		if (showDesaColumn) return list.sort((a, b) => {
			const desaA = a.namaDesa || "";
			const desaB = b.namaDesa || "";
			const desaCmp = desaA.localeCompare(desaB);
			if (desaCmp !== 0) return desaCmp;
			return (a.nop || "").localeCompare(b.nop || "");
		});
		return list;
	}, [
		filteredTrxByDesa,
		filterDusun,
		searchQuery,
		isKolektorRestricted,
		userDusunAkses,
		currentRole,
		showDesaColumn
	]);
	const feeKolektorTotal = (0, import_react.useMemo)(() => {
		return {
			totalTrx: feeKolektorList.length,
			totalFee: feeKolektorList.reduce((a, c) => a + Number(c.feeKolektor || 0), 0),
			totalPokok: feeKolektorList.reduce((a, c) => a + Number(c.pokok || 0), 0),
			totalSetoran: feeKolektorList.reduce((a, c) => a + Number(c.totalBayar || 0), 0)
		};
	}, [feeKolektorList]);
	const handleExportCsvTab = () => {
		let headers = [];
		let rows = [];
		let grandTotalRow = [];
		let filename = "";
		let reportTitle = "";
		const targetDesaText = isSuperAdmin ? filterDesa === "all" ? "SELURUH DESA" : `DESA ${(selectedDesaObj?.nama_desa || settings.namaDesa || "DESA").toUpperCase()}` : `DESA ${(tenant?.nama_desa || settings.namaDesa || "DESA").toUpperCase()}`;
		if (activeTab === "realisasi_21") {
			reportTitle = "LAPORAN PENERIMAAN PBB-P2 PER DUSUN (FORMAT 21 KOLOM BAPENDA)";
			filename = `Laporan_21_Kolom_PBB_${selectedTahun}_${selectedBulan}.csv`;
			headers = [
				"NO",
				...showDesaColumn ? ["DESA"] : [],
				"DUSUN",
				`KETETAPAN TAHUN ${selectedTahun}`,
				"JUMLAH SPPT",
				"POKOK MINGGU LALU (STTS)",
				"POKOK MINGGU LALU (Rp)",
				"POKOK MINGGU INI (STTS)",
				"POKOK MINGGU INI (Rp)",
				"POKOK S/D MINGGU INI (STTS)",
				"POKOK S/D MINGGU INI (Rp)",
				"TUNGGAKAN MINGGU LALU (STTS)",
				"TUNGGAKAN MINGGU LALU (Rp)",
				"TUNGGAKAN MINGGU INI (STTS)",
				"TUNGGAKAN MINGGU INI (Rp)",
				"TUNGGAKAN S/D MINGGU INI (STTS)",
				"TUNGGAKAN S/D MINGGU INI (Rp)",
				"JUMLAH STTS",
				"JUMLAH (Rp)",
				"SISA STTS",
				"SISA POKOK (Rp)",
				"% CAPAIAN"
			];
			rows = computed21Rows.map((r) => [
				r.no,
				...showDesaColumn ? [`"${r.namaDesa || "-"}"`] : [],
				`"${r.dusun}"`,
				r.ketetapanRp,
				r.jumlahSppt,
				r.pokokMingguLaluStts,
				r.pokokMingguLaluRp,
				r.pokokMingguIniStts,
				r.pokokMingguIniRp,
				r.pokokSdMingguIniStts,
				r.pokokSdMingguIniRp,
				r.tunggakanMingguLaluStts,
				r.tunggakanMingguLaluRp,
				r.tunggakanMingguIniStts,
				r.tunggakanMingguIniRp,
				r.tunggakanSdMingguIniStts,
				r.tunggakanSdMingguIniRp,
				r.jumlahStts,
				r.jumlahRp,
				r.sisaStts,
				r.sisaPokokRp,
				`${r.persentase.toFixed(2)}%`
			]);
			grandTotalRow = [
				"JUMLAH TOTAL",
				...showDesaColumn ? [""] : [],
				"",
				grandTotal21.ketetapanRp,
				grandTotal21.jumlahSppt,
				grandTotal21.pokokMingguLaluStts,
				grandTotal21.pokokMingguLaluRp,
				grandTotal21.pokokMingguIniStts,
				grandTotal21.pokokMingguIniRp,
				grandTotal21.pokokSdMingguIniStts,
				grandTotal21.pokokSdMingguIniRp,
				grandTotal21.tunggakanMingguLaluStts,
				grandTotal21.tunggakanMingguLaluRp,
				grandTotal21.tunggakanMingguIniStts,
				grandTotal21.tunggakanMingguIniRp,
				grandTotal21.tunggakanSdMingguIniStts,
				grandTotal21.tunggakanSdMingguIniRp,
				grandTotal21.jumlahStts,
				grandTotal21.jumlahRp,
				grandTotal21.sisaStts,
				grandTotal21.sisaPokokRp,
				`${grandTotal21.persentase.toFixed(2)}%`
			];
		} else if (activeTab === "rekap_dhkp") {
			reportTitle = "REKAPITULASI KETETAPAN DAN REALISASI DHKP PER DUSUN";
			filename = `Laporan_Rekap_DHKP_Dusun_${selectedTahun}.csv`;
			headers = [
				"NO",
				...showDesaColumn ? ["DESA"] : [],
				"DUSUN / LOKASI TANAH",
				"TOTAL SPPT",
				"TOTAL KETETAPAN (Rp)",
				"SPPT LUNAS",
				"REALISASI LUNAS (Rp)",
				"PIUTANG SPPT",
				"PIUTANG (Rp)",
				"% CAPAIAN"
			];
			rows = dhkpRecapGrouped.map((g, idx) => {
				const pct = g.totalKetetapan > 0 ? g.lunasRp / g.totalKetetapan * 100 : 0;
				return [
					idx + 1,
					...showDesaColumn ? [`"${g.namaDesa || "-"}"`] : [],
					`"${g.dusun}"`,
					g.totalSppt,
					g.totalKetetapan,
					g.lunasSppt,
					g.lunasRp,
					g.piutangSppt,
					g.piutangRp,
					`${pct.toFixed(2)}%`
				];
			});
			const grandPct = dhkpRecapTotal.totalKetetapan > 0 ? dhkpRecapTotal.lunasRp / dhkpRecapTotal.totalKetetapan * 100 : 0;
			grandTotalRow = [
				"JUMLAH TOTAL",
				...showDesaColumn ? [""] : [],
				"",
				dhkpRecapTotal.totalSppt,
				dhkpRecapTotal.totalKetetapan,
				dhkpRecapTotal.lunasSppt,
				dhkpRecapTotal.lunasRp,
				dhkpRecapTotal.piutangSppt,
				dhkpRecapTotal.piutangRp,
				`${grandPct.toFixed(2)}%`
			];
		} else if (activeTab === "piutang_kendali") {
			reportTitle = "LEMBAR KENDALI PENAGIHAN PIUTANG PBB-P2";
			filename = `Lembar_Kendali_Penagihan_Piutang_${selectedTahun}.csv`;
			headers = [
				"NO",
				...showDesaColumn ? ["DESA"] : [],
				"NOP",
				"TAHUN",
				"NAMA SPPT",
				"NAMA PEMILIK SEKARANG",
				"ALAMAT / LOKASI",
				"DUSUN",
				"BLOK",
				"DOMISILI",
				"TAGIHAN POKOK (Rp)",
				"FEE KOLEKTOR (Rp)",
				"TOTAL TAGIHAN (Rp)",
				"STATUS"
			];
			rows = piutangList.map((p, idx) => {
				const fee = p.domisili === "LUAR_DESA" && settings.enableFeeKolektorLuarDesa ? settings.feeKolektorLuarDesa || 5e3 : 0;
				return [
					idx + 1,
					...showDesaColumn ? [`"${p.namaDesa || "-"}"`] : [],
					`"\t${p.nop}"`,
					p.tahun,
					`"${p.namaSppt}"`,
					`"${p.namaAktual || p.namaSppt}"`,
					`"${p.alamatPemilik || "-"}"`,
					`"${p.dusun}"`,
					`"${p.blok}"`,
					p.domisili || "DALAM_DESA",
					p.dibulatkan,
					fee,
					p.dibulatkan + fee,
					p.status
				];
			});
			grandTotalRow = [
				"JUMLAH TOTAL",
				...showDesaColumn ? [""] : [],
				"",
				"",
				"",
				"",
				"",
				"",
				"",
				"",
				piutangSummary.totalPokok,
				piutangSummary.totalFee,
				piutangSummary.totalTagihan,
				""
			];
		} else if (activeTab === "fee_kolektor") {
			reportTitle = "AUDIT DAN PERHITUNGAN FEE KOLEKTOR PAJAK (WARGA LUAR DESA)";
			filename = `Laporan_Fee_Kolektor_Luar_Desa.csv`;
			headers = [
				"NO",
				...showDesaColumn ? ["DESA"] : [],
				"NO STTS",
				"TANGGAL",
				"NOP",
				"WAJIB PAJAK",
				"DUSUN / LOKASI",
				"POKOK (Rp)",
				"FEE KOLEKTOR (Rp)",
				"TOTAL SETORAN (Rp)",
				"PETUGAS / KOLEKTOR"
			];
			rows = feeKolektorList.map((f, idx) => [
				idx + 1,
				...showDesaColumn ? [`"${f.namaDesa || "-"}"`] : [],
				`"\t${f.noStts}"`,
				`"${f.tanggal}"`,
				`"\t${f.nop}"`,
				`"${f.namaSppt}"`,
				`"${f.dusun}"`,
				f.pokok,
				f.feeKolektor,
				f.totalBayar,
				`"${f.petugas}"`
			]);
			grandTotalRow = [
				"JUMLAH TOTAL",
				...showDesaColumn ? [""] : [],
				"",
				"",
				"",
				"",
				"",
				feeKolektorTotal.totalPokok,
				feeKolektorTotal.totalFee,
				feeKolektorTotal.totalSetoran,
				""
			];
		}
		const csvContent = "﻿" + [
			`# PEMERINTAH KABUPATEN ${settings.kabupaten.toUpperCase()}`,
			`# KECAMATAN ${settings.kecamatan.toUpperCase()} - ${targetDesaText}`,
			`# ${reportTitle}`,
			`# TAHUN KETETAPAN: ${selectedTahun} | PERIODE: ${selectedBulan} (${selectedMinggu}) | DUSUN: ${filterDusun === "ALL" ? "SEMUA WILAYAH" : filterDusun}`,
			`# TANGGAL UNDUH: ${(/* @__PURE__ */ new Date()).toLocaleDateString("id-ID", {
				day: "numeric",
				month: "long",
				year: "numeric",
				hour: "2-digit",
				minute: "2-digit"
			})}`,
			""
		].join("\n") + "\n" + [
			headers.join(";"),
			...rows.map((e) => e.join(";")),
			grandTotalRow.join(";")
		].join("\n");
		const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = filename;
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
		toast.success(`File CSV (${filename}) berhasil diunduh!`);
	};
	const handleExportExcelTab = () => {
		let tablename = "";
		let tableHtml = "";
		const targetDesaText = isSuperAdmin ? filterDesa === "all" ? "SELURUH DESA" : `DESA ${(selectedDesaObj?.nama_desa || settings.namaDesa || "DESA").toUpperCase()}` : `DESA ${(tenant?.nama_desa || settings.namaDesa || "DESA").toUpperCase()}`;
		if (activeTab === "realisasi_21") {
			tablename = `Laporan Realisasi 21-Kolom PBB-P2 Tahun ${selectedTahun}`;
			tableHtml = `
        <table border="1">
          <thead>
            <tr style="background-color: #059669; color: white;">
              <th rowspan="2">NO</th>
              ${showDesaColumn ? "<th rowspan=\"2\">DESA</th>" : ""}
              <th rowspan="2">DUSUN</th>
              <th rowspan="2">KETETAPAN TAHUN ${selectedTahun} (Rp)</th>
              <th rowspan="2">JUMLAH SPPT</th>
              <th colspan="6">PENERIMAAN DARI POKOK PBB</th>
              <th colspan="6">PENERIMAAN DARI TUNGGAKAN PBB</th>
              <th rowspan="2">JUMLAH STTS</th>
              <th rowspan="2">JUMLAH (Rp)</th>
              <th rowspan="2">SISA STTS</th>
              <th rowspan="2">SISA POKOK (Rp)</th>
              <th rowspan="2">% CAPAIAN</th>
            </tr>
            <tr style="background-color: #047857; color: white;">
              <th>Minggu Lalu (STTS)</th><th>Minggu Lalu (Rp)</th><th>Minggu Ini (STTS)</th><th>Minggu Ini (Rp)</th><th>s/d Minggu Ini (STTS)</th><th>s/d Minggu Ini (Rp)</th>
              <th>Minggu Lalu (STTS)</th><th>Minggu Lalu (Rp)</th><th>Minggu Ini (STTS)</th><th>Minggu Ini (Rp)</th><th>s/d Minggu Ini (STTS)</th><th>s/d Minggu Ini (Rp)</th>
            </tr>
          </thead>
          <tbody>
            ${computed21Rows.map((r) => `
              <tr>
                <td style="text-align: center;">${r.no}</td>
                ${showDesaColumn ? `<td style="mso-number-format:'\@';">${r.namaDesa || "-"}</td>` : ""}
                <td style="mso-number-format:'\@';">${r.dusun}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: right;">${r.ketetapanRp}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: center;">${r.jumlahSppt}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: center;">${r.pokokMingguLaluStts}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: right;">${r.pokokMingguLaluRp}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: center;">${r.pokokMingguIniStts}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: right;">${r.pokokMingguIniRp}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: center;">${r.pokokSdMingguIniStts}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: right;">${r.pokokSdMingguIniRp}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: center;">${r.tunggakanMingguLaluStts}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: right;">${r.tunggakanMingguLaluRp}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: center;">${r.tunggakanMingguIniStts}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: right;">${r.tunggakanMingguIniRp}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: center;">${r.tunggakanSdMingguIniStts}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: right;">${r.tunggakanSdMingguIniRp}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: center;">${r.jumlahStts}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: right;">${r.jumlahRp}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: center;">${r.sisaStts}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: right;">${r.sisaPokokRp}</td>
                <td style="mso-number-format:'0\.00%'; text-align: center;">${(r.persentase / 100).toFixed(4)}</td>
              </tr>
            `).join("")}
            <tr style="background-color: #d1fae5; font-weight: bold;">
              <td colspan="${showDesaColumn ? 3 : 2}" style="text-align: center;"><b>JUMLAH GRAND TOTAL</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: right;"><b>${grandTotal21.ketetapanRp}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: center;"><b>${grandTotal21.jumlahSppt}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: center;"><b>${grandTotal21.pokokMingguLaluStts}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: right;"><b>${grandTotal21.pokokMingguLaluRp}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: center;"><b>${grandTotal21.pokokMingguIniStts}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: right;"><b>${grandTotal21.pokokMingguIniRp}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: center;"><b>${grandTotal21.pokokSdMingguIniStts}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: right;"><b>${grandTotal21.pokokSdMingguIniRp}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: center;"><b>${grandTotal21.tunggakanMingguLaluStts}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: right;"><b>${grandTotal21.tunggakanMingguLaluRp}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: center;"><b>${grandTotal21.tunggakanMingguIniStts}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: right;"><b>${grandTotal21.tunggakanMingguIniRp}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: center;"><b>${grandTotal21.tunggakanSdMingguIniStts}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: right;"><b>${grandTotal21.tunggakanSdMingguIniRp}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: center;"><b>${grandTotal21.jumlahStts}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: right;"><b>${grandTotal21.jumlahRp}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: center;"><b>${grandTotal21.sisaStts}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: right;"><b>${grandTotal21.sisaPokokRp}</b></td>
              <td style="mso-number-format:'0\.00%'; text-align: center;"><b>${(grandTotal21.persentase / 100).toFixed(4)}</b></td>
            </tr>
          </tbody>
        </table>
      `;
		} else if (activeTab === "rekap_dhkp") {
			tablename = `Rekapitulasi DHKP dan Ketetapan Per Dusun Tahun ${selectedTahun}`;
			tableHtml = `
        <table border="1">
          <thead>
            <tr style="background-color: #059669; color: white;">
              <th>NO</th>
              ${showDesaColumn ? "<th>DESA</th>" : ""}
              <th>DUSUN / LOKASI TANAH</th><th>TOTAL SPPT</th><th>TOTAL KETETAPAN (Rp)</th><th>SPPT LUNAS</th><th>REALISASI LUNAS (Rp)</th><th>PIUTANG SPPT</th><th>PIUTANG (Rp)</th><th>% CAPAIAN</th>
            </tr>
          </thead>
          <tbody>
            ${dhkpRecapGrouped.map((g, i) => {
				const pct = g.totalKetetapan > 0 ? g.lunasRp / g.totalKetetapan * 100 : 0;
				return `
                <tr>
                  <td style="text-align: center;">${i + 1}</td>
                  ${showDesaColumn ? `<td style="mso-number-format:'\@';">${g.namaDesa || "-"}</td>` : ""}
                  <td style="mso-number-format:'\@';">${g.dusun}</td>
                  <td style="mso-number-format:'\#\,\#\#0'; text-align: center;">${g.totalSppt}</td>
                  <td style="mso-number-format:'\#\,\#\#0'; text-align: right;">${g.totalKetetapan}</td>
                  <td style="mso-number-format:'\#\,\#\#0'; text-align: center;">${g.lunasSppt}</td>
                  <td style="mso-number-format:'\#\,\#\#0'; text-align: right;">${g.lunasRp}</td>
                  <td style="mso-number-format:'\#\,\#\#0'; text-align: center;">${g.piutangSppt}</td>
                  <td style="mso-number-format:'\#\,\#\#0'; text-align: right;">${g.piutangRp}</td>
                  <td style="mso-number-format:'0\.00%'; text-align: center;">${(pct / 100).toFixed(4)}</td>
                </tr>
              `;
			}).join("")}
            <tr style="background-color: #d1fae5; font-weight: bold;">
              <td colspan="${showDesaColumn ? 3 : 2}" style="text-align: center;"><b>JUMLAH TOTAL</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: center;"><b>${dhkpRecapTotal.totalSppt}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: right;"><b>${dhkpRecapTotal.totalKetetapan}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: center;"><b>${dhkpRecapTotal.lunasSppt}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: right;"><b>${dhkpRecapTotal.lunasRp}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: center;"><b>${dhkpRecapTotal.piutangSppt}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: right;"><b>${dhkpRecapTotal.piutangRp}</b></td>
              <td style="mso-number-format:'0\.00%'; text-align: center;"><b>${((dhkpRecapTotal.totalKetetapan > 0 ? dhkpRecapTotal.lunasRp / dhkpRecapTotal.totalKetetapan * 100 : 0) / 100).toFixed(4)}</b></td>
            </tr>
          </tbody>
        </table>
      `;
		} else if (activeTab === "piutang_kendali") {
			tablename = `Lembar Kendali Penagihan Piutang PBB-P2 Tahun ${selectedTahun}`;
			tableHtml = `
        <table border="1">
          <thead>
            <tr style="background-color: #059669; color: white;">
              <th>NO</th>
              ${showDesaColumn ? "<th>DESA</th>" : ""}
              <th>NOP</th><th>TAHUN</th><th>NAMA SPPT</th><th>NAMA PEMILIK SEKARANG</th><th>ALAMAT</th><th>DUSUN</th><th>BLOK</th><th>DOMISILI</th><th>TAGIHAN POKOK (Rp)</th><th>FEE KOLEKTOR (Rp)</th><th>TOTAL TAGIHAN (Rp)</th><th>PARAF / TTD WP</th>
            </tr>
          </thead>
          <tbody>
            ${piutangList.map((p, i) => {
				const fee = p.domisili === "LUAR_DESA" && settings.enableFeeKolektorLuarDesa ? settings.feeKolektorLuarDesa || 5e3 : 0;
				return `
                <tr>
                  <td style="text-align: center;">${i + 1}</td>
                  ${showDesaColumn ? `<td style="mso-number-format:'\@';">${p.namaDesa || "-"}</td>` : ""}
                  <td style="mso-number-format:'\@';">${p.nop}</td>
                  <td style="mso-number-format:'\@'; text-align: center;">${p.tahun}</td>
                  <td style="mso-number-format:'\@';">${p.namaSppt}</td>
                  <td style="mso-number-format:'\@';">${p.namaAktual || p.namaSppt}</td>
                  <td style="mso-number-format:'\@';">${p.alamatPemilik || "-"}</td>
                  <td style="mso-number-format:'\@';">${p.dusun}</td>
                  <td style="mso-number-format:'\@';">${p.blok}</td>
                  <td style="mso-number-format:'\@';">${p.domisili || "DALAM_DESA"}</td>
                  <td style="mso-number-format:'\#\,\#\#0'; text-align: right;">${p.dibulatkan}</td>
                  <td style="mso-number-format:'\#\,\#\#0'; text-align: right;">${fee}</td>
                  <td style="mso-number-format:'\#\,\#\#0'; text-align: right;">${p.dibulatkan + fee}</td>
                  <td></td>
                </tr>
              `;
			}).join("")}
            <tr style="background-color: #fef3c7; font-weight: bold;">
              <td colspan="${showDesaColumn ? 10 : 9}" style="text-align: center;"><b>JUMLAH PIUTANG TERUTANG</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: right;"><b>${piutangSummary.totalPokok}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: right;"><b>${piutangSummary.totalFee}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: right;"><b>${piutangSummary.totalTagihan}</b></td>
              <td></td>
            </tr>
          </tbody>
        </table>
      `;
		} else if (activeTab === "fee_kolektor") {
			tablename = `Laporan Perhitungan Fee Kolektor Warga Luar Desa`;
			tableHtml = `
        <table border="1">
          <thead>
            <tr style="background-color: #059669; color: white;">
              <th>NO</th>
              ${showDesaColumn ? "<th>DESA</th>" : ""}
              <th>NO STTS</th><th>TANGGAL</th><th>NOP</th><th>WAJIB PAJAK</th><th>DUSUN / LOKASI</th><th>POKOK (Rp)</th><th>FEE KOLEKTOR (Rp)</th><th>TOTAL SETORAN (Rp)</th><th>PETUGAS / KOLEKTOR</th>
            </tr>
          </thead>
          <tbody>
            ${feeKolektorList.map((f, i) => `
              <tr>
                <td style="text-align: center;">${i + 1}</td>
                ${showDesaColumn ? `<td style="mso-number-format:'\@';">${f.namaDesa || "-"}</td>` : ""}
                <td style="mso-number-format:'\@';">${f.noStts}</td>
                <td style="mso-number-format:'\@';">${f.tanggal}</td>
                <td style="mso-number-format:'\@';">${f.nop}</td>
                <td style="mso-number-format:'\@';">${f.namaSppt}</td>
                <td style="mso-number-format:'\@';">${f.dusun} - ${f.blok}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: right;">${f.pokok}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: right;">${f.feeKolektor}</td>
                <td style="mso-number-format:'\#\,\#\#0'; text-align: right;">${f.totalBayar}</td>
                <td style="mso-number-format:'\@';">${f.petugas}</td>
              </tr>
            `).join("")}
            <tr style="background-color: #fef3c7; font-weight: bold;">
              <td colspan="${showDesaColumn ? 7 : 6}" style="text-align: center;"><b>TOTAL FEE KOLEKTOR</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: right;"><b>${feeKolektorTotal.totalPokok}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: right;"><b>${feeKolektorTotal.totalFee}</b></td>
              <td style="mso-number-format:'\#\,\#\#0'; text-align: right;"><b>${feeKolektorTotal.totalSetoran}</b></td>
              <td></td>
            </tr>
          </tbody>
        </table>
      `;
		}
		const isKecamatanLevel = isSuperAdmin && filterDesa === "all";
		const targetNamaDesa = isSuperAdmin ? selectedDesaObj?.nama_desa || settings.namaDesa || "Desa" : tenant.nama_desa || settings.namaDesa || "Desa";
		const targetNamaKades = isSuperAdmin ? selectedDesaObj?.nama_kades || settings.namaKades : tenant.nama_kades || settings.namaKades;
		const targetNipKades = isSuperAdmin ? selectedDesaObj?.nip_kades || settings.nipKades : tenant.nip_kades || settings.nipKades;
		const template = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta charset="utf-8">
        <!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>${tablename}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->
        <style>
          body { font-family: Arial, sans-serif; font-size: 11px; }
          h2, h3, h4 { margin: 4px 0; }
          table { border-collapse: collapse; width: 100%; }
          th { background-color: #059669; color: white; padding: 8px; text-align: center; }
          td { padding: 6px; }
        </style>
      </head>
      <body>
        <h2>PEMERINTAH KABUPATEN ${settings.kabupaten.toUpperCase()}</h2>
        <h3>KECAMATAN ${settings.kecamatan.toUpperCase()} - ${targetDesaText}</h3>
        <h4>${tablename.toUpperCase()}</h4>
        <p><b>Periode:</b> ${selectedBulan} (${selectedMinggu}) ${selectedTahun} | <b>Dusun:</b> ${filterDusun === "ALL" ? "Semua Wilayah" : filterDusun}</p>
        <br/>
        ${tableHtml}
        <br/>
        <table border="0">
          <tr>
            <td colspan="4" align="center">
              Mengetahui,<br/>
              <b>${isKecamatanLevel ? `CAMAT ${settings.kecamatan.toUpperCase()}` : `${settings.jabatanKades || "Kepala Desa"} ${targetNamaDesa}`}</b><br/><br/><br/><br/>
              <u><b>${isKecamatanLevel ? settings.namaKades || `Camat ${settings.kecamatan}` : targetNamaKades || "______________________"}</b></u><br/>
              ${isKecamatanLevel ? settings.nipKades ? `NIP. ${settings.nipKades}` : `Pemerintah Kecamatan ${settings.kecamatan}` : targetNipKades ? `NIP. ${targetNipKades}` : `${settings.jabatanKades || "Kepala Desa"}`}
            </td>
            <td colspan="4" align="center">
              ${isKecamatanLevel ? settings.kecamatan : targetNamaDesa}, ${(/* @__PURE__ */ new Date()).toLocaleDateString("id-ID", {
			day: "numeric",
			month: "long",
			year: "numeric"
		})}<br/>
              <b>${isKecamatanLevel ? "KASI PEMERINTAHAN / TIM PBB KECAMATAN" : settings.jabatanPetugas || "Bendahara / Kolektor Utama PBB"}</b><br/><br/><br/><br/>
              <u><b>${isKecamatanLevel ? settings.namaPetugas || "Tim Pajak Kecamatan" : settings.namaPetugas || "______________________"}</b></u><br/>
              ${isKecamatanLevel ? settings.nipPetugas ? `NIP/NIK. ${settings.nipPetugas}` : `Kecamatan ${settings.kecamatan}` : settings.nipPetugas ? `NIP/NIK. ${settings.nipPetugas}` : `Kolektor PBB`}
            </td>
          </tr>
        </table>
      </body>
      </html>
    `;
		const blob = new Blob([template], { type: "application/vnd.ms-excel;charset=utf-8;" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = `${tablename.replace(/\s+/g, "_")}.xls`;
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
		toast.success(`File Excel (${tablename}.xls) berhasil diunduh!`);
	};
	const handleGeneratePdf = () => {
		try {
			toast.info("Menggenerasi dokumen PDF resmi SIPABAR...");
			const targetNamaKades = isSuperAdmin ? selectedDesaObj?.nama_kades || settings.namaKades : tenant.nama_kades || settings.namaKades;
			const targetNipKades = isSuperAdmin ? selectedDesaObj?.nip_kades || settings.nipKades : tenant.nip_kades || settings.nipKades;
			generatePdfReport({
				activeTab,
				settings,
				selectedTahun,
				selectedBulan,
				selectedMinggu,
				filterDusun,
				showDesaColumn,
				isSuperAdmin,
				filterDesa,
				selectedDesaName: selectedDesaObj?.nama_desa,
				signerInfo: {
					namaKades: targetNamaKades,
					nipKades: targetNipKades
				},
				computed21Rows,
				grandTotal21,
				dhkpRecapGrouped,
				dhkpRecapTotal,
				piutangList,
				piutangSummary,
				feeKolektorList,
				feeKolektorTotal
			});
			toast.success("Dokumen PDF SIPABAR berhasil diunduh!");
		} catch (err) {
			console.error("Gagal menggenerasi PDF via jsPDF:", err);
			toast.error("Gagal menggenerasi PDF. Menggunakan jendela cetak browser...");
			window.print();
		}
	};
	const handleOpenEdit = (index) => {
		const item = rawRows[index];
		setEditingIndex(index);
		setEditForm({ ...item });
		setIsEditModalOpen(true);
	};
	const handleSaveEdit = () => {
		if (editingIndex === null) return;
		const updated = [...rawRows];
		updated[editingIndex] = { ...editForm };
		setRawRows(updated);
		setIsEditModalOpen(false);
		setEditingIndex(null);
	};
	const handleSaveAdd = () => {
		if (!addForm.dusun.trim()) return;
		setRawRows([...rawRows, { ...addForm }]);
		setIsAddModalOpen(false);
		setAddForm({
			dusun: "",
			ketetapanRp: 0,
			jumlahSppt: 0,
			pokokMingguLaluStts: 0,
			pokokMingguLaluRp: 0,
			pokokMingguIniStts: 0,
			pokokMingguIniRp: 0,
			tunggakanMingguLaluStts: 0,
			tunggakanMingguLaluRp: 0,
			tunggakanMingguIniStts: 0,
			tunggakanMingguIniRp: 0
		});
	};
	const handleDeleteDusun = (index) => {
		if (confirm(`Hapus data dusun ${rawRows[index].dusun}?`)) {
			const updated = rawRows.filter((_, i) => i !== index);
			setRawRows(updated);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-[1650px] space-y-6 pb-16 print:p-0 print:m-0 print:max-w-none",
		children: [
			isKolektorRestricted && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "print:hidden p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-300 text-xs font-medium flex items-center gap-3 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-5 shrink-0 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-bold",
					children: "Mode Terbatas (Akses Peran: KOLEKTOR)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] opacity-90",
					children: [
						"Sebagai ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Kolektor Dusun" }),
						", Anda dapat melihat rekapitulasi data. Untuk mengunduh Laporan 21-Kolom Resmi Desa atau mengubah data laporan, diperlukan akun ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Bendahara Desa" }),
						" atau ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Super Admin" }),
						"."
					]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "print:hidden space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-700 via-emerald-600 to-teal-700 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 p-6 sm:p-8 text-white shadow-2xl border border-emerald-500/30 dark:border-slate-800 backdrop-blur-md",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative z-10 flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "inline-flex items-center gap-2 rounded-full bg-white/15 dark:bg-emerald-500/10 border border-white/30 dark:border-emerald-500/30 px-3.5 py-1 text-xs font-bold uppercase tracking-widest text-emerald-50 dark:text-emerald-400 backdrop-blur-md",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileChartColumn, { className: "size-4 text-amber-300" }),
											" Modul Eksekutif Laporan PBB-P2",
											isSuperAdmin && filterDesa === "all" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												variant: "outline",
												className: "ml-1 text-[9px] font-bold bg-amber-500/20 border-amber-400/40 text-amber-200",
												children: "Seluruh Desa"
											}),
											isSuperAdmin && filterDesa !== "all" && selectedDesaObj && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
												variant: "outline",
												className: "ml-1 text-[9px] font-bold bg-emerald-500/20 border-emerald-400/40 text-emerald-200",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3 mr-0.5 inline" }), selectedDesaObj.nama_desa]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "text-2xl font-black tracking-tight text-white sm:text-3xl lg:text-4xl",
										children: pageTitle
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs sm:text-sm text-emerald-50 dark:text-slate-300 max-w-3xl leading-relaxed font-medium",
										children: pageSubtitle
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col items-end gap-3 shrink-0",
								children: [isSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2.5 rounded-xl bg-white/15 dark:bg-slate-900/80 p-2.5 border border-white/20 dark:border-slate-800 backdrop-blur-md shadow-inner",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4 text-emerald-200" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-bold text-white whitespace-nowrap",
											children: "Filter Desa:"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											value: filterDesa,
											onValueChange: setFilterDesa,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
												className: "h-9 w-44 bg-white dark:bg-slate-950 border-emerald-300 dark:border-slate-800 text-xs font-bold text-slate-900 dark:text-slate-100 shadow-sm",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Pilih Desa" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
												className: "bg-white dark:bg-slate-950 border-emerald-200 dark:border-slate-800 text-slate-900 dark:text-slate-100",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
													value: "all",
													className: "font-bold text-emerald-600 dark:text-emerald-400",
													children: "🌐 Seluruh Desa"
												}), desasList.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
													value: String(d.id),
													className: "text-xs font-medium",
													children: ["Desa ", d.nama_desa]
												}, d.id))]
											})]
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											onClick: () => setRawRows([...defaultLaporanRows]),
											variant: "outline",
											className: "border-emerald-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/80 text-slate-800 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-slate-800 font-semibold text-xs h-10 gap-1.5 rounded-2xl shadow-sm",
											title: "Reset Simulasi Data",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-4 text-amber-600 dark:text-amber-400" }), " Reset"]
										}),
										activeTab === "realisasi_21" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											onClick: () => setIsAddModalOpen(true),
											variant: "outline",
											className: "border-emerald-300 dark:border-emerald-500/40 bg-white dark:bg-emerald-500/10 text-emerald-800 dark:text-emerald-300 hover:bg-emerald-50 dark:hover:bg-emerald-500/20 font-semibold text-xs h-10 gap-1.5 rounded-2xl shadow-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Tambah Dusun"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											onClick: handleExportCsvTab,
											variant: "outline",
											className: "border-emerald-300 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-slate-800 font-semibold text-xs h-10 gap-1.5 rounded-2xl shadow-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4 text-emerald-600" }), " CSV"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											onClick: handleExportExcelTab,
											variant: "outline",
											className: "border-emerald-400 dark:border-emerald-500/40 bg-white dark:bg-emerald-500/10 text-emerald-900 dark:text-emerald-300 hover:bg-emerald-50 dark:hover:bg-emerald-500/20 font-bold text-xs h-10 gap-2 rounded-2xl shadow-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, { className: "size-4 text-emerald-600 dark:text-emerald-400" }), " Unduh Excel (.xls)"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											onClick: handleGeneratePdf,
											className: "bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs h-10 gap-2 rounded-2xl shadow-lg",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), " Cetak / Unduh PDF Resmi"]
										})
									]
								})]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 p-1.5 rounded-2xl bg-slate-200/80 dark:bg-slate-900/90 border border-slate-300 dark:border-slate-800 shadow-inner tabs-scroll overflow-x-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setActiveTab("realisasi_21"),
								className: `flex items-center gap-2 px-4 py-2.5 rounded-xl font-extrabold text-xs whitespace-nowrap transition-all shrink-0 ${activeTab === "realisasi_21" ? "bg-emerald-600 text-white shadow-lg scale-[1.02]" : "text-slate-700 dark:text-slate-300 hover:bg-white/60 dark:hover:bg-slate-800/60"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-4 shrink-0" }), " 1. Laporan Setoran Per Dusun"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setActiveTab("rekap_dhkp"),
								className: `flex items-center gap-2 px-4 py-2.5 rounded-xl font-extrabold text-xs whitespace-nowrap transition-all shrink-0 ${activeTab === "rekap_dhkp" ? "bg-emerald-600 text-white shadow-lg scale-[1.02]" : "text-slate-700 dark:text-slate-300 hover:bg-white/60 dark:hover:bg-slate-800/60"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-4 shrink-0" }), " 2. Rekapitulasi DHKP"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setActiveTab("piutang_kendali"),
								className: `flex items-center gap-2 px-4 py-2.5 rounded-xl font-extrabold text-xs whitespace-nowrap transition-all shrink-0 ${activeTab === "piutang_kendali" ? "bg-emerald-600 text-white shadow-lg scale-[1.02]" : "text-slate-700 dark:text-slate-300 hover:bg-white/60 dark:hover:bg-slate-800/60"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "size-4 shrink-0" }),
									" 3. Lembar Kendali Penagihan Piutang (",
									piutangSummary.count,
									")"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setActiveTab("fee_kolektor"),
								className: `flex items-center gap-2 px-4 py-2.5 rounded-xl font-extrabold text-xs whitespace-nowrap transition-all shrink-0 ${activeTab === "fee_kolektor" ? "bg-emerald-600 text-white shadow-lg scale-[1.02]" : "text-slate-700 dark:text-slate-300 hover:bg-white/60 dark:hover:bg-slate-800/60"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, { className: "size-4 shrink-0" }),
									" 4. Fee Kolektor Luar Desa (",
									feeKolektorTotal.totalTrx,
									")"
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "border-emerald-100/80 dark:border-slate-800/80 bg-white/90 dark:bg-slate-900/80 backdrop-blur-md shadow-xl p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-4 md:flex-row md:items-center md:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative flex-1 max-w-md",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-slate-400" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										placeholder: "Cari NOP, Wajib Pajak, Alamat, atau Resi STTS...",
										value: searchQuery,
										onChange: (e) => setSearchQuery(e.target.value),
										className: "w-full rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 pl-10 pr-4 py-2 text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:border-emerald-500 focus:outline-none"
									}),
									searchQuery && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setSearchQuery(""),
										className: "absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2.5 text-xs font-bold",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5 bg-amber-500/10 border border-amber-500/30 px-3 py-1.5 rounded-xl",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3.5 text-amber-600 dark:text-amber-400" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-amber-700 dark:text-amber-400 uppercase",
												children: "Tahun:"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
												value: selectedTahun,
												onChange: (e) => setSelectedTahun(Number(e.target.value)),
												className: "bg-transparent text-amber-900 dark:text-amber-300 font-black focus:outline-none cursor-pointer",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: 2026,
														className: "bg-white dark:bg-slate-900 text-slate-900 dark:text-white",
														children: "2026"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: 2025,
														className: "bg-white dark:bg-slate-900 text-slate-900 dark:text-white",
														children: "2025"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: 2024,
														className: "bg-white dark:bg-slate-900 text-slate-900 dark:text-white",
														children: "2024"
													})
												]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5 bg-emerald-500/10 border border-emerald-500/30 px-3 py-1.5 rounded-xl",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5 text-emerald-600 dark:text-emerald-400" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-emerald-700 dark:text-emerald-400 uppercase",
												children: "Dusun:"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
												value: filterDusun,
												onChange: (e) => setFilterDusun(e.target.value),
												className: "bg-transparent text-emerald-900 dark:text-emerald-300 font-black focus:outline-none cursor-pointer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "ALL",
													className: "bg-white dark:bg-slate-900 text-slate-900 dark:text-white",
													children: isKolektorRestricted && userDusunAkses !== "ALL" ? "SEMUA DUSUN SAYA" : "SEMUA DUSUN"
												}), availableDusuns.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: d,
													className: "bg-white dark:bg-slate-900 text-slate-900 dark:text-white",
													children: d
												}, d))]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5 bg-purple-500/10 border border-purple-500/30 px-3 py-1.5 rounded-xl",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-3.5 text-purple-600 dark:text-purple-400" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-purple-700 dark:text-purple-400 uppercase",
												children: "Domisili:"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
												value: filterDomisili,
												onChange: (e) => setFilterDomisili(e.target.value),
												className: "bg-transparent text-purple-900 dark:text-purple-300 font-black focus:outline-none cursor-pointer",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "ALL",
														className: "bg-white dark:bg-slate-900 text-slate-900 dark:text-white",
														children: "SEMUA"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "DALAM_DESA",
														className: "bg-white dark:bg-slate-900 text-slate-900 dark:text-white",
														children: "DALAM DESA"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "LUAR_DESA",
														className: "bg-white dark:bg-slate-900 text-slate-900 dark:text-white",
														children: "LUAR DESA"
													})
												]
											})
										]
									})
								]
							})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden print:block text-black space-y-2 text-center pb-4 border-b-2 border-black mb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-lg font-bold uppercase tracking-wider",
						children: ["Pemerintah Kabupaten ", settings.kabupaten]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "text-base font-bold uppercase tracking-wide",
						children: [
							"Kecamatan ",
							settings.kecamatan,
							" - ",
							isSuperAdmin ? filterDesa === "all" ? "Seluruh Desa" : `Desa ${selectedDesaObj?.nama_desa || settings.namaDesa}` : `Desa ${settings.namaDesa}`
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-serif italic",
						children: settings.alamatDesa || "Kantor Kepala Desa"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t-2 border-black pt-3 mt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "text-xl font-black uppercase text-black",
							children: [
								activeTab === "realisasi_21" && `LAPORAN PENERIMAAN PBB-P2 PER DUSUN TAHUN ${selectedTahun}`,
								activeTab === "rekap_dhkp" && `REKAPITULASI DHKP & KETETAPAN PBB PER DUSUN TAHUN ${selectedTahun}`,
								activeTab === "piutang_kendali" && `LEMBAR KENDALI PENAGIHAN PIUTANG PBB-P2 TAHUN ${selectedTahun}`,
								activeTab === "fee_kolektor" && `LAPORAN FEE KOLEKTOR PAJAK (WARGA LUAR DESA)`
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-semibold",
							children: [
								"Periode Laporan: ",
								selectedBulan,
								" (",
								selectedMinggu,
								") • Dusun: ",
								filterDusun === "ALL" ? "Semua Wilayah" : filterDusun,
								isSuperAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [" • Desa: ", filterDesa === "all" ? "Seluruh Desa" : selectedDesaObj?.nama_desa || "Terpilih"] })
							]
						})]
					})
				]
			}),
			activeTab === "realisasi_21" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Realisasi21KolomTab, {
				calculatedRows: computed21Rows,
				totalRow: grandTotal21,
				onOpenEdit: handleOpenEdit,
				onDeleteDusun: handleDeleteDusun,
				showDesaColumn
			}),
			activeTab === "rekap_dhkp" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RekapDhkpBlokTab, {
				recapGroupedList: dhkpRecapGrouped,
				dhkpRecapTotal,
				showDesaColumn
			}),
			activeTab === "piutang_kendali" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PiutangKendaliTab, {
				piutangList,
				piutangSummary,
				settings,
				showDesaColumn
			}),
			activeTab === "fee_kolektor" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeeKolektorTab, {
				feeKolektorList,
				feeKolektorTotal,
				showDesaColumn
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden print:grid grid-cols-2 gap-12 text-black pt-12 text-xs font-serif border-t border-black mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center space-y-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Mengetahui," }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-bold",
						children: isSuperAdmin && filterDesa === "all" ? `CAMAT ${settings.kecamatan.toUpperCase()}` : `${settings.jabatanKades || "Kepala Desa"} ${isSuperAdmin ? selectedDesaObj?.nama_desa || settings.namaDesa : tenant?.nama_desa || settings.namaDesa}`
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold underline uppercase text-sm",
							children: isSuperAdmin && filterDesa === "all" ? settings.namaKades || `Camat ${settings.kecamatan}` : (isSuperAdmin ? selectedDesaObj?.nama_kades || settings.namaKades : tenant?.nama_kades || settings.namaKades) || "______________________"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px]",
							children: isSuperAdmin && filterDesa === "all" ? settings.nipKades ? `NIP. ${settings.nipKades}` : `Pemerintah Kecamatan ${settings.kecamatan}` : (isSuperAdmin ? selectedDesaObj?.nip_kades || settings.nipKades : tenant?.nip_kades || settings.nipKades) ? `NIP. ${isSuperAdmin ? selectedDesaObj?.nip_kades || settings.nipKades : tenant?.nip_kades || settings.nipKades}` : `${settings.jabatanKades || "Kepala Desa"} ${isSuperAdmin ? selectedDesaObj?.nama_desa || settings.namaDesa : tenant?.nama_desa || settings.namaDesa}`
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center space-y-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						isSuperAdmin && filterDesa === "all" ? settings.kecamatan : isSuperAdmin ? selectedDesaObj?.nama_desa || settings.namaDesa : tenant?.nama_desa || settings.namaDesa || "Desa",
						", ",
						(/* @__PURE__ */ new Date()).toLocaleDateString("id-ID", {
							day: "numeric",
							month: "long",
							year: "numeric"
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-bold",
						children: isSuperAdmin && filterDesa === "all" ? "KASI PEMERINTAHAN / TIM PBB KECAMATAN" : settings.jabatanPetugas || "Bendahara / Kolektor Utama PBB-P2"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold underline uppercase text-sm",
							children: isSuperAdmin && filterDesa === "all" ? settings.namaPetugas || "Tim Pajak Kecamatan" : settings.namaPetugas || "______________________"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px]",
							children: isSuperAdmin && filterDesa === "all" ? settings.nipPetugas ? `NIP/NIK. ${settings.nipPetugas}` : `Kecamatan ${settings.kecamatan}` : settings.nipPetugas ? `NIP/NIK. ${settings.nipPetugas}` : `Kolektor PBB`
						})]
					})]
				})]
			}),
			isEditModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 dark:bg-slate-950/80 p-4 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-2xl rounded-2xl border border-emerald-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between border-b border-emerald-100 dark:border-slate-800 pb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquarePen, { className: "size-5 text-emerald-600 dark:text-emerald-400" }),
									" Edit Data Penerimaan Dusun: ",
									editForm.dusun
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "ghost",
								onClick: () => setIsEditModalOpen(false),
								className: "size-8 rounded-lg text-slate-500",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-4 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-slate-700 dark:text-slate-400 font-medium mb-1",
									children: "Nama Dusun"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									value: editForm.dusun,
									onChange: (e) => setEditForm({
										...editForm,
										dusun: e.target.value
									}),
									className: "w-full rounded-xl bg-white dark:bg-slate-950 border border-emerald-200 dark:border-slate-800 px-3 py-2 text-slate-900 dark:text-white font-semibold focus:border-emerald-500 focus:outline-none"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-slate-700 dark:text-slate-400 font-medium mb-1",
									children: "Ketetapan Target (Rp)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									value: editForm.ketetapanRp,
									onChange: (e) => setEditForm({
										...editForm,
										ketetapanRp: Number(e.target.value)
									}),
									className: "w-full rounded-xl bg-white dark:bg-slate-950 border border-emerald-200 dark:border-slate-800 px-3 py-2 text-slate-900 dark:text-white font-mono focus:border-emerald-500 focus:outline-none"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-slate-700 dark:text-slate-400 font-medium mb-1",
									children: "Jumlah SPPT (Lembar)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									value: editForm.jumlahSppt,
									onChange: (e) => setEditForm({
										...editForm,
										jumlahSppt: Number(e.target.value)
									}),
									className: "w-full rounded-xl bg-white dark:bg-slate-950 border border-emerald-200 dark:border-slate-800 px-3 py-2 text-slate-900 dark:text-white font-mono focus:border-emerald-500 focus:outline-none"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "col-span-2 border-t border-emerald-100 dark:border-slate-800 pt-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-bold text-emerald-700 dark:text-emerald-400 mb-2 uppercase",
										children: "1. Penerimaan Pokok PBB"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "block text-slate-700 dark:text-slate-400",
												children: "Minggu Lalu (STTS)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "number",
												value: editForm.pokokMingguLaluStts,
												onChange: (e) => setEditForm({
													...editForm,
													pokokMingguLaluStts: Number(e.target.value)
												}),
												className: "w-full rounded-xl bg-white dark:bg-slate-950 border border-emerald-200 dark:border-slate-800 px-3 py-2 text-slate-900 dark:text-white font-mono"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "block text-slate-700 dark:text-slate-400",
												children: "Minggu Lalu (Rp)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "number",
												value: editForm.pokokMingguLaluRp,
												onChange: (e) => setEditForm({
													...editForm,
													pokokMingguLaluRp: Number(e.target.value)
												}),
												className: "w-full rounded-xl bg-white dark:bg-slate-950 border border-emerald-200 dark:border-slate-800 px-3 py-2 text-slate-900 dark:text-white font-mono"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "block text-slate-700 dark:text-slate-400",
												children: "Minggu Ini (STTS)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "number",
												value: editForm.pokokMingguIniStts,
												onChange: (e) => setEditForm({
													...editForm,
													pokokMingguIniStts: Number(e.target.value)
												}),
												className: "w-full rounded-xl bg-white dark:bg-slate-950 border border-emerald-200 dark:border-slate-800 px-3 py-2 text-slate-900 dark:text-white font-mono"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "block text-slate-700 dark:text-slate-400",
												children: "Minggu Ini (Rp)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "number",
												value: editForm.pokokMingguIniRp,
												onChange: (e) => setEditForm({
													...editForm,
													pokokMingguIniRp: Number(e.target.value)
												}),
												className: "w-full rounded-xl bg-white dark:bg-slate-950 border border-emerald-200 dark:border-slate-800 px-3 py-2 text-slate-900 dark:text-white font-mono"
											})] })
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "col-span-2 border-t border-emerald-100 dark:border-slate-800 pt-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-bold text-amber-700 dark:text-amber-400 mb-2 uppercase",
										children: "2. Penerimaan Tunggakan PBB"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "block text-slate-700 dark:text-slate-400",
												children: "Minggu Lalu (STTS)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "number",
												value: editForm.tunggakanMingguLaluStts,
												onChange: (e) => setEditForm({
													...editForm,
													tunggakanMingguLaluStts: Number(e.target.value)
												}),
												className: "w-full rounded-xl bg-white dark:bg-slate-950 border border-emerald-200 dark:border-slate-800 px-3 py-2 text-slate-900 dark:text-white font-mono"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "block text-slate-700 dark:text-slate-400",
												children: "Minggu Lalu (Rp)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "number",
												value: editForm.tunggakanMingguLaluRp,
												onChange: (e) => setEditForm({
													...editForm,
													tunggakanMingguLaluRp: Number(e.target.value)
												}),
												className: "w-full rounded-xl bg-white dark:bg-slate-950 border border-emerald-200 dark:border-slate-800 px-3 py-2 text-slate-900 dark:text-white font-mono"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "block text-slate-700 dark:text-slate-400",
												children: "Minggu Ini (STTS)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "number",
												value: editForm.tunggakanMingguIniStts,
												onChange: (e) => setEditForm({
													...editForm,
													tunggakanMingguIniStts: Number(e.target.value)
												}),
												className: "w-full rounded-xl bg-white dark:bg-slate-950 border border-emerald-200 dark:border-slate-800 px-3 py-2 text-slate-900 dark:text-white font-mono"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "block text-slate-700 dark:text-slate-400",
												children: "Minggu Ini (Rp)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "number",
												value: editForm.tunggakanMingguIniRp,
												onChange: (e) => setEditForm({
													...editForm,
													tunggakanMingguIniRp: Number(e.target.value)
												}),
												className: "w-full rounded-xl bg-white dark:bg-slate-950 border border-emerald-200 dark:border-slate-800 px-3 py-2 text-slate-900 dark:text-white font-mono"
											})] })
										]
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-end gap-2 pt-4 border-t border-emerald-100 dark:border-slate-800",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setIsEditModalOpen(false),
								children: "Batal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: handleSaveEdit,
								className: "bg-emerald-600 text-white font-bold",
								children: "Simpan Perubahan"
							})]
						})
					]
				})
			}),
			isAddModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 dark:bg-slate-950/80 p-4 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-lg rounded-2xl border border-emerald-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-2xl space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between border-b border-emerald-100 dark:border-slate-800 pb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5 text-emerald-600 dark:text-emerald-400" }), " Tambah Wilayah Dusun Baru"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "ghost",
								onClick: () => setIsAddModalOpen(false),
								className: "size-8 rounded-lg text-slate-500",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-slate-700 dark:text-slate-400 font-medium mb-1",
								children: "Nama Dusun / Wilayah"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								placeholder: "Contoh: Dusun V / Dusun 1",
								value: addForm.dusun,
								onChange: (e) => setAddForm({
									...addForm,
									dusun: e.target.value
								}),
								className: "w-full rounded-xl bg-white dark:bg-slate-950 border border-emerald-200 dark:border-slate-800 px-3 py-2 text-slate-900 dark:text-white font-semibold focus:border-emerald-500 focus:outline-none"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-slate-700 dark:text-slate-400 font-medium mb-1",
									children: "Target Ketetapan (Rp)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									value: addForm.ketetapanRp,
									onChange: (e) => setAddForm({
										...addForm,
										ketetapanRp: Number(e.target.value)
									}),
									className: "w-full rounded-xl bg-white dark:bg-slate-950 border border-emerald-200 dark:border-slate-800 px-3 py-2 text-slate-900 dark:text-white font-mono"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-slate-700 dark:text-slate-400 font-medium mb-1",
									children: "Jumlah SPPT"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									value: addForm.jumlahSppt,
									onChange: (e) => setAddForm({
										...addForm,
										jumlahSppt: Number(e.target.value)
									}),
									className: "w-full rounded-xl bg-white dark:bg-slate-950 border border-emerald-200 dark:border-slate-800 px-3 py-2 text-slate-900 dark:text-white font-mono"
								})] })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-end gap-2 pt-4 border-t border-emerald-100 dark:border-slate-800",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setIsAddModalOpen(false),
								children: "Batal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: handleSaveAdd,
								className: "bg-emerald-600 text-white font-bold",
								children: "Tambah Dusun"
							})]
						})
					]
				})
			})
		]
	});
}
//#endregion
export { LaporanPbbP2 as component };
