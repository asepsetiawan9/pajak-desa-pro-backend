//#region node_modules/.nitro/vite/services/ssr/assets/dusunHelper-BcA75wHe.js
/**
* Parses user's `dusun_akses` or `dusunAssigned` string into an array of uppercase dusun names.
* Example: "BALOK, CIDERES" -> ["BALOK", "CIDERES"]
* Example: "ALL" or "SEMUA" or empty -> ["ALL"]
*/
function parseDusunAkses(dusunAkses) {
	if (!dusunAkses || dusunAkses.trim() === "" || dusunAkses.toUpperCase() === "ALL" || dusunAkses.toUpperCase() === "SEMUA") return ["ALL"];
	return dusunAkses.split(",").map((s) => s.trim().toUpperCase()).filter(Boolean);
}
/**
* Checks if a specific dusun is allowed for a user based on their role and assigned dusuns.
*/
function isDusunAllowed(dusunName, userDusunAkses, role) {
	if (role && role !== "KOLEKTOR") return true;
	const allowedList = parseDusunAkses(userDusunAkses);
	if (allowedList.includes("ALL")) return true;
	if (!dusunName) return false;
	const target = dusunName.trim().toUpperCase();
	return allowedList.some((allowed) => allowed === target || target.includes(allowed) || allowed.includes(target));
}
/**
* Returns array of dusun names available to a user for filter options.
*/
function getAllowedDusunOptions(userDusunAkses, role, defaultDusuns = []) {
	if (!role || role !== "KOLEKTOR") return [...defaultDusuns];
	const allowedList = parseDusunAkses(userDusunAkses);
	if (allowedList.includes("ALL")) return [...defaultDusuns];
	return defaultDusuns.filter((dusun) => allowedList.some((a) => a === dusun.toUpperCase() || dusun.toUpperCase().includes(a) || a.includes(dusun.toUpperCase())));
}
/**
* Formats assigned dusun list for clean UI badge/text display.
*/
function formatDusunDisplay(dusunAkses) {
	const list = parseDusunAkses(dusunAkses);
	if (list.includes("ALL")) return "SEMUA DUSUN";
	return list.join(", ");
}
//#endregion
export { getAllowedDusunOptions as n, isDusunAllowed as r, formatDusunDisplay as t };
