import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/authStore-CZRDvP0Z.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
/**
* LENTERA PBB-P2 API Client Service Layer
* Clean abstraction wrapper for HTTP communication with Laravel API Backend.
*/
function getEffectiveBaseUrl() {
	if (typeof window !== "undefined") {
		const host = window.location.hostname;
		const port = window.location.port;
		const protocol = window.location.protocol;
		if (port === "8826") return `${protocol}//${host}:8827/api/v1`;
		if (host && host !== "localhost" && host !== "127.0.0.1") return "/api/v1";
		return "/api/v1";
	} else {
		const nodeEnvUrl = typeof process !== "undefined" ? process.env.INTERNAL_API_URL || process.env.VITE_API_BASE_URL : null;
		if (nodeEnvUrl) return nodeEnvUrl.endsWith("/") ? nodeEnvUrl.slice(0, -1) : nodeEnvUrl;
		return "http://127.0.0.1/api/v1";
	}
	const defaultUrl = "http://127.0.0.1:8000/api/v1";
	return defaultUrl.endsWith("/") ? defaultUrl.slice(0, -1) : defaultUrl;
}
function formatNetworkError(error, endpoint, url) {
	if (error instanceof TypeError && (error.message.includes("Failed to fetch") || error.message.includes("NetworkError"))) {
		const msg = url.includes("127.0.0.1") || url.includes("localhost") ? `Gagal terhubung ke Server Backend (${url}). Jika Anda membuka dari HP/perangkat lain, pastikan VITE_API_BASE_URL mengarah ke IP Server/VPS.` : `Gagal terhubung ke Server Backend (${url}). Periksa koneksi internet/jaringan Wi-Fi Anda atau pastikan server backend sedang aktif.`;
		const err = new Error(msg);
		err.status = 0;
		return err;
	}
	return error;
}
var ApiClient = class {
	getBaseUrl() {
		return getEffectiveBaseUrl();
	}
	getToken() {
		if (typeof window !== "undefined") return localStorage.getItem("lentera_auth_token");
		return null;
	}
	getHeaders(customHeaders = {}) {
		const headers = {
			"Content-Type": "application/json",
			"Accept": "application/json",
			...customHeaders
		};
		const token = this.getToken();
		if (token) headers["Authorization"] = `Bearer ${token}`;
		return headers;
	}
	resolveUrl(endpoint, params) {
		const cleanEndpoint = endpoint.startsWith("/") ? endpoint : `/${endpoint}`;
		const baseUrl = this.getBaseUrl();
		let fullUrlStr = baseUrl.startsWith("http") ? `${baseUrl}${cleanEndpoint}` : `${window.location.origin}${baseUrl}${cleanEndpoint}`;
		if (params) {
			const urlObj = new URL(fullUrlStr);
			Object.keys(params).forEach((key) => {
				if (params[key] !== void 0 && params[key] !== null && params[key] !== "") urlObj.searchParams.append(key, String(params[key]));
			});
			fullUrlStr = urlObj.toString();
		}
		return fullUrlStr;
	}
	checkAuthStatus(response, endpoint) {
		if (response.status === 401 && !endpoint.includes("/auth/login")) {
			console.warn(`[ApiClient] 401 Unauthorized encountered on ${endpoint}. Clearing auth session.`);
			clearAuthSession();
		}
	}
	async get(endpoint, params) {
		const url = this.resolveUrl(endpoint, params);
		try {
			const response = await fetch(url, {
				method: "GET",
				headers: this.getHeaders()
			});
			const responseData = await response.json().catch(() => ({}));
			if (!response.ok) {
				this.checkAuthStatus(response, endpoint);
				const message = responseData.message || (responseData.errors ? Object.values(responseData.errors).flat().join(", ") : `HTTP ${response.status}: ${response.statusText}`);
				const err = new Error(message);
				err.status = response.status;
				err.data = responseData;
				throw err;
			}
			return responseData;
		} catch (error) {
			const formatted = formatNetworkError(error, endpoint, url);
			console.warn(`[ApiClient] GET ${endpoint} failed.`, formatted);
			throw formatted;
		}
	}
	async post(endpoint, body) {
		const url = this.resolveUrl(endpoint);
		try {
			const response = await fetch(url, {
				method: "POST",
				headers: this.getHeaders(),
				body: body ? JSON.stringify(body) : void 0
			});
			const responseData = await response.json().catch(() => ({}));
			if (!response.ok) {
				this.checkAuthStatus(response, endpoint);
				const message = responseData.message || (responseData.errors ? Object.values(responseData.errors).flat().join(", ") : `HTTP ${response.status}: ${response.statusText}`);
				const err = new Error(message);
				err.status = response.status;
				err.data = responseData;
				throw err;
			}
			return responseData;
		} catch (error) {
			const formatted = formatNetworkError(error, endpoint, url);
			console.warn(`[ApiClient] POST ${endpoint} failed.`, formatted);
			throw formatted;
		}
	}
	async put(endpoint, body) {
		const url = this.resolveUrl(endpoint);
		try {
			const response = await fetch(url, {
				method: "PUT",
				headers: this.getHeaders(),
				body: body ? JSON.stringify(body) : void 0
			});
			const responseData = await response.json().catch(() => ({}));
			if (!response.ok) {
				this.checkAuthStatus(response, endpoint);
				const message = responseData.message || (responseData.errors ? Object.values(responseData.errors).flat().join(", ") : `HTTP ${response.status}: ${response.statusText}`);
				const err = new Error(message);
				err.status = response.status;
				err.data = responseData;
				throw err;
			}
			return responseData;
		} catch (error) {
			const formatted = formatNetworkError(error, endpoint, url);
			console.warn(`[ApiClient] PUT ${endpoint} failed.`, formatted);
			throw formatted;
		}
	}
	async patch(endpoint, body) {
		const url = this.resolveUrl(endpoint);
		try {
			const response = await fetch(url, {
				method: "PATCH",
				headers: this.getHeaders(),
				body: body ? JSON.stringify(body) : void 0
			});
			const responseData = await response.json().catch(() => ({}));
			if (!response.ok) {
				this.checkAuthStatus(response, endpoint);
				const message = responseData.message || (responseData.errors ? Object.values(responseData.errors).flat().join(", ") : `HTTP ${response.status}: ${response.statusText}`);
				const err = new Error(message);
				err.status = response.status;
				err.data = responseData;
				throw err;
			}
			return responseData;
		} catch (error) {
			const formatted = formatNetworkError(error, endpoint, url);
			console.warn(`[ApiClient] PATCH ${endpoint} failed.`, formatted);
			throw formatted;
		}
	}
	async delete(endpoint, body) {
		const url = this.resolveUrl(endpoint);
		try {
			const response = await fetch(url, {
				method: "DELETE",
				headers: this.getHeaders(),
				body: body ? JSON.stringify(body) : void 0
			});
			const responseData = await response.json().catch(() => ({}));
			if (!response.ok) {
				this.checkAuthStatus(response, endpoint);
				const message = responseData.message || (responseData.errors ? Object.values(responseData.errors).flat().join(", ") : `HTTP ${response.status}: ${response.statusText}`);
				const err = new Error(message);
				err.status = response.status;
				err.data = responseData;
				throw err;
			}
			return responseData;
		} catch (error) {
			const formatted = formatNetworkError(error, endpoint, url);
			console.warn(`[ApiClient] DELETE ${endpoint} failed.`, formatted);
			throw formatted;
		}
	}
	async downloadBlob(endpoint, filename) {
		const url = this.resolveUrl(endpoint);
		try {
			const response = await fetch(url, {
				method: "GET",
				headers: this.getHeaders()
			});
			if (!response.ok) {
				this.checkAuthStatus(response, endpoint);
				const message = (await response.json().catch(() => ({}))).message || `Gagal mengunduh file (HTTP ${response.status}: ${response.statusText})`;
				const err = new Error(message);
				err.status = response.status;
				throw err;
			}
			const blob = await response.blob();
			const blobUrl = window.URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = blobUrl;
			a.download = filename;
			document.body.appendChild(a);
			a.click();
			a.remove();
			setTimeout(() => window.URL.revokeObjectURL(blobUrl), 1e3);
		} catch (error) {
			const formatted = formatNetworkError(error, endpoint, url);
			console.warn(`[ApiClient] downloadBlob ${endpoint} failed.`, formatted);
			throw formatted;
		}
	}
};
var apiClient = new ApiClient();
var authService = {
	async login(username, password) {
		return apiClient.post("/auth/login", {
			username,
			password
		});
	},
	async me() {
		return apiClient.get("/auth/me");
	},
	async logout() {
		return apiClient.post("/auth/logout");
	}
};
/**
* User & RBAC API Service Layer
* Interfaces frontend with backend Auth and User Management endpoints.
*/
function getAvatarBgForRole(role) {
	switch (role) {
		case "SUPER_ADMIN_SYSTEM": return "from-rose-600 to-red-600";
		case "SUPER_ADMIN": return "from-purple-600 to-indigo-600";
		case "BENDAHARA": return "from-blue-600 to-cyan-600";
		case "KOLEKTOR": return "from-emerald-600 to-teal-600";
		case "KEPALA_DESA": return "from-amber-600 to-yellow-500";
		default: return "from-slate-700 to-slate-900";
	}
}
function mapBackendToUser(raw) {
	const role = raw.role || "KOLEKTOR";
	return {
		id: String(raw.id),
		username: String(raw.username || ""),
		name: String(raw.name || raw.username || ""),
		email: raw.email || void 0,
		phone: raw.phone || void 0,
		nip: raw.nip || void 0,
		role,
		dusunAssigned: raw.dusun_akses || void 0,
		status: raw.status_aktif === false || raw.status === "NONAKTIF" ? "NONAKTIF" : "AKTIF",
		avatarBg: raw.avatarBg || getAvatarBgForRole(role),
		createdAt: raw.created_at || raw.createdAt || (/* @__PURE__ */ new Date()).toISOString(),
		lastLogin: raw.last_login || raw.lastLogin || void 0,
		desa_id: raw.desa_id !== void 0 ? raw.desa_id ? Number(raw.desa_id) : null : void 0,
		desa: raw.desa ? {
			id: Number(raw.desa.id),
			nama_desa: String(raw.desa.nama_desa),
			kode_desa: String(raw.desa.kode_desa),
			subdomain: String(raw.desa.subdomain)
		} : null
	};
}
function mapUserToBackend(user) {
	const payload = {};
	if (user.name !== void 0) payload.name = user.name;
	if (user.username !== void 0) payload.username = user.username;
	if (user.email !== void 0) payload.email = user.email || null;
	if (user.phone !== void 0) payload.phone = user.phone || null;
	if (user.nip !== void 0) payload.nip = user.nip || null;
	if (user.role !== void 0) payload.role = user.role;
	if (user.dusunAssigned !== void 0) payload.dusun_akses = user.dusunAssigned || null;
	if (user.status !== void 0) payload.status_aktif = user.status === "AKTIF";
	if (user.password) payload.password = user.password;
	if (user.desa_id !== void 0) payload.desa_id = user.desa_id;
	return payload;
}
var userService = {
	async getUsers(filters) {
		const params = {};
		if (filters?.desa_id && filters.desa_id !== "ALL") params.desa_id = filters.desa_id;
		const res = await apiClient.get("/users", params);
		const data = Array.isArray(res.data) ? res.data.map(mapBackendToUser) : [];
		return {
			...res,
			data
		};
	},
	async createUser(data) {
		const payload = {
			...mapUserToBackend(data),
			password: data.password || "password123"
		};
		const res = await apiClient.post("/users", payload);
		return {
			...res,
			data: mapBackendToUser(res.data)
		};
	},
	async updateUser(id, data) {
		const payload = mapUserToBackend(data);
		const res = await apiClient.put(`/users/${id}`, payload);
		return {
			...res,
			data: mapBackendToUser(res.data)
		};
	},
	async toggleUserStatus(id) {
		const res = await apiClient.put(`/users/${id}/status`, {});
		return {
			...res,
			data: mapBackendToUser(res.data)
		};
	},
	async resetPassword(id, newPassword = "password123") {
		const res = await apiClient.put(`/users/${id}`, { password: newPassword });
		return {
			...res,
			data: mapBackendToUser(res.data)
		};
	},
	async deleteUser(id) {
		return apiClient.delete(`/users/${id}`);
	}
};
var ROLE_LABELS = {
	SUPER_ADMIN_SYSTEM: {
		label: "Super Admin System",
		description: "Akses pusat seluruh sistem multi-desa, kelola desa master, & seluruh pengguna",
		badgeClass: "bg-rose-500/15 text-rose-600 dark:text-rose-400 border-rose-500/30"
	},
	SUPER_ADMIN: {
		label: "Admin Desa",
		description: "Akses administrator internal desa, kelola akun pengguna & settings desa",
		badgeClass: "bg-purple-500/15 text-purple-600 dark:text-purple-400 border-purple-500/30"
	},
	BENDAHARA: {
		label: "Bendahara Desa",
		description: "Verifikasi setoran, rekapitulasi, pengelompokan 1 KK, & void transaksi",
		badgeClass: "bg-blue-500/15 text-blue-600 dark:text-blue-400 border-blue-500/30"
	},
	KOLEKTOR: {
		label: "Kolektor / Kasir",
		description: "Kasir STTS, bayar Multi-NOP, cetak resi, & lembar kendali penagihan",
		badgeClass: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30"
	},
	KEPALA_DESA: {
		label: "Kepala Desa",
		description: "Read-only monitoring dashboard realisasi & laporan 21-kolom",
		badgeClass: "bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30"
	}
};
var ACTIVE_USER_STORAGE_KEY = "lentera_active_user_id_v1";
function loadActiveUserIdFromStorage() {
	if (typeof window === "undefined") return "1";
	try {
		const saved = localStorage.getItem(ACTIVE_USER_STORAGE_KEY);
		if (saved) return saved;
	} catch (err) {
		console.error("Gagal membaca activeUserId dari localStorage:", err);
	}
	return "1";
}
var globalUsers = [];
var globalActiveUserId = loadActiveUserIdFromStorage();
var globalIsLoading = false;
var userStoreListeners = /* @__PURE__ */ new Set();
function notifyUserListeners() {
	if (typeof window !== "undefined") try {
		localStorage.setItem(ACTIVE_USER_STORAGE_KEY, globalActiveUserId);
	} catch (err) {
		console.error("Gagal menyimpan activeUserId ke localStorage:", err);
	}
	userStoreListeners.forEach((fn) => fn());
}
async function refreshUsersFromApi(filters) {
	globalIsLoading = true;
	notifyUserListeners();
	try {
		const res = await userService.getUsers(filters);
		if (res.data && Array.isArray(res.data)) {
			globalUsers = res.data;
			if (!globalUsers.some((u) => u.id === globalActiveUserId) && globalUsers.length > 0) globalActiveUserId = globalUsers[0].id;
		}
	} catch (err) {
		console.error("[userStore] Gagal mengambil data pengguna dari API Laravel Backend:", err);
	} finally {
		globalIsLoading = false;
		notifyUserListeners();
	}
	return globalUsers;
}
async function addUserAsync(user) {
	globalIsLoading = true;
	notifyUserListeners();
	try {
		const res = await userService.createUser(user);
		if (res.data) {
			await refreshUsersFromApi();
			return res.data;
		}
		throw new Error(res.message || "Gagal menambah pengguna");
	} finally {
		globalIsLoading = false;
		notifyUserListeners();
	}
}
async function updateUserAsync(id, updated) {
	globalIsLoading = true;
	notifyUserListeners();
	try {
		const res = await userService.updateUser(id, updated);
		if (res.data) {
			await refreshUsersFromApi();
			return res.data;
		}
		throw new Error(res.message || "Gagal meng-update pengguna");
	} finally {
		globalIsLoading = false;
		notifyUserListeners();
	}
}
async function toggleUserStatusAsync(id) {
	globalIsLoading = true;
	notifyUserListeners();
	try {
		const res = await userService.toggleUserStatus(id);
		if (res.data) {
			await refreshUsersFromApi();
			return res.data;
		}
		throw new Error(res.message || "Gagal mengubah status pengguna");
	} finally {
		globalIsLoading = false;
		notifyUserListeners();
	}
}
async function resetPasswordAsync(id, newPassword = "password123") {
	globalIsLoading = true;
	notifyUserListeners();
	try {
		const res = await userService.resetPassword(id, newPassword);
		if (res.data) {
			await refreshUsersFromApi();
			return res.data;
		}
		throw new Error(res.message || "Gagal reset password pengguna");
	} finally {
		globalIsLoading = false;
		notifyUserListeners();
	}
}
async function deleteUserAsync(id) {
	globalIsLoading = true;
	notifyUserListeners();
	try {
		await userService.deleteUser(id);
		await refreshUsersFromApi();
		return true;
	} catch (err) {
		console.error(`Gagal menghapus pengguna ID #${id}:`, err);
		throw err;
	} finally {
		globalIsLoading = false;
		notifyUserListeners();
	}
}
function addUser(user) {
	addUserAsync(user).catch((err) => console.error("Error adding user:", err));
}
function updateUser(id, updated) {
	updateUserAsync(id, updated).catch((err) => console.error(`Error updating user #${id}:`, err));
}
function deleteUser(id) {
	deleteUserAsync(id).catch((err) => console.error(`Error deleting user #${id}:`, err));
}
function toggleUserStatus(id) {
	toggleUserStatusAsync(id).catch((err) => console.error(`Error toggling status user #${id}:`, err));
}
function setActiveUser(id) {
	globalActiveUserId = id;
	notifyUserListeners();
}
function getActiveUser() {
	return globalUsers.find((u) => u.id === globalActiveUserId) || globalUsers[0] || {
		id: "1",
		username: "admin.desa",
		name: "Asep Setiawan, S.Kom",
		nip: "19880512 201201 1 004",
		email: "admin@desa.id",
		phone: "081234567890",
		role: "SUPER_ADMIN",
		status: "AKTIF",
		avatarBg: "from-purple-600 to-indigo-600",
		createdAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
function useUserStore() {
	const [users, setUsers] = (0, import_react.useState)(globalUsers);
	const [activeUserId, setActiveUserIdState] = (0, import_react.useState)(globalActiveUserId);
	const [isLoading, setIsLoading] = (0, import_react.useState)(globalIsLoading);
	(0, import_react.useEffect)(() => {
		refreshUsersFromApi();
		const handleChange = () => {
			setUsers([...globalUsers]);
			setActiveUserIdState(globalActiveUserId);
			setIsLoading(globalIsLoading);
		};
		userStoreListeners.add(handleChange);
		return () => {
			userStoreListeners.delete(handleChange);
		};
	}, []);
	const activeUser = globalUsers.find((u) => u.id === activeUserId) || globalUsers[0] || getActiveUser();
	return {
		users,
		activeUserId,
		activeUser,
		isLoading,
		refreshFromApi: refreshUsersFromApi,
		addUser,
		addUserAsync,
		updateUser,
		updateUserAsync,
		deleteUser,
		deleteUserAsync,
		toggleUserStatus,
		toggleUserStatusAsync,
		resetPasswordAsync,
		setActiveUser,
		getActiveUser: () => activeUser
	};
}
var DEFAULT_DESA = {
	id: 0,
	kode_desa: "",
	nama_desa: "Desa",
	nama_kecamatan: "Malangbong",
	nama_kabupaten: "Garut",
	nama_provinsi: "Jawa Barat",
	nama_kades: "",
	nip_kades: "",
	subdomain: "",
	logo_path: "/logo2.png"
};
var currentTenant = DEFAULT_DESA;
var tenantListeners = /* @__PURE__ */ new Set();
function setTenantInfo(desa) {
	if (desa && desa.nama_desa) currentTenant = { ...desa };
	else currentTenant = DEFAULT_DESA;
	tenantListeners.forEach((fn) => fn());
}
function useTenantStore() {
	const [tenant, setTenant] = (0, import_react.useState)(currentTenant);
	(0, import_react.useEffect)(() => {
		const handleChange = () => {
			setTenant({ ...currentTenant });
		};
		tenantListeners.add(handleChange);
		return () => {
			tenantListeners.delete(handleChange);
		};
	}, []);
	return tenant;
}
var TOKEN_KEY = "lentera_auth_token";
var USER_KEY = "lentera_auth_user";
function getInitialAuthState() {
	if (typeof window === "undefined") return {
		user: null,
		token: null,
		isAuthenticated: false,
		isLoading: false
	};
	const token = localStorage.getItem(TOKEN_KEY);
	const savedUser = localStorage.getItem(USER_KEY);
	if (token && savedUser) try {
		const user = JSON.parse(savedUser);
		if (user?.id) {
			setActiveUser(String(user.id));
			if (user.desa) setTenantInfo(user.desa);
		}
		return {
			user,
			token,
			isAuthenticated: true,
			isLoading: false
		};
	} catch (e) {
		console.error("[authStore] Failed parsing saved user:", e);
	}
	return {
		user: null,
		token: null,
		isAuthenticated: false,
		isLoading: false
	};
}
var globalAuthState = getInitialAuthState();
var activeInitPromise = null;
var initialValidationDone = false;
var authListeners = /* @__PURE__ */ new Set();
function notifyAuthListeners() {
	if (typeof window !== "undefined") try {
		if (globalAuthState.token) localStorage.setItem(TOKEN_KEY, globalAuthState.token);
		else localStorage.removeItem(TOKEN_KEY);
		if (globalAuthState.user) localStorage.setItem(USER_KEY, JSON.stringify(globalAuthState.user));
		else localStorage.removeItem(USER_KEY);
	} catch (err) {
		console.error("[authStore] Failed writing to localStorage:", err);
	}
	authListeners.forEach((fn) => fn());
}
async function initializeAuth() {
	if (activeInitPromise) return activeInitPromise;
	const token = typeof window !== "undefined" ? localStorage.getItem(TOKEN_KEY) : globalAuthState.token;
	if (!token) {
		globalAuthState = {
			user: null,
			token: null,
			isAuthenticated: false,
			isLoading: false
		};
		notifyAuthListeners();
		return globalAuthState;
	}
	activeInitPromise = (async () => {
		try {
			const res = await authService.me();
			if (res && res.data) {
				const authUser = {
					...res.data,
					id: String(res.data.id)
				};
				globalAuthState = {
					user: authUser,
					token,
					isAuthenticated: true,
					isLoading: false
				};
				setActiveUser(String(authUser.id));
				if (authUser.desa) setTenantInfo(authUser.desa);
			}
		} catch (err) {
			if (err?.status === 401 || typeof err?.message === "string" && (err.message.includes("401") || err.message.includes("Unauthenticated"))) {
				console.warn("[authStore] Token invalid or expired (401), clearing session:", err);
				globalAuthState = {
					user: null,
					token: null,
					isAuthenticated: false,
					isLoading: false
				};
				setTenantInfo(null);
			} else {
				console.warn("[authStore] Background session revalidation failed, keeping existing local session:", err);
				globalAuthState = {
					...globalAuthState,
					isLoading: false
				};
			}
		} finally {
			globalAuthState.isLoading = false;
			notifyAuthListeners();
		}
		return globalAuthState;
	})().finally(() => {
		activeInitPromise = null;
	});
	return activeInitPromise;
}
async function loginUser(username, password) {
	globalAuthState.isLoading = true;
	notifyAuthListeners();
	try {
		const res = await authService.login(username, password);
		if (res.success && res.data) {
			const { access_token, user } = res.data;
			const authUser = {
				...user,
				id: String(user.id)
			};
			globalAuthState = {
				user: authUser,
				token: access_token,
				isAuthenticated: true,
				isLoading: false
			};
			initialValidationDone = true;
			setActiveUser(String(authUser.id));
			if (authUser.desa) setTenantInfo(authUser.desa);
			notifyAuthListeners();
			return authUser;
		}
		throw new Error(res.message || "Gagal melakukan login");
	} catch (err) {
		globalAuthState.isLoading = false;
		notifyAuthListeners();
		throw err;
	}
}
function clearAuthSession() {
	initialValidationDone = false;
	globalAuthState = {
		user: null,
		token: null,
		isAuthenticated: false,
		isLoading: false
	};
	setTenantInfo(null);
	notifyAuthListeners();
}
async function logoutUser() {
	globalAuthState.isLoading = true;
	notifyAuthListeners();
	try {
		await authService.logout();
	} catch (err) {
		console.warn("[authStore] Server logout notice failed:", err);
	} finally {
		clearAuthSession();
	}
}
function useAuthStore() {
	const [state, setState] = (0, import_react.useState)(globalAuthState);
	(0, import_react.useEffect)(() => {
		const handleChange = () => {
			setState({ ...globalAuthState });
		};
		authListeners.add(handleChange);
		if (globalAuthState.token && !initialValidationDone) {
			initialValidationDone = true;
			initializeAuth();
		}
		return () => {
			authListeners.delete(handleChange);
		};
	}, []);
	return {
		user: state.user,
		token: state.token,
		isAuthenticated: state.isAuthenticated,
		isLoading: state.isLoading,
		login: loginUser,
		logout: logoutUser,
		initializeAuth,
		hasRole: (roles) => {
			if (!state.user) return false;
			return (Array.isArray(roles) ? roles : [roles]).includes(state.user.role);
		}
	};
}
//#endregion
export { useTenantStore as a, useAuthStore as i, apiClient as n, useUserStore as o, cn as r, userService as s, ROLE_LABELS as t };
